/*==============================================================*/
/*=                                                            =*/
/*=   Application: Instant Savings Maintenance                 =*/
/*=   Module     : SSEISVELGG - Save Eligibility for a Group   =*/
/*=   Author     : Greg Pyle                                   =*/
/*=   Language   : SQL                                         =*/
/*=   Project #  : 9159                                        =*/
/*=   Version    : 1.0                                         =*/
/*=   Date       : Jul 31, 2017                                =*/
/*=   Description: Save IS Eligibility for a group (WEBAPP)    =*/
/*=                - state:  0=not eligible (unchecked)        =*/
/*=                          1=eligible (checked)              =*/
/*=   Updated By    : -                                        =*/
/*=   Last Updated  : -                                        =*/
/*==============================================================*/
--call webdev/SSEISVELGG(10004160,1)

CREATE OR REPLACE PROCEDURE SSEISVELGG(   
   in @vendor decimal(6),
   in @dept decimal(3),   
   in @sdept decimal(3),
   in @class decimal(3),
   in @eligState Char(1),
   in @user Varchar(100),
   out @messageCd Decimal(3),
   out @messageType Char(1)
)
Language SQL
Specific SSEISVELGG
Program Type Sub
Set Option Commit=*CHG, 
           DATFMT=*ISO, 
		   TIMFMT=*ISO, 
		   DFTRDBCOL=*NONE,
  		   DYNUSRPRF=*OWNER,
  		   DBGVIEW=*SOURCE
Begin     
   Declare SQLCODE int default 0;
   Declare SQLSTATE char(5);    
   Declare @vSqlCode int default 0;
   Declare @vSqlState char(5);
   Declare @step Char(3) default '0';
   
   --Declare Exit handlers
   Declare Exit Handler For SQLEXCEPTION
   Begin
     Set @vSqlCode = SQLCODE;
     Set @vSqlState = SQLSTATE;     
     Rollback;
     Insert into BBPSPDEBUG (step) Values (
       'SSM - SSEISVELGG SQLEXCEPTION EXIT HANDLER SQLSTATE ='
        || @vSqlState|| ' SQLCODE = ' 
        || Char(@vSqlCode) || ' step '|| @step);
        Set @messageCd = 200;
        Set @messageType = '3';
        Commit;        
     Resignal;  
   End;
   
   -- Enter Header information in CCPFPF and CCPSPF 
   -- if the planning sheet number
   -- does not exists in the database.
   Set @step = '1';    
  
   IF(@eligState ='1') THEN
       Set @step = '2';   
	   IF NOT EXISTS(
		  SELECT 1 FROM SSSINSAV 
		  WHERE ISASNUM=@vendor 
		  AND ISDEPT=@dept 
		  AND ISSDEPT=@sdept 
		  AND ISCLAS=@class
		  AND ISINUMBR=0
	   )
	   THEN     
	     Set @step = '3';
	     --ISINUMBR. ISEVT, ISMA does not allow nulls so write 0   
	     INSERT INTO SSSINSAV (ISINUMBR, ISASNUM, ISDEPT, ISSDEPT, ISCLAS,
	     ISEVT, ISMA, CREATEUSER, CREATEPGM, CREATETIME,
	     CHANGEUSER, CHANGEPGM)
	     VALUES(0, @vendor, @dept, @sdept, @class, 
	     0, '', @user, 'SSEISVELGG', CURRENT_TIMESTAMP,
	     @user, 'SSEISVELGG');
	   END IF;
   ELSE
       Set @step = '4';   
       DELETE FROM SSSINSAV 
	   WHERE ISASNUM=@vendor 
	   AND ISDEPT=@dept 
	   AND ISSDEPT=@sdept 
	   AND ISCLAS=@class
	   AND ISINUMBR=0;
   END IF;

   Commit;
    
End