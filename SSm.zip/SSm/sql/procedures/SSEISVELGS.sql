/*==============================================================*/
/*=                                                            =*/
/*=   Application: Instant Savings Maintenance                 =*/
/*=   Module     : SSEISVELGS - Save Eligibility for SKU List  =*/
/*=   Author     : Greg Pyle                                   =*/
/*=   Language   : SQL                                         =*/
/*=   Project #  : 9159                                        =*/
/*=   Version    : 1.0                                         =*/
/*=   Date       : Jul 31, 2017                                =*/
/*=   Description: Save IS Eligibility for SKU List (WEBAPP)   =*/
/*=                - Limit SKU list to 2000 comma spearated    =*/
/*=                     without spaces                         =*/
/*=                - states: comma spearated without spaces    =*/
/*=                          0=not eligible (unchecked)        =*/
/*=                          1=eligible (checked)              =*/
/*=   Updated By    : -                                        =*/
/*=   Last Updated  : -                                        =*/
/*==============================================================*/

CREATE OR REPLACE PROCEDURE SSEISVELGS(   
   in @skus Varchar(32000),
   in @eligStates Varchar(20000),
   in @vendors Varchar(32000),
   in @depts Varchar(32000),
   in @sdepts Varchar(32000),
   in @classes Varchar(32000),
   in @events Varchar(32000),
   in @merchanals Varchar(32000),
   in @ids Varchar(32000),
   in @user Varchar(100),
   out @messageCd Decimal(3),
   out @messageType Char(1)
)
Language SQL
Specific SSEISVELGS
Program Type Sub
Set Option Commit=*CHG, 
   		   DATFMT=*ISO, 
		   TIMFMT=*ISO, 
		   DFTRDBCOL=*NONE,
  		   DYNUSRPRF=*OWNER,
  		   DBGVIEW=*SOURCE
Begin     
   Declare SQLCODE int default 0;
   Declare SQLSTATE char(5);    
   Declare @vSqlCode int default 0;
   Declare @vSqlState char(5);
   Declare @step Char(3) default '0';
   Declare @isParseComplete Char(1);
   Declare @separator Char(1);   
   Declare @sku Decimal(9);
   Declare @eligState Char(1);
   Declare @vendor Decimal(6);
   Declare @dept Decimal(3);
   Declare @sdept Decimal(3);
   Declare @class Decimal(3);
   Declare @event Decimal(6);
   Declare @merchanal Char(5);
   Declare @isid Decimal(15);
   
   --Declare Exit handlers
   Declare Exit Handler For SQLEXCEPTION
   Begin
     Set @vSqlCode = SQLCODE;
     Set @vSqlState = SQLSTATE;     
     Rollback;
     Insert into BBPSPDEBUG (step) Values (
       'SSM - SSEISVELGS SQLEXCEPTION EXIT HANDLER SQLSTATE ='
        || @vSqlState|| ' SQLCODE = ' 
        || Char(@vSqlCode) || ' step '|| @step);
        Set @messageCd = 200;
        Set @messageType = '3';
        Commit;        
     Resignal;  
   End;
   
   Set @step = '1';
   Set @isParseComplete = 'N';
   Set @separator = ',';
   While @isParseComplete = 'N' and @eligStates <> '' DO     
     
     Set @step = '2';   
     Call SSESPLIT(@eligStates, @separator, @eligState);
     Call SSESPLIT(@skus, @separator, @sku);
     Call SSESPLIT(@vendors, @separator, @vendor);
     Call SSESPLIT(@depts, @separator, @dept);
     Call SSESPLIT(@sdepts, @separator, @sdept);
     Call SSESPLIT(@classes, @separator, @class);
     Call SSESPLIT(@events, @separator, @event);
     Call SSESPLITC(@merchanals, @separator, @merchanal);
     Call SSESPLIT(@ids, @separator, @isid);

	 IF(@eligState =1) THEN
	       Set @step = '3';   
		   IF NOT EXISTS(
			  SELECT 1 FROM SSSINSAV 
			  WHERE ISINUMBR=@sku
				AND ISASNUM=@vendor
				AND ISDEPT=@dept
				AND ISSDEPT=@sdept
				AND ISCLAS=@class
				AND ISEVT=@event
				AND ISMA=@merchanal
		   )
		   THEN     
		     Set @step = '4';   
		     INSERT INTO SSSINSAV (
		     ISASNUM,ISDEPT,ISSDEPT,ISCLAS,
		     ISINUMBR, ISEVT, ISMA,
		     CREATEUSER, CREATEPGM, CREATETIME,
	         CHANGEUSER, CHANGEPGM)
		     VALUES(@vendor, @dept, @sdept, @class,
		     @sku, @event, @merchanal, 
		     @user, 'SSEISVELGS', CURRENT_TIMESTAMP,
		     @user, 'SSEISVELGG');
		   END IF;
	 ELSE
	       Set @step = '5';   
	       DELETE FROM SSSINSAV WHERE ISID=@isid;
	 END IF;
     
     Set @step = '8';     
     If(@eligStates = '' or @eligState is null) Then
        Set @step = '98';
        Set @isParseComplete = 'Y';
     End If;         
      
   End While;
   
   Set @step = '99';
   Commit;
    
End