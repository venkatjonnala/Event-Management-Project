/*==============================================================*/
/*=                                                            =*/
/*=   Application: Instant Savings Maintenance                 =*/
/*=   Module     : SSEISSRCH - Save Eligibility SKU Search     =*/
/*=   Author     : Greg Pyle                                   =*/
/*=   Language   : SQL                                         =*/
/*=   Project #  : 9159                                        =*/
/*=   Version    : 1.0                                         =*/
/*=   Date       : Aug 28, 2017                                =*/
/*=   Description: Search SKUs by Event Number (WEBAPP)        =*/
/*=   Updated By    : -                                        =*/
/*=   Last Updated  : -                                        =*/
/*==============================================================*/

CREATE OR REPLACE PROCEDURE SSEISSRCH(   
   in @eventNum Varchar(100)
)
Language SQL
Result Sets 1
Specific SSEISSRCH
Program Type Sub
Set Option Commit=*NONE, 
   		   DATFMT=*ISO, 
		   TIMFMT=*ISO, 
		   DFTRDBCOL=*NONE,
  		   DYNUSRPRF=*OWNER,
  		   DBGVIEW=*SOURCE
Begin     
   Declare SQLCODE int default 0;
   Declare SQLSTATE char(5);    
   Declare @vSqlCode int default 0;
   Declare @vSqlState char(5);
   Declare @step Char(3) default '0';
   Declare @skudetailsQuery Varchar(32000) ;
   Declare skudetails Cursor For s1; 
   
   --Declare Exit handlers
   Declare Exit Handler For SQLEXCEPTION
   Begin
     Set @vSqlCode = SQLCODE;
     Set @vSqlState = SQLSTATE;     
     Rollback;
     Insert into BBPSPDEBUG (step) Values (
       'SSM - SSEISSRCH SQLEXCEPTION EXIT HANDLER SQLSTATE ='
        || @vSqlState|| ' SQLCODE = ' 
        || Char(@vSqlCode) || ' step '|| @step);
        Commit;        
     Resignal;  
   End;
   
   Set @step = '1';

   Set @skudetailsQuery = 
    'SELECT INUMBR FROM INVEVD WHERE EVENT='||@eventNum;
   
   Set @step = '2';
   Prepare s1 From @skudetailsQuery;  
   Open skudetails;
    
End