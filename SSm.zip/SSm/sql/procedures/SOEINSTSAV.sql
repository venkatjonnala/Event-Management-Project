/*=========================================================*/
/*=                                                       =*/
/*=   Application: Instant Saving                         =*/
/*=   Module     : SOEINSTSAV                             =*/
/*=   Author     : Shalaj Jain                            =*/
/*=   Language   : SQL                                    =*/
/*=   Project #  :                                        =*/
/*=   Version    : 1.0                                    =*/
/*=   Date       : Sept 05, 2017                          =*/
/*=   Description: Instant save specific elasticsearch    =*/
/*=                 lookup load                           =*/
/*=========================================================*/

--call webqa/SOEINSTSAV()

Create or Replace Procedure SOEINSTSAV()
LANGUAGE SQL
RESULT SETS 1 
Program Type Sub
Set Option Commit=*NONE, 
		   DATFMT=*ISO, 
		   TIMFMT=*ISO, 
		   DFTRDBCOL=*NONE,
  		   DYNUSRPRF=*OWNER,
  		   DBGVIEW=*SOURCE
BEGIN 
        Declare SQLCODE int default 0;
        Declare SQLSTATE char(5);    	
        Declare @query1  varchar(20000);
        Declare loadCursor cursor for s1; 

--Declare Exit handlers
    Declare Exit Handler For SQLEXCEPTION
    Begin
     Insert into BBPSPDEBUG (step) Values (
      'SO - SOEINSTSAV SQLEXCEPTION EXIT HANDLER SQLSTATE =' || 
      SQLSTATE|| ' SQLCODE = ' || Char(SQLCODE));
     Resignal;  
    End;


 set @query1 = '
 with TMPINVGPS (sku, ma, ma_category) as 
 (select a.GPSSKU, 
         substr( xmlserialize
             (xmlagg( xmltext( 
             concat( '','', trim(a.GPSGRP) ) ) ) as varchar( 5000 ) ), 2 ) ma,
         substr( xmlserialize
             (xmlagg( xmltext( 
             concat( '','', trim(a.GPSGRP)||'':''||digits(GPSCAT)  ) ) )  
             as varchar( 10000 ) ), 2 )  ma_category
     from  (select distinct GPSSKU, GPSGRP, GPSCAT  
            from INVGPS 
            union 
            select distinct  GPSSKU, GPSGRP, GPSCAT  
            from INVGPO
            ) a  
     group by a.GPSSKU
 ),
 TMPINVEVT (sku, eventno) as 
 (
   select a.inumbr, 
         substr( 
           xmlserialize(
             xmlagg( 
               xmltext( 
                 concat( '','', trim(a.event) )
               )
             ) as varchar(5000) 
           ), 2 
         ) eventno
     from  (
     SELECT distinct a.inumbr, a.event
 	 FROM INVEVD A 
     ) a  
     group by a.inumbr
 ),
TMPINVUPC (sku, upcs) as    
     (select INUMBR, 
         substr( xmlserialize( xmlagg( xmltext( 
         concat( '','', IUPC ) ) ) as varchar( 5000 ) ), 2 ) 
     from  INVUPC 
    group by INUMBR),
 TMPINSAVE   
 (SKU,DEPT,SDEPT,CLAS,VENDORNO,SKUSTATUS,VENDORNM,SKUDESC,SKUWEBDESC)
 as
 (SELECT b.inumbr,b.idept,b.isdept, b.iclas,b.asnum,b.idsccd,
 c.asname,b.idescr,e.asddes
 	FROM INVMST B 
 	left outer join
 	APSUPP C on B.asnum= c.asnum 
 	left outer join
 	JDAPLIBF3/INPASDALL e on b.INUMBR = e.asdsku )
 Select A.SKU,A.DEPT,A.SDEPT as SUBDEPT,A.CLAS as CLASS,A.VENDORNO,
 A.SKUSTATUS,trim(E.EVENTNO) as EVENTNO,trim(A.VENDORNM) as VENDORNM,
 trim(A.SKUDESC) as SKUDESC,trim(A.SKUWEBDESC) as SKUWEBDESC,
 B.MA,trim(C.UPCS) as UPC,
 current_timestamp as CRTDT, '''' as UPDDT
 From TMPINSAVE A
 left outer join TMPINVGPS B on A.SKU = B.SKU
 left outer join TMPINVUPC C on A.SKU = C.SKU
 left outer join TMPINVEVT E on A.SKU = E.SKU
 ';
 
 prepare s1 from @query1;
open loadCursor;
END