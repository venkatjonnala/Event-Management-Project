/*==============================================================*/
/*=                                                            =*/
/*=   Application: Instant Savings Maintenance                 =*/
/*=   Module     : SSEISGTELG - Get Eligibility for List       =*/
/*=   Author     : Greg Pyle                                   =*/
/*=   Language   : SQL                                         =*/
/*=   Project #  : 9159                                        =*/
/*=   Version    : 1.0                                         =*/
/*=   Date       : Jul 31, 2017                                =*/
/*=   Description: Get IS Eligibility for List       (WEBAPP)  =*/
/*=                - Limit list to 2000 SKUs                   =*/
/*=   Updated By    : -                                        =*/
/*=   Last Updated  : -                                        =*/
/*==============================================================*/

CREATE OR REPLACE PROCEDURE SSEISGTELS(   
   in @skus Varchar(32000)
)
Language SQL
Result Sets 1
Specific SSEISGTELS
Program Type Sub
Set Option Commit=*CHG, 
		   DATFMT=*ISO, 
		   TIMFMT=*ISO, 
		   DFTRDBCOL=*NONE,
  		   DYNUSRPRF=*OWNER,
  		   DBGVIEW=*SOURCE
  		   
Begin     
   Declare SQLCODE int default 0;
   Declare SQLSTATE char(5);    
   Declare @vSqlCode int default 0;
   Declare @vSqlState char(5);
   Declare @step Char(3) default '0';
   Declare @skudetailsQuery Varchar(32600) ;
   
   Declare skudetails Cursor For s1; 
   
   --Declare Exit handlers
   Declare Exit Handler For SQLEXCEPTION
   Begin
     Set @vSqlCode = SQLCODE;
     Set @vSqlState = SQLSTATE;     
     --Rollback;
     Insert into BBPSPDEBUG (step) Values (
       'SSM - SSEISGTELS SQLEXCEPTION EXIT HANDLER SQLSTATE ='
        || @vSqlState|| ' SQLCODE = ' 
        || Char(@vSqlCode) || ' step '|| @step);
        --Commit;        
     Resignal;  
   End;

      -- Search a list of SKUs
   Set @step = '1';
      
   Set @skudetailsQuery = '
    Select s.ISINUMBR, 1 as instSavElig,
     s.ISASNUM, s.ISDEPT, s.ISSDEPT, s.ISCLAS, 
     s.ISID, s.ISEVT, s.ISMA, 
     s.CREATEUSER, s.CREATEPGM, s.CREATETIME,
     s.CHANGEUSER, s.CHANGEPGM, s.CHANGETIME
     From SSSINSAV s 
     WHERE s.ISINUMBR IN ('||@skus||')';
   
   Set @step = '2';
   Prepare s1 From @skudetailsQuery;  
   Open skudetails;

End
