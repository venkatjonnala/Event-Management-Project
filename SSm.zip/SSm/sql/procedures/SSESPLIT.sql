/*==============================================================*/
/*=                                                            =*/
/*=   Application: Instant Savings Maintenance                 =*/
/*=   Module     : SSESPLIT - String Parser                    =*/
/*=   Author     : Greg Pyle                                   =*/
/*=   Language   : SQL                                         =*/
/*=   Project #  : 9159                                        =*/
/*=   Version    : 1.0                                         =*/
/*=   Date       : Jul 31, 2017                                =*/
/*=   Description: Take a comma separated list of string       =*/
/*=                and return the first string and remove      =*/
/*=                the values form the passed in string        =*/
/*=   Updated By    : -                                        =*/
/*=   Last Updated  : -                                        =*/
/*==============================================================*/
--Call SSESPLIT('1,2,3', ',' ,'')

CREATE OR REPLACE PROCEDURE SSESPLIT(
	inout @text Varchar(25000), 
    @separator Char(1), 
    out @ntoken Decimal(14)
)
Language SQL
Program Type Sub
Set Option Commit=*NONE, 
	DATFMT=*ISO, 
	TIMFMT=*ISO, 
	DFTRDBCOL=*NONE,
    DYNUSRPRF=*OWNER,
	DBGVIEW=*SOURCE

Begin
    Declare @separatorIndex int;
    Declare @token Varchar(10);

    set @separatorIndex =    Locate(@separator , @text, 1);
    
    if (@separatorIndex = 0) then
      set @separatorIndex = Length(@text) + 1;
    end if;      
    
    set @token = substr(@text, 1, @separatorIndex-1);
    
    set @text = trim(substr(@text, @separatorIndex+1, length(@text))); 
        
    set @ntoken = Decimal(@token);
    
End 
