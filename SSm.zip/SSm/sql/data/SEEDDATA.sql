-- DELETE Role/Privilege Mapping
delete from ASPAPRLPRV where APPID IN
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT');

-- DELETE PRIVILIGES: View, Change
delete from ASPAPPRV where APPID IN
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT');

-- DELETE ROLES: VIEWER, ADMIN
delete from ASPAPROLE where APPID IN
   (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT');

-- DELETE App Properties: 
delete from ASPAPPROP where APPID IN
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT');

-- DELETE: Store access to app.  All stores
DELETE ASPAPSTORE WHERE APPID IN
   (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT');

-- DELETE: App users
DELETE aspapuser WHERE APPID IN
   (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT');

-- DELETE: Application
delete from ASPAPLCATN where APPCODE = 'SIGNMAINT';

--============================================================================
--============================================================================
--============================================================================

insert into ASPAPLCATN (APPID, APPCODE, APPNAME, APPDESC, COUNTRY, CONCEPT, 
EFFECTFROM, CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSAPP, 
'SIGNMAINT', 'SIGN SYSTEM MAINTENANCE', 
'Sign System Maintenance Web App', 
'CAN', 'BEDBATH', curdate(), now(), User, 'Y');

insert into ASPAPLCATN (APPID, APPCODE, APPNAME, APPDESC, COUNTRY, CONCEPT, 
EFFECTFROM, CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSAPP, 
'SIGNMAINT', 'SIGN SYSTEM MAINTENANCE', 
'Sign System Maintenance Web App', 
'MEX', 'BEDBATH', curdate(), now(), User, 'Y');

insert into ASPAPLCATN (APPID, APPCODE, APPNAME, APPDESC, COUNTRY, CONCEPT, 
EFFECTFROM, CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSAPP, 
'SIGNMAINT', 'SIGN SYSTEM MAINTENANCE', 
'Sign System Maintenance Web App', 
'USA', 'BEDBATH', curdate(), now(), User, 'Y');

insert into ASPAPLCATN (APPID, APPCODE, APPNAME, APPDESC, COUNTRY, CONCEPT, 
EFFECTFROM, CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSAPP, 
'SIGNMAINT', 'SIGN SYSTEM MAINTENANCE', 
'Sign System Maintenance Web App', 
'USA', 'CTS', curdate(), now(), User, 'Y');

insert into ASPAPLCATN (APPID, APPCODE, APPNAME, APPDESC, COUNTRY, CONCEPT, 
EFFECTFROM, CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSAPP, 
'SIGNMAINT', 'SIGN SYSTEM MAINTENANCE', 
'Sign System Maintenance Web App', 
'USA', 'HARMON', curdate(), now(), User, 'Y');

-- Store access to app.  Stores 990 and 1
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
   1, '2017-08-01', '2027-12-12', current_timestamp, User);
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
   1, '2017-08-01', '2027-12-12', current_timestamp, User);
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
   1, '2017-08-01', '2027-12-12', current_timestamp, User);
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
   1, '2017-08-01', '2027-12-12', current_timestamp, User);
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
   1, '2017-08-01', '2027-12-12', current_timestamp, User);

INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
   990, '2017-08-01', '2027-12-12', current_timestamp, User);
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
   990, '2017-08-01', '2027-12-12', current_timestamp, User);
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
   990, '2017-08-01', '2027-12-12', current_timestamp, User);
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
   990, '2017-08-01', '2027-12-12', current_timestamp, User);
INSERT INTO ASPAPSTORE (APPID, STORE_ID, EFFECT_FROM, EFFECT_TO, 
   CREATE_TIMESTAMP, CREATE_USERID) 
   VALUES ((select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
   and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
   990, '2017-08-01', '2027-12-12', current_timestamp, User);
   
-- App Properties: 

insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
     nextval for ASSPROP, 'MAINTENANCE_STARTTIME', 'MAINTENANCE STARTTIME', 
     '04:00', now(), User, 'Y');
insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
     nextval for ASSPROP, 'MAINTENANCE_ENDTIME', 'MAINTENANCE ENDTIME', 
     '05:00', now(), User, 'Y');

insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
     nextval for ASSPROP, 'MAINTENANCE_STARTTIME', 'MAINTENANCE STARTTIME', 
     '04:00', now(), User, 'Y');
insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
     nextval for ASSPROP, 'MAINTENANCE_ENDTIME', 'MAINTENANCE ENDTIME', 
     '05:00', now(), User, 'Y');

insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
     nextval for ASSPROP, 'MAINTENANCE_STARTTIME', 'MAINTENANCE STARTTIME', 
     '04:00', now(), User, 'Y');
insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
     nextval for ASSPROP, 'MAINTENANCE_ENDTIME', 'MAINTENANCE ENDTIME', 
     '05:00', now(), User, 'Y');

insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
     nextval for ASSPROP, 'MAINTENANCE_STARTTIME', 'MAINTENANCE STARTTIME', 
     '04:00', now(), User, 'Y');
insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
     nextval for ASSPROP, 'MAINTENANCE_ENDTIME', 'MAINTENANCE ENDTIME', 
     '05:00', now(), User, 'Y');

insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
     nextval for ASSPROP, 'MAINTENANCE_STARTTIME', 'MAINTENANCE STARTTIME', 
     '04:00', now(), User, 'Y');
insert into ASPAPPROP  (APPID, PROPID, PROPNAME, PROPDESC, PROPVALUE, 
   CREATETS, CRUPUSERID, AUDIT) values (
     (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
     and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
     nextval for ASSPROP, 'MAINTENANCE_ENDTIME', 'MAINTENANCE ENDTIME', 
     '05:00', now(), User, 'Y');


--ROLES: VIEWER, ADMIN

insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
  'VIEWER', 'View Only', now(), User, 'Y');
insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
  'ADMIN', 'Full Access', now(), User, 'Y');

insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
  'VIEWER', 'View Only', now(), User, 'Y');
insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
  'ADMIN', 'Full Access', now(), User, 'Y');

insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
  'VIEWER', 'View Only', now(), User, 'Y');
insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
  'ADMIN', 'Full Access', now(), User, 'Y');

insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
  'VIEWER', 'View Only', now(), User, 'Y');
insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
  'ADMIN', 'Full Access', now(), User, 'Y');

insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
  'VIEWER', 'View Only', now(), User, 'Y');
insert into ASPAPROLE (ROLEID, APPID, ROLENAME, ROLEDESC, 
  CREATETS, CRUPUSERID, AUDIT) values(nextval for ASSROLE, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
  'ADMIN', 'Full Access', now(), User, 'Y');

--PRIVILIGES: View, Change

insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
  'View', 'View Eligibility', now(), User, 'Y');
insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
  'Change', 'Change Eligibility', now(), User, 'Y');

insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
  'View', 'View Eligibility', now(), User, 'Y');
insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
  'Change', 'Change Eligibility', now(), User, 'Y');

insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
  'View', 'View Eligibility', now(), User, 'Y');
insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
  'Change', 'Change Eligibility', now(), User, 'Y');

insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
  'View', 'View Eligibility', now(), User, 'Y');
insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
  'Change', 'Change Eligibility', now(), User, 'Y');

insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
  'View', 'View Eligibility', now(), User, 'Y');
insert into ASPAPPRV (PRIVID, APPID, PRIVNAME, PRIVDESC, 
  CRTDTTIME, CRUPUSERID, AUDIT) values(nextval for ASSPRV, 
  (select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
  and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
  'Change', 'Change Eligibility', now(), User, 'Y');

-- Role/Privilege Mapping

-- USA/BEDBATH

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'VIEWER'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'Change'), now(), User);

-- CAN/BEDBATH

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'VIEWER'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'CAN' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'Change'), now(), User);

-- MEX/BEDBATH

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'VIEWER'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'MEX' and CONCEPT = 'BEDBATH') 
and PRIVNAME = 'Change'), now(), User);

-- USA/CTS

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS') 
and ROLENAME = 'VIEWER'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'CTS') 
and PRIVNAME = 'Change'), now(), User);

-- USA/HARMON

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON') 
and ROLENAME = 'VIEWER'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON') 
and PRIVNAME = 'View'), now(), User);

insert into ASPAPRLPRV (APPID, ROLEID, PRIVID,  CREATETS, CRUSERID) values(
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON'), 
(select ROLEID from ASPAPROLE where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON') 
and ROLENAME = 'ADMIN'), 
(select PRIVID from ASPAPPRV where APPID = 
(select APPID from ASPAPLCATN where APPCODE = 'SIGNMAINT' 
and COUNTRY = 'USA' and CONCEPT = 'HARMON') 
and PRIVNAME = 'Change'), now(), User);
