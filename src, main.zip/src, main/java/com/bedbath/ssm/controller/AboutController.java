package com.bedbath.ssm.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.Manifest;

import javax.annotation.PostConstruct;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/about.htm")
public class AboutController {

    private final static Logger LOGGER = LoggerFactory.getLogger(AboutController.class);
    private Map manifestMap;

    /**
     * if this controller implements ServletContextAware, Spring does not map
     * this object as a Controller. This is due to the Proxy Created by the
     * Aspect LogAround.
     */

    private ApplicationContext servletContext;

    @Autowired(required = true)
    public void setServletContext(final ApplicationContext servletContext) {
	this.servletContext = servletContext;
    }

    /**
     * Loads the manifest object from META-INF/MANIFEST.MF
     * 
     * @throws IOException
     * when the input stream read fails
     */

    @PostConstruct
    private void loadManifestInfo() throws IOException {
	final Manifest manifest;
	InputStream fis = null;
	try {
	    fis = servletContext.getResource("/META-INF/MANIFEST.MF").getInputStream();
	    manifest = new Manifest(fis);
	    manifestMap = manifest.getMainAttributes();
	} catch (final FileNotFoundException e) {
	    LOGGER.debug("Manifest file not found:", e);
	} catch (final IOException io) {
	    LOGGER.debug("Error opening manifest:", io);
	} finally {
	    if (fis != null) {
		fis.close();
	    }
	}
    }

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public Map getAboutBoxInfo(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException 
    {
		System.out.println("getAboutBoxInfo ##############################");
    	final Map<String, Object> map = new HashMap<String, Object>(3);
		final Map<String, Object> aboutBoxMap = new HashMap<String, Object>();
		final String hostName = InetAddress.getLocalHost().getHostName();
		final String hostIp = InetAddress.getLocalHost().getHostAddress();
		aboutBoxMap.put("Server-Name", hostName);
		aboutBoxMap.put("Server-IP", hostIp);
		aboutBoxMap.put("Server-Port", request.getServerPort());
		aboutBoxMap.put("Local-Port", request.getLocalPort());
		aboutBoxMap.put("Instance", "SO");// AppUtil.getSystemProperty("adhoc.instance"));
		aboutBoxMap.putAll(manifestMap);
		map.put("results", aboutBoxMap);
		map.put("totalCount", 1);
		map.put("result", "true");
		return map;
    }

}
