package com.bedbath.ssm.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.IntStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;







import com.bedbath.ssm.common.util.AppConstants;
/*
import com.bedbath.so.domain.SearchRequest;
import com.bedbath.so.domain.User;
import com.bedbath.so.domain.Vendor;
import com.bedbath.so.exception.SOException;
import com.bedbath.so.service.SearchService;
import com.bedbath.so.service.SearchServiceAsync;
import com.bedbath.so.util.SOConstants;
import com.bedbath.so.util.ApplicationUtil;
*/
import com.bedbath.ssm.common.util.ApplicationUtil;
import com.bedbath.ssm.common.util.ResponseEntity;
import com.bedbath.ssm.exception.CommonDataAccessException;
import com.bedbath.ssm.exception.SSMException;
import com.bedbath.ssm.model.EligibilityDetails;
import com.bedbath.ssm.model.SearchDetails;
import com.bedbath.ssm.model.SearchRequest;
import com.bedbath.ssm.service.SearchService;
import com.bedbath.ssm.service.SearchServiceAsync;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import static java.lang.Math.toIntExact;

@Controller
@RequestMapping(value = "/search.htm")
public class SearchController {

	@Autowired(required = true)
	private SearchService service;

	@Autowired(required = true)
	private SearchServiceAsync serviceAsync;

	private static final Logger LOGGER = LoggerFactory.getLogger(SearchController.class);

	@RequestMapping(params = "action=search")
	public @ResponseBody Map<String, Object> getOrderDetails(
		@RequestParam(value="vendorNos", required=false) List<Long> vendorNos,
		@RequestParam(value="depts", required=false) List<Long> depts,
		@RequestParam(value="subdepts", required=false) List<Long> subDepts,
		@RequestParam(value="clas", required=false) List<Long> clas,
		@RequestParam(value="events", required=false) List<Long> events,
		@RequestParam(value="statuses", required=true) List<String> statuses,

		@RequestParam(value="storeNos", required=false) List<Long> storeNos,
		@RequestParam(value="storeNo", required=true) Long storeNo,

		@RequestParam(value="userid", required=false) String userId,
		@RequestParam(value="vendorNo", required=false) String vendorNo,
		@RequestParam(value="venNameRawValue", required=false) String venNameRawValue,

		@RequestParam(value="skus", required=false) List<Long> skus,
		@RequestParam(value="upcs", required=false) List<Long> upcs,

		@RequestParam(value="merchAnalyzerComb", required=false) String merchAnalyzerComb,
		@RequestParam(value="skuDesc", required=false) String skuDesc,
		@RequestParam(value="filters", required=false) String filters,

		@RequestParam(value="lang", required=false) String lang,
		@RequestParam(value="elasticSearch", required=false) Boolean elasticSearch,
		@RequestParam(value="start", required=true) Integer start,
		@RequestParam(value="limit", required=true) Integer limit,

		@RequestParam(value="maxCount", required=false) Integer maxCount,
		@RequestParam(value="sort", required=false) String sort,
		@RequestParam(value="dir", required=false) String dir,
		@RequestParam(value="venNameSearchMode", required=false) String venNameSearchMode,
		@RequestParam(value="skuSearchMode", required=false) String skuSearchMode,
		@RequestParam(value="merchcatno", required=false) String merchcatno,

		@RequestParam(value="country", required=true) String country,
		@RequestParam(value="conceptShortName", required=false) String conceptShortName,
		@RequestParam(value="concept", required=false) String concept,

		//@RequestParam(value="use53FiscalWeeks", required=true) Boolean use53FiscalWeeks,
		@RequestParam(value="use53FiscalWeeks", required=false) Boolean use53FiscalWeeks,
		//@RequestParam(value="eventNumber", required=false) String eventNumber,
		@RequestParam(value="selectedCriteria", required=false) Boolean selectedCriteria,

		HttpServletRequest request
		)
	{
		long startNanos = System.nanoTime();
		System.out.println("SearchController getOrderDetails() ###################### elasticSearch = "+elasticSearch +" filters = "+filters);
		System.out.println("search invoked:: vendorNos=> "+vendorNos+":: vendorNo=>"+vendorNo+":: vendorNos"+vendorNos+":: SKU"+skus+":: storeNos:"+storeNos);
		System.out.println("search invoked:: skus=> "+skus+":: vendorNo=>"+vendorNo+":: vendorNos"+vendorNos+":: SKU"+skus+":: storeNos:"+storeNos);
		System.out.println(":: SKU = "+skus+":: Sort = "+sort+":: Dir = "+dir);
		System.out.println(":: lang = "+lang+":: Sort = "+sort+":: Dir = "+dir);
		System.out.println(":: eventNumber = "+ events);
		System.out.println(":: merchcatno = "+merchcatno +" merchAnalyzerComb = "+merchAnalyzerComb +" selectedCriteria = "+selectedCriteria);
		System.out.println(":: maxCount = "+maxCount);
		
		SearchRequest searchRequest = new SearchRequest();

		searchRequest.setElasticSearch(elasticSearch);
		searchRequest.setUserId(userId);
		searchRequest.setSearchType("common");

		List<String> newSearchKeys = new ArrayList<String>();
		if(conceptShortName != null && !conceptShortName.isEmpty()) {searchRequest.setConceptShortName(conceptShortName);}
		if(concept != null && !concept.isEmpty()) {	searchRequest.setConcept(concept) ;}
		if (merchcatno!=null && !merchcatno.isEmpty()){	searchRequest.setMerchcatno(merchcatno);}
		if (vendorNos!=null && !vendorNos.isEmpty()){searchRequest.setVendorNos(vendorNos);}

		if (vendorNo!=null) {
			try{
				if(vendorNo.equalsIgnoreCase(venNameRawValue))
				{
					searchRequest.setVendorName(vendorNo.toUpperCase());
				}
				else
				{
					long vendorNum = Long.parseLong(vendorNo);
					List<Long> vendorNosLst = new ArrayList<Long>();
					vendorNosLst.add(vendorNum);
					searchRequest.setVendorNos(vendorNosLst);
				}
			}catch (Exception e) {
				searchRequest.setVendorName(vendorNo.toUpperCase());
			}
		}

		if (depts!=null && !depts.isEmpty()) {searchRequest.setDepts(depts);}
		if (subDepts!=null && !subDepts.isEmpty()) {searchRequest.setSubDepts(subDepts);}
		if (clas!=null && !clas.isEmpty()) {searchRequest.setClas(clas);}
		if (events!=null && !events.isEmpty()) {searchRequest.setEvents(events);}

		System.out.println(":: statuses = "+statuses);
		System.out.println(":: statuses size = "+statuses.size());
		
		searchRequest.setStatuses(statuses);
		if(storeNos!=null)
			searchRequest.setStoreNos(storeNos);
		else
		{
			List<Long> storeList = new ArrayList<Long>();
			storeList.add(storeNo)	;
			searchRequest.setStoreNos(storeList);
		}
		searchRequest.setStoreNo(storeNo);

		if(upcs != null && !upcs.isEmpty()){searchRequest.setUpcs(upcs);}
		if(skuDesc != null && !skuDesc.isEmpty()){searchRequest.setSkuDescription(skuDesc.trim());}

		if(skus != null && !skus.isEmpty()){searchRequest.setSkus(skus);}
		if((skus != null && !skus.isEmpty()) ||
				(upcs != null && !upcs.isEmpty()) ||
				(skuDesc != null && !skuDesc.isEmpty()))
		{
			searchRequest.setSearchType("sku");
		}
		if(merchAnalyzerComb != null && !merchAnalyzerComb.isEmpty()){
			searchRequest.setMerchAnalyz(merchAnalyzerComb.split(" ")[0]);
			System.out.println(":: merchAnalyzerComb = "+merchAnalyzerComb.split(" ")[0] +" merchAnalyzerComb = "+merchAnalyzerComb);
		}

		if(merchcatno != null && !merchcatno.isEmpty() ){searchRequest.setSearchType("pog");}
		if(lang != null && !lang.isEmpty()){searchRequest.setLanguage(lang);}

		searchRequest.setCountry(country);
		searchRequest.setStart(start);
		searchRequest.setLimit(limit);
		searchRequest.setMaxCount(maxCount);
		searchRequest.setIpAddress(request.getRemoteAddr());

		//Set starts with or contains search mode
		if(venNameSearchMode != null && venNameSearchMode.trim().length() > 0){searchRequest.setVenNameMode(venNameSearchMode);	}
		if(skuSearchMode != null && skuSearchMode.trim().length() > 0){	searchRequest.setSkuMode(skuSearchMode);}

		//TODO -- revisit in case of sorting by sku (group sort)
		//Need to come up with up a better option
		if(sort != null && !sort.equals("sku"))
		{
			if(sort.equalsIgnoreCase("skuno")){
				sort = "sku";
			}
			sort = sort.toLowerCase();
			searchRequest.setOrderBy(sort);
			searchRequest.setOrderDir(dir);
		}

		//System.out.println("SearchController getOrderDetails() 1 - 1  ###################### searchRequest.isElasticSearch() = "+searchRequest.isElasticSearch());
		Map<String, Object> detailsMap = new HashMap<String, Object>();
		Map<String, Object> modelMap = new HashMap<String, Object>(4);
	
		try
		{

			/////////////////////////// Start Event Number logic/////////////////////////////////////////////////////////////////////////
			System.out.println("SearchController getOrderDetails() 1 - 3  ###################### before ElasticSearch eventNumber = "+events);
			System.out.println("SearchController getOrderDetails() 1 - 3  ###################### before ElasticSearch skus = "+skus);
			
/*			if(eventNumber!=null && eventNumber.length()>0){
				
				final ResponseEntity<EligibilityDetails> skusByEventNumberResponse = service.getSkusByEventNumber(eventNumber);
				skusByEventNumberResponse.getRows();
				List<EligibilityDetails> skusByEventNumberList = (List<EligibilityDetails>) skusByEventNumberResponse.getRows();
				for(EligibilityDetails bean : skusByEventNumberList){
					 skus.add(bean.getIsinumbr().longValue());
				}

				if(skus != null && !skus.isEmpty()){
					searchRequest.setSkus(skus);
				} else {
					//In case event number is invalid
					 skus.add((long)0);
				}
				System.out.println("SearchController getOrderDetails() 1 - 3  ###################### After ElasticSearch skus = "+skus);
				System.out.println("SearchController getOrderDetails() 1 - 3  ###################### After ElasticSearch getSkus = "+searchRequest.getSkus());
				if (skus.size()==0) {
					
				}
			}
*/
			//////////////////////////// End of Event Number logic/////////////////////////////////////////////////////////////////////////

			if(searchRequest.isElasticSearch()){
				detailsMap = service.esSearch(searchRequest);
			}

			List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();
			searchDetailsList = (List<SearchDetails>)detailsMap.get("data");
			Long totalCount = (Long)detailsMap.get("total");

			System.out.println("SearchController getOrderDetails() 1 - 3  ###################### ElasticSearch totalCount = "+totalCount +" Elastic searchDetailsList size = "+searchDetailsList.size());
			//System.out.println("SearchController getOrderDetails() 1 - 4  ###################### searchDetailsList = "+searchDetailsList);

			List<Long> skusfromElstic = new ArrayList<Long>();
			for(SearchDetails bean : searchDetailsList){
				 skusfromElstic.add(bean.getSku());
			}			
			System.out.println("SearchController getOrderDetails() 1 - 4 - 0  ###################### skusfromElstic size = "+skusfromElstic.size());
			//System.out.println("SearchController getOrderDetails() 1 - 4 - 0  ###################### allCommSeperatedSku = "+allCommSeperatedSku);

			//********** RC::  Merge Logic from DB ***************
			// --------------------- Start Get Eligibility By Skus	--------------------------
			//elgibilityresultsMap = service.getEligibilityBySkus(searchRequest);

			//System.out.println("SearchController getOrderDetails() 1 - 4 - 1  ###################### searchRequest.getSkus() = "+searchRequest.getSkus());
			//System.out.println("SearchController getOrderDetails() 1 - 4 - 2  ###################### searchRequest.getSkus() size = "+searchRequest.getSkus().size());
			//List<Long> skus = searchRequest.getSkus();

			List<EligibilityDetails> eligibilitySkuDetailsList = new ArrayList<EligibilityDetails>();
			//if(searchRequest.getSkus().size()>0){
			if(searchRequest.getSkus()!=null){
				final ResponseEntity<EligibilityDetails> elgibilityResultsMap = service.getEligibilityBySkus(searchRequest);
				eligibilitySkuDetailsList = (List<EligibilityDetails>) elgibilityResultsMap.getRows();
			}

			//System.out.println("SearchController getOrderDetails() 1 - 5  ###################### eligibilitySkuDetailsList = "+eligibilitySkuDetailsList);
			System.out.println("SearchController getOrderDetails() 1 - 6  ###################### eligibilitySkuDetailsList size = "+eligibilitySkuDetailsList.size());

			///////////// 8/15/2017 ///////////////////////////////////////////////////////////////////////////////////////
			if(eligibilitySkuDetailsList.size() ==0){
				if(skusfromElstic != null && !skusfromElstic.isEmpty()){
					System.out.println("SearchController getOrderDetails() 1 - 6 - 0  ##");
					searchRequest.setSkus(skusfromElstic);

					final ResponseEntity<EligibilityDetails> elgibilityResultsMap_1 = service.getEligibilityBySkus(searchRequest);
					eligibilitySkuDetailsList = (List<EligibilityDetails>) elgibilityResultsMap_1.getRows();
				}
			}

			System.out.println("SearchController getOrderDetails() 1 - 6 - 1  ###################### eligibilitySkuDetailsList size = "+eligibilitySkuDetailsList.size());
			////////////////////////////////////////////////////////////////////////////////////////

			//for(SearchDetails bean : searchDetailsList){
			//	 System.out.println("SearchController getOrderDetails() 1 - 8 - 1 BEFORE sku = "+bean.getSku() +" InstsaveElg = "+bean.getInstsaveElg());
			//}

			 for(SearchDetails bean : searchDetailsList){
				   //System.out.println("SearchController getOrderDetails() 1 - 9 sku = "+bean.getSku());
				   bean.setIsid(0); // for delete, need to pass stored proc
				   bean.setInstSaveElig(false);
				   for(EligibilityDetails eligSkuDetailsList : eligibilitySkuDetailsList){
					   long skuLongValue = eligSkuDetailsList.getIsinumbr().longValue();
					   long vendorLongValue = eligSkuDetailsList.getIsAsnum().longValue();
					   long deptLongValue = eligSkuDetailsList.getIsDept().longValue();
					   long subDeptLongValue = eligSkuDetailsList.getIsSdept().longValue();
					   long classLongValue = eligSkuDetailsList.getIsClas().longValue();
					   //System.out.println("SearchController getOrderDetails() 1 - 9 - 1 sku = "+eligSkuDetailsList.getIsinumbr() +" skuLongValue = "+skuLongValue +" isid = "+eligSkuDetailsList.getIsId() +" InstsavElig = "+eligSkuDetailsList.getInstsavElig());

					   if(bean.getSku() == skuLongValue){
						   bean.setIsid(eligSkuDetailsList.getIsId()); // for delete, need to pass stored proc
						   bean.setInstsaveElg("selected");
						   bean.setInstSaveElig(true);

						   //if(bean.getVendorNo() == vendorLongValue && bean.getDept() == deptLongValue && bean.getSubDept() == subDeptLongValue && bean.getClas() == classLongValue){
						   //	   bean.setGroupSelectionFlag(true);
						   //}
					   }
				    }
		     }

			 //for(SearchDetails bean : searchDetailsList){
			 //	 System.out.println("SearchController getOrderDetails() 1 - 9 - 2 AFTER sku = "+bean.getSku() +" InstsaveElg = "+bean.getInstsaveElg() +" isid = "+bean.getIsid() +" group Flag ="+bean.getGroupSelectionFlag());
			 //}
			 // --------------------- End Get Eligibility By Skus	--------------------------

			 // ------- Start Get Eligibility By Group	----------
			 final ResponseEntity<EligibilityDetails> elgibilityGroupResultsMap = service.getEligibilityByGroup();
			 List<EligibilityDetails> eligibilityGroupDetailsList = (List<EligibilityDetails>) elgibilityGroupResultsMap.getRows();

			 //System.out.println("SearchController getOrderDetails() 1 - 7  ###################### eligibilityGroupDetailsList = "+eligibilityGroupDetailsList);
			 System.out.println("SearchController getOrderDetails() 1 - 10  ###################### eligibilityGroupDetailsList size = "+eligibilityGroupDetailsList.size());

			 for(SearchDetails bean : searchDetailsList){
				   //System.out.println("SearchController getOrderDetails() 1 - 10 - 1 sku = "+bean.getSku());
				   //bean.setIsid(0); // for delete, need to pass stored proc
				   for(EligibilityDetails eligSkuDetailsList : eligibilityGroupDetailsList){
					   //long skuLongValue = eligSkuDetailsList.getIsinumbr().longValue();
					   long vendorLongValue = eligSkuDetailsList.getIsAsnum().longValue();
					   long deptLongValue = eligSkuDetailsList.getIsDept().longValue();
					   long subDeptLongValue = eligSkuDetailsList.getIsSdept().longValue();
					   long classLongValue = eligSkuDetailsList.getIsClas().longValue();

					   //System.out.println("SearchController getOrderDetails() 1 - 10 - 2 vendor = "+vendorLongValue +" Dept = "+deptLongValue +" subDept = "+subDeptLongValue +" clas = "+classLongValue);

					   if(vendorLongValue != 0 && deptLongValue != 0){
						   if( vendorLongValue == bean.getVendorNo() &&	 deptLongValue == bean.getDept() &&  subDeptLongValue == bean.getSubDept() && classLongValue == bean.getClas())
					       {
							   //System.out.println("SearchController getOrderDetails() 1 - 10 - 3 - 1");
							   bean.setGroupSelectionFlag(true);
						   } else if( vendorLongValue == bean.getVendorNo() &&	 deptLongValue == bean.getDept() &&  subDeptLongValue == bean.getSubDept()) {
							   //System.out.println("SearchController getOrderDetails() 1 - 10 - 3 - 2");
							   bean.setGroupSelectionFlag(true);
						   } else if( vendorLongValue == bean.getVendorNo() &&	 deptLongValue == bean.getDept()) {
							   //System.out.println("SearchController getOrderDetails() 1 - 10 - 3 - 3");
							   bean.setGroupSelectionFlag(true);
						   }

					   } else if(vendorLongValue != 0 && deptLongValue == 0){
						   if( vendorLongValue == bean.getVendorNo() ){
							   //System.out.println("SearchController getOrderDetails() 1 - 10 - 3 - 4");
							   bean.setGroupSelectionFlag(true);
						   }

					   } else if(vendorLongValue == 0 && deptLongValue != 0){
						   if( deptLongValue == bean.getDept() &&  subDeptLongValue == bean.getSubDept() && classLongValue == bean.getClas()) {
							   //System.out.println("SearchController getOrderDetails() 1 - 10 - 3 - 5");
							   bean.setGroupSelectionFlag(true);
						   } else if( deptLongValue == bean.getDept() &&  subDeptLongValue == bean.getSubDept() ) {
							   //System.out.println("SearchController getOrderDetails() 1 - 10 - 3 - 6");
							   bean.setGroupSelectionFlag(true);
						   } else if( deptLongValue == bean.getDept() ) {
							   //System.out.println("SearchController getOrderDetails() 1 - 10 - 3 - 7");
							   bean.setGroupSelectionFlag(true);
						   }
					   } else {
						   // Event number logic goes here
					   }
				    }
		     }

			 //for(SearchDetails bean : searchDetailsList){
			//	 System.out.println("SearchController getOrderDetails() 1 - 11 AFTER sku = "+bean.getSku() +" InstsaveElg = "+bean.getInstsaveElg() +" isid = "+bean.getIsid() +" group Flag ="+bean.getGroupSelectionFlag());
			// }
			// ------- End Get Eligibility By Group	----------
			 
			 // ********* Start selectedCriteria logic **********
			 if(selectedCriteria){
				System.out.println("SearchController getOrderDetails() 1 - 11 - 1  ######");
				for(Iterator<SearchDetails> esearchDetailsListIterator=searchDetailsList.iterator();
					  esearchDetailsListIterator.hasNext();) {				
						   SearchDetails searchDetails = (SearchDetails) esearchDetailsListIterator.next();
						   if(searchDetails.getIsid() == 0){
							   esearchDetailsListIterator.remove();	
						   }
				      }
				
				 //modelMap.put("data", (List<SearchDetails>) searchDetailsList);
			     //modelMap.put("total", 28);
			     //modelMap.put("success", true); 
			 }
			 System.out.println("SearchController getOrderDetails() 1 - 11 - 2  ###################### searchDetailsList size = "+searchDetailsList.size());
			 // ********* End selectedCriteria logic **********
		}

		catch(SSMException soe) {
			String msg = soe.getErrorMessage();
			LOGGER.info("ISMException Message:" + msg);
			msg = msg == null?"":msg;
			//RC:::
			if (msg.startsWith("EXCEEDS_MAX")) {
				detailsMap.put("success", false); 
    			//detailsMap.put("error","i18n.message.refinesearch");
				String errMsg = AppConstants.EXCEEDS_MAX_MSG;
				errMsg = errMsg.replace("XXXX", maxCount.toString());
    			detailsMap.put("error",errMsg);
			}
			else {
				soe.printStackTrace();
	    		detailsMap.put("error", "i18n.message.genericerror");
				LOGGER.error("Error in getOrderDetails:: " + soe.getMessage() + "::StackTrace::" + soe);
			}
		} catch(Exception e) {
			System.out.println("Error in getOrderDetails:: " + e.getMessage() + "::StackTrace::" + e);
			e.printStackTrace();
    		detailsMap.put("error", "i18n.message.genericerror");
			LOGGER.error("Error in getOrderDetails:: " + e.getMessage() + "::StackTrace::" + e);

		}        
		
		long nanoSeconds = (System.nanoTime() - startNanos);
		LOGGER.debug("\n\n"+ApplicationUtil.formatNanos(nanoSeconds, false,
			"Search:getOrderDetails")
				+ " - Total time for getOrderDetails(Search)\n");
		
		/*
		if(selectedCriteria){
			return modelMap;
		} else {
			return detailsMap;	
		}*/
		return detailsMap;
	}
	
	@RequestMapping(params = "action=saveInstantSavings", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity saveSchedulebChanges(final HttpServletRequest request, final HttpServletResponse response,
			 @RequestParam final String instantSavingsList,
			 //@RequestParam final String eligStates,
			 //@RequestParam final String ids,
			 @RequestParam final String userId,
			 @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) {

		System.out.println("saveSchedulebChanges ############### instantSavingsList = "+instantSavingsList);
		System.out.println("saveSchedulebChanges ############### userId = "+userId);
		//System.out.println("saveSchedulebChanges ############### eligStates = "+eligStates +" ids = "+ids +" userId = "+userId);
		System.out.println("saveSchedulebChanges ############### lang = "+lang +" country = "+country +" concept = "+concept +" conceptShortName = "+conceptShortName);

		ResponseEntity gridResponse = new ResponseEntity();
		try {

			final ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			final List<SearchDetails> searchDetailsList = mapper.readValue(
					instantSavingsList, mapper.getTypeFactory().constructCollectionType(ArrayList.class, SearchDetails.class));

			//System.out.println("saveSchedulebChanges ############### 4 - 2 searchDetailsList = "+searchDetailsList);
			System.out.println("saveSchedulebChanges ############### 4 - 3 SearchDetailsList size = "+searchDetailsList.size());

			if (ApplicationUtil.isNotNullNotEmptyCollection(searchDetailsList)) {
				//for (SchedulebBean schedulebBean : schedulebBeanList) {
				//	logger.info("getScheduleb6 = "+schedulebBean.getScheduleb() +" getScheduleb6 = "+schedulebBean.getScheduleb6() +" getScheduleb64 = "+schedulebBean.getScheduleb4());
				//}
				/////////////////List<Scheduleb> schedulebList = prepareObjFromBean(schedulebBeanList);
				//for (Scheduleb scheduleb : schedulebList) {
				//	logger.info("########## final Scheduleb = "+scheduleb.getScheduleb());
				//}

				final ResponseEntity<SearchDetails> schedulebResponse = new ResponseEntity<SearchDetails>();
				schedulebResponse.setSuccess(true);
				//schedulebResponse.setReason(errorMessage);

				//gridResponse = service.saveEligibility(searchDetailsList ,eligStates, ids, userId, lang, country, concept, conceptShortName);
				gridResponse = service.saveEligibility(searchDetailsList , userId, lang, country, concept, conceptShortName);
				gridResponse.setSuccess(true);
			}

		} catch (SSMException e) {
			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());

		} catch (JsonParseException e) {
			//LOGGER.error("Error while mapping object before account update :"+ e);
			System.out.println("CATCH################### 1");
			e.printStackTrace();

			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());
		} catch (JsonMappingException e) {
			//LOGGER.error("Error while mapping object before account update :"+ e);
			System.out.println("CATCH################### 2");
			e.printStackTrace();

			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());
		} catch (IOException e) {
			//LOGGER.error("Error while mapping object before account update :"+ e);
			System.out.println("CATCH################### 3");
			e.printStackTrace();
			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());
		}

		System.out.println("saveSchedulebChanges ############### 4 - 2 gridResponse = "+gridResponse);

		return gridResponse;
	}
	
	@RequestMapping(params = "action=eligibilitydetailsbyskus", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity eligibilityDetailsBySkus(final HttpServletRequest request, final HttpServletResponse response,
			SearchRequest searchRequest,
			 //@RequestParam final String instantSavingsList,
			 //@RequestParam final String eligStates,
			 //@RequestParam final String ids,
			 @RequestParam final String skus,
			 @RequestParam final String userId, @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) {

		System.out.println("eligibilityDetailsBySkus ############### skus = "+skus);
		//System.out.println("eligibilityDetailsBySkus ############### eligStates = "+eligStates +" ids = "+ids +" userId = "+userId);
		System.out.println("eligibilityDetailsBySkus ############### lang = "+lang +" country = "+country +" concept = "+concept +" conceptShortName = "+conceptShortName);

		ResponseEntity gridResponse = new ResponseEntity();
		try {

			final ResponseEntity<EligibilityDetails> schedulebResponse = new ResponseEntity<EligibilityDetails>();
			schedulebResponse.setSuccess(true);


			gridResponse = service.getEligibilityBySkus(searchRequest);
			//gridResponse.setTotal(gridResponseFromServer.getTotal());
			//gridResponse.setSuccess(gridResponseFromServer.isSuccess());
			gridResponse.setSuccess(true);

		} catch (SSMException e) {
			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());

		}
		return gridResponse;
	}

	@RequestMapping(params = "action=instantsavingsgroupsearch", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getEligibilityByGroup(final HttpServletRequest request, final HttpServletResponse response,
				//SearchRequest searchRequest,
				 //@RequestParam final String instantSavingsList,
				 //@RequestParam final String eligStates,
				 //@RequestParam final String ids,
				 //@RequestParam final String skus,
				 @RequestParam(value="vendorNos", required=false) List<Long> vendorNos,
				 @RequestParam(value="depts", required=false) List<Long> depts,
				 @RequestParam(value="subdepts", required=false) List<Long> subDepts,
				 @RequestParam(value="clas", required=false) List<Long> clas,
				 @RequestParam(value="merchAnalyzerComb", required=false) String merchAnalyzerComb,
				 @RequestParam(value="events", required=false) String eventNumberText,
				 @RequestParam(value="start", required=false) int start,
				 @RequestParam(value="limit", required=false) int limit,
				 @RequestParam(value="page", required=false) int page,

				 //@RequestParam(value="venNameSearchMode", required=false) String venNameSearchMode,
				 //@RequestParam(value="skuSearchMode", required=false) String skuSearchMode,
				 //@RequestParam(value="merchcatno", required=false) String merchcatno,

				 @RequestParam final String userId, @RequestParam final String lang,  @RequestParam final String country,
				 @RequestParam final String concept,  @RequestParam final String conceptShortName) {

			//System.out.println("getEligibilityByGroup ############### skus = "+skus);
			//System.out.println("eligibilityDetailsBySkus ############### eligStates = "+eligStates +" ids = "+ids +" userId = "+userId);
		    System.out.println("getEligibilityByGroup ############### 8 - 0 - 1 lang = "+lang +" country = "+country +" concept = "+concept +" conceptShortName = "+conceptShortName);

			System.out.println("getEligibilityByGroup invoked:: 8 - 0 - 2 vendorNos=> "+vendorNos+ " :: depts = "+depts +" :: subDepts = "+subDepts+" :: clas = "+clas);
			System.out.println("getEligibilityByGroup invoked:: 8 - 0 - 3 merchAnalyzerComb=> "+merchAnalyzerComb+ " :: eventNumber = "+eventNumberText);
			//System.out.println("search invoked:: vendorNos=> "+vendorNos+":: vendorNo=>"+vendorNo+":: vendorNos"+vendorNos+":: SKU"+skus+":: storeNos:"+storeNos);
			//System.out.println("search invoked:: skus=> "+skus+":: vendorNo=>"+vendorNo+":: vendorNos"+vendorNos+":: SKU"+skus+":: storeNos:"+storeNos);

			ResponseEntity<EligibilityDetails> gridResponse = new ResponseEntity<EligibilityDetails>();
			try {

				// Get Eligibility By Group
				final ResponseEntity<EligibilityDetails> elgibilityGroupResultsMap = service.getEligibilityByGroup();
				List<EligibilityDetails> eligibilityGroupDetailsList = (List<EligibilityDetails>) elgibilityGroupResultsMap.getRows();

				//System.out.println("SearchController getEligibilityByGroup 8 - 1  ###################### getTotal = "+elgibilityGroupResultsMap.getTotal());
				System.out.println("SearchController getEligibilityByGroup 8 - 2  ###################### eligibilityGroupDetailsList size = "+eligibilityGroupDetailsList.size());

				for(EligibilityDetails bean : eligibilityGroupDetailsList){
					 System.out.println("SearchController getEligibilityByGroup() 8 - 3 before Vendor = "+bean.getIsAsnum() +" Dept = "+bean.getIsDept() +" GroupElgFlag = "+bean.getGroupElgFlag() +" isid  = "+bean.getIsId() +" Merch Analyz = "+bean.getIsma());
				}

				/////////////////////////////////////////////////////////////////////////////////////////////////////////
				//System.out.println("search invoked:: vendorNos=> "+vendorNos+ " :: depts = "+depts +" :: subDepts = "+subDepts+" :: clas = "+clas);

				//Long subDeptValue = (long) 0;
				long vendorValue =  0;
				long deptValue =  0;
				long subDeptValue =  0;
				long clasValue =  0;
				String merchAnalyzer = "";
				String eventNumber = "";
				
				boolean bMultipleMultiple = ((vendorNos.size() > 1) && 
						((depts.size() > 1) || (subDepts.size() > 1) || (clas.size() > 1)));
				
				if(vendorNos.size() == 1){vendorValue = vendorNos.get(0);}
				if(depts.size() == 1){deptValue = depts.get(0);}
				if(subDepts.size() == 1){subDeptValue = subDepts.get(0);}
				if(clas.size() == 1){clasValue = clas.get(0);}
				
				if(merchAnalyzerComb != null && !merchAnalyzerComb.isEmpty()){
					merchAnalyzer = merchAnalyzerComb.split(" ")[0];
					//searchRequest.setMerchAnalyz(merchAnalyzerComb.split(" ")[0]);
					System.out.println("8 - 3 - 1 getEligibilityByGroup() :: eventNumber = "+eventNumber +" merchAnalyzerComb = "+merchAnalyzerComb.split(" ")[0] +" merchAnalyzerComb = "+merchAnalyzerComb);
				}
				
				if(eventNumberText != null && !eventNumberText.isEmpty()){
					//eventNumber = Integer.parseInt(eventNumberText);
					eventNumber = eventNumberText;
				}

				boolean bGlobalSearch = ((vendorNos.size() == 0) 
						&& (depts.size() == 0) && (subDepts.size() == 0) && (clas.size() == 0)
						&& eventNumber.length() == 0 && merchAnalyzer.length() == 0);

				System.out.println("8 - 3 - 1 getEligibilityByGroup() :: eventNumber = "+eventNumber +" merchAnalyzerComb = "+merchAnalyzerComb.split(" ")[0] +" merchAnalyzerComb = "+merchAnalyzerComb);
				
				
				System.out.println("SearchController getEligibilityByGroup() 8 - 4 vendorValue= "+vendorValue +" deptValue = "+deptValue);
				System.out.println("SearchController getEligibilityByGroup() 8 - 4 - 1 subDeptValue= "+subDeptValue +" clasValue = "+clasValue +" merchAnalyzerComb = "+merchAnalyzerComb);
				System.out.println("SearchController getEligibilityByGroup() 8 - 4 - 1 merchAnalyzerComb.length()= "+merchAnalyzerComb.length() +" eventNumberText.length() = "+eventNumberText.length() );

				List<EligibilityDetails> eligibilityDetailsNewList = new ArrayList<EligibilityDetails>();

				//Add all groups to the grid that match the search criteria
				System.out.println("SearchController getEligibilityByGroup() 8 - 6 - 3 For MULTI VALUES");
				for(EligibilityDetails bean : eligibilityGroupDetailsList) {

					if (bGlobalSearch || isRowMatchesCriteria(bean, vendorNos, depts, subDepts, clas, merchAnalyzer, eventNumber)){
						EligibilityDetails eligibilityDetails = new EligibilityDetails();
						eligibilityDetails.setIsAsnum(bean.getIsAsnum());
						eligibilityDetails.setIsDept(bean.getIsDept());
						eligibilityDetails.setIsSdept(bean.getIsSdept());
						eligibilityDetails.setIsClas(bean.getIsClas());
						eligibilityDetails.setIsId(bean.getIsId());
						eligibilityDetails.setIsma(bean.getIsma().trim());
						eligibilityDetails.setIsevt(bean.getIsevt());
						//eligibilityDetails.setGroupElgFlag(false); // delete
						eligibilityDetails.setGroupElgFlag("Delete"); // delete
						eligibilityDetails.setGroupEligFl(true);
						eligibilityDetailsNewList.add(eligibilityDetails);
					}
			     }
				 System.out.println("SearchController getEligibilityByGroup() 8 - 6 - 3 - 0 - 1 eligibilityDetailsNewList size = "+eligibilityDetailsNewList.size());

				 if (!bMultipleMultiple) {
					 //Add new rows for any vendor that does not have a row
					for (long vendor : vendorNos) {
						 System.out.println("vendor  8 - 6 - 3 - 1 ============================= "+vendor);
						 EligibilityDetails eligibilityFirstRecord = new EligibilityDetails();
						 eligibilityFirstRecord.setIsAsnum((int) toIntExact(vendor));
						 eligibilityFirstRecord.setIsDept((int) deptValue);
						 eligibilityFirstRecord.setIsSdept((int) subDeptValue);
						 eligibilityFirstRecord.setIsClas((int) clasValue);
						 eligibilityFirstRecord.setIsma(merchAnalyzer);
						 eligibilityFirstRecord.setIsevt(eventNumber);
						 eligibilityFirstRecord.setIsId((int) 0);
						 eligibilityFirstRecord.setGroupElgFlag("Add"); // add
						 eligibilityFirstRecord.setGroupEligFl(false);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, vendor, deptValue, subDeptValue, clasValue, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord);
						 }
						 EligibilityDetails eligibilityFirstRecord2 = copyEligibilityRecord(eligibilityFirstRecord); 
						 eligibilityFirstRecord2.setIsDept((int) 0);
						 eligibilityFirstRecord2.setIsSdept((int) 0);
						 eligibilityFirstRecord2.setIsClas((int) 0);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, vendor, 0, 0, 0, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord2);
						 }
					}

					//Add rows for any dept that does not have a row
					for (long dept : depts) {
						 System.out.println("vendor  8 - 6 - 4 - 2 ============================= "+dept);
						 EligibilityDetails eligibilityFirstRecord = new EligibilityDetails();
						 eligibilityFirstRecord.setIsAsnum((int) vendorValue);
						 eligibilityFirstRecord.setIsDept((int) toIntExact(dept));
						 eligibilityFirstRecord.setIsSdept((int) subDeptValue);
						 eligibilityFirstRecord.setIsClas((int) clasValue);
						 eligibilityFirstRecord.setIsma(merchAnalyzer);
						 eligibilityFirstRecord.setIsevt(eventNumber);
						 eligibilityFirstRecord.setIsId((int) 0);
						 eligibilityFirstRecord.setGroupElgFlag("Add"); // add
						 eligibilityFirstRecord.setGroupEligFl(false);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, vendorValue, dept, subDeptValue, clasValue, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord);
						 }
						 EligibilityDetails eligibilityFirstRecord2 = copyEligibilityRecord(eligibilityFirstRecord); 
						 eligibilityFirstRecord2.setIsAsnum((int) 0);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, 0, dept, subDeptValue, clasValue, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord2);
						 }
					}

					//Add rows for any subdept that does not have a row
					for (long subDept : subDepts) {
						 System.out.println("vendor  8 - 6 - 4 - 2 ============================= "+subDept);
						 EligibilityDetails eligibilityFirstRecord = new EligibilityDetails();
						 eligibilityFirstRecord.setIsAsnum((int) vendorValue);
						 eligibilityFirstRecord.setIsDept((int) deptValue);
						 eligibilityFirstRecord.setIsSdept((int) toIntExact(subDept));
						 eligibilityFirstRecord.setIsClas((int) clasValue);
						 eligibilityFirstRecord.setIsma(merchAnalyzer);
						 eligibilityFirstRecord.setIsevt(eventNumber);
						 eligibilityFirstRecord.setIsId((int) 0);
						 eligibilityFirstRecord.setGroupElgFlag("Add"); // add
						 eligibilityFirstRecord.setGroupEligFl(false);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, vendorValue, deptValue, subDeptValue, clasValue, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord);
						 }
						 EligibilityDetails eligibilityFirstRecord2 = copyEligibilityRecord(eligibilityFirstRecord); 
						 eligibilityFirstRecord2.setIsAsnum((int) 0);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, 0, deptValue, subDeptValue, clasValue, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord2);
						 }
					}

					//Add rows for any clas that does not have a row
					for (long cla : clas) {
						 System.out.println("vendor  8 - 6 - 4 - 2 ============================= "+cla);
						 EligibilityDetails eligibilityFirstRecord = new EligibilityDetails();
						 eligibilityFirstRecord.setIsAsnum((int) vendorValue);
						 eligibilityFirstRecord.setIsDept((int) deptValue);
						 eligibilityFirstRecord.setIsSdept((int) subDeptValue);
						 eligibilityFirstRecord.setIsClas((int) toIntExact(cla));
						 eligibilityFirstRecord.setIsma(merchAnalyzer);
						 eligibilityFirstRecord.setIsevt(eventNumber);
						 eligibilityFirstRecord.setIsId((int) 0);
						 eligibilityFirstRecord.setGroupElgFlag("Add"); // add
						 eligibilityFirstRecord.setGroupEligFl(false);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, vendorValue, deptValue, subDeptValue, cla, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord);
						 }
						 EligibilityDetails eligibilityFirstRecord2 = copyEligibilityRecord(eligibilityFirstRecord); 
						 eligibilityFirstRecord2.setIsAsnum((int) 0);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, 0, deptValue, subDeptValue, cla, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord2);
						 }
					}

					//Add rows for any clas that does not have a row
					if (!merchAnalyzerComb.isEmpty()) {
						 System.out.println("vendor  8 - 6 - 4 - 2 ============================= "+merchAnalyzerComb);
						 EligibilityDetails eligibilityFirstRecord = new EligibilityDetails();
						 eligibilityFirstRecord.setIsAsnum((int) vendorValue);
						 eligibilityFirstRecord.setIsDept((int) deptValue);
						 eligibilityFirstRecord.setIsSdept((int) subDeptValue);
						 eligibilityFirstRecord.setIsClas((int) clasValue);
						 eligibilityFirstRecord.setIsma(merchAnalyzer);
						 eligibilityFirstRecord.setIsevt(eventNumber);
						 eligibilityFirstRecord.setIsId((int) 0);
						 eligibilityFirstRecord.setGroupElgFlag("Add"); // add
						 eligibilityFirstRecord.setGroupEligFl(false);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, vendorValue, deptValue, subDeptValue, clasValue, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord);
						 }
					}

					if (eventNumber.length()>0) {
						 System.out.println("vendor  8 - 6 - 4 - 2 ============================= "+eventNumber);
						 EligibilityDetails eligibilityFirstRecord = new EligibilityDetails();
						 eligibilityFirstRecord.setIsAsnum((int) vendorValue);
						 eligibilityFirstRecord.setIsDept((int) deptValue);
						 eligibilityFirstRecord.setIsSdept((int) subDeptValue);
						 eligibilityFirstRecord.setIsClas((int) clasValue);
						 eligibilityFirstRecord.setIsma(merchAnalyzer);
						 eligibilityFirstRecord.setIsevt(eventNumber);
						 eligibilityFirstRecord.setIsId((int) 0);
						 eligibilityFirstRecord.setGroupElgFlag("Add"); // add
						 eligibilityFirstRecord.setGroupEligFl(false);
						 if(!isGroupRowAlreadyAdded(eligibilityDetailsNewList, vendorValue, deptValue, subDeptValue, clasValue, merchAnalyzer, eventNumber)){
							 eligibilityDetailsNewList.add(0,eligibilityFirstRecord);
						 }
					}
				 }

				 //for(SearchDetails bean : searchDetailsList){
				 //	 System.out.println("SearchController getOrderDetails() 1 - 9 - 2 AFTER sku = "+bean.getSku() +" InstsaveElg = "+bean.getInstsaveElg() +" isid = "+bean.getIsid() +" group Flag ="+bean.getGroupSelectionFlag());
				 //}

				/////////////////////////////////////////////////////////////////////////////////////////////////////////

				gridResponse.setSuccess(true);
				//gridResponse.setRows(eligibilityGroupDetailsList);
				//gridResponse.setTotal(String.valueOf(eligibilityGroupDetailsList.size()));
				gridResponse.setRows(eligibilityDetailsNewList.subList(start, Math.min(start+limit, eligibilityDetailsNewList.size())));
				gridResponse.setTotal(String.valueOf(eligibilityDetailsNewList.size()));
				
				//gridResponse.setTotal(elgibilityGroupResultsMap.getTotal());
				//gridResponse.setSuccess(elgibilityGroupResultsMap.isSuccess());

			} catch (SSMException e) {
				e.printStackTrace();
				gridResponse.setSuccess(false);
				gridResponse.setReason(e.getMessage());
			}
			return gridResponse;
	}

	EligibilityDetails copyEligibilityRecord(EligibilityDetails objOriginal) {
		EligibilityDetails objCopy = new EligibilityDetails();
		objCopy.setIsAsnum(objOriginal.getIsAsnum());
		objCopy.setIsDept(objOriginal.getIsDept());
		objCopy.setIsSdept(objOriginal.getIsSdept());
		objCopy.setIsClas(objOriginal.getIsClas());
		objCopy.setIsma(objOriginal.getIsma());
		objCopy.setIsevt(objOriginal.getIsevt());
		objCopy.setIsId(objOriginal.getIsId());
		objCopy.setGroupElgFlag(objOriginal.getGroupElgFlag());
		objCopy.setGroupEligFl(objOriginal.getGroupEligFl());
		return objCopy;
	}
	
	boolean isGroupRowAlreadyAdded(List<EligibilityDetails> eligibilityGridList,
			long vendorValue, long deptValue, long subDeptValue, long clasValue, String merchAnalyzer, String eventNum) {
		boolean bFound = false; 
		for(EligibilityDetails bean : eligibilityGridList) {
			if(bean.getIsAsnum() == vendorValue && bean.getIsDept() == toIntExact(deptValue) 
					&& bean.getIsSdept() == subDeptValue && bean.getIsClas() == clasValue
				    && (merchAnalyzer.isEmpty() || bean.getIsma().equalsIgnoreCase(merchAnalyzer))
				    && (bean.getIsevt().equalsIgnoreCase(eventNum)) ){
				bFound = true;
				break;
			 }
		}
		return bFound;
	}

	boolean isRowMatchesCriteria(EligibilityDetails eligibilityRow,
			List<Long> vendorNos, List<Long> depts, List<Long> subDepts, List<Long> classes, String merchAnalyzer, String eventNum) {
		boolean bFound = false;
		for (Long vendor : vendorNos) {
			if( eligibilityRow.getIsAsnum()==toIntExact(vendor)){
				bFound = true;
				break;
			}
		}
		if (!bFound) {
			for (Long dept : depts) {
				if( eligibilityRow.getIsDept()==toIntExact(dept)){
					bFound = true;
					break;
				}
			}
		}
		if (!bFound) {
			for (Long subDept : subDepts) {
				if( eligibilityRow.getIsSdept()==toIntExact(subDept)){
					bFound = true;
					break;
				}
			}
		}
		if (!bFound) {
			for (Long clas : classes) {
				if( eligibilityRow.getIsClas()==toIntExact(clas)){
					bFound = true;
					break;
				}
			}
		}
		if (!bFound) {
			if( merchAnalyzer.length() > 0 && eligibilityRow.getIsma().equalsIgnoreCase(merchAnalyzer)){
				bFound = true;
			}
		}
		if (!bFound) {
			if( eventNum.length()>0 && eligibilityRow.getIsevt().equalsIgnoreCase(eventNum)){
				bFound = true;
			}
		}
		return bFound;
	}

	 

	
	//@RequestMapping(value = "scheduleb/updateSchedulebgrid.htm", method = RequestMethod.POST)
		@RequestMapping(params = "action=saveinstantsavingsbygroup", method = RequestMethod.POST)
		public @ResponseBody ResponseEntity saveInstantSavingsByGroup(final HttpServletRequest request, final HttpServletResponse response,
					 //@RequestParam final String instantSavingsList,
					 //@RequestParam final String eligStates,
					 //@RequestParam final String ids,
				     @RequestParam final String instSavingsType,
				     @RequestParam final String eligState,
				     @RequestParam final String vendorNos,
				     @RequestParam final String depts,
				     @RequestParam final String subdepts,
				     @RequestParam final String clas,

					 @RequestParam final String userId,
					 @RequestParam final String lang,  @RequestParam final String country,
					 @RequestParam final String concept,  @RequestParam final String conceptShortName) {


				System.out.println("saveInstantSavingsByGroup 7 - 1 ############### instSavingsType = "+instSavingsType +" eligState = "+eligState);
				System.out.println("saveInstantSavingsByGroup 7 - 2 ############### vendorNos = "+vendorNos +" depts = "+depts +" subdepts = "+subdepts +" clas = "+clas);
				System.out.println("saveInstantSavingsByGroup 7 - 3 ############### userId = "+userId);
				//System.out.println("saveSchedulebChanges ############### eligStates = "+eligStates +" ids = "+ids +" userId = "+userId);
				System.out.println("saveInstantSavingsByGroup 7 - 4 ############### lang = "+lang +" country = "+country +" concept = "+concept +" conceptShortName = "+conceptShortName);

				//final ResponseEntity gridResponse = new ResponseEntity();
				ResponseEntity gridResponse = new ResponseEntity();

				try {
						final ResponseEntity<SearchDetails> schedulebResponse = new ResponseEntity<SearchDetails>();
						gridResponse = service.saveEligibilityByGroup(instSavingsType, eligState, vendorNos,depts,subdepts,
														                clas, userId, lang, country, concept, conceptShortName);

						//gridResponse = service.saveEligibility(searchDetailsList , userId, lang, country, concept, conceptShortName);
						//gridResponse.setSuccess(true);
						//gridResponse = schedulebResponse;
						gridResponse.setSuccess(true);
					//}

				} catch (SSMException e) {
					gridResponse.setSuccess(false);
					gridResponse.setReason(e.getMessage());

				}

				System.out.println("saveSchedulebChanges ############### 4 - 2 gridResponse = "+gridResponse);

				return gridResponse;
	}

	@RequestMapping(params = "action=saveInstantelgibygroup", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity saveInstantElgiByGroup(final HttpServletRequest request, final HttpServletResponse response,
			 @RequestParam final String instantSavingsList,
			 //@RequestParam final String eligStates,
			 //@RequestParam final String ids,
			 @RequestParam final String userId,
			 @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) {

		System.out.println("saveInstantElgiByGroup ############### instantSavingsList = "+instantSavingsList);
		System.out.println("saveInstantElgiByGroup ############### userId = "+userId);
		//System.out.println("saveSchedulebChanges ############### eligStates = "+eligStates +" ids = "+ids +" userId = "+userId);
		System.out.println("saveInstantElgiByGroup ############### lang = "+lang +" country = "+country +" concept = "+concept +" conceptShortName = "+conceptShortName);

		ResponseEntity gridResponse = new ResponseEntity();
		try {

			//System.out.println("SchedulebController saveSchedulebChanges() ######## 4 - 1 - 1 ##### testString_1 = "+testString_1 +" testint_1 = "+testint_1);
			final ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			final List<EligibilityDetails> eligibilityDetailsList = mapper.readValue(
					instantSavingsList, mapper.getTypeFactory().constructCollectionType(ArrayList.class, EligibilityDetails.class));

			//System.out.println("saveSchedulebChanges ############### 4 - 2 searchDetailsList = "+searchDetailsList);
			System.out.println("saveSchedulsaveInstantElgiByGroupebChanges ############### 4 - 3 eligibilityDetailsList size = "+eligibilityDetailsList.size());

			if (ApplicationUtil.isNotNullNotEmptyCollection(eligibilityDetailsList)) {


				for (EligibilityDetails bean : eligibilityDetailsList) {
					    System.out.println("SearchDao saveEligibility Sku = "+bean.getIsinumbr() +" Vendor = "+bean.getIsAsnum() +" MerchGroup = "+bean.getIsma() +" Event = "+bean.getIsevt() +" isid = "+bean.getIsId()  +" GroupEligFl = "+bean.getGroupEligFl() +" InstsavElig = "+bean.getInstsavElig());
		        	    System.out.println("SearchDao saveEligibility Dept = "+bean.getIsDept() +" SDept = "+bean.getIsSdept() +" instsavElig = "+bean.getInstsavElig());
                        
		        	    /*gridResponse = service.saveEligibilityByGroup(
								//request, response,
				                "group", String.valueOf(bean.getInstsavElig()), String.valueOf(bean.getIsAsnum()), String.valueOf(bean.getIsDept()),
				                String.valueOf(bean.getIsSdept()), String.valueOf(bean.getIsClas()),
				                userId, lang, country, concept, conceptShortName  );*/		        	    
		        	    
		        	   gridResponse = service.saveInstantElgiByGroup(eligibilityDetailsList , userId, lang, country, concept, conceptShortName);

				}
				gridResponse.setSuccess(true);
			}

		} catch (SSMException e) {
			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());

		} catch (JsonParseException e) {
			//LOGGER.error("Error while mapping object before account update :"+ e);
			System.out.println("CATCH################### 1");
			e.printStackTrace();

			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());
		} catch (JsonMappingException e) {
			//LOGGER.error("Error while mapping object before account update :"+ e);
			System.out.println("CATCH################### 2");
			e.printStackTrace();

			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());
		} catch (IOException e) {
			//LOGGER.error("Error while mapping object before account update :"+ e);
			System.out.println("CATCH################### 3");
			e.printStackTrace();
			gridResponse.setSuccess(false);
			gridResponse.setReason(e.getMessage());
		}

		System.out.println("saveSchedulebChanges ############### 4 - 2 gridResponse = "+gridResponse);

		return gridResponse;
	}

	// for popup
	@RequestMapping(params = "action=instantsavingsgroupdetails", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<EligibilityDetails> getGroupDetails(final HttpServletRequest request, final HttpServletResponse response,
			 @RequestParam final String instantSavingsList) {

			ResponseEntity<EligibilityDetails> gridResponse = new ResponseEntity<EligibilityDetails>();
			try {

				final ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

				final List<SearchDetails> searchDetailsList = mapper.readValue(
						instantSavingsList, mapper.getTypeFactory().constructCollectionType(ArrayList.class, SearchDetails.class));

				// Get Eligibility By Group
				final ResponseEntity<EligibilityDetails> elgibilityGroupResultsMap = service.getEligibilityByGroup();
				List<EligibilityDetails> eligibilityGroupDetailsList = (List<EligibilityDetails>) elgibilityGroupResultsMap.getRows();

				List<EligibilityDetails> eligibilityDetailsNewList = new ArrayList<EligibilityDetails>();

				//for(SearchDetails bean : searchDetailsList){
				//	 System.out.println("SearchController getOrderDetails() 8 - 4 AFTER sku = "+bean.getSku() +" InstsaveElg = "+bean.getInstsaveElg() +" isid = "+bean.getIsid() +" group Flag ="+bean.getGroupSelectionFlag());
				//}

				for(SearchDetails bean : searchDetailsList){
					   for(EligibilityDetails eligSkuDetailsList : eligibilityGroupDetailsList){
						   long vendorLongValue = eligSkuDetailsList.getIsAsnum().longValue();
						   long deptLongValue = eligSkuDetailsList.getIsDept().longValue();
						   long subDeptLongValue = eligSkuDetailsList.getIsSdept().longValue();
						   long classLongValue = eligSkuDetailsList.getIsClas().longValue();
						   if( vendorLongValue == bean.getVendorNo() ||	 deptLongValue == bean.getDept() ||  subDeptLongValue == bean.getSubDept() || classLongValue == bean.getClas())
					       {
							   eligibilityDetailsNewList.add(eligSkuDetailsList);
						   }
					    }
			    }

				gridResponse.setSuccess(true);
				gridResponse.setRows(eligibilityDetailsNewList);
				gridResponse.setTotal(String.valueOf(eligibilityDetailsNewList.size()));

			} catch (SSMException e) {
				//e.printStackTrace();
				gridResponse.setSuccess(false);
				gridResponse.setReason(e.getMessage());
			} catch (JsonParseException e) {
				LOGGER.error("Error while mapping object while getting group:"+ e);
				e.printStackTrace();
				gridResponse.setSuccess(false);
				gridResponse.setReason(e.getMessage());
			} catch (JsonMappingException e) {
				LOGGER.error("Error while mapping object while getting group :"+ e);
				e.printStackTrace();
				gridResponse.setSuccess(false);
				gridResponse.setReason(e.getMessage());
			} catch (IOException e) {
				LOGGER.error("Error while mapping object while getting group:"+ e);
				//e.printStackTrace();
				gridResponse.setSuccess(false);
				gridResponse.setReason(e.getMessage());
			}
			return gridResponse;
	}

	@RequestMapping(params = "action=skusbyeventnumber", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getSkusByEventNumber(final HttpServletRequest request, final HttpServletResponse response,
			SearchRequest searchRequest,  @RequestParam final String eventNumber){

		ResponseEntity<EligibilityDetails> skusByEventNumberResponse = new ResponseEntity<EligibilityDetails>();
		try {
			skusByEventNumberResponse = service.getSkusByEventNumber(eventNumber);
			List<EligibilityDetails> skusByEventNumberList = (List<EligibilityDetails>) skusByEventNumberResponse.getRows();

			skusByEventNumberResponse.setSuccess(true);
			if(skusByEventNumberList!=null && skusByEventNumberList.size()==0){
				skusByEventNumberResponse.setSuccess(false);
			}
		} catch (SSMException e) {
			skusByEventNumberResponse.setSuccess(false);
			skusByEventNumberResponse.setReason(e.getMessage());
		}
		return skusByEventNumberResponse;
	}


}