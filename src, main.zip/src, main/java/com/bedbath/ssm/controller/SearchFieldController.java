package com.bedbath.ssm.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bedbath.ssm.common.util.ApplicationUtil;
import com.bedbath.ssm.model.EventNumber;
import com.bedbath.ssm.model.MerchAnalyzer;
import com.bedbath.ssm.model.Sku;
import com.bedbath.ssm.model.Vendor;
import com.bedbath.ssm.service.SearchFieldService;

/*
@RestController
public class WeeklySalesController {
	private static final Logger LOGGER = LoggerFactory.getLogger(WeeklySalesController.class);
	
	@Autowired (required = true)
	WeeklySalesService weeklySalesService;
	
	@RequestMapping(value = "/weeklysales", method = RequestMethod.GET)
	public @ResponseBody Map<String, Object> searchWeeklySales(
			@RequestParam(value="sku", required=true) Long sku,
	
	{
*/

@Controller
@RequestMapping(value = "/searchfield.htm")
public class SearchFieldController {	
	private static final Logger LOGGER = LoggerFactory.getLogger(SearchFieldController.class);
	
	@Autowired(required = true)
	//@Autowired
	private SearchFieldService service;		

	
	@RequestMapping(params = "action=getVendor")    
	public @ResponseBody Map<String, Object> getVendorList(	    		
		@RequestParam(value="vendorNo", required=false) List<Long> vendorNo,
		@RequestParam(value="vendorDesc", required=false) String vendorDesc,
		@RequestParam(value="country", required=false) String country,
		@RequestParam(value="conceptShortName", required=false) String conceptShortName,
		@RequestParam(value="searchMode", required=false) String searchMode
	    )
	{
		LOGGER.info("country::"+country+":: searchMode:"+searchMode);
		System.out.println("SearchFieldController getVendorList vendorNo = "+vendorNo +" vendorDesc = "+vendorDesc +" country =  " +country);
		System.out.println("SearchFieldController getVendorList conceptShortName = "+conceptShortName +" searchMode = "+searchMode);
		
		Map<String, Object> vendorMap = new HashMap<String, Object>();    
		List<Vendor> vendorList = null; 
		try
		{
			vendorList = service.getVendorList(vendorNo,vendorDesc,country,conceptShortName,searchMode);
			if(vendorList != null)
			{
				vendorMap = ApplicationUtil.getMap(vendorList);
			}
		}
		catch(Exception ex)
		{    		
    		//LOGGER.error("Erorr in getVendorList:: " + ex.getMessage()+"::StackTrace::" + ex);
    		System.out.println("Erorr in getVendorList:: " + ex.getMessage()+"::StackTrace::" + ex);
    		ex.printStackTrace();
    		vendorMap.put("error", "Error while retrieving vendors");			
		}
		return vendorMap;
	
	}

	
	@RequestMapping(params = "action=getSku")    
	public @ResponseBody Map<String, Object> getSkuList(
		@RequestParam(value="vendorNo", required=false) String vendorNo,
		@RequestParam(value="vendorNos", required=false) List<Long> vendorNos,
		@RequestParam(value="sku", required=false) Integer sku,
		@RequestParam(value="skuDesc", required=false) String skuDesc,
		@RequestParam(value="venPartNo", required=false) String venPartNo,
		@RequestParam(value="country", required=false) String country,
		@RequestParam(value="conceptShortName", required=false) String conceptShortName,
		@RequestParam(value="searchMode", required=false) String searchMode
	    )
	{
		
		System.out.println("SearchFieldController getSkuList vendorNo = "+vendorNo +" vendorNos = "+vendorNos +" sku =  " +sku);
		System.out.println("SearchFieldController getSkuList skuDesc = "+skuDesc +" venPartNo = "+venPartNo);
		System.out.println("SearchFieldController getSkuList country = "+country +" conceptShortName = "+conceptShortName +" searchMode = "+searchMode);
		
		Map<String, Object> skuMap = new HashMap<String, Object>();    
		List<Sku> skuList = null; 
		try
		{
			
			LOGGER.info("country::"+country+"::"+vendorNo+":::"+vendorNos+":: searchMode:"+searchMode);
//			country ="USA";
			if((sku == null && (skuDesc == null || (skuDesc != null && skuDesc.isEmpty())) 
					&& (venPartNo == null || (venPartNo != null && venPartNo.isEmpty())))) {
				return skuMap;
			} else{
				if(vendorNos != null &&  vendorNos.size() != 0){
					skuList = service.getSku(sku, skuDesc, venPartNo,  country, Integer.parseInt(""+vendorNos.get(0)),conceptShortName,searchMode);
				}else if (vendorNo != null && vendorNo.trim().length() != 0){
					skuList = service.getSku(sku, skuDesc, venPartNo,  country, null,conceptShortName, searchMode);
				}
				else{
					skuList = service.getSku(sku, skuDesc, venPartNo,  country,null,conceptShortName, searchMode);
				}
				if(skuList != null)
				{
					skuMap = ApplicationUtil.getMap(skuList);
				}
			}
		}
		catch(Exception ex)
		{    		
    		LOGGER.error("Erorr in getSkuList:: " + ex.getMessage() +"::StackTrace::" + ex);
    		skuMap.put("error", "Error while retrieving skus");			
		}
		return skuMap;
	
	}
	
	@RequestMapping(params = "action=getEventNumber")    
	public @ResponseBody Map<String, Object> getEventNumberList(	    		
		//@RequestParam(value="vendorNo", required=false) List<Long> vendorNo,
		//@RequestParam(value="vendorDesc", required=false) String vendorDesc,
		@RequestParam(value="vendorDesc", required=false) String eventNumber,
		@RequestParam(value="country", required=false) String country,
		@RequestParam(value="conceptShortName", required=false) String conceptShortName
		//@RequestParam(value="searchMode", required=false) String searchMode
	    )
	{
		//LOGGER.info("country::"+country+":: searchMode:"+searchMode);
		System.out.println("SearchFieldController getEventNumberList eventNumber = "+eventNumber);
		//System.out.println("SearchFieldController getEventNumberList vendorNo = "+vendorNo +" vendorDesc = "+vendorDesc +" country =  " +country);
		System.out.println("SearchFieldController getEventNumberList conceptShortName = "+country +" searchMode = "+country);
		
		Map<String, Object> vendorMap = new HashMap<String, Object>();    
		//List<EventNumber> eventNumberList = null; 
		List<EventNumber> eventNumberList = new ArrayList<EventNumber>();		
		
		EventNumber eventNumber_1 =new EventNumber();		
		EventNumber eventNumber_2 =new EventNumber();		
		EventNumber eventNumber_3 =new EventNumber();
		EventNumber eventNumber_4 =new EventNumber();
		EventNumber eventNumber_5 =new EventNumber();
		
		eventNumber_1.setEventNumber(Long.valueOf(111));
		eventNumber_1.setEventDesc("Test 11");
		
		eventNumber_2.setEventNumber(Long.valueOf(1115));
		eventNumber_2.setEventDesc("Test 11115");
		
		eventNumber_3.setEventNumber(Long.valueOf(11116));
		eventNumber_3.setEventDesc("Test 11116");
		
		eventNumber_4.setEventNumber(Long.valueOf(222));
		eventNumber_4.setEventDesc("Test 22222");
		eventNumber_5.setEventNumber(Long.valueOf(222225));
		eventNumber_5.setEventDesc("Test 222225");
		
		eventNumberList.add(eventNumber_1);
		eventNumberList.add(eventNumber_2);
		eventNumberList.add(eventNumber_3);
		eventNumberList.add(eventNumber_4);
		eventNumberList.add(eventNumber_5);
		
		try
		{
			//vendorList = service.getVendorList(vendorNo,vendorDesc,country,conceptShortName,searchMode);
			if(eventNumberList != null)
			{
				vendorMap = ApplicationUtil.getMap(eventNumberList);
			}
		}
		catch(Exception ex)
		{    		
    		//LOGGER.error("Erorr in getVendorList:: " + ex.getMessage()+"::StackTrace::" + ex);
    		System.out.println("Erorr in getVendorList:: " + ex.getMessage()+"::StackTrace::" + ex);
    		ex.printStackTrace();
    		vendorMap.put("error", "Error while retrieving vendors");			
		}
		return vendorMap;
	
	}
	
	/*
	 //searchMode: venNameMode.getText(),    
	 //vendorDesc: vendorName.getValue(),
	 eventNumber: eventNumber.getValue(),
    userId: params.userid,
    lang: params.lang,
    country: params.country,
    //concept: params.concept
    concept: 'BB',
    conceptShortName: 'BB'
    */
	
	/*@RequestMapping(params = "action=getDept")    
	public @ResponseBody Map<String, Object> getDepartmentList(
		@RequestParam(value="dept", required=false) Integer dept,
		@RequestParam(value="subDept", required=false) Integer subDept,
		@RequestParam(value="deptClass", required=false) Integer deptClass
	    )
	{
		Map<String, Object> deptMap = new HashMap<String, Object>();    
		List<Department> deptList = null; 
		try
		{
			deptList = service.getDepartment(dept, subDept, deptClass);
			if(deptList != null)
			{
				deptMap = SOUtil.getMap(deptList);
			}
		}
		catch(Exception ex)
		{    		
    		LOGGER.error("Erorr in getDepartmentList:: " + ex.getMessage());
    		deptMap.put("error", "Error while retrieving department");			
		}
		return deptMap;
	
	}*/
	
	
	@RequestMapping(params = "action=getMerchandise")    
	public @ResponseBody Map<String, Object> getMerchList(
		@RequestParam(value="merchAnalyzer", required=true) String merchAnalyzer,
		@RequestParam(value="country", required=true) String country,
		@RequestParam(value="concept", required=true) String concept
		)
	{
		System.out.println("SearchFiedlController ############## merchAnalyzer = "+merchAnalyzer);
		System.out.println("SearchFiedlController ############## concept = "+concept +" country = "+country);
		Map<String, Object> merchMap = new HashMap<String, Object>();    
		List<MerchAnalyzer> merchList = null; 
		try
		{
			if(merchAnalyzer != null && !merchAnalyzer.isEmpty()){
				merchList = service.getMerchAnalyzer(merchAnalyzer,country, concept);
				if(merchList != null)
				{
					merchMap = ApplicationUtil.getMap(merchList);
				}
			}
		}
		catch(Exception ex)
		{    		
    		LOGGER.error("Erorr in getMerchList:: " + ex.getMessage() +"::StackTrace::" + ex);
    		ex.printStackTrace();
    		merchMap.put("error", "Error while retrieving merchandise");			
		}
		return merchMap;
	
	}

}
