package com.bedbath.ssm.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bedbath.ssm.common.util.ApplicationUtil;
import com.bedbath.ssm.model.UserPrivilegeModel;
import com.bedbath.ssm.service.AppSecurityService;
import com.bedbath.security.service.SecurityService;
	
@Controller
@RequestMapping(value = "/index.htm")
public class IndexController {

	@Autowired(required = true)
	private SecurityService secService;
	@Autowired(required = true)
	AppSecurityService appSecService;

	private static Logger logger = LoggerFactory.getLogger(IndexController.class);
	protected static Map<String, String> conceptMap = new HashMap<String, String>(2);
	
	static{
		conceptMap.put("001", "BB:BEDBATH:10");
		conceptMap.put("002", "HN:HARMON:30");
		conceptMap.put("003", "CT:CTS:20");
		conceptMap.put("004", "BU:BABY:40");
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		// ASM  WEBSO   SKUINQ
		//String appCode ="WEBSO";	
		String appCode ="SIGNMAINT";	
		appCode = appCode.toUpperCase();
		Map<String, String> paramMap = null;
		ModelAndView mv = null;
		
		// Logic added for developer test link
		String action = request.getParameter("action");
		
		if (action != null && action.equals("test") )
		{
			paramMap = getTestMap(request);
		}
		else
		{
			// get encoded parameter
			String encodedParam = request.getQueryString();
			// decode encoded parameter
			paramMap = ApplicationUtil.decodeAsMap(encodedParam);
		}
		
		mv = getModel(request, paramMap, appCode);
		
		return mv;
	}	

	///////////SkuInqu --------------
	
	
	// Pull non decoded parameters from development test link
		protected Map<String, String> getTestMap(HttpServletRequest request) {
			Map<String, String> paramMap = new HashMap<String, String>();
			if (request.getParameter("action") != null) {
				paramMap.put("action", request.getParameter("action"));
			}
			paramMap.put("country", request.getParameter("country"));
			paramMap.put("concept", request.getParameter("concept"));
			paramMap.put("conceptShortName", request.getParameter("conceptShortName"));
			paramMap.put("strnum", request.getParameter("strnum"));
			paramMap.put("fullname", request.getParameter("fullname"));
			paramMap.put("lang", request.getParameter("lang"));
			paramMap.put("jdausername", request.getParameter("jdausername"));
			if (request.getParameter("pstore") != null) {
				paramMap.put("pstore", request.getParameter("pstore"));
			} else {
				paramMap.put("pstore", request.getParameter("strnum"));
			}
			return paramMap;
		}

		protected ModelAndView getModel(HttpServletRequest request, Map<String, String> paramMap, String appCode) {
			
			System.out.println("IndexController getModel()  #################");
			int strnum = 0;
			String userid = null;
			String country = null;
			String bednetConcept = null;
			String concept = null;
			String conceptShortName = null;
			String storeAccessList = "";
			String fullname = null;
			String maintenanceStartTime = null;
			String maintenanceEndTime = null;
			String userAccessError = "";
			String countrylist = "";
			String langlist = "";
			String userlang = null;
			String countryConceptlist = "";
			String navCards = "";
			String lookupVipUrl = "";
			if (paramMap.get("strnum") != null && !paramMap.get("strnum").equals("undefined")) {
				strnum = Integer.parseInt((String) paramMap.get("strnum"));
			}
			userid = (String) paramMap.get("jdausername");
			country = (String) paramMap.get("country");
			bednetConcept = (String) paramMap.get("concept"); // value from bednet
			conceptShortName = (String) paramMap.get("conceptShortName");
			fullname = (String) paramMap.get("fullname");
			if (paramMap.get("language") != null && !paramMap.get("language").equals("undefined")) {
				userlang = paramMap.get("language").toLowerCase();
			}
			boolean isMultiStoreUser = false;
			boolean isAllStoreUser = false;
			int pstore = strnum;
			
			System.out.println("IndexController getModel()  ################# userid = "+userid +" country = "+country);
			System.out.println("IndexController getModel()  ################# bednetConcept = "+bednetConcept +" conceptShortName = "+conceptShortName);
			
			
			
			
			List<String> appPrinters = new ArrayList<String>();
			try {
				pstore = Integer.parseInt((String) paramMap.get("pstore"));
			} catch (Exception e) {
				logger.debug("Error reading/parsing pstore");
			}

			ModelAndView model = new ModelAndView("start");

			if (bednetConcept == null) {
				// Throw a proper error message
				logger.info(userAccessError);
				model = new ModelAndView("error");
				model.getModel().put("error", "Concept is missing");
				model.getModel().put("lang", "en");
				return model;
			}

			// meaning we are coming from bednet, otherwise this code is not
			// required
			if (conceptShortName == null) {
				String conceptValue = conceptMap.get(bednetConcept);
				String[] conceptValues = conceptValue.split(":");
				conceptShortName = conceptValues[0]; // replace 001/004 with BB/BU
				concept = conceptValues[1];

			} else if (conceptShortName != null && conceptShortName.length() == 2) {
				concept = bednetConcept;
			}

			userid = userid.toUpperCase();

			logger.debug(userid + "::" + strnum + "::" + appCode + "::" + country + "::" + concept);

			try {

				if ("switchLanguage".equals(paramMap.get("action"))) {
					secService.updateUserLanguage(userid, paramMap.get("lang").toLowerCase());
				}

				List<Map<String, Object>> countryConcepts = secService.getCountryConcept(userid, appCode);

				if (countryConcepts != null) {
					for (Map<String, Object> countryConceptmap : countryConcepts) {
						if (countryConceptlist.equals("")) {
							countryConceptlist = (String) countryConceptmap.get("COUNTRY") + "_"
									+ (String) countryConceptmap.get("CONCEPT");
						} else {
							countryConceptlist = countryConceptlist + "," + (String) countryConceptmap.get("COUNTRY") + "_"
									+ (String) countryConceptmap.get("CONCEPT");
						}
					}

				} else {
					userAccessError = "country concept list is null";
					logger.info(userAccessError);
				}

				Map result = secService.processInitPrivProp(userid, strnum, appCode, country, concept);

				lookupVipUrl = secService.getProperty("APPSEC", null, null, "LOOKUP_VIPURL", userid);
				request.setAttribute("vipUrl", lookupVipUrl);

				//TODO: Not used yet.  Add property when we add the second app to the menu
				//navCards = secService.getProperty(appCode, country, concept, "CARD_NAVIGATION", userid);
				//request.setAttribute("navCards", navCards);
				
				//TODO: 8/22/17 Troubleshooting why DEV is in Spanish. Eliminating this as possiblilty
				//userlang = ((String) result.get("@userlang"));
				if (userlang != null) {
					userlang = userlang.toLowerCase();
				}

				int retVal = ((BigDecimal) result.get("@isUserValid")).intValue();

				// Passed application security -- get properties
				if (retVal == 0) {
					if (result != null && result.size() > 0) {
						List<HashMap<String, Object>> userPrvs = (List) result.get("prvCursor");

						List<HashMap<String, Object>> appProperties = (List) result.get("prpCursor");
						if (appProperties != null) {
							Map<String, Object> propMap = new HashMap<String, Object>();
							for (HashMap property : appProperties) {
								String prop = (String) property.get("PROPERTY_NAME");
								Object value = property.get("PROPVALUE");
								if (prop.contains("_PRINTER")) {
									// add printerDescription
									appPrinters.add(prop.trim());
								} else {
									propMap.put(prop, value);
								}
							}

							maintenanceStartTime = (String) propMap.get("MAINTENANCE_STARTTIME");
							maintenanceEndTime = (String) propMap.get("MAINTENANCE_ENDTIME");
						}

						// list of user privileges; includes both associated to a
						// role, or special user privileges that are not tied to
						// role
						Map<String, Object> userPrivMap = new HashMap<String, Object>();
						if (userPrvs != null) {
							for (HashMap property : userPrvs) {
								String prop = (String) property.get("PRIVILEGE_NAME");
								Object value = property.get("PRIVILEGE_DESCRIPTION");
								userPrivMap.put(prop, value);
							}
						}

						Calendar now = Calendar.getInstance();
						Calendar start = Calendar.getInstance();
						Calendar end = Calendar.getInstance();
						int startHour = start.get(Calendar.HOUR_OF_DAY);
						int startMinute = start.get(Calendar.MINUTE);
						int endHour = end.get(Calendar.HOUR_OF_DAY);
						int endMinute = end.get(Calendar.MINUTE);
						if (maintenanceStartTime != null) {
							maintenanceStartTime = maintenanceStartTime.trim();
							startHour = Integer
									.parseInt(maintenanceStartTime.substring(0, maintenanceStartTime.indexOf(":")));
							startMinute = Integer.parseInt(maintenanceStartTime
									.substring(maintenanceStartTime.indexOf(":") + 1, maintenanceStartTime.length()));
							logger.debug("maintenanceStartTime :" + maintenanceStartTime);
						}
						if (maintenanceEndTime != null) {
							maintenanceEndTime = maintenanceEndTime.trim();
							endHour = Integer.parseInt(maintenanceEndTime.substring(0, maintenanceEndTime.indexOf(":")));
							endMinute = Integer.parseInt(maintenanceEndTime.substring(maintenanceEndTime.indexOf(":") + 1,
									maintenanceEndTime.length()));
						}
						start.set(Calendar.MINUTE, startMinute);
						// start.set(Calendar.HOUR, startHour);
						start.set(Calendar.HOUR_OF_DAY, startHour);
						end.set(Calendar.MINUTE, endMinute);
						// end.set(Calendar.HOUR, endHour);
						end.set(Calendar.HOUR_OF_DAY, endHour);
						if (now.after(start) && now.before(end) && userPrivMap.get("APPLICATION_OWNER") == null) {
							model = new ModelAndView("maintenanceDown");
							model.getModel().put("error", "maintenanceDown");
							model.getModel().put("lang", userlang);
							return model;
						}

						List<HashMap<String, Object>> appCountry = (List) result.get("appCntryLst");

						if (appCountry != null) {
							for (HashMap countryMap : appCountry) {
								if (countrylist.equals("")) {
									countrylist = (String) countryMap.get("COUNTRY");
								} else {
									countrylist = countrylist + "," + (String) countryMap.get("COUNTRY");
								}
							}
						}

						HashMap<String, String> countryStoreMap = (HashMap<String, String>) result.get("cntryStoreLst");

						// set the store access list attributes for each country
						if (countryStoreMap != null) {
							Iterator<String> iter = countryStoreMap.keySet().iterator();
							String cntry = "";
							while (iter.hasNext()) {
								cntry = (String) iter.next();
								storeAccessList = (String) countryStoreMap.get(cntry);
								storeAccessList = storeAccessList != null ? storeAccessList.trim() : storeAccessList;
								logger.debug("storeAccessList:" + cntry + ":" + storeAccessList);
								// If LDAP Stores and JDA 99999, then restrict to
								// LDAP stores only
								if (storeAccessList != null && storeAccessList.trim().equals("99999")) {
									storeAccessList = ""; // means All store access
								}
								logger.debug("storeAccessList after checking for 99999:" + cntry + ":" + storeAccessList);

								if (storeAccessList != null && storeAccessList.trim().length() > 0) {
									model.getModel().put(cntry, "," + storeAccessList + ",");
									request.setAttribute(cntry, "," + storeAccessList + ",");
								} else {
									model.getModel().put(cntry, storeAccessList);
									request.setAttribute(cntry, storeAccessList);
								}
							}
						}

						List<HashMap<String, Object>> languageLst = (List) result.get("languageLst");
						if (languageLst != null) {
							for (HashMap langMap : languageLst) {
								if (langlist.equals("")) {
									langlist = ((String) langMap.get("LANGUAGE")).toLowerCase();
								} else {
									langlist = langlist + "," + ((String) langMap.get("LANGUAGE")).toLowerCase();
								}
							}
						}

						isMultiStoreUser = new Boolean((String) result.get("isMultiStoreUser"));
						isAllStoreUser = new Boolean((String) result.get("isAllStoreUser"));

						// app on stores for appcode and concept
						List<Map<String, Object>> appOnStoresList = secService.getAppOnStores(appCode, concept);
						List<Map<String, Object>> allAppOnStoresList = secService.getAllAppOnStores(appCode);
						if (allAppOnStoresList != null) {
							StringBuffer allStr = new StringBuffer();
							Map<BigDecimal, BigDecimal> tempMap = new HashMap<BigDecimal, BigDecimal>();
							for (Map<String, Object> allApOnStoreMap : allAppOnStoresList) {
								BigDecimal strNo = (BigDecimal) allApOnStoreMap.get("STOREID");
								if (!tempMap.containsKey(strNo)) {
									if (allStr.length() == 0) {
										allStr.append(":" + (BigDecimal) allApOnStoreMap.get("STOREID") + ":");
										tempMap.put(strNo, strNo);
									} else {
										allStr.append("," + ":" + (BigDecimal) allApOnStoreMap.get("STOREID") + ":");
										tempMap.put(strNo, strNo);
									}
								}
							}
							model.getModel().put("ALL_APPON", allStr.toString());
							request.setAttribute("ALL_APPON", allStr.toString());
							allStr.delete(0, allStr.length());
						}

						if (appOnStoresList != null) {
							String appOnCountry = "";
							String tempAppOnCountry = null;
							StringBuffer appOnCountryStores = new StringBuffer();
							for (Map<String, Object> appOnStoreMap : appOnStoresList) {
								tempAppOnCountry = (String) appOnStoreMap.get("COUNTRY");

								if (!appOnCountry.equals(tempAppOnCountry)) {
									if (!"".equals(appOnCountry)) {
										System.out.println(appOnCountry + "_APPON" + "    " + appOnCountryStores);

										if (appOnCountryStores.indexOf("99998") != -1) {

											model.getModel().put(appOnCountry + "_APPON", "");
											request.setAttribute(appOnCountry + "_APPON", "");
										} else {

											model.getModel().put(appOnCountry + "_APPON", appOnCountryStores.toString());
											request.setAttribute(appOnCountry + "_APPON", appOnCountryStores.toString());
										}

									}
									appOnCountryStores.delete(0, appOnCountryStores.length());
									appOnCountry = tempAppOnCountry;
									appOnCountryStores.append(":" + (BigDecimal) appOnStoreMap.get("STOREID") + ":");

								} else {

									appOnCountryStores.append("," + ":" + (BigDecimal) appOnStoreMap.get("STOREID") + ":");
								}

							}

							if (!"".equals(appOnCountry)) {

								if (appOnCountryStores.indexOf("99998") != -1) {

									model.getModel().put(appOnCountry + "_APPON", "");
									request.setAttribute(appOnCountry + "_APPON", "");
								} else {

									model.getModel().put(appOnCountry + "_APPON", appOnCountryStores.toString());
									request.setAttribute(appOnCountry + "_APPON", appOnCountryStores.toString());
								}

							}

							/* Get Store Notifications */
							/*
							 * 1- Set Routing Data Source 2- Call Procedure return
							 * the values in the map
							 */

							/* End */

						}

					}

				} else if (retVal == 1) {
					userAccessError = "securityError1::" + " : " + strnum + "/" + userid;
				} else if (retVal == 2) {
					userAccessError = "securityError2::" + " : " + userid;
				} else if (retVal == 3) {
					userAccessError = "securityError3::" + " : " + strnum + "/" + userid;
				} else if (retVal == 4) {
					userAccessError = "securityError4::" + " : " + userid;
				}

			} catch (Exception ex) {
				logger.debug("Security Controller Exception:", ex);
				ex.printStackTrace();
				if (ex.getMessage().contains("connection")) {
					userAccessError = "securtyError0::" + " : " + strnum + "/" + userid;
				} else {
					userAccessError = ex.getMessage();
				}
				logger.info(userAccessError);
			}

			if (!userAccessError.equals("")) {
				logger.info(userAccessError);
				model = new ModelAndView("error");
				model.getModel().put("error", userAccessError);
				model.getModel().put("lang", userlang);
			}

			String appPrintersString = "";

			if (appPrinters != null) {
				appPrintersString = appPrinters.toString();
				appPrintersString = appPrintersString.replace("[", "").replace("]", "");
			}
			
			System.out.println("IndexController getModel()  ################# 1 userid = "+userid +" country = "+country);
			System.out.println("IndexController getModel()  ################# 2 bednetConcept = "+bednetConcept +" conceptShortName = "+conceptShortName);
			System.out.println("IndexController getModel()  ################# 3 strnum = "+strnum +" pstore = "+pstore );
			System.out.println("IndexController getModel()  ################# 4 lookupVipUrl = "+lookupVipUrl);
			System.out.println("IndexController getModel()  ################# 5 userlang = "+userlang);			
			//lookupVipUrl = "http://192.168.192.24/";

			userlang = userlang != null ? userlang.toLowerCase() : "en";
			model.getModel().put("jdausername", userid);
			//model.getModel().put("navCards", navCards);
			model.getModel().put("country", country);
			model.getModel().put("concept", concept);
			model.getModel().put("conceptShortName", conceptShortName);
			model.getModel().put("strnum", strnum);
			model.getModel().put("pstore", pstore);
			model.getModel().put("lang", userlang);
			model.getModel().put("userid", userid);
			model.getModel().put("fullname", fullname);
			model.getModel().put("countrylist", countrylist);
			model.getModel().put("langlist", langlist);
			model.getModel().put("multiStoreUser", isMultiStoreUser);
			model.getModel().put("allStoreUser", isAllStoreUser);
			model.getModel().put("countryConceptlist", countryConceptlist);
			model.getModel().put("appPrinters", appPrintersString);
			model.getModel().put("vipUrl", lookupVipUrl);
			
			model.getModel().put("maSearchUrl", lookupVipUrl + "elasticsearch/lookups5/" +"lookup_merchandiseanalyzer/_search?source=" );
			model.getModel().put("skuDescSearchUrl", lookupVipUrl + "elasticsearch/lookups5/" +"lookup_sku/_search?source=" );
			model.getModel().put("eventNumberUrl", lookupVipUrl + "elasticsearch/lookups5/" +"lookup_event/_search?source=" );	
			model.getModel().put("vendorNameUrl", lookupVipUrl + "elasticsearch/lookups5/" +"lookup_vendor/_search?source=" );
		
			return model;
		}

}