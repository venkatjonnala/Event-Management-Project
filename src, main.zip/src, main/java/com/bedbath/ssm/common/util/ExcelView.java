package com.bedbath.ssm.common.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.bedbath.common.util.AppUtil;

public class ExcelView extends AbstractExcelView {

	public static final String EXCEL_LIST_KEY = "results";
	public static final String EXCEL_HDR_KEY = "gridColHeaderList";
	public static final String SHEET_NAME_KEY = "sheetName";

	protected void buildExcelDocument(Map model, HSSFWorkbook workbook,
			HttpServletRequest request, HttpServletResponse response) {

		List gridColHeaderList = null;
		

		// Create sheet
		String sheetName = (String) model.get(SHEET_NAME_KEY);
		if (sheetName == null) {
			sheetName = "Search List";
		}
		HSSFSheet sheet = workbook.createSheet(sheetName);

		// Creating Style to Show Additional Detail in Second line in Description Column.
		CellStyle cs = workbook.createCellStyle();
		cs.setWrapText(true);

		short currentRow = 0;
		// Write Row for Header
		Object object = model.get(EXCEL_HDR_KEY);
		if (object != null) {
			gridColHeaderList = (List) model.get(EXCEL_HDR_KEY);
		}

		if (gridColHeaderList != null && !gridColHeaderList.isEmpty()) {

			Iterator it = gridColHeaderList.iterator();
			while (it.hasNext()) {

				GridColumnHeader gch = (GridColumnHeader) it.next();
				HSSFCell header = getCell(sheet, currentRow, gch.getOrder());
				setText(header, gch.getHeader());
			}
			object = model.get(EXCEL_HDR_KEY);
			List rowList = null;
			if (object != null) {
				rowList = (List) model.get(EXCEL_LIST_KEY);
				if(rowList==null || rowList.isEmpty())
					rowList = (List) model.get("objectList");
			}
			if (rowList != null && !rowList.isEmpty()) {
				// Write Rows
				Iterator rowIter = rowList.iterator();
				while (rowIter.hasNext()) {

					currentRow++;
					HSSFRow row = sheet.createRow(currentRow);
					Map map = (Map) rowIter.next();
					// Map map = object.getKeyValues();
					it = gridColHeaderList.iterator();
					logger.debug(map);
					while (it.hasNext()) {
						GridColumnHeader gch = (GridColumnHeader) it.next();
						Object value=map.get(gch.getColumn());
						String itemType=" ", perdescr="";
						
						// To check whether item is LTL/Personalized.
						if(map.get("itemtype")!= null){
							itemType = map.get("itemtype").toString();
						}
						
						if(map.get("perdescr")!= null){
							perdescr = map.get("perdescr").toString().trim();
						}
						
						value=(value==null)?"":value;
						if(value instanceof String  && ((String)value).trim().equals("null"))
							value="";
						logger.debug(gch.getColumn() + "   " + gch.getColumn()
								+ " value in database "
								+ value);
						
						row.createCell(gch.getOrder()).setCellValue(
								String.valueOf(map.get(gch.getColumn())));
						HSSFCell cell=row.createCell(gch.getOrder());
						/*if(value instanceof Integer){
							cell.setCellValue((Integer)value);
							cell.setCellType(cell.CELL_TYPE_NUMERIC);
						}else if(value instanceof Double){
							cell.setCellValue((Double)value);
						}else if(value instanceof Date){
							cell.setCellValue((Date)value);
						}else if(value instanceof Boolean){
							cell.setCellValue((Boolean)value);	
						}else{
							cell.setCellValue(String.valueOf(value));	
						}*/
						
						cell.setCellValue(String.valueOf(value));
						

					}

				}
			} else {
				currentRow++;
				HSSFRow row = sheet.createRow(currentRow);
				row.createCell(1).setCellValue("No Records found");
			}
		}

	}

}
