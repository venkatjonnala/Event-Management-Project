package com.bedbath.ssm.common.util;


public class AppConstants {
	public static final String VENDOR_NO = "vendorNo";
	public static final String VENDOR_DESC = "vendorDesc";
    public static final String ELASTIC_HOSTNAME_PROP="elasticHostname";
    public static final String ELASTIC_PORTNO_PROP="elasticPortno";
    public static final  String RESOURCE_FILENAME = "SO";
    //public static final String ELASTIC_CLIENT_TRANSPORT = "client.transport.sniff";
    public static final String ELASTIC_VENDOR = "lookup_vendor_bb";    
    public static final String ELASTIC_VENDOR_HARMON = "lookup_vendor_harmon";    
    public static final String ELASTIC_VENDOR_CANADA = "lookup_vendor_can";
    public static final String ELASTIC_VENDOR_MEXICO = "lookup_vendor_mex";
    public static final String ELASTIC_VENDOR_CTS = "lookup_vendor_cts";
    public static final String ELASTIC_VENDOR_DESC = "ASNAME";    
    public static final String ELASTIC_VENDOR_NO = "S_ASNUM";
    public static final String ELASTIC_VENDOR_ASLEAD = "ASLEAD";
    public static final String ELASTIC_VEN_NO = "ASNUM";
    public static final String ELASTIC_VEN_CUR = "ASCURC";
    
    public static final String ELASTIC_VENDOR_PART_NO = "IVNDP#";    
    public static final String ELASTIC_VENDOR_PART_NO_SORT = "IVNDP#._IVNDP#";    
    public static final String ORDER_TYPE_PROC = "SOEOTYPE";    
    public static final String ORDER_TYPE_PROC_CUR = "ordtypeCursor";    
    public static final String STORE_NO_PARAM = "@storeNo";
    public static final String ALL_COL = "All";
    public static final String APPROVED_COL = "Approved";
    public static final String UNAPPROVED_COL = "UnApproved";
    public static final String RFGUN_STR = "RF - Gun";
    public static final String RFGUN_COL = "RFGun";
    public static final String ELASTIC_SKU_USA = "lookup_sku_bb";    
    public static final String ELASTIC_SKU_CAN = "lookup_sku_can";
    public static final String ELASTIC_SKU_MEX = "lookup_sku_mex";  
    public static final String ELASTIC_SKU_HN = "lookup_sku_harmon";    
    public static final String ELASTIC_SKU_CTS = "lookup_sku_cts";    
    public static final String ELASTIC_SKU_DESC = "IDESCR";    
    public static final String ELASTIC_SKU_DESC_SORT = "IDESCR._IDESCR";    
    public static final String ELASTIC_SKUNO_STR = "S_INUMBR";    
    public static final String ELASTIC_SKUNO = "INUMBR";    
    public static final String ELASTIC_SKU_KIT = "ISET";    
    public static final String ELASTIC_SKU_DEPT = "IDEPT";    
    public static final String ELASTIC_SKU_SUB_DEPT = "ISDEPT";    
    public static final String ELASTIC_SKU_CLASS = "ICLAS";    
    

    public static final String ELASTIC_EXCEPTION_SKU = "lookup_exception_sku";    
    public static final String ELASTIC_STORE_NUM = "STORE_NUM";    
    public static final String ELASTIC_CONCEPT = "CONCEPT";    

    public static final String ELASTIC_DEPARTMENT = "lookup_department";    
    public static final String ELASTIC_DEPT_NO = "S_IDEPT";    
    public static final String ELASTIC_SUB_DEPT_NO = "S_ISDEPT";    
    public static final String ELASTIC_DEPT_CLASS = "S_ICLAS";    

    public static final String ELASTIC_MERCHANDISE_ANALYZER = "lookup_merchandiseanalyzer";    
    public static final String ELASTIC_MERCHANDISE_ANALYZER_HN = "lookup_merchandiseanalyzer_harmon";    
    public static final String ELASTIC_MERCHANDISE_ANALYZER_CTS = "lookup_merchandiseanalyzer_cts";    
    public static final String ELASTIC_MERCHANDISE_ANALYZER_CA = "lookup_merchandiseanalyzer_can";    
    public static final String ELASTIC_MERCH_CODE = "CODE";    
    public static final String ELASTIC_MERCH_DESC = "NAMESORT";    
    public static final String ELASTIC_MERCH_COMBINE = "GP_COMBINED";    
    public static final String ELASTIC_MERCH_COMBINE_SORT = "GP_COMBINED.GP_COMBINED_SORT";    

    public static final String ELASTIC_INVVEN = "lookup_vendor_ven_bb";    
    public static final String ELASTIC_INVVEN_HN = "lookup_vendor_ven_harmon";    
    public static final String ELASTIC_INVVEN_CTS = "lookup_vendor_ven_cts";
    public static final String ELASTIC_INVVEN_CA = "lookup_vendor_ven_can";
    public static final String ELASTIC_INVVEN_MX = "lookup_vendor_ven_mex";
    public static final String ELASTIC_INVVEN_VENNO = "IVVNUM";    
    public static final String ELASTIC_INVVEN_STRNO = "IVSTOR";    
    public static final String ELASTIC_INVVEN_DEPT = "IVDEPT";    
    public static final String ELASTIC_INVVEN_SUBDEPT = "IVSDPT";    
    public static final String ELASTIC_INVVEN_CLAS = "IVCLAS";    
    public static final String ELASTIC_INVVEN_CP = "IVSDPK";    
    public static final String ELASTIC_INVVEN_VENDOR_PART_NO = "VPN";    
    public static final String ELASTIC_INVVEN_VENDOR_PART_NO_SORT = "VPN.VPN_SORT";    

    public static final String ELASTIC_UPC = "lookup_upc_bb";    
    public static final String ELASTIC_UPC_HN = "lookup_upc_harmon";    
    public static final String ELASTIC_UPC_CA = "lookup_upc_can";
    public static final String ELASTIC_UPC_MX = "lookup_upc_mex";
    public static final String ELASTIC_UPC_CTS = "lookup_upc_cts";
    public static final String ELASTIC_UPCNO = "IUPC";
    

    public static final String ELASTIC_CURCOD = "lookup_currency_cd";    
    public static final String ELASTIC_CURCOD_HN = "lookup_currency_cd_harmon";    
    public static final String ELASTIC_CURCOD_CA = "lookup_currency_cd_can";
    public static final String ELASTIC_CURCOD_MX = "lookup_currency_cd_mex";
    public static final String ELASTIC_CURCOD_CTS = "lookup_currency_cd_cts";
    public static final String ELASTIC_CUR_CODE = "CURCOD";    
    public static final String ELASTIC_CUR_HOME = "CURHOM";
    
    public static final String DEFAULT_SCHEDULE_NAME = "CORPORATE";

    public static final String TOP_100_SEARCH_TYPE = "top100";
    
    public static final String EXCEEDS_MAX_MSG = "Search results exceeds max count (XXXX). Please refine search criteria";
    
    public static final String SOSEARCH_INDEX = "sosearch";
    // Instant savings elastic Index
    public static final String LOOKUP_INSTANT_SAVE = "lookup_instant_save";
    
}
