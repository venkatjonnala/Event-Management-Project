package com.bedbath.ssm.common.util;

import java.util.List;
import java.util.Map;

public class Result {
	List results;
	long count;

	public List getResults() {
		return results;
	}
	public void setResults(List results) {
		this.results = results;
	}
	public long getCount() {
		if(count==0&&results!=null){
			count=results.size();
		}
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	
	
	

}
