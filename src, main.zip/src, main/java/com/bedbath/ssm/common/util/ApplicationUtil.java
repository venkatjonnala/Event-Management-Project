package com.bedbath.ssm.common.util;

import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bedbath.ssm.exception.SSMException;
//import com.bedbath.ssm.model.ExcelCapable;
import com.bedbath.ssm.model.JSONCapable;

public class ApplicationUtil {
	private static Logger logger = LoggerFactory.getLogger(ApplicationUtil.class);
	public static final int EXCEL_SHEET_SIZE = 65536;
	public static final String TIMESTAMP_FORMAT = "yyyy-MM-dd-HH.mm.ss.SSSSSS";
	public static final String DATETIME_FORMAT = "yyyy-MM-dd-HH.mm.ss";
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String TIME_FORMAT = "HH.mm.ss";
	public static final String OUTPUT_DATE_FORMAT = "MM/dd/yyyy";
	public static final String OUTPUT_TIME_FORMAT = "h:mm a";

    public static String delimit(String str, String delimiter) {		
		return delimiter + str + delimiter;		   
    }
    
    public static boolean isNotBlank(final String str) {
		boolean notBlank = false;
		if (str != null && str.trim().length() > 0) {
			notBlank = true;
		}
		return notBlank;
	}
	public static String getJsonString(List<? extends JSONCapable> list, Long totalCount, Integer start,
			Integer limit) {
		JSONObject results = new JSONObject();
		JSONArray array = new JSONArray();

		if (list == null || list.size() == 0) {
			return getEmptyJsonString();
		}

		if (start != null && limit != null) {
			for (int i = start.intValue(); (i < start.intValue() + limit.intValue() && i < list.size()); i++) {
				JSONCapable obj = (JSONCapable) list.get(i);
				array.add(obj.toJSON());
			}
		} else {
			for (JSONCapable obj : list)
				array.add(obj.toJSON());
		}

		if (totalCount != null)
			results.put("total", totalCount);
		else
			results.put("total", new Long(list.size()));

		results.put("results", array);
		return results.toString();
	}

	public static String getEmptyJsonString() {
		JSONObject results = new JSONObject();
		JSONArray array = new JSONArray();
		results.put("total", 0);
		results.put("results", array);
		return results.toString();
	}

	public static String getJsonString(List<? extends JSONCapable> list, long totalCount) {
		return getJsonString(list, new Long(totalCount), null, null);
	}

	public static String getJsonString(List<? extends JSONCapable> list, Integer start, Integer limit) {
		return getJsonString(list, null, start, limit);
	}

	/*
	public static String getExcelTable(List<? extends ExcelCapable> list) {
		if (list == null || list.size() == 0) {
			return getEmptyExcelTable();
		} else {
			StringBuffer results = new StringBuffer();
			results.append(
					"<head><style>table{mso-displayed-decimal-separator:\"\\.\";mso-displayed-thousand-separator:\"\\,\";}@page{margin:1.0in .75in 1.0in .75in;mso-header-margin:.5in;mso-footer-margin:.5in;}tr{mso-height-source:auto;}col{mso-width-source:auto;}.numberFormat{mso-style-parent:style0;mso-number-format:\"\\@\";border:.5pt solid windowtext;} .numberFormatCurrency{mso-style-parent:style0;mso-number-format:\"\\@\";text-align:right;border:.5pt solid windowtext;}.dateFormat{mso-number-format:\"Short Date\";border:.5pt solid windowtext;} .headerItem{padding-top:1px;padding-right:1px;padding-left:1px;mso-ignore:padding;color:windowtext;font-size:10.0pt;font-weight:700;font-style:normal;text-decoration:none;font-family:Arial, sans-serif;mso-font-charset:0;mso-number-format:General;text-align:center;vertical-align:bottom;border:.5pt solid windowtext;background:silver;mso-pattern:auto none;white-space:nowrap;}.bodyItem{padding-top:1px;padding-right:1px;padding-left:1px;mso-ignore:padding;color:windowtext;font-size:10.0pt;font-weight:500;font-style:normal;text-decoration:none;font-family:Arial, sans-serif;mso-font-charset:0;mso-number-format:General;text-align:general;vertical-align:bottom;border:.5pt solid windowtext;mso-background-source:auto;mso-pattern:auto;white-space:nowrap;}</style></head>");

			results.append("<TABLE>");
			results.append(list.get(0).getExcelHeader());
			for (ExcelCapable obj : list)
				results.append(obj.getExcelRow());
			results.append("</TABLE>");

			return results.toString();
		}
	}*/

	public static String getEmptyExcelTable() {
		StringBuffer results = new StringBuffer();

		results.append("<TABLE>");
		results.append("ERROR - No results to display");
		results.append("</TABLE>");

		return results.toString();
	}

	public static String getExcelFailureResponse(String msg) {
		StringBuffer results = new StringBuffer();

		results.append("<TABLE>");
		results.append(msg);
		results.append("</TABLE>");

		return results.toString();
	}

	public static Integer getIntegerObject(String param) {
		Integer paramInt = null;
		if (param != null) {
			try {
				paramInt = new Integer(param);
			} catch (Exception e) {
				// do nothing;
			}
		}
		return paramInt;
	}

	public static String getSuccessResponse() {
		JSONObject results = new JSONObject();
		results.put("success", "true");
		return results.toString();
	}

	public static String getFailureResponse(String errorMessage) {
		JSONObject results = new JSONObject();

		JSONObject reason = new JSONObject();
		reason.put("reason", errorMessage);

		results.put("success", "false");
		results.put("errors", reason);
		return results.toString();
	}

	/*
	 * public static String getFailureResponse(List<String> errorList){
	 * JSONObject results = new JSONObject(); results.put("success", "false");
	 * for(String errorMsg:errorList){ JSONObject reason = new JSONObject();
	 * reason.put("reason", errorMsg); results.put("errors", reason); }
	 * 
	 * return results.toString(); }
	 */

	/*
	public static void generateExcelResponse(HttpServletResponse response, String title,
			List<? extends ExcelCapable> list) throws ServletException, IOException {
		logger.debug("Generating Excel for: " + title);
		response.setContentType("application/vnd.ms-excel");
		StringBuffer results = new StringBuffer();

		results.append(
				"<head><style>table{mso-displayed-decimal-separator:\"\\.\";mso-displayed-thousand-separator:\"\\,\";}@page{margin:1.0in .75in 1.0in .75in;mso-header-margin:.5in;mso-footer-margin:.5in;}tr{mso-height-source:auto;}col{mso-width-source:auto;}.numberFormat{mso-style-parent:style0;mso-number-format:\"\\@\";border:.5pt solid windowtext;} .numberFormatCurrency{mso-style-parent:style0;mso-number-format:\"\\@\";text-align:right;border:.5pt solid windowtext;}.dateFormat{mso-number-format:\"Short Date\";border:.5pt solid windowtext;} .headerItem{padding-top:1px;padding-right:1px;padding-left:1px;mso-ignore:padding;color:windowtext;font-size:10.0pt;font-weight:700;font-style:normal;text-decoration:none;font-family:Arial, sans-serif;mso-font-charset:0;mso-number-format:General;text-align:center;vertical-align:bottom;border:.5pt solid windowtext;background:silver;mso-pattern:auto none;white-space:nowrap;}.bodyItem{padding-top:1px;padding-right:1px;padding-left:1px;mso-ignore:padding;color:windowtext;font-size:10.0pt;font-weight:500;font-style:normal;text-decoration:none;font-family:Arial, sans-serif;mso-font-charset:0;mso-number-format:General;text-align:general;vertical-align:bottom;border:.5pt solid windowtext;mso-background-source:auto;mso-pattern:auto;white-space:nowrap;}</style></head>");
		results.append("<TABLE>");
		if (list == null || list.size() == 0) {
			results.append(getEmptyExcelTable());
		} else if (list.size() > EXCEL_SHEET_SIZE) {
			results.append(getExcelFailureResponse(
					"Number of records: " + list.size() + " exceeds excel sheet size.  Please refine your search."));
		} else {
			results.append(list.get(0).getExcelHeader());
			int i = 0;
			for (ExcelCapable obj : list) {
				results.append(obj.getExcelRow());
				i++;
				if (i == 100) {
					response.getWriter().write(results.toString());
					response.getWriter().flush();
					results.setLength(0);
					i = 0;
				}
			}
		}
		results.append("</TABLE>");
		response.getWriter().write(results.toString());
		response.getWriter().close();
		logger.debug("Excel file successfully generated:" + title);
	}*/



	

	public static HashMap<String, String> parseSortParameters(String sortParam) {
		HashMap<String, String> map = null;

		if (sortParam == null || sortParam.trim().length() == 0) {
			map = new HashMap<String, String>();
			return map;
		}
		logger.debug("sort parameters: " + sortParam);

		JSONParser parser = new JSONParser();
		try {
			StringReader reader = new StringReader(sortParam);
			Object obj = parser.parse(reader);

			JSONArray arr = (JSONArray) obj;
			JSONObject jsonObj = (JSONObject) arr.get(0);

			map = new HashMap<String, String>();
			map.put("property", (String) jsonObj.get("property"));
			map.put("direction", (String) jsonObj.get("direction"));

		} catch (Exception e) {
			logger.warn("Sku SORT Parameter value is invalid!!");
		}
		return map;
	}

	// Convert timestamp string "yyyy-MM-dd-HH.mm.ss.SSSSSS" to joda UTC datetime
	public static org.joda.time.DateTime getJodaDateTimeUTC(String stringTimestamp ,org.joda.time.DateTimeZone zone) {
		return getJodaDateTime(stringTimestamp, zone);
	}

	// Convert date string "yyyy-MM-dd" and time "HH.mm.ss" to joda UTC datetime
	public static org.joda.time.DateTime getJodaDateTimeUTC(String localStringDate, String localStringTime) {
		return getJodaDateTimeUTC(localStringDate, localStringTime, org.joda.time.DateTimeZone.getDefault());
	}

	// Convert date string "yyyy-MM-dd" and time "HH.mm.ss" to joda UTC datetime
	public static org.joda.time.DateTime getJodaDateTimeUTC(String localStringDate, String localStringTime,
			org.joda.time.DateTimeZone zone) {
		return convertJodaDateTimeToUTC(getJodaDateTimeLocal(localStringDate, localStringTime, zone));
	}

	// Convert date/time strings "yyyy-MM-dd" and "HH.mm.ss" to joda local
	// datetime
	public static org.joda.time.DateTime getJodaDateTimeLocal(String localStringDate, String localStringTime) {
		org.joda.time.DateTimeZone zone = org.joda.time.DateTimeZone.getDefault();
		return getJodaDateTimeLocal(localStringDate, localStringTime, zone);
	}

	// Convert timestamp string "yyyy-MM-dd-HH.mm.ss.SSSSSS" to joda local
	// datetime
	public static org.joda.time.DateTime getJodaDateTime(String localStringTimestamp, org.joda.time.DateTimeZone zone) {
		String dateFormat = TIMESTAMP_FORMAT;
		org.joda.time.format.DateTimeFormatter formatter = org.joda.time.format.DateTimeFormat.forPattern(dateFormat)
				.withZone(zone);

		// parsing in utc is safe, there are no gaps
		// parsing a LocalDate would also be appropriate,
		// but joda 1.6 doesn't support that
		org.joda.time.DateTime utc = formatter.withZone(org.joda.time.DateTimeZone.UTC).parseDateTime(localStringTimestamp);

		// false means don't be strict, joda will nudge the result forward by
		// the
		// size of the gap. The method is somewhat confusingly named, we're
		// actually going from UTC to local
		long millis = zone.convertLocalToUTC(utc.getMillis(), false);

		return new org.joda.time.DateTime(millis, zone);
	}
	
	// Convert date/time strings "yyyy-MM-dd" and "HH.mm.ss" to joda local
	// datetime
	public static org.joda.time.DateTime getJodaDateTimeLocal(String localStringDate, String localStringTime,
			org.joda.time.DateTimeZone zone) {
		String dateFormat = DATETIME_FORMAT;
		String datepart = localStringDate.trim() + "-" + localStringTime.trim();
		org.joda.time.format.DateTimeFormatter formatter = org.joda.time.format.DateTimeFormat.forPattern(dateFormat)
				.withZone(zone);

		// parsing in utc is safe, there are no gaps
		// parsing a LocalDate would also be appropriate,
		// but joda 1.6 doesn't support that
		org.joda.time.DateTime utc = formatter.withZone(org.joda.time.DateTimeZone.UTC).parseDateTime(datepart);

		// false means don't be strict, joda will nudge the result forward by
		// the
		// size of the gap. The method is somewhat confusingly named, we're
		// actually going from UTC to local
		long millis = zone.convertLocalToUTC(utc.getMillis(), false);

		return new org.joda.time.DateTime(millis, zone);
	}

	// Convert joda datetime to UTC datetime
	public static org.joda.time.DateTime convertJodaDateTimeToUTC(org.joda.time.DateTime localDateTime) {
		return convertJodaDateTimeToZone(localDateTime, org.joda.time.DateTimeZone.UTC);
	}

	// Convert joda datetime to local datetime
	public static org.joda.time.DateTime convertJodaDateTimeToLocal(org.joda.time.DateTime utcDateTime) {
		return convertJodaDateTimeToZone(utcDateTime, org.joda.time.DateTimeZone.getDefault());
	}

	// Convert joda datetime to another zone
	public static org.joda.time.DateTime convertJodaDateTimeToZone(org.joda.time.DateTime dateTime,
			org.joda.time.DateTimeZone zone) {
		org.joda.time.DateTime zoneDateTime = dateTime.withZone(zone);
		return zoneDateTime;
	}
	
    public static Map<String, Object> getErrorMap() {
        Map<String, Object> modelMap = new HashMap<String, Object>(1);
        modelMap.put("error", "i18n.message.genericerror");
        return modelMap;
    }
    public static Map<String, Object> getErrorMap(Exception ex) {
    	if (ex instanceof SSMException) {
    		return getErrorMap(((SSMException) ex));
    	}
        Map<String, Object> modelMap = new HashMap<String, Object>(1);
        modelMap.put("error", ex.getMessage());
        return modelMap;
    }
    public static Map<String, Object> getErrorMap(SSMException ex) {
        Map<String, Object> modelMap = new HashMap<String, Object>(1);
         if (ex.getErrorCd() != null) {
            modelMap.put("error", ex.getErrorCd());
        } else if (ex.getErrorMessage() != null) {
            modelMap.put("error", ex.getErrorMessage());
        } else {
            modelMap.put("error", ex.getMessage());
        }
        return modelMap;
    }
    
    
    /////////////////////////////////////////////////////
    
public static final String APPNAME = "SO";
	
    public static Map<String, Object> getMap(List list) {
        return getMap(list, list.size());
    }
    
    //will help for pagination mapping
    public static Map<String, Object> getMap(List list, int total) {
        Map<String, Object> modelMap = new HashMap<String, Object>(3);
        modelMap.put("data", list);
        modelMap.put("total", total);
        modelMap.put("success", true);
        return modelMap;
    }    
    
    public static Map<String, Object> getMap(Map map) {
        Map<String, Object> modelMap = new HashMap<String, Object>(3);
        modelMap.put("data", map.get("data"));
        modelMap.put("total", map.get("rowCount"));
        modelMap.put("success", true);
        return modelMap;
    }    
	
    public static Map<String, Object> getMap(List list, Map<String, Object> modelMap) {
        
        modelMap.put("data", list);
        modelMap.put("total", list.size());
        modelMap.put("success", true);
        
        return modelMap;
    }        
	    
    public static Map<String, String> decodeAsMap(String stBase64Encoded) {
		Map<String, String> paramMap = new HashMap<String, String>();
		String stDecoded = decode(stBase64Encoded);

		String[] params = stDecoded.split("&");
		for (String st : params) {
			String[] keyValues = st.split("=");
			if (keyValues != null ){//  removing to incorporate appon and user access stores  && 1 < keyValues.length) {
				if( 1 < keyValues.length){
					paramMap.put(keyValues[0], keyValues[1]);
				}else{
					paramMap.put(keyValues[0], "");
				}
			}
		}

		return paramMap;
	}        
	
    public static String decode(String stBase64Encoded) {
		byte[] bytes = Base64.decodeBase64(stBase64Encoded.getBytes());
		StringBuilder sb = new StringBuilder(bytes.length);
		for (byte b : bytes) {
			sb.append(Character.toString((char) b));
		}
		String stBase64Decoded = sb.toString();
		logger.info("stBase64Decoded : " + stBase64Decoded);
		return stBase64Decoded;
	}      


    public static List<String> parseString(String inStr) {
    	List<String> outList = new ArrayList<String>();
    	String delims = ",";
		String[] tokens = inStr.split(delims);
		for (int i = 0; i<tokens.length; i++ ){
			outList.add(tokens[i]);
		}
		return outList;
	}
    
    public static List<Long> parseStringToLongList(String inStr) {
    	List<Long> outList = new ArrayList<Long>();
    	String delims = ",";
		String[] tokens = inStr.split(delims);
		for (int i = 0; i<tokens.length; i++ ){
			if(tokens[i]!=null && !tokens[i].trim().equals(""))
				outList.add(Long.parseLong(tokens[i].trim()));
		}
		return outList;
	}
    

    public static String longListToStringWithQuotes(List<Long> listNos)
	{
		String listToString = "";
		if(listNos == null)
		{
			return listToString;
		}
		for(int i=0; i<listNos.size(); i++)
		{
			if(i==0)
			{
				listToString = "" +  listNos.get(i);
			}
			else
			{
				String tempLongVal = ""+listNos.get(i);
				if(tempLongVal != null && !(tempLongVal.trim().isEmpty()) ){
					listToString = listToString + "," + listNos.get(i);
				}
			}					
		}
		
		listToString = "\"" + listToString + "\"";
		//listToString = "\'" + listToString + "\'";
		return listToString;
	}
    
    public static String longListToStringWithSingleQuotes(List<Long> listNos)
   	{
   		String listToString = "";
   		if(listNos == null)
   		{
   			return listToString;
   		}
   		for(int i=0; i<listNos.size(); i++)
   		{
   			if(i==0)
   			{
   				listToString = "" +  listNos.get(i);
   			}
   			else
   			{
   				String tempLongVal = ""+listNos.get(i);
   				if(tempLongVal != null && !(tempLongVal.trim().isEmpty()) ){
   					listToString = listToString + "," + listNos.get(i);
   				}
   			}					
   		}
   		
   		//listToString = "\"" + listToString + "\"";
   		listToString = "\'" + listToString + "\'";
   		return listToString;
   	}
    
    public static String longListToString(List<Long> listNos)
	{
		String listToString = "";
		if(listNos == null)
		{
			return listToString;
		}
		for(int i=0; i<listNos.size(); i++)
		{
			if(i==0)
			{
				listToString = "" +  listNos.get(i);
			}
			else
			{
				String tempLongVal = ""+listNos.get(i);
				if(tempLongVal != null && !(tempLongVal.trim().isEmpty()) ){
					listToString = listToString + "," + listNos.get(i);
				}
			}					
		}
		return listToString;
	}
    
    public static String getLongListToString(List<Long> listNos)
  	{
  		String listToString = "";
  		if(listNos == null)
  		{
  			return listToString;
  		}
  		for(int i=0; i<listNos.size(); i++)
  		{
  			if(i==0)
  			{
  				listToString = "" +  listNos.get(i);
  			}
  			else
  			{
  				String tempLongVal = ""+listNos.get(i);
  				
				if(tempLongVal != null && !(tempLongVal.trim().isEmpty()) &&
						!tempLongVal.trim().equals("null")){
  					listToString = listToString + "," + listNos.get(i);
  				}
  			}					
  		}
  		return listToString;
  	}
    public static String listToString(List<String> listNos)
    {
		
    	return listToString(listNos, true);
    }
    
    public static String listToString(List<String> listNos, boolean addQuotes)
    {
		String listToString = "";
		if(listNos == null)
		{
			return listToString;
		}
		for(int i=0; i<listNos.size(); i++)
		{
			if(i==0)
			{
				if (addQuotes) {
					listToString = "'" +  listNos.get(i) + "'";
				} else {
					listToString = listNos.get(i) ;
				}
			}
			else
			{
				if (addQuotes) {
					listToString = listToString + "," + "'" + listNos.get(i) + "'";
				} else {
					listToString = listToString + "," + listNos.get(i);
				}
			}
		}
		return listToString;
	}
    
    public static Map<String, Object> getSuccessMap() {
        Map<String, Object> modelMap = new HashMap<String, Object>(1);
        modelMap.put("success", true);
        return modelMap;
    }
//    public static Map<String, Object> getErrorMap() {
//        Map<String, Object> modelMap = new HashMap<String, Object>(1);
//        modelMap.put("error", "i18n.message.genericerror");
//        return modelMap;
//    }
    
	public static String toProperCase(String inStr){
		if(inStr!= null){
			String[] parts = inStr.split(" ");
			StringBuilder sb = new StringBuilder(64);
			for (String part : parts) {
			    char[] chars = part.toLowerCase().toCharArray();
			    if(chars.length > 0){
			    chars[0] = Character.toUpperCase(chars[0]);
	
			    sb.append(new String(chars)).append(" ");
			    }
			}
	
			inStr = sb.toString().trim();
	//		System.out.println(inStr);
		}
		return inStr;
	}
	
	public static String trimInStrSpaces(String str){
		Pattern pattern = Pattern.compile("\\s+");
	    Matcher matcher = pattern.matcher(str.trim());
	    boolean check = matcher.find();
	    return matcher.replaceAll(" ");
	}
	
	public static String formatString(String value, String token, String appendVal, int len) {
		StringBuffer returnVal = new StringBuffer(value);
		
		
		return returnVal.toString();
	}
	/*
	 * Convert MM/DD/YY format to DD/MM/YY
	 * @param date in string mm/dd/yy format
	 * @return String in dd/mm/yy format 
	 */
	public static String dmy(String mdyDate)
	{
		String month = "";
		String date = "";
		String year = "";
		String dmyDate = "";
		String mdyDateTime = "";
		if(mdyDate != null)
		{   
			mdyDate = mdyDate.trim();
			mdyDateTime = mdyDate.substring(mdyDate.indexOf(" "), mdyDate.length());
			if(mdyDateTime!=null&&!mdyDateTime.equals("")){
				mdyDate = mdyDate.substring(0, mdyDate.indexOf(" "));
			}
			StringTokenizer st = new StringTokenizer(mdyDate , "/");
			if(st.hasMoreTokens())
			{
				month = st.nextToken();

				if(st.hasMoreTokens())
				{
					date = st.nextToken();
				}
				if(st.hasMoreTokens())
				{
					year = st.nextToken();
				}
				dmyDate = date + "/" + month + "/" + year;
			}			
		}				
		return dmyDate + " " + mdyDateTime;
	}
	
	public static Date getDateFromStrArray(String[] dateSplit)
	{
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MONTH, Integer.parseInt(dateSplit[0]) - 1);
		cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateSplit[1]));
		cal.set(Calendar.YEAR, Integer.parseInt(dateSplit[2]));
		cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(dateSplit[3]));
		cal.set(Calendar.MINUTE, Integer.parseInt(dateSplit[4]));
		cal.set(Calendar.SECOND, Integer.parseInt(dateSplit[5]));
		if("AM".equalsIgnoreCase(dateSplit[6]))
		{
			cal.set(Calendar.SECOND, Calendar.AM);
		}
		else
		{
			cal.set(Calendar.SECOND, Calendar.PM);
		}
		
		return cal.getTime();
	}
	
	public static Date convTimeZone(Date date, String destTZ) throws Exception
	{   
		if(date==null){
			return date;
		}
		String format = "MM-dd-yyyy-H-mm-ss-a";
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		if (destTZ != null)
		{
			if(destTZ.indexOf("-") == -1)
			{
				destTZ = "+" + destTZ.trim();
			}
			
			sdf.setTimeZone(TimeZone.getTimeZone("GMT" + destTZ));
		}
		else
		{
			sdf.setTimeZone(TimeZone.getDefault()); //Default to server's timezone
		}
		
		String clientDateStr = sdf.format(date);
		String dateSplit[] = clientDateStr.split("-");
		
		return getDateFromStrArray(dateSplit);
	}
	
	public static String splitFullname(String param) {
		 String[] tempArr = param.split("\\.");
		 if (tempArr != null) {
			 StringBuilder sb = new StringBuilder();
			 for (String temp: tempArr) {
				 sb.append(temp);
				 sb.append(" ");
			 }
			 return sb.toString();
		 }
		 return null;
	 }
	 
	 public static String getLanguageSpecificValue(String lang, String keyword) {
		 if(keyword==null || keyword.trim().equals(""))
			 return "";
		 String propFileName = "i18n_" + lang;
		 ResourceBundle bundle = ResourceBundle.getBundle(propFileName);
		 String value =null;
		 try
		 {
			 value = bundle.getString(keyword.trim());
		 }
		 catch(Exception e)
		 {
			 value= keyword;
		 }	
		 if(value==null)
		 {
			 value= keyword;
		 }
		 return value;
	 }
	 
	 public static String formatNanos(long nanoSeconds, boolean logTimeout, String methodName)
	 {
		 	StringBuilder sb = new StringBuilder();
		 	formatNanos(sb, nanoSeconds, logTimeout, methodName);
		 	return sb.toString();
	 }	
	 private static void formatNanos(StringBuilder sb, long nanoSeconds, boolean logTimeout, String methodName)
	 {
			long totalMills = nanoSeconds/1000000;
 			long totalSeconds = totalMills/1000;
 			long totalMinutes = totalSeconds/60;
 			
 			long remainderSeconds = (totalSeconds%60);
 			long remainderMillis = (totalMills%1000);
 			
 			sb.append((totalMinutes < 10) ? "0" + totalMinutes : totalMinutes);
 			sb.append(":");
 			sb.append((remainderSeconds < 10) ? "0" + remainderSeconds : remainderSeconds);
 			sb.append(":");
 			sb.append((remainderMillis < 10) ? "00" + remainderMillis : 
 				(remainderMillis < 100) ? "0" + remainderMillis : remainderMillis);
 			sb.append(" (mm:ss:SSS) ");
 			
 			if (logTimeout && totalMinutes >= 1)
 			{
 				logger.error("Method " + methodName + " took " + totalMinutes + " minute(s).");
 			}
	 }	
	 
	 @SuppressWarnings("rawtypes")
	 public static boolean isNotNullNotEmptyCollection(final Collection coll) {
			boolean notNullNotEmpty = true;
			if (coll == null || coll.isEmpty()) {
				notNullNotEmpty = false;
			}
			return notNullNotEmpty;
	 }
	 
	 public static boolean isNULL(final Object obj) {
			return null == obj;
	}
	 
	 public static int getIntForString(final String value) {
			int retValue = 0;
			if (!isNULL(value)) {
				retValue = Integer.parseInt(value);
			}
			return retValue;
		}		


}
