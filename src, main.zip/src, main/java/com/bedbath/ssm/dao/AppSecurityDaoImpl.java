package com.bedbath.ssm.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bedbath.common.jdbc.BaseJdbcDaoSupport;
import com.bedbath.ssm.exception.SSMException;
import com.bedbath.ssm.model.UserPrivilegeModel;


@Repository
public class AppSecurityDaoImpl extends BaseJdbcDaoSupport implements AppSecurityDao {
	private static final String OUT_OF_MEMORY_ERROR = "Out of memory error in ASM AsmSecurityDao";
	private static final String GENERAL_ERROR = "Error in ASM AsmSecurityDao";
	private static Logger logger = LoggerFactory.getLogger(AppSecurityDaoImpl.class);

	
	@Override
	public Map<String, Object> getUserPrivileges(String appCode, String country, String concept, String userId) throws SSMException {
		Map<String, Object> rs = null;
		String myMethod = " [getUserPrivileges]";
		try {
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
	
			simpleJdbcCall.withProcedureName("ASEGTUSPRV");
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			simpleJdbcCall.returningResultSet("results", new UserPrivilegeResultsMapper());
	
			simpleJdbcCall.declareParameters(
					new SqlParameter("@appCode", Types.VARCHAR),
					new SqlParameter("@country", Types.VARCHAR), 
					new SqlParameter("@concept", Types.VARCHAR),
					new SqlParameter("@userId", Types.VARCHAR));
	
			final Map<String, Object> inputParams = new HashMap<String, Object>();
			inputParams.put("@appCode", appCode);
			inputParams.put("@country", country);
			inputParams.put("@concept", concept);
			inputParams.put("@userId", userId);
				
			rs = simpleJdbcCall.execute(inputParams);
		} catch (Exception e) {
			logger.error(GENERAL_ERROR + myMethod, e);
			if (e instanceof SSMException) {
				throw (SSMException) e;
			} else {
				throw new SSMException(GENERAL_ERROR + myMethod, e);
			}
		} catch (java.lang.OutOfMemoryError err) {
			logger.error(OUT_OF_MEMORY_ERROR + myMethod, err);
			throw new SSMException(OUT_OF_MEMORY_ERROR + myMethod, err);
		}
		return rs;

	}
	
	private static class UserPrivilegeResultsMapper implements RowMapper<UserPrivilegeModel> {
		public UserPrivilegeModel mapRow(ResultSet rs, int rowNum) throws SQLException {

			UserPrivilegeModel dataRow = new UserPrivilegeModel();
			dataRow.setAppId(rs.getLong("APPID"));
			dataRow.setPrivId(rs.getLong("PRIVID"));
			dataRow.setPrivName(rs.getString("PRIVNAME"));
			dataRow.setPrivDescription(rs.getString("PRIVDESC"));
			Date createTS = rs.getTimestamp("CRTDTTIME");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if (createTS == null) {
				dataRow.setCreateTS("");
			} else {
				dataRow.setCreateTS(sdf.format(createTS));
			}
			Date updateTS = rs.getTimestamp("UPDTTIME");
			if (updateTS == null) {
				dataRow.setUpdateTS("");
			} else {
				dataRow.setUpdateTS(sdf.format(updateTS));
			}
			dataRow.setUpdateUser(rs.getString("CRUPUSERID"));
			dataRow.setAuditFlag(rs.getString(8));

			return dataRow;
		}
	}


}
