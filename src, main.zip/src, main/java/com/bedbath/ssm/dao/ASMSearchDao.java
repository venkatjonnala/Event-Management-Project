package com.bedbath.ssm.dao;

import java.util.HashMap;
import java.util.Map;

import com.bedbath.ssm.exception.SSMException;

public interface ASMSearchDao {
	public Map<String, Object> getAppList() throws SSMException;

	public Map<String, Object> getCountryList() throws SSMException;

	public Map<String, Object> getConceptList() throws SSMException;

	public Map<String, Object> getAppGrid(String appCode, String countryCode, String conceptCodeS, int start, int limit, HashMap<String, String> sortMap) throws SSMException;

	public Map<String, Object> getRoleGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws SSMException;

	public Map<String, Object> getPropGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws SSMException;

	public Map<String, Object> getRolePropGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws SSMException;

}
