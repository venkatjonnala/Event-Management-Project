package com.bedbath.ssm.dao;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import com.bedbath.common.jdbc.BaseJdbcDaoSupport;

public class BaseDaoSupport extends BaseJdbcDaoSupport{
	
	@Value("classpath:/Sql.xml")
	private Resource sqlResource;

    public String getSql(String sqlKey) throws Exception 
    {
    	String sql = "";
    	if (sqlResource.exists()) 
    	{
    		Properties pro = new Properties();
    		pro.loadFromXML(sqlResource.getInputStream());
    		sql = pro.getProperty(sqlKey);
    	}
    	
    	if (sql.equals("")) 
    	{
    		throw new Exception("Could not read sql " + sqlKey);
    	}
    	return sql;
    }

}
