package com.bedbath.ssm.dao;

import java.util.List;
import java.util.Map;

import com.bedbath.ssm.model.MerchAnalyzer;
import com.bedbath.ssm.model.SearchRequest;
import com.bedbath.ssm.model.Sku;
import com.bedbath.ssm.model.Upc;
import com.bedbath.ssm.model.Vendor;

public interface ElasticSearchDAO {
    /*
	public List<Vendor>  getVendorList(List<Long> vendorNo, String vendorDesc, String country, boolean nolimit, String concept, String searchmode) throws Exception;
	public List<Sku>  getSku(Integer sku, String skuDesc, String venPartNo, String country, Integer vendorno,String skuDescFromSearch, String concept, String searchMode) throws Exception;
//	public List<Department>  getDepartment(Integer dept, Integer subDept, Integer deptClass) throws Exception;
	
	
	
	public void saveESSkusWithBT(SearchRequest searchRequest, final String saveId, final String saveAction) throws Exception;
	public Map  getESTop100(SearchRequest searchRequest) throws Exception;
	public void searchExceptionSKus(SearchRequest searchRequest) throws Exception;
	*/
	
	public List<Vendor>  getVendorList(List<Long> vendorNo, String vendorDesc, String country, boolean nolimit, String concept, String searchmode) throws Exception;
	public List<Sku>  getSku(Integer sku, String skuDesc, String venPartNo, String country, Integer vendorno,String skuDescFromSearch, String concept, String searchMode) throws Exception;
	public List<MerchAnalyzer>  getMerchAnalyzer(String merchAnalyzerComb,String country,String concept) throws Exception;
	public List<Upc>  getUpc(List<Long> upcList, List<Long> skuList, String concept) throws Exception;
	
	public Map  getESSkus(SearchRequest searchRequest) throws Exception;
	
	
}
