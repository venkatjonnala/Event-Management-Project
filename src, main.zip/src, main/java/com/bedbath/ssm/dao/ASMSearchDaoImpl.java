package com.bedbath.ssm.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bedbath.ssm.exception.SSMException;
import com.bedbath.ssm.model.ASMAppGridModel;
import com.bedbath.ssm.model.ASMAppListModel;
import com.bedbath.ssm.model.ASMConceptListModel;
import com.bedbath.ssm.model.ASMCountryListModel;
import com.bedbath.ssm.model.ASMPropGridModel;
import com.bedbath.ssm.model.ASMRoleGridModel;
import com.bedbath.ssm.model.ASMRolePropGridModel;

@Repository
public class ASMSearchDaoImpl extends BaseDaoSupport implements ASMSearchDao {
	private static final String OUT_OF_MEMORY_ERROR = "Out of memory error in ASM Search DAO";
	private static final String GENERAL_ERROR = "Error in ASM Search DAO";
	private static final HashMap<String, String> sortMapXref;

	// ??? update this
	static {
		sortMapXref = new HashMap<String, String>();
		sortMapXref.put("appId", "APPID");
		sortMapXref.put("roleId", "ROLEID");
		sortMapXref.put("appCode", "APPCODE");
		sortMapXref.put("appName", "APP_NAME");
		sortMapXref.put("appDescription", "APP_DESCRIPTION");
		sortMapXref.put("roleName", "ROLE_NAME");
		sortMapXref.put("roleDescription", "ROLE_DESCRIPTION");
		sortMapXref.put("propId", "PROPERTY_ID");
		sortMapXref.put("propValue", "PROPERTY_VALUE");
		sortMapXref.put("propName", "PROPERTY_NAME");
		sortMapXref.put("propDescription", "PROPERTY_DESCRIPTION");
		sortMapXref.put("countryCode", "COUNTRY");
		sortMapXref.put("conceptCode", "CONCEPT");
		sortMapXref.put("effectiveFromDate", "EFFECTIVE_FROM");
		sortMapXref.put("effectiveToDate", "EFFECTIVE_TO");
		sortMapXref.put("createTS", "CREATE_TIMESTAMP");
		sortMapXref.put("updateTS", "UPDATE_TIMESTAMP");
		sortMapXref.put("updateUser", "CRUPUSERID");
		sortMapXref.put("auditFlag", "AUDIT");
	}

	@Override
	public Map<String, Object> getAppList() throws SSMException {
		Map<String, Object> returnMap = null;
		String myMethod = " [getAppList]";

		try {
			// Create the jdbc call interface for the stored proc
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			Map<String, Object> inputParams = new HashMap<String, Object>();
			String procname = "INE1860";

			simpleJdbcCall.withProcedureName(procname);
			simpleJdbcCall.returningResultSet("results", new AppListResultsMapper());

			Map<String, Object> resultMap = simpleJdbcCall.execute(inputParams);

			// For returning a map including results and row count
			returnMap = new HashMap<String, Object>();
			returnMap.put("results", resultMap.get("results"));

		} catch (Exception e) {
			logger.error(GENERAL_ERROR + myMethod, e);
			if (e instanceof SSMException) {
				throw (SSMException) e;
			} else {
				throw new SSMException(GENERAL_ERROR + myMethod, e);
			}
		} catch (java.lang.OutOfMemoryError err) {
			logger.error(OUT_OF_MEMORY_ERROR + myMethod, err);
			throw new SSMException(OUT_OF_MEMORY_ERROR + myMethod, err);
		}
		return returnMap;
	}

	private static class AppListResultsMapper implements RowMapper<ASMAppListModel> {
		public ASMAppListModel mapRow(ResultSet rs, int rowNum) throws SQLException {

			ASMAppListModel dataRow = new ASMAppListModel();
			dataRow.setAppCode(rs.getString("APPCODE"));
			dataRow.setAppName(rs.getString("APP_NAME"));
			dataRow.setAppDisplay(rs.getString("APP_DISPLAY"));

			return dataRow;
		}
	}

	@Override
	public Map<String, Object> getCountryList() throws SSMException {
		Map<String, Object> returnMap = null;
		String myMethod = " [getCountryList]";

		try {
			// Create the jdbc call interface for the stored proc
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			Map<String, Object> inputParams = new HashMap<String, Object>();
			String procname = "INE1870";

			simpleJdbcCall.withProcedureName(procname);
			simpleJdbcCall.returningResultSet("results", new CountryListResultsMapper());

			Map<String, Object> resultMap = simpleJdbcCall.execute(inputParams);

			// For returning a map including results and row count
			returnMap = new HashMap<String, Object>();
			returnMap.put("results", resultMap.get("results"));

		} catch (Exception e) {
			logger.error(GENERAL_ERROR + myMethod, e);
			if (e instanceof SSMException) {
				throw (SSMException) e;
			} else {
				throw new SSMException(GENERAL_ERROR + myMethod, e);
			}
		} catch (java.lang.OutOfMemoryError err) {
			logger.error(OUT_OF_MEMORY_ERROR + myMethod, err);
			throw new SSMException(OUT_OF_MEMORY_ERROR + myMethod, err);
		}
		return returnMap;
	}

	private static class CountryListResultsMapper implements RowMapper<ASMCountryListModel> {
		public ASMCountryListModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			ASMCountryListModel dataRow = new ASMCountryListModel();
			dataRow.setCtryCode(rs.getString("CTRYCOD"));
			dataRow.setCtryName(rs.getString("CTRYNAM"));
			return dataRow;
		}
	}

	@Override
	public Map<String, Object> getConceptList() throws SSMException {
		Map<String, Object> returnMap = null;
		String myMethod = " [getConceptList]";

		try {
			// Create the jdbc call interface for the stored proc
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			Map<String, Object> inputParams = new HashMap<String, Object>();
			String procname = "INE1865";

			simpleJdbcCall.withProcedureName(procname);
			simpleJdbcCall.returningResultSet("results", new ConceptListResultsMapper());

			Map<String, Object> resultMap = simpleJdbcCall.execute(inputParams);

			// For returning a map including results and row count
			returnMap = new HashMap<String, Object>();
			returnMap.put("results", resultMap.get("results"));

		} catch (Exception e) {
			logger.error(GENERAL_ERROR + myMethod, e);
			if (e instanceof SSMException) {
				throw (SSMException) e;
			} else {
				throw new SSMException(GENERAL_ERROR + myMethod, e);
			}
		} catch (java.lang.OutOfMemoryError err) {
			logger.error(OUT_OF_MEMORY_ERROR + myMethod, err);
			throw new SSMException(OUT_OF_MEMORY_ERROR + myMethod, err);
		}
		return returnMap;
	}

	private static class ConceptListResultsMapper implements RowMapper<ASMConceptListModel> {
		public ASMConceptListModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			ASMConceptListModel dataRow = new ASMConceptListModel();
			dataRow.setConceptDesc(rs.getString("CONCEPTDESC"));
			return dataRow;
		}
	}

	@Override
	public Map<String, Object> getAppGrid(String appCode, String countryCode, String conceptCode, int start, int limit,
			HashMap<String, String> sortMap) throws SSMException {
		Map<String, Object> returnMap = null;
		String myMethod = " [getAppGrid]";

		// Default sort
		String sortField = "COUNTRY, CONCEPT, APPCODE";

		// Get sort field and sort order
		if (sortMap != null) {
			if (sortMap.containsKey("property")) {
				if (sortMapXref.containsKey(sortMap.get("property").trim())) {
					sortField = sortMapXref.get(sortMap.get("property").trim());
				}
			}
		}

		try {
			// Create the jdbc call interface for the stored proc
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			Map<String, Object> inputParams = new HashMap<String, Object>();
			String procname = "INE1880";
			simpleJdbcCall.declareParameters(new SqlParameter("pAppCode", Types.VARCHAR),
					new SqlParameter("pCountry", Types.VARCHAR), new SqlParameter("pConcept", Types.VARCHAR),
					new SqlParameter("pStartRow", Types.NUMERIC), new SqlParameter("pPageSize", Types.NUMERIC),
					new SqlParameter("Sort", Types.VARCHAR), new SqlOutParameter("pRecCount", Types.NUMERIC),
					new SqlOutParameter("pReturnCode", Types.VARCHAR));
			inputParams.put("pAppCode", appCode);
			inputParams.put("pCountry", countryCode);
			inputParams.put("pConcept", conceptCode);
			inputParams.put("pStartRow", start);
			inputParams.put("pPageSize", limit);
			inputParams.put("Sort", sortField);

			simpleJdbcCall.withProcedureName(procname);
			simpleJdbcCall.returningResultSet("results", new AppGridResultsMapper());

			Map<String, Object> resultMap = simpleJdbcCall.execute(inputParams);
			int rowCount = (((BigDecimal) resultMap.get("pRecCount")).intValue());
			String returnCode = ((String) resultMap.get("pReturnCode")).trim();

			// For returning a map including results and row count
			returnMap = new HashMap<String, Object>();
			returnMap.put("results", resultMap.get("results"));

		} catch (Exception e) {
			logger.error(GENERAL_ERROR + myMethod, e);
			if (e instanceof SSMException) {
				throw (SSMException) e;
			} else {
				throw new SSMException(GENERAL_ERROR + myMethod, e);
			}
		} catch (java.lang.OutOfMemoryError err) {
			logger.error(OUT_OF_MEMORY_ERROR + myMethod, err);
			throw new SSMException(OUT_OF_MEMORY_ERROR + myMethod, err);
		}
		return returnMap;
	}

	private static class AppGridResultsMapper implements RowMapper<ASMAppGridModel> {
		public ASMAppGridModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			ASMAppGridModel dataRow = new ASMAppGridModel();
			dataRow.setAppId(rs.getLong("APPID"));
			dataRow.setAppCode(rs.getString("APPCODE"));
			dataRow.setAppName(rs.getString("APP_NAME"));
			dataRow.setAppDescription(rs.getString("APP_DESCRIPTION"));
			dataRow.setCountryCode(rs.getString("COUNTRY"));
			dataRow.setConceptCode(rs.getString("CONCEPT"));
			dataRow.setEffectiveFromDate(rs.getDate("EFFECTIVE_FROM"));
			dataRow.setEffectiveToDate(rs.getDate("EFFECTIVE_TO"));
			Date createTS = rs.getTimestamp("CREATE_TIMESTAMP");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if (createTS == null) {
				dataRow.setCreateTS("");
			} else {
				dataRow.setCreateTS(sdf.format(createTS));
			}
			Date updateTS = rs.getTimestamp("UPDATE_TIMESTAMP");
			if (updateTS == null) {
				dataRow.setUpdateTS("");
			} else {
				dataRow.setUpdateTS(sdf.format(updateTS));
			}
			dataRow.setUpdateUser(rs.getString("CRUPUSERID"));
			dataRow.setAuditFlag(rs.getString("AUDIT"));
			return dataRow;
		}
	}
	
	@Override
	public Map<String, Object> getRoleGrid(long appId, int start, int limit,
			HashMap<String, String> sortMap) throws SSMException {
		Map<String, Object> returnMap = null;
		String myMethod = " [getRoleGrid]";

		// Default sort
		String sortField = "ROLEID";

		// Get sort field and sort order
		if (sortMap != null) {
			if (sortMap.containsKey("property")) {
				if (sortMapXref.containsKey(sortMap.get("property").trim())) {
					sortField = sortMapXref.get(sortMap.get("property").trim());
				}
			}
		}

		try {
			// Create the jdbc call interface for the stored proc
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			Map<String, Object> inputParams = new HashMap<String, Object>();
			String procname = "INE1890";
			simpleJdbcCall.declareParameters(new SqlParameter("pAppId", Types.NUMERIC),
					new SqlParameter("pStartRow", Types.NUMERIC), new SqlParameter("pPageSize", Types.NUMERIC),
					new SqlParameter("Sort", Types.VARCHAR), new SqlOutParameter("pRecCount", Types.NUMERIC),
					new SqlOutParameter("pReturnCode", Types.VARCHAR));
			inputParams.put("pAppId", appId);
			inputParams.put("pStartRow", start);
			inputParams.put("pPageSize", limit);
			inputParams.put("Sort", sortField);

			simpleJdbcCall.withProcedureName(procname);
			simpleJdbcCall.returningResultSet("results", new RoleGridResultsMapper());

			Map<String, Object> resultMap = simpleJdbcCall.execute(inputParams);
			int rowCount = (((BigDecimal) resultMap.get("pRecCount")).intValue());
			String returnCode = ((String) resultMap.get("pReturnCode")).trim();

			// For returning a map including results and row count
			returnMap = new HashMap<String, Object>();
			returnMap.put("results", resultMap.get("results"));

		} catch (Exception e) {
			logger.error(GENERAL_ERROR + myMethod, e);
			if (e instanceof SSMException) {
				throw (SSMException) e;
			} else {
				throw new SSMException(GENERAL_ERROR + myMethod, e);
			}
		} catch (java.lang.OutOfMemoryError err) {
			logger.error(OUT_OF_MEMORY_ERROR + myMethod, err);
			throw new SSMException(OUT_OF_MEMORY_ERROR + myMethod, err);
		}
		return returnMap;
	}

	private static class RoleGridResultsMapper implements RowMapper<ASMRoleGridModel> {
		public ASMRoleGridModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			ASMRoleGridModel dataRow = new ASMRoleGridModel();
			dataRow.setAppId(rs.getLong("APPID"));
			dataRow.setRoleId(rs.getLong("ROLEID"));
			dataRow.setRoleName(rs.getString("ROLE_NAME"));
			dataRow.setRoleDescription(rs.getString("ROLE_DESCRIPTION"));
			Date createTS = rs.getTimestamp("CREATE_TIMESTAMP");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if (createTS == null) {
				dataRow.setCreateTS("");
			} else {
				dataRow.setCreateTS(sdf.format(createTS));
			}
			Date updateTS = rs.getTimestamp("UPDATE_TIMESTAMP");
			if (updateTS == null) {
				dataRow.setUpdateTS("");
			} else {
				dataRow.setUpdateTS(sdf.format(updateTS));
			}
			dataRow.setUpdateUser(rs.getString("CRUPUSERID"));
			dataRow.setAuditFlag(rs.getString("AUDIT"));
			return dataRow;
		}
	}
	
	@Override
	public Map<String, Object> getPropGrid(long appId, int start, int limit,
			HashMap<String, String> sortMap) throws SSMException {
		Map<String, Object> returnMap = null;
		String myMethod = " [getPropGrid]";

		// Default sort
		String sortField = "PROPERTY_ID";

		// Get sort field and sort order
		if (sortMap != null) {
			if (sortMap.containsKey("property")) {
				if (sortMapXref.containsKey(sortMap.get("property").trim())) {
					sortField = sortMapXref.get(sortMap.get("property").trim());
				}
			}
		}

		try {
			// Create the jdbc call interface for the stored proc
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			Map<String, Object> inputParams = new HashMap<String, Object>();
			String procname = "INE1895";
			simpleJdbcCall.declareParameters(new SqlParameter("pAppId", Types.NUMERIC),
					new SqlParameter("pStartRow", Types.NUMERIC), new SqlParameter("pPageSize", Types.NUMERIC),
					new SqlParameter("Sort", Types.VARCHAR), new SqlOutParameter("pRecCount", Types.NUMERIC),
					new SqlOutParameter("pReturnCode", Types.VARCHAR));
			inputParams.put("pAppId", appId);
			inputParams.put("pStartRow", start);
			inputParams.put("pPageSize", limit);
			inputParams.put("Sort", sortField);

			simpleJdbcCall.withProcedureName(procname);
			simpleJdbcCall.returningResultSet("results", new PropGridResultsMapper());

			Map<String, Object> resultMap = simpleJdbcCall.execute(inputParams);
			int rowCount = (((BigDecimal) resultMap.get("pRecCount")).intValue());
			String returnCode = ((String) resultMap.get("pReturnCode")).trim();

			// For returning a map including results and row count
			returnMap = new HashMap<String, Object>();
			returnMap.put("results", resultMap.get("results"));

		} catch (Exception e) {
			logger.error(GENERAL_ERROR + myMethod, e);
			if (e instanceof SSMException) {
				throw (SSMException) e;
			} else {
				throw new SSMException(GENERAL_ERROR + myMethod, e);
			}
		} catch (java.lang.OutOfMemoryError err) {
			logger.error(OUT_OF_MEMORY_ERROR + myMethod, err);
			throw new SSMException(OUT_OF_MEMORY_ERROR + myMethod, err);
		}
		return returnMap;
	}

	private static class PropGridResultsMapper implements RowMapper<ASMPropGridModel> {
		public ASMPropGridModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			ASMPropGridModel dataRow = new ASMPropGridModel();
			dataRow.setAppId(rs.getLong("APPID"));
			dataRow.setPropId(rs.getLong("PROPERTY_ID"));
			dataRow.setPropName(rs.getString("PROPERTY_NAME"));
			dataRow.setPropValue(rs.getString("PROPERTY_VALUE"));
			dataRow.setPropDescription(rs.getString("PROPERTY_DESCRIPTION"));
			Date createTS = rs.getTimestamp("CREATE_TIMESTAMP");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if (createTS == null) {
				dataRow.setCreateTS("");
			} else {
				dataRow.setCreateTS(sdf.format(createTS));
			}
			Date updateTS = rs.getTimestamp("UPDATE_TIMESTAMP");
			if (updateTS == null) {
				dataRow.setUpdateTS("");
			} else {
				dataRow.setUpdateTS(sdf.format(updateTS));
			}
			dataRow.setUpdateUser(rs.getString("CRUPUSERID"));
			dataRow.setAuditFlag(rs.getString("AUDIT"));
			return dataRow;
		}
	}
	
	@Override
	public Map<String, Object> getRolePropGrid(long appId, int start, int limit,
			HashMap<String, String> sortMap) throws SSMException {
		Map<String, Object> returnMap = null;
		String myMethod = " [getRolePropGrid]";

		// Default sort
		String sortField = "ROLEID, PROPERTY_ID";

		// Get sort field and sort order
		if (sortMap != null) {
			if (sortMap.containsKey("property")) {
				if (sortMapXref.containsKey(sortMap.get("property").trim())) {
					sortField = sortMapXref.get(sortMap.get("property").trim());
				}
			}
		}

		try {
			// Create the jdbc call interface for the stored proc
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			Map<String, Object> inputParams = new HashMap<String, Object>();
			String procname = "INE1915";
			simpleJdbcCall.declareParameters(new SqlParameter("pAppId", Types.NUMERIC),
					new SqlParameter("pStartRow", Types.NUMERIC), new SqlParameter("pPageSize", Types.NUMERIC),
					new SqlParameter("Sort", Types.VARCHAR), new SqlOutParameter("pRecCount", Types.NUMERIC),
					new SqlOutParameter("pReturnCode", Types.VARCHAR));
			inputParams.put("pAppId", appId);
			inputParams.put("pStartRow", start);
			inputParams.put("pPageSize", limit);
			inputParams.put("Sort", sortField);

			simpleJdbcCall.withProcedureName(procname);
			simpleJdbcCall.returningResultSet("results", new RolePropGridResultsMapper());

			Map<String, Object> resultMap = simpleJdbcCall.execute(inputParams);
			int rowCount = (((BigDecimal) resultMap.get("pRecCount")).intValue());
			String returnCode = ((String) resultMap.get("pReturnCode")).trim();

			// For returning a map including results and row count
			returnMap = new HashMap<String, Object>();
			returnMap.put("results", resultMap.get("results"));

		} catch (Exception e) {
			logger.error(GENERAL_ERROR + myMethod, e);
			if (e instanceof SSMException) {
				throw (SSMException) e;
			} else {
				throw new SSMException(GENERAL_ERROR + myMethod, e);
			}
		} catch (java.lang.OutOfMemoryError err) {
			logger.error(OUT_OF_MEMORY_ERROR + myMethod, err);
			throw new SSMException(OUT_OF_MEMORY_ERROR + myMethod, err);
		}
		return returnMap;
	}

	private static class RolePropGridResultsMapper implements RowMapper<ASMRolePropGridModel> {
		public ASMRolePropGridModel mapRow(ResultSet rs, int rowNum) throws SQLException {
			ASMRolePropGridModel dataRow = new ASMRolePropGridModel();
			dataRow.setAppId(rs.getLong("APPID"));
			dataRow.setRoleId(rs.getLong("ROLEID"));
			dataRow.setRoleName(rs.getString("ROLE_NAME"));
			dataRow.setRoleDescription(rs.getString("ROLE_DESCRIPTION"));
			dataRow.setPropId(rs.getLong("PROPERTY_ID"));
			dataRow.setPropName(rs.getString("PROPERTY_NAME"));
			dataRow.setPropValue(rs.getString("PROPERTY_VALUE"));
			dataRow.setPropDescription(rs.getString("PROPERTY_DESCRIPTION"));
			Date createTS = rs.getTimestamp("CREATE_TIMESTAMP");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if (createTS == null) {
				dataRow.setCreateTS("");
			} else {
				dataRow.setCreateTS(sdf.format(createTS));
			}
			Date updateTS = rs.getTimestamp("UPDATE_TIMESTAMP");
			if (updateTS == null) {
				dataRow.setUpdateTS("");
			} else {
				dataRow.setUpdateTS(sdf.format(updateTS));
			}
			dataRow.setUpdateUser(rs.getString("CRUPUSERID"));
			return dataRow;
		}
	}
	
}