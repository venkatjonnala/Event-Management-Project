
package com.bedbath.ssm.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.sort.ScriptSortBuilder.ScriptSortType;
import org.elasticsearch.search.sort.FieldSortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.bedbath.common.jdbc.BaseJdbcDaoSupport;
import com.bedbath.ssm.common.util.AppConstants;
import com.bedbath.ssm.common.util.ApplicationUtil;
import com.bedbath.ssm.model.ESSortRequest;
import com.bedbath.ssm.model.MerchAnalyzer;
import com.bedbath.ssm.model.SearchDetails;
import com.bedbath.ssm.model.SearchRequest;
import com.bedbath.ssm.model.Sku;
import com.bedbath.ssm.model.Upc;
import com.bedbath.ssm.model.Vendor;
import com.bedbath.ssm.service.ESClientService;
/**
 * @author sjain
 *   Elastic search implementation class
 *
 */
@Repository
public class ElasticSearchDAOImpl extends BaseJdbcDaoSupport implements  ElasticSearchDAO{

	private static final Logger LOGGER = LoggerFactory.getLogger(ElasticSearchDAOImpl.class);	
	@Autowired(required = true)
	private ESClientService esClientService;		
	
	private Map<String,String>  getCurrencyCode(String concept) throws Exception {
		
		RestHighLevelClient client = esClientService.getESClient();
		Map<String,String> currencyMap = new HashMap<String,String>();

		BoolQueryBuilder builder = new BoolQueryBuilder();
		QueryBuilder queryBuilder = QueryBuilders.matchAllQuery();
		builder.must(queryBuilder);

		String indexname = AppConstants.ELASTIC_CURCOD;
		if(concept.equalsIgnoreCase("HN")){
			indexname = AppConstants.ELASTIC_CURCOD_HN;
		}else if(concept.equalsIgnoreCase("CAN")){
			indexname = AppConstants.ELASTIC_CURCOD_CA;
		}else if(concept.equalsIgnoreCase("MEX")){
			indexname = AppConstants.ELASTIC_CURCOD_MX;
		}else if(concept.equalsIgnoreCase("CT")){
			indexname = AppConstants.ELASTIC_CURCOD_CTS;
		}
		
		
		org.elasticsearch.action.search.SearchRequest searchRequest = new org.elasticsearch.action.search.SearchRequest(indexname);
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder(); 
		sourceBuilder.from(0);
		sourceBuilder.size(1500);
		sourceBuilder.query(builder);
		searchRequest.source(sourceBuilder);

		SearchResponse searchResponse = client.search(searchRequest); 
		SearchHit[] docs = searchResponse.getHits().getHits();

		for (SearchHit hit : docs) {
			  Map<String,Object> result = hit.getSourceAsMap(); 
//			  LOGGER.info((String)result.get(AppConstants.ELASTIC_CUR_CODE));
//			  LOGGER.info((String)result.get(AppConstants.ELASTIC_CUR_HOME));
			  String curhom = (String)result.get(AppConstants.ELASTIC_CUR_HOME);
			  if(curhom != null) {
				  currencyMap.put((String)result.get(AppConstants.ELASTIC_CUR_CODE), (String)result.get(AppConstants.ELASTIC_CUR_HOME));
			  }
		}
		//client.threadPool().shutdown();
		//client = null;
		return  currencyMap;
	}

	
	public List<Vendor>  getVendorList(List<Long> vendorNoList, String vendorDesc, String country, boolean nolimit, String concept, String searchmode) throws Exception {
		System.out.println("ElsticSearch DAO getVendorList vendorNoList = "+vendorNoList +" vendorDesc = "+vendorDesc +" country =  " +country);
		System.out.println("ElsticSearch DAO getVendorList nolimit = "+nolimit +" concept = "+concept +" searchmode =  " +searchmode);
		
		RestHighLevelClient client = esClientService.getESClient();		
		System.out.println("ElsticSearch DAO getVendorList client = "+client);
				
				
		Map<String,String>  currencyCodeMap = null;
//		if(country.equalsIgnoreCase("CAN")){
//			currencyCodeMap = getCurrencyCode("CAN");
//		} else{
//			currencyCodeMap = getCurrencyCode(concept);
//		}
		if(country.equalsIgnoreCase("USA")){
			currencyCodeMap = getCurrencyCode("USA");
		} 
		List<Vendor> vendorList = new ArrayList<Vendor>();

		QueryBuilder queryBuilder = null;
		BoolQueryBuilder vendornoBuilder = new BoolQueryBuilder();
		if(vendorDesc != null && vendorDesc.length() > 0){
			//LOGGER.info("vendorDesc::"+vendorDesc);
		    String venDesc = ApplicationUtil.trimInStrSpaces(vendorDesc);
		    if(searchmode != null && searchmode.indexOf("S") != -1){
		    	queryBuilder = QueryBuilders.prefixQuery("ASNAME._ASNAME", venDesc.toLowerCase());
		    }else if(searchmode != null && searchmode.indexOf("C") != -1){
//		    	queryBuilder = QueryBuilders.wildcardQuery("ASNAME._ASNAME", "*"+venDesc.toLowerCase()+"*");
		    	queryBuilder = QueryBuilders.termQuery("ASNAME.ASNAME_CONTAINS", venDesc.toLowerCase());
		    }
			vendornoBuilder.must(queryBuilder);
		}  else if(vendorNoList != null) {
			for(int i=0; i< vendorNoList.size(); i++){
					queryBuilder = QueryBuilders.termQuery(AppConstants.ELASTIC_VEN_NO, vendorNoList.get(i));
					vendornoBuilder.should(queryBuilder);
			}
		}
		int size = 20; 
		if(nolimit){
			size =1000;
		}
		String venIndexName = AppConstants.ELASTIC_VENDOR;
		if(concept.equalsIgnoreCase("HN")){
			venIndexName = AppConstants.ELASTIC_VENDOR_HARMON;
		}else if(country.equalsIgnoreCase("CAN")){
			venIndexName = AppConstants.ELASTIC_VENDOR_CANADA;
		}else if(country.equalsIgnoreCase("MEX")){
			venIndexName = AppConstants.ELASTIC_VENDOR_MEXICO;
		}else if(concept.equalsIgnoreCase("CT")){
			venIndexName = AppConstants.ELASTIC_VENDOR_CTS;
		}
		
		System.out.println("ElsticSearch DAO getVendorList venIndexName = "+venIndexName);
//		SearchResponse response = client.prepareSearch(venIndexName)
//				.setSearchType(SearchType.DEFAULT)
//				.addSort( "ASNAME.ASNAME_SORT" , SortOrder.ASC)
//				.setQuery(vendornoBuilder)
//				.setFrom(0).setSize(size).setExplain(false).execute().actionGet();
//
//		SearchHit[] docs = response.getHits().getHits();
//		System.out.println("docs count::"+docs.length);
		
		
		org.elasticsearch.action.search.SearchRequest searchRequest = new org.elasticsearch.action.search.SearchRequest(venIndexName);
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder(); 
		sourceBuilder.from(0);
		sourceBuilder.size(size);
		sourceBuilder.sort(new FieldSortBuilder("ASNAME.ASNAME_SORT").order(SortOrder.ASC));
		sourceBuilder.query(vendornoBuilder);
		searchRequest.source(sourceBuilder);

		SearchResponse searchResponse = client.search(searchRequest); 
		SearchHit[] docs = searchResponse.getHits().getHits();
		
		
		Vendor vendor = null;
		for (SearchHit hit : docs) {
			  Map<String,Object> result = hit.getSourceAsMap(); 
			 // LOGGER.info((String)result.get(AppConstants.ELASTIC_VENDOR_DESC));
			 // LOGGER.info((String)result.get(AppConstants.ELASTIC_VENDOR_NO));
			  boolean validVendorCountry = true;
			  String venCurrency = (String)result.get(AppConstants.ELASTIC_VEN_CUR);
			  if(venCurrency != null && country != null && country.trim().equalsIgnoreCase("USA")){
//			  if(venCurrency != null ){
				  String curhom = (String)currencyCodeMap.get(venCurrency.trim());
				  if(curhom != null && ! curhom.trim().equalsIgnoreCase("Y")){
					  validVendorCountry = false;
				  }
			  }
			  if(validVendorCountry){
				  vendor = new Vendor();
				  vendor.setVendorNo( new Long( ((String)result.get(AppConstants.ELASTIC_VENDOR_NO)).trim()) );
				  vendor.setVendorDesc(ApplicationUtil.toProperCase(((String)result.get(AppConstants.ELASTIC_VENDOR_DESC)).trim()));
				 // LOGGER.info("-----------------------------------");
				  vendorList.add(vendor);
			  }
		}
		//client.threadPool().shutdown();
		//client.threadPool().shutdown();
		//client = null;
		return  vendorList;
	}

	public List<Sku>  getSku(Integer sku, String skuDesc, String venPartNo, String country, Integer vendorno,String skuDescFromSearch, String concept, String searchMode) throws Exception{
		
		List<Sku> skuList = new ArrayList<Sku>();
		RestHighLevelClient client = esClientService.getESClient();

		String sortby = "INUMBR";
		Integer totalResults = 20;
		
		QueryBuilder queryBuilder = null;
		BoolQueryBuilder vendorPartBuilder = new BoolQueryBuilder();
		if(skuDesc != null && skuDesc.length() > 0){
			String tempSkuDesc =  ApplicationUtil.trimInStrSpaces(skuDesc);
//			queryBuilder = QueryBuilders.wildcardQuery(AppConstants.ELASTIC_SKU_DESC_SORT, tempSkuDesc.toUpperCase()+"*");
			if(searchMode != null && searchMode.indexOf("S") != -1){
				queryBuilder = QueryBuilders.prefixQuery("IDESCR._IDESCR", tempSkuDesc.toLowerCase());
			}else if(searchMode != null && searchMode.indexOf("C") != -1){
//				queryBuilder = QueryBuilders.wildcardQuery("IDESCR._IDESCR", "*"+tempSkuDesc.toLowerCase()+"*");
				queryBuilder = QueryBuilders.termQuery("IDESCR.IDESCR_CONTAINS", tempSkuDesc.toLowerCase());
			} else{
				queryBuilder = QueryBuilders.prefixQuery("IDESCR._IDESCR", tempSkuDesc.toLowerCase());
			}
			 sortby = "IDESCR.IDESCR_SORT";
			//LOGGER.info("skuDesc::"+skuDesc);
		}
		else if(sku != null){
			//LOGGER.info("sku::"+sku);
			queryBuilder = QueryBuilders.termQuery(AppConstants.ELASTIC_SKUNO_STR, sku.toString());
		}else if(venPartNo != null && venPartNo.length() > 0){
			//LOGGER.info("venPartNo.toLowerCase()::"+venPartNo.toLowerCase());
			String tempVenPartNo =  ApplicationUtil.trimInStrSpaces(venPartNo);
			if(searchMode != null &&  searchMode.indexOf("S") != -1){
				queryBuilder = QueryBuilders.prefixQuery(AppConstants.ELASTIC_VENDOR_PART_NO_SORT, tempVenPartNo.toLowerCase());
			}else if(searchMode != null &&  searchMode.indexOf("C") != -1){
//				queryBuilder = QueryBuilders.wildcardQuery(AppConstants.ELASTIC_VENDOR_PART_NO_SORT, "*"+tempVenPartNo.toLowerCase()+"*");
				queryBuilder = QueryBuilders.termQuery("IVNDP#.IVNDP#_CONTAINS", tempVenPartNo.toLowerCase());
				
			}else{
				queryBuilder = QueryBuilders.prefixQuery(AppConstants.ELASTIC_VENDOR_PART_NO_SORT, tempVenPartNo.toLowerCase());
			}

			if(vendorno != null) {
				QueryBuilder queryBuilder1 = QueryBuilders.termQuery (AppConstants.ELASTIC_VEN_NO, vendorno);
				vendorPartBuilder.must(queryBuilder);
				vendorPartBuilder.must(queryBuilder1);
				queryBuilder = vendorPartBuilder;
			}
			
			 sortby = "IVNDP#.IVNDP#_SORT";
		}else if(skuDescFromSearch != null && skuDescFromSearch.length() > 0){
			String tempSkuDesc =  ApplicationUtil.trimInStrSpaces(skuDescFromSearch);
			
			if(searchMode != null && searchMode.indexOf("S") != -1){
				queryBuilder = QueryBuilders.prefixQuery("IDESCR._IDESCR", tempSkuDesc.toLowerCase());
			}else if(searchMode != null && searchMode.indexOf("C") != -1){
				queryBuilder = QueryBuilders.termQuery("IDESCR.IDESCR_CONTAINS", tempSkuDesc.toLowerCase());
//				queryBuilder = QueryBuilders.wildcardQuery("IDESCR._IDESCR", "*"+tempSkuDesc.toLowerCase()+"*");
			} else{
				queryBuilder = QueryBuilders.prefixQuery("IDESCR._IDESCR", tempSkuDesc.toLowerCase());
			}
			
			 sortby = "IDESCR.IDESCR_SORT";
		//	LOGGER.info("skuDescFromSearch::"+skuDescFromSearch);
			totalResults = 2000;
		}

		
		String indexName = null;
		
		if(country.equalsIgnoreCase("USA")){
			indexName = AppConstants.ELASTIC_SKU_USA;
		}else if(country.equalsIgnoreCase("CAN")){
			indexName = AppConstants.ELASTIC_SKU_CAN;
		}else if(country.equalsIgnoreCase("MEX")){
			indexName = AppConstants.ELASTIC_SKU_MEX;
		}
		if(concept !=null && concept.equalsIgnoreCase("HN")){
			indexName = AppConstants.ELASTIC_SKU_HN;
		}else if(concept !=null && concept.equalsIgnoreCase("CT")){
			indexName = AppConstants.ELASTIC_SKU_CTS;
		}
		
//		SearchResponse response = client.prepareSearch(indexName)
//				.setSearchType(SearchType.DEFAULT)
//				.setQuery(queryBuilder)
//				.addSort(sortby, SortOrder.ASC)				
//				.setFrom(0).setSize(totalResults).setExplain(false).execute().actionGet();
//
//		SearchHit[] docs = response.getHits().getHits();
		
		
		org.elasticsearch.action.search.SearchRequest searchRequest = new org.elasticsearch.action.search.SearchRequest(indexName);
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder(); 
		sourceBuilder.from(0);
		sourceBuilder.size(totalResults);
		sourceBuilder.sort(new FieldSortBuilder(sortby).order(SortOrder.ASC));
		sourceBuilder.query(queryBuilder);
		searchRequest.source(sourceBuilder);

		SearchResponse searchResponse = client.search(searchRequest); 
		SearchHit[] docs = searchResponse.getHits().getHits();
		
		// LOGGER.info("Sku size is " + docs.length);
		Sku skuObj = null;
////		boolean countryFlag = true;
//		   BoolQueryBuilder skuCountrybool = new BoolQueryBuilder();
//			QueryBuilder cntryBuilder = QueryBuilders.termQuery("CTRYCOD", country.toLowerCase().trim());
//			skuCountrybool.must(cntryBuilder);
//			QueryBuilder codeBuilder = QueryBuilders.termQuery("CTSOLDFLG", "y");
//			skuCountrybool.must(codeBuilder);
		for (SearchHit hit : docs) {
			  Map<String,Object> result = hit.getSourceAsMap(); 
//			   LOGGER.info((String)result.get(AppConstants.ELASTIC_SKU_DESC));
//			   LOGGER.info((String)result.get(AppConstants.ELASTIC_SKUNO_STR));
//			   LOGGER.info((String)result.get(AppConstants.ELASTIC_VENDOR_PART_NO));
			   String inumbr = ((Integer)result.get(AppConstants.ELASTIC_SKUNO))+"";
				  skuObj = new Sku();
				  skuObj.setSku(inumbr);
				  skuObj.setSkuDesc(ApplicationUtil.toProperCase(((String)result.get(AppConstants.ELASTIC_SKU_DESC)).trim()));
				  if((String)result.get(AppConstants.ELASTIC_VENDOR_PART_NO) != null && !((String)result.get(AppConstants.ELASTIC_VENDOR_PART_NO)).trim().isEmpty()){
					  skuObj.setVenPartNo(ApplicationUtil.toProperCase(((String)result.get(AppConstants.ELASTIC_VENDOR_PART_NO)).trim()));
				  }
				  skuObj.setAsnum(""+((Integer)result.get(AppConstants.ELASTIC_VEN_NO)).intValue());
				  skuList.add(skuObj);
		}
		//client.threadPool().shutdown();
		//client = null;
		return  skuList;
	}
	
	/* (non-Javadoc)
	 * @see com.bedbath.so.dao.ElasticSearchDAO#getMerchAnalyzer(java.lang.String)
	 * Return list of Merchandise Analyzer objects w.r.t. Merchandise code 
	 * for Merchandise Analyzer lookup
	 */
	public List<MerchAnalyzer>  getMerchAnalyzer(String merchAnalyzer,String country, String concept) throws Exception{
		System.out.println("ElasticSearchDAO getMerchAnalyzer() 4 - 3  ####### merchAnalyzer = "+merchAnalyzer +" country = "+country +" concept = "+concept);
		RestHighLevelClient client = esClientService.getESClient();
		List<MerchAnalyzer> merchAnalyzerList = new ArrayList<MerchAnalyzer>();
		QueryBuilder queryBuilder = null;
		BoolQueryBuilder boolBuilder = new BoolQueryBuilder();
		QueryBuilder queryBuilder1 = new BoolQueryBuilder();

		//ES values for country/concept
		//	usa	bedbath
		//	usa	baby
		//	usa	harmon
		//	usa	cts
		//	can	bedbath
		//	can	baby
		//	mex	bedbath
		if (concept.equalsIgnoreCase("beyond")) {
			concept="bedbath";
		}
		
		if(merchAnalyzer != null && merchAnalyzer.length() > 0){
			String tempMerchAnalyzer =  ApplicationUtil.trimInStrSpaces(merchAnalyzer);
			boolBuilder.must(QueryBuilders.wildcardQuery("GP_COMBINED.GP_COMBINED_SORT", "*"+tempMerchAnalyzer.toLowerCase()+"*"));
			boolBuilder.must(QueryBuilders.termQuery("COUNTRY",country.toLowerCase()));
			boolBuilder.must(QueryBuilders.termQuery("CONCEPT",concept.toLowerCase()));
			queryBuilder = boolBuilder;
		//	LOGGER.info("merchAnalyzer::"+merchAnalyzer);
		}
		
		String indexName = AppConstants.ELASTIC_MERCHANDISE_ANALYZER;
		//if(concept.equalsIgnoreCase("harmon")){
		//			indexName = AppConstants.ELASTIC_MERCHANDISE_ANALYZER_HN ;
		//}else if(concept.equalsIgnoreCase("cts")){
		//	indexName = AppConstants.ELASTIC_MERCHANDISE_ANALYZER_CTS ;
		//}
//		SearchResponse response = client.prepareSearch(indexName)
//				.setSearchType(SearchType.DEFAULT)
//				.setQuery(queryBuilder)
//				.addSort(AppConstants.ELASTIC_MERCH_COMBINE_SORT, SortOrder.ASC)				
//				.setFrom(0).setSize(20).setExplain(false).execute().actionGet();
//
//		SearchHit[] docs = response.getHits().getHits();
//		// LOGGER.info("Merch analyzer size is " + docs.length);
		
		
		org.elasticsearch.action.search.SearchRequest searchRequest = new org.elasticsearch.action.search.SearchRequest(indexName);
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder(); 
		sourceBuilder.from(0);
		sourceBuilder.size(20);
		sourceBuilder.sort(new FieldSortBuilder(AppConstants.ELASTIC_MERCH_COMBINE_SORT).order(SortOrder.ASC));
		sourceBuilder.query(queryBuilder);
		searchRequest.source(sourceBuilder);

		SearchResponse searchResponse = client.search(searchRequest); 
		SearchHit[] docs = searchResponse.getHits().getHits();

		
		
		MerchAnalyzer merchAnalyzerObj = null;
		for (SearchHit hit : docs) {
			  Map<String,Object> result = hit.getSourceAsMap(); 
			  merchAnalyzerObj = new MerchAnalyzer();
			  String code = ((String)result.get(AppConstants.ELASTIC_MERCH_CODE)).trim();
			  String desc = ((String)result.get(AppConstants.ELASTIC_MERCH_DESC)).trim() ;
			  merchAnalyzerObj.setMerchAnalyzerCode(code);
			  merchAnalyzerObj.setMerchAnalyzerDesc(desc);
//			  merchAnalyzerObj.setMerchAnalyzerComb(ApplicationUtil.toProperCase(((String)result.get(AppConstants.ELASTIC_MERCH_COMBINE)).trim()));
			  merchAnalyzerObj.setMerchAnalyzerComb((code +" "+ApplicationUtil.toProperCase(desc)));
			  merchAnalyzerList.add(merchAnalyzerObj);
		}
		
		return  merchAnalyzerList;
	}
	
	/* (non-Javadoc)
	 * @see com.bedbath.so.dao.ElasticSearchDAO#getUpc(java.lang.Integer, java.lang.Integer)
	 * Return list of UPC objects w.r.t. UPC code List and SKU List
	 */	
	public List<Upc>  getUpc(List<Long> upcList, List<Long> skuList, String concept) throws Exception {
		System.out.println("ElasticSearchDAO getUpc() 4 - 3  ######################");
		RestHighLevelClient client = esClientService.getESClient();
		
		List<Upc> returnUpcList = new ArrayList<Upc>();
		QueryBuilder queryBuilder = null;
		BoolQueryBuilder upcBuilder = new BoolQueryBuilder();
		
		if(upcList != null && upcList.size() > 0){
			for(int i=0; i<upcList.size(); i++){
				String tempupc = ""+upcList.get(i);
				if(tempupc != null && !(tempupc.trim().isEmpty()) ){
					queryBuilder = QueryBuilders.termQuery(AppConstants.ELASTIC_UPCNO, upcList.get(i));
					upcBuilder.should(queryBuilder);
				}
			}
		}else if(skuList != null && skuList.size() > 0){
			for(Long skuno : skuList){ 
				String tempsku = ""+skuno;
				if(tempsku != null && !(tempsku.trim().isEmpty()) ){
					queryBuilder = QueryBuilders.termQuery(AppConstants.ELASTIC_SKUNO, skuno);
					upcBuilder.should(queryBuilder);
				}
			}
		}
		String indexName = AppConstants.ELASTIC_UPC;
		if(concept.equalsIgnoreCase("HN")){
			indexName = AppConstants.ELASTIC_UPC_HN;
		}else if(concept.equalsIgnoreCase("CAN")){
			indexName = AppConstants.ELASTIC_UPC_CA;
		}else if(concept.equalsIgnoreCase("MEX")){
			indexName = AppConstants.ELASTIC_UPC_MX;
		}else if(concept.equalsIgnoreCase("CT")){
			indexName = AppConstants.ELASTIC_UPC_CTS;
		}
		
//		SearchResponse response = client.prepareSearch(indexName)
//				.setSearchType(SearchType.DEFAULT)
//				.setQuery(upcBuilder)
//				.setFrom(0).setSize(500).setExplain(false).execute().actionGet();
//
//		SearchHit[] docs = response.getHits().getHits();
//		// LOGGER.info("UPC size is " + docs.length);
		
		
		org.elasticsearch.action.search.SearchRequest searchRequest = new org.elasticsearch.action.search.SearchRequest(indexName);
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder(); 
		sourceBuilder.from(0);
		sourceBuilder.size(500);
		sourceBuilder.query(upcBuilder);
		searchRequest.source(sourceBuilder);

		SearchResponse searchResponse = client.search(searchRequest); 
		SearchHit[] docs = searchResponse.getHits().getHits();
		
		
		 Upc upcObject = null;
		for (SearchHit hit : docs) {
			  Map<String,Object> result = hit.getSourceAsMap(); 
			  upcObject = new Upc();
			  upcObject.setInumbr(""+((Integer)result.get(AppConstants.ELASTIC_SKUNO)).intValue());
			  returnUpcList.add(upcObject);
		}
		//client.threadPool().shutdown();
		//client = null;
		return  returnUpcList;
	}
	
	/**
	 * Get Search Results based on passed SearchRequest
	 */
	@Override
	public Map getESSkus(SearchRequest searchRequest) throws Exception {
		
		System.out.println("ElasticSearchDAO getESSkus() 4 - 1  ###################### @@@@@@");
		RestHighLevelClient client = esClientService.getESClient();
		System.out.println("ElasticSearchDAO getESSkus() 4 - 2  ###################### Elastic Search Begin MerchAnalyz = "+searchRequest.getMerchAnalyz());
		
		//LOGGER.debug("Elastic Search Begin");
		Map<String, Object> modelMap = new HashMap<String, Object>(4);
		List<SearchDetails> detailsList = new ArrayList<SearchDetails>();
		Map<String, SearchDetails> detailsMap = new HashMap<String, SearchDetails>();
			
		//1- Set Filter
		QueryBuilder QueryBuilder = this.getSearchFilter(searchRequest);
		
		QueryBuilder query = QueryBuilders.boolQuery()
	            .must(QueryBuilders.matchAllQuery())
	            .filter(QueryBuilder);		
		
//		SearchRequestBuilder srb = client.prepareSearch(getSearchIndexName(searchRequest))
//				.setSearchType(SearchType.DEFAULT).setQuery(query)
//				.setFrom(searchRequest.getStart())
//				.setSize(searchRequest.getLimit()).setExplain(false);    
//		LOGGER.debug("Order by::" +searchRequest.getOrderBy());
		
		org.elasticsearch.action.search.SearchRequest esSearchRequest = new org.elasticsearch.action.search.SearchRequest(getSearchIndexName(searchRequest));
		SearchSourceBuilder sourceBuilder = new SearchSourceBuilder(); 
		sourceBuilder.from(searchRequest.getStart());
		sourceBuilder.size(searchRequest.getLimit());
		
		sourceBuilder.query(query);
		
		/*
		//2- Define Sort
		//Ignore sorting if sorting by rank since we are coming from a NR search
		if (searchRequest.getOrderBy() != null
			&& searchRequest.getOrderBy().indexOf("Rank") == -1) {
			
			System.out.println("ElasticSearchDAO getESSkus() 4 - 2 - 2  ###################### Elastic Search searchRequest.getOrderBy() = "+searchRequest.getOrderBy());
			if(searchRequest.getOrderBy().equalsIgnoreCase("merchGroup")){
				searchRequest.setOrderBy("merchgroup");
			}
			if ("DESC".equalsIgnoreCase(searchRequest.getOrderDir())) {
				if(searchRequest.getOrderBy().equalsIgnoreCase("merchGroup")){
					srb.addSort("store", SortOrder.DESC);
					srb.addSort("vendorno", SortOrder.DESC);
					srb.addSort(searchRequest.getOrderBy(), SortOrder.DESC);
				}else{
					srb.addSort(searchRequest.getOrderBy(), SortOrder.DESC);
				}
			} else {
				if(searchRequest.getOrderBy().equalsIgnoreCase("merchGroup")){
					srb.addSort("store", SortOrder.ASC);
					srb.addSort("vendorno", SortOrder.ASC);
					srb.addSort(searchRequest.getOrderBy(), SortOrder.ASC);
				}else{
					srb.addSort(searchRequest.getOrderBy(), SortOrder.ASC);
				}
			}
		}
		else
		{
			System.out.println("ElasticSearchDAO getESSkus() 4 - 2 - 3  ###################### Elastic Search searchRequest.getOrderBy() = "+searchRequest.getOrderBy() +" getMerchAnalyz = "+searchRequest.getMerchAnalyz());
			if (searchRequest.getMerchAnalyz()!=null)
			{
				srb = setMASort(srb, searchRequest.getMerchAnalyz());
			}
			else
			{
				srb = setDefaultSort(srb);
			}
		}*/
		
		//RC::

		sourceBuilder = setDefaultSort(sourceBuilder);
		esSearchRequest.source(sourceBuilder);

		System.out.println("ElasticSearchDAO getESSkus() 4 - 2 - 1  ###################### Elastic Search searchRequest.getOrderBy() = "+searchRequest.getOrderBy());
		LOGGER.debug("ES Request Query:" + sourceBuilder.toString());		

		// 3- Process results
		
		SearchResponse searchResponse = client.search(esSearchRequest); 
		SearchHit[] docs = searchResponse.getHits().getHits();
		
//		SearchResponse response = srb.execute().actionGet();
//		SearchHit[] docs = response.getHits().getHits();
		long totalCount = searchResponse.getHits().getTotalHits();
		
		//LOGGER.info("ES size is " + totalCount);
		System.out.println("ElasticSearchDAO getESSkus() 4 - 3  ###################### totalCount = "+totalCount +" searchRequest.getLanguage() = "+searchRequest.getLanguage());
		System.out.println("ElasticSearchDAO getESSkus() 4 - 4  ###################### getMaxCount = "+searchRequest.getMaxCount());
		if (totalCount > 0  && totalCount<=searchRequest.getMaxCount())
		{
			SearchDetails detailsObj = null;
			List<Long> skus = new ArrayList<Long>();
			List<Long> stores = new ArrayList<Long>();
			List<Long> vendors = new ArrayList<Long>();
			
			System.out.println("ElasticSearchDAO getESSkus() 4 - 5  ###################### getMaxCount = "+searchRequest.getMaxCount());
			
			for (SearchHit hit : docs) {
				detailsObj = new SearchDetails();
				detailsObj = this.getDetailsObjectFromMap(detailsObj,
						hit.getSourceAsMap(), searchRequest.getLanguage());
				
				skus.add(detailsObj.getSku());
				stores.add(detailsObj.getStoreNo());
				vendors.add(detailsObj.getVendorNo());
				
				detailsList.add(detailsObj);
				detailsMap.put(detailsObj.getSku()+":"+
						detailsObj.getStoreNo() + ":"+
						detailsObj.getVendorNo(), detailsObj);
			}
			
			System.out.println("ElasticSearchDAO getESSkus() 4 - 5 - 1  ###################### SKUS = "+searchRequest.getSkus());
			System.out.println("ElasticSearchDAO getESSkus() 4 - 5 - 2  ###################### Vendors = "+searchRequest.getVendorNos());
			System.out.println("ElasticSearchDAO getESSkus() 4 - 5 - 3  ###################### Dept = "+searchRequest.getDepts());
			System.out.println("ElasticSearchDAO getESSkus() 4 - 5 - 4  ###################### Sub Dept = "+searchRequest.getSubDepts());			
		}
		
		modelMap.put("data", detailsList);
		modelMap.put("total", totalCount);
		modelMap.put("success", true);
		return modelMap;
	}

	/**
	 * Builds and returns the search filter based on SearchRequest object
	 * @param searchRequest
	 * @return
	 */
	public QueryBuilder getSearchFilter(SearchRequest searchRequest){
		
		System.out.println("ElasticSearchDAO getSearchFilter() 10 - 1   ###################### searchRequest.getStatuses() = "+searchRequest.getStatuses());
		// convert statuses to lower case
		List<String> searchStatus; 
		
		if (searchRequest.getStatuses() == null) {
			//This happens for Top 100 links
			searchStatus = Arrays.asList("a", "i", "n", "d");
		} else {
			searchStatus = new ArrayList<String>();
			for (int i = 0; i < searchRequest.getStatuses().size(); i++) {
				System.out.println("ElasticSearchDAO getSearchFilter() 10 - 1 - 1   ###################### searchRequest.getStatuses() = "+searchRequest.getStatuses().get(i));
				searchStatus.add(searchRequest.getStatuses().get(i).toLowerCase());
			}
		}
		
		System.out.println("ElasticSearchDAO getSearchFilter() 10 - 1 - 2   ###################### searchRequest.getStoreNos() = "+searchRequest.getStoreNos() +" size = "+searchRequest.getStoreNos().size());
		//This happens for Top 100 links
		/*
		if (searchRequest.getStoreNos()==null || searchRequest.getStoreNos().size()==0) {
			System.out.println("ElasticSearchDAO getSearchFilter() 10 - 1 - 3   ###################### searchRequest.getStoreNo() = "+searchRequest.getStoreNo());
			List<Long> storeNos = new ArrayList<Long>();
			storeNos.add(searchRequest.getStoreNo());
			searchRequest.setStoreNos(storeNos);
		}*/
		
		// 1- Store & Status
		QueryBuilder QueryBuilder  = QueryBuilders.boolQuery();
		//QueryBuilder QueryBuilder  = QueryBuilders.boolQuery().must(QueryBuilders.termsQuery("store",searchRequest.getStoreNos()));
				//.must(QueryBuilders.termsQuery("store",searchRequest.getStoreNos()));
		
		//QueryBuilder QueryBuilder  = QueryBuilders.boolQuery().must(QueryBuilders.typeQuery("invbal"))
		//		.must(QueryBuilders.termsQuery("store",searchRequest.getStoreNos()));
		
				//.must(QueryBuilders.termQuery("abletobesold", "y"));		
		System.out.println("ElasticSearchDAO getSearchFilter() 10 - 2   ####### searchStatus.size() = "+searchStatus.size() +" COntains a = "+searchStatus.contains("a"));
		
		if(searchStatus.size() == 1 && searchStatus.contains("a"))
		{
			/////////////
			//System.out.println("ElasticSearchDAO getSearchFilter() 10 - 2 - 1   #######");
			//QueryBuilder = ((BoolQueryBuilder)QueryBuilder).must(QueryBuilders.termsQuery("invstatus", searchStatus));
			System.out.println("ElasticSearchDAO getSearchFilter() 10 - 2 - 1   #######");
			QueryBuilder = ((BoolQueryBuilder)QueryBuilder).must(QueryBuilders.termsQuery("SKUSTATUS", searchStatus));
			//////////////////////
		}
		else 
		{
			BoolQueryBuilder skuStatusABuilder = new BoolQueryBuilder();
			BoolQueryBuilder skuStatusINDBuilder1 = new BoolQueryBuilder();
			//BoolQueryBuilder skuStatusINDBuilder2 = new BoolQueryBuilder();
			//SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			//SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			
			/////////////
			List<String> temStatus = new ArrayList<String>(searchStatus);
			temStatus.remove("a");
			//skuStatusINDBuilder1.must(QueryBuilders.termsQuery("invstatus", temStatus));		
			skuStatusINDBuilder1.must(QueryBuilders.termsQuery("SKUSTATUS", temStatus));
			System.out.println("ElasticSearchDAO getSearchFilter() 10 - 3   ######################");
			//////////
						
			/*
			RangeQueryBuilder onhandQueryBuilder = new RangeQueryBuilder("onhand");
			onhandQueryBuilder.gt("0");
			skuStatusINDBuilder2.should(onhandQueryBuilder);
			RangeQueryBuilder onorderQueryBuilder = new RangeQueryBuilder("onorder");
			onorderQueryBuilder.gt("0");
			skuStatusINDBuilder2.should(onorderQueryBuilder);
            RangeQueryBuilder lastSoldDateFilterBuilder = new RangeQueryBuilder(
					"lastsolddate");
			lastSoldDateFilterBuilder.gte("99999999");
			lastSoldDateFilterBuilder.lte("99999999");
			skuStatusINDBuilder2.should(lastSoldDateFilterBuilder);
			skuStatusINDBuilder1.must(skuStatusINDBuilder2);
			*/	
			
            /////////////
			if(searchStatus.contains("a"))
			{
				System.out.println("ElasticSearchDAO getSearchFilter() 10 - 3 - 1   ######################");
				//skuStatusABuilder.should(QueryBuilders.termsQuery("invstatus", "a"));
				skuStatusABuilder.should(QueryBuilders.termsQuery("SKUSTATUS", "a"));
				skuStatusABuilder.should(skuStatusINDBuilder1);				
				QueryBuilder = ((BoolQueryBuilder)QueryBuilder).must(skuStatusABuilder);
			}
			else
			{
				System.out.println("ElasticSearchDAO getSearchFilter() 10 - 3 - 2   ######################");
				QueryBuilder = ((BoolQueryBuilder)QueryBuilder).must(skuStatusINDBuilder1);
			}
            /////////////
			
		}
		
		// 2 - SKU
		// If SKU is available in search , Ignore else block
		if (searchRequest.getSkus() != null
				&& searchRequest.getSkus().size() > 0) {
			QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
					.must(QueryBuilders.termsQuery("SKU",
							searchRequest.getSkus()));
		} else {
		// 2- Vendor Number
		if (searchRequest.getVendorNos() != null
				&& searchRequest.getVendorNos().size() > 0) {
			QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
					.must(QueryBuilders.termsQuery("VENDORNO",
							searchRequest.getVendorNos()));
		}

		//3- Department
		if (searchRequest.getDepts() != null
				&& searchRequest.getDepts().size() > 0) {
			QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
					.must(QueryBuilders.termsQuery("DEPT",
							searchRequest.getDepts()));
		}
		
		// 4- Sub Department
		if (searchRequest.getSubDepts() != null
				&& searchRequest.getSubDepts().size() > 0) {
			QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
					.must(QueryBuilders.termsQuery("SUBDEPT",
							searchRequest.getSubDepts()));
		}
		
		// 5- Class
		if (searchRequest.getClas() != null
				&& searchRequest.getClas().size() > 0) {
			QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
					.must(QueryBuilders.termsQuery("CLASS",
							searchRequest.getClas()));
		}
		
		// 6- Event
		if (searchRequest.getEvents() != null
				&& searchRequest.getEvents().size() > 0) {
			for (int i = 0; i < searchRequest.getEvents().size(); i++) {
				//System.out.println("ElasticSearchDAO getSearchFilter() 10 - 1 - 1   ###################### searchRequest.getStatuses() = "+searchRequest.getStatuses().get(i));
				//searchStatus.add(searchRequest.getStatuses().get(i).toLowerCase());
				QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
						.should(QueryBuilders.wildcardQuery("EVENTNO._EVENTNO",
								"*"+searchRequest.getEvents().get(i)+"*"));
								//"*375646*"));
								//searchRequest.getEvents()));
			}
			QueryBuilder = ((BoolQueryBuilder) QueryBuilder).minimumShouldMatch("1");
		}
		
		// 7- Vendor Name
		if (searchRequest.getVendorName() != null
				&& !searchRequest.getVendorName().trim().equals("")) {
			if(searchRequest.getVenNameMode() != null && searchRequest.getVenNameMode().indexOf("S") != -1) {
				QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
						.must(QueryBuilders.prefixQuery("VENDORNM._VENDORNM",
								searchRequest.getVendorName().toLowerCase()));
			}else if(searchRequest.getVenNameMode() != null && searchRequest.getVenNameMode().indexOf("C") != -1){
//				QueryBuilder = ((BoolQueryBuilder) QueryBuilder).must(QueryBuilders.queryFilter(QueryBuilders.wildcardQuery("vendornm._vendornm", "*"+searchRequest.getVendorName().toLowerCase()+"*")));
				QueryBuilder = ((BoolQueryBuilder) QueryBuilder).must(
						QueryBuilders.termQuery("VENDORNM.VENDORNM_CONTAINS", searchRequest.getVendorName().toLowerCase()));
//								QueryBuilders.wildcardQuery("vendornm._vendornm", "*"+searchRequest.getVendorName().toLowerCase()+"*"));
			}else{
				QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
						.must(QueryBuilders.termQuery("VENDORNM._VENDORNM",
								searchRequest.getVendorName().toLowerCase()));
			}
		}

		// 9- SKU Description
		if (searchRequest.getSkuDescription() != null) {
			if(searchRequest.getSkuMode() != null && searchRequest.getSkuMode().indexOf("S") != -1) {
				QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
						.must(QueryBuilders.termsQuery("SKUDESC._SKUDESC",
								searchRequest.getSkuDescription().toLowerCase()));
			}else if(searchRequest.getSkuMode() != null && searchRequest.getSkuMode().indexOf("C") != -1){
//				QueryBuilder = ((BoolQueryBuilder) QueryBuilder).must(QueryBuilders.wildcardQuery("skudesc._skudesc", "*"+searchRequest.getSkuDescription().toLowerCase()+"*")); 
				QueryBuilder = ((BoolQueryBuilder) QueryBuilder).must(QueryBuilders.termQuery("SKUDESC.SKUDESC_CONTAINS", searchRequest.getSkuDescription().toLowerCase())); 
			}else{
				QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
						.must(QueryBuilders.termsQuery("SKUDESC._SKUDESC",
								searchRequest.getSkuDescription().toLowerCase()));
			}
		}

		// 10- UPC
		if (searchRequest.getUpcs() != null
				&& searchRequest.getUpcs().size() > 0) {
			QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
					.must(QueryBuilders.termsQuery("UPCS._UPCS",
							searchRequest.getUpcs()));
		}

		} // SKU else block end
       
		// 11- Merch Analyzer
		if (searchRequest.getMerchAnalyz() != null) {
			QueryBuilder = ((BoolQueryBuilder) QueryBuilder)
					.must(QueryBuilders.termsQuery("MA._MA",
							searchRequest.getMerchAnalyz().trim().toLowerCase()));
		}
		
		System.out.println("ElasticSearchDAO getSearchFilter() 10 - 4 END   ######################");

		return ((BoolQueryBuilder) QueryBuilder);
	}

	/**
	 * Set Default Sort
	 * @param srb
	 * @return
	 */
	public SearchSourceBuilder setDefaultSort(SearchSourceBuilder srb) {
		
		   srb.sort(new FieldSortBuilder("DEPT").order(SortOrder.ASC));
		   srb.sort(new FieldSortBuilder("SUBDEPT").order(SortOrder.ASC));
		   srb.sort(new FieldSortBuilder("CLASS").order(SortOrder.ASC));
		   srb.sort(new FieldSortBuilder("VENDORNO").order(SortOrder.ASC));
		   srb.sort(new FieldSortBuilder("SKU").order(SortOrder.ASC));
		return srb;
	}
	
	/**
	 * Set Merch Analyzer Sort
	 * @param srb
	 * @return
	 */
/*	public SearchRequestBuilder setMASort(SearchRequestBuilder srb, String ma) {

		String script = "for ($i in doc['ma_category'].values) { " + 
		" if ((!$i.isEmpty()) && ($i.substring(0,len)==ma)) " + 
		" return $i.substring(len+1,len+4); " + 
		" }; " + 
		" return \"no_sort\" "; 

		Map<String, Object> params = new HashMap<>();

		params.put("ma", ma.toUpperCase());
		params.put("len", ma.length());
		//params.put("terms",searchTerms);
		Script sc = new Script(ScriptType.INLINE,"groovy",script,params);  

		srb.addSort(SortBuilders.scriptSort(sc, ScriptSortType.STRING));
		srb = this.setDefaultSort(srb);
		
		return srb;
	}*/
	
	/**
	 * Get Search Index Name
	 * @param searchRequest
	 * @return
	 */
	public String getSearchIndexName(SearchRequest searchRequest){
		//String indexName = "lookup_instant_save";
		String indexName = AppConstants.LOOKUP_INSTANT_SAVE;
		
		/*
		String indexName = AppConstants.SOSEARCH_INDEX;
		String indexName = "sosearch";
		if (searchRequest.getConcept().equalsIgnoreCase("HARMON")){
			indexName = "sosearchhm";
		} else if (searchRequest.getCountry().equalsIgnoreCase("CAN")){
			indexName = "sosearchca";
		} else if (searchRequest.getCountry().equalsIgnoreCase("MEX")){
			indexName = "sosearchmx";
		}else if (searchRequest.getConcept().equalsIgnoreCase("CTS")){
			indexName = "sosearchcts";
		}*/
		System.out.println("ElasticSearchDao getSearchIndexName indexName = "+indexName);
		return indexName;
	}
	
	/**
	 * Get DetailsObj Data from Map
	 * @param detailsObj
	 * @param result
	 * @return
	 */
	public SearchDetails getDetailsObjectFromMap(SearchDetails detailsObj,
			Map<String, Object> result, String lang) {
		
		//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 1  ###################### lang = "+lang);		
		//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 1  ###################### lang = "+lang);
		//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 1  ###################### ma = "+result.get("ma"));
		//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 4 sku = "+result.get("sku") +" enwebdesc = "+result.get("enwebdesc") +" ma = "+result.get("ma") +" eventno = "+result.get("eventno"));
		//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 4 sku = "+result.get("sku") +" skuwebdesc = "+result.get("skuwebdesc") +" ma = "+result.get("ma") +" eventno = "+result.get("eventno") +" skustatus = "+result.get("skustatus"));
		
		String vendorDeptText, deptText, skuDesc, webDesc;
		//Double retail, mu, dblObj, cost;
		
		detailsObj.setSku(Long.parseLong(result.get("SKU").toString()));
//		detailsObj.setSku(((Integer) result.get("sku")).longValue());
//		detailsObj.setStoreNo(((Integer) result.get("store")).longValue());

		detailsObj.setVendorNo(((Integer) result.get("VENDORNO")).longValue());
		if(((String) result.get("VENDORNM"))!=null){
			detailsObj.setVendorName(((String) result.get("VENDORNM")).trim());
		}
		else{
			detailsObj.setVendorName(((String) result.get("VENDORNM")));
		}
		detailsObj.setSkuDescription(((String) result.get("SKUDESC")).trim());
		
		detailsObj.setMerchGroup(((String) result.get("MA")));		
		//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 2  ###################### lang = "+lang);

		detailsObj.setDept((Integer) result.get("DEPT"));
		detailsObj.setSubDept((Integer) result.get("SUBDEPT"));
		detailsObj.setClas((Integer) result.get("CLASS"));
		//detailsObj.setStatus((String) result.get("invstatus"));
		//detailsObj.setEnWebDesc((String) result.get("enwebdesc"));
		detailsObj.setStatus((String) result.get("SKUSTATUS"));
		detailsObj.setEnWebDesc((String) result.get("SKUWEBDESC"));
		
		skuDesc = ((String)result.get(lang+"skudesc"));
		webDesc = ((String)result.get(lang+"webdesc"));
		if (skuDesc!=null && !skuDesc.trim().equals("")){
			detailsObj.setSkuDescription(skuDesc.replaceAll("\"", "\'\'"));
		}
		
		Object vendormina= result.get("vendormina");
		if(vendormina!=null)
		{
			if(vendormina instanceof Double )
			{
				detailsObj.setVendorMina(((Double) vendormina).doubleValue());
			}
			else
			{
				detailsObj.setVendorMina(((Integer) vendormina).doubleValue());
			}
		}
		detailsObj.setVendorMinc((String) result.get("vendorminc"));
		
		//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 3  ###################### vendorminc = "+result.get("vendorminc"));
		/*		
		String vendorMinType=null;
		if(detailsObj.getVendorMinc().equals("1")){
			vendorMinType="Dollar($)";
		}else
		if(detailsObj.getVendorMinc().equals("2")){
			vendorMinType="Weight";
		}else
		if(detailsObj.getVendorMinc().equals("3")){
			vendorMinType="Units";
		}else
		if(detailsObj.getVendorMinc().equals("4")){
			vendorMinType="Cases";
		}*/
		//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 3  ###################### lang = "+lang);
		
		try {
			/*
			if(detailsObj.getVendorMinc()!=null){
				if(detailsObj.getVendorMinc().equals("1")){
					DecimalFormat df = new DecimalFormat("0.00");
					vendorDeptText = "Vendor#:&nbsp;" + detailsObj.getVendorNo()
					+ ",&nbsp;" + detailsObj.getDept() + "/"
					+ detailsObj.getSubDept() + "/" + detailsObj.getClas()
				 	+ ",&nbsp;<upc_token><br> " + detailsObj.getVendorName()+ "-&nbsp;" + vendorMinType+ "-&nbsp;"
					+"$"+df.format(detailsObj.getVendorMina());
				}else{
					if(detailsObj.getVendorMina()!=null){
				       vendorDeptText = "Vendor#:&nbsp;" + detailsObj.getVendorNo()
						+ ",&nbsp;" + detailsObj.getDept() + "/"
						+ detailsObj.getSubDept() + "/" + detailsObj.getClas()
				 	    + ",&nbsp;<upc_token><br> " + detailsObj.getVendorName()+ "-&nbsp;" + vendorMinType+ "-&nbsp;"
						+ Math.round(detailsObj.getVendorMina());
					}else{
						vendorDeptText = "Vendor#:&nbsp;" + detailsObj.getVendorNo()
								+ ",&nbsp;" + detailsObj.getDept() + "/"
								+ detailsObj.getSubDept() + "/" + detailsObj.getClas()
							    + ",&nbsp;<upc_token><br> " + detailsObj.getVendorName()+ "-&nbsp;" + vendorMinType+ "-&nbsp;"
								+ detailsObj.getVendorMina();
					}
				}
			}else{
			        vendorDeptText = "Vendor#:&nbsp;" + detailsObj.getVendorNo()
					+ ",&nbsp;" + detailsObj.getDept() + "/"
					+ detailsObj.getSubDept() + "/" + detailsObj.getClas()
				    + ",&nbsp;<upc_token><br> " + detailsObj.getVendorName()+ "-&nbsp;" + vendorMinType+ "-&nbsp;"
					+detailsObj.getVendorMina();
			}*/
			
			vendorDeptText = "Vendor#:&nbsp;" + detailsObj.getVendorNo()
					+ ",&nbsp;" + detailsObj.getDept() + "/"
					+ detailsObj.getSubDept() + "/" + detailsObj.getClas()
				    + ",&nbsp;<upc_token><br> " + detailsObj.getVendorName(); //+ "-&nbsp;" + vendorMinType+ "-&nbsp;"
					//+detailsObj.getVendorMina();
			
			deptText = detailsObj.getDept() +"/" +detailsObj.getSubDept() + "/" + detailsObj.getClas();
			
			if (webDesc!=null && !webDesc.trim().equals("")){
				detailsObj.setWebSkuDesc(webDesc.trim().replaceAll("\"", "\'\'"));						
			}					
			else
			{				
				if (skuDesc!=null && !skuDesc.trim().equals("")){
					detailsObj.setWebSkuDesc(skuDesc.replaceAll("\"", "\'\'"));
				} 
				else {
					detailsObj.setWebSkuDesc(detailsObj.getSkuDescription().trim().replaceAll("\"", "\'\'"));
				}
			}	
			detailsObj.setVendorWebSkuDesc(detailsObj.getWebSkuDesc() + " <br> " + vendorDeptText);
			detailsObj.setWebSkuDesc(detailsObj.getWebSkuDesc() + " <br> " + deptText);					
			detailsObj.setWebSkuDesc(detailsObj.getWebSkuDesc() + " <br> "
					+ vendorDeptText);
			
			//detailsObj.setEventNumber((Integer) result.get("eventno"));
			detailsObj.setEventNumber((String) result.get("EVENTNO"));
			//System.out.println("ElasticSearchDAO getDetailsObjectFromMap() 9 - 4  ###################### lang = "+lang);

		} catch (Exception ex) {			
			System.out.println("Exception in websku description:"+ex.getMessage() + "::StackTrace::" + ex);
			ex.printStackTrace();
			logger.error("Exception in websku description:"+ex.getMessage() + "::StackTrace::" + ex);			
		}
		return detailsObj;
	}
	
	/**
	 * Call SuperProc to get Page Details
	 * @param searchRequest
	 * @param detailsList
	 * @return
	 * @throws SOException
	 */
	public List<SearchDetails> getPageSPDetails(
			SearchRequest searchRequest, Map<String, SearchDetails> detailsMap) throws Exception
	{		
		
		System.out.println("ElasticSearchDAO getPageSPDetails() 6 - 1  ######################");
		List<SearchDetails> detailsList = new ArrayList<SearchDetails>();
		if(detailsMap.size() > 0){
			JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
			jdbcTemplate.setResultsMapCaseInsensitive(true);
		    LOGGER.debug("Invoking search details procedure: SOESRCHDTL");
	
		    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
		    simpleJdbcCall.withProcedureName("SOESRCHDTL"); 
		    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
	
		    simpleJdbcCall.declareParameters(
		    		new SqlParameter("@skus", Types.VARCHAR),
		    		new SqlParameter("@storeNos", Types.VARCHAR),
		    		new SqlParameter("@vendorNos", Types.VARCHAR),
		    		new SqlParameter("@salesStr1", Types.DECIMAL),
		    		new SqlParameter("@startDt1", Types.CHAR),
		    		new SqlParameter("@endDt1", Types.CHAR),
		    		new SqlParameter("@salesStr2", Types.DECIMAL),
		    		new SqlParameter("@startDt2", Types.CHAR),
		    		new SqlParameter("@endDt2", Types.CHAR),
		    		new SqlParameter("@multiStrFlag", Types.CHAR),
		    		new SqlParameter("@searchId", Types.VARCHAR),
		    		new SqlParameter("@start", Types.NUMERIC),
		    		new SqlParameter("@pageSize", Types.NUMERIC),
		    		new SqlParameter("@orderCol", Types.VARCHAR),
		    		new SqlParameter("@orderDir", Types.VARCHAR));
		    
		    SearchDetailsMapper searchDetailsMapper = new SearchDetailsMapper(
		    			null, searchRequest.getRoundDown(), 0, 
		    			detailsMap, searchRequest.getNoAccessStores());
		    
			simpleJdbcCall.returningResultSet("results", searchDetailsMapper);
		    Map<String, Object> inputParams = new HashMap<String, Object>();
		    	    
			ESSortRequest esSortRequest = searchRequest.getEsSortRequest();

		    inputParams.put("@skus", null);
		    inputParams.put("@storeNos", null);
		    inputParams.put("@vendorNos", null);
			inputParams.put("@salesStr1", searchRequest.getSalesStr1());
			inputParams.put("@startDt1", searchRequest.getStartDt1());
			inputParams.put("@endDt1", searchRequest.getEndDt1());
			inputParams.put("@salesStr2", searchRequest.getSalesStr2());
			inputParams.put("@startDt2", searchRequest.getStartDt2());
			inputParams.put("@endDt2", searchRequest.getEndDt2());
			inputParams.put("@multiStrFlag", searchRequest.getStoreNos().size() > 1 ? "Y" : "N");
			
			inputParams.put("@searchId", esSortRequest!=null?esSortRequest.getSearchId():null);
			inputParams.put("@start", esSortRequest!=null?esSortRequest.getStart():null);
			inputParams.put("@pageSize", esSortRequest!=null?esSortRequest.getLimit():null);
			inputParams.put("@orderCol", esSortRequest!=null?esSortRequest.getOrderBy():null);
			inputParams.put("@orderDir", esSortRequest!=null?esSortRequest.getOrderDir():null);
			Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams); 	 
			
			detailsList = searchDetailsMapper.getDetailsList();
		}
	    return detailsList;
	}	
	
	/**
	 * Call SuperProc to get Page Details
	 * @param searchRequest
	 * @param detailsList
	 * @param skus
	 * @param stores
	 * @param vendors
	 * @return
	 * @throws SOException
	 */
	public List<SearchDetails> getPageSPDetails(SearchRequest searchRequest,
			List<SearchDetails> detailsList, List<Long> skus,
			List<Long> stores, List<Long> vendors) {		
		
		System.out.println("ElasticSearchDAO getPageSPDetails() 4 - 4  ###################### detailsList.size() = "+detailsList.size());
		JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
		jdbcTemplate.setResultsMapCaseInsensitive(true);
	    LOGGER.debug("Invoking search details procedure: SOESRCHDTL");

	    if(detailsList.size()>0)
	    {
		    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
		    simpleJdbcCall.withProcedureName("SOESRCHDTL"); 
		    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
	
		    simpleJdbcCall.declareParameters(
		    		new SqlParameter("@skus", Types.VARCHAR),
		    		new SqlParameter("@storeNos", Types.VARCHAR),
		    		new SqlParameter("@vendorNos", Types.VARCHAR),
		    		new SqlParameter("@salesStr1", Types.DECIMAL),
		    		new SqlParameter("@startDt1", Types.CHAR),
		    		new SqlParameter("@endDt1", Types.CHAR),
		    		new SqlParameter("@salesStr2", Types.DECIMAL),
		    		new SqlParameter("@startDt2", Types.CHAR),
		    		new SqlParameter("@endDt2", Types.CHAR),
		    		new SqlParameter("@multiStrFlag", Types.CHAR),
		    		new SqlParameter("@searchId", Types.VARCHAR),
		    		new SqlParameter("@start", Types.NUMERIC),
		    		new SqlParameter("@pageSize", Types.NUMERIC),
		    		new SqlParameter("@orderCol", Types.VARCHAR),
		    		new SqlParameter("@orderDir", Types.VARCHAR));
		    
			simpleJdbcCall.returningResultSet("results",
					new SearchDetailsMapper(detailsList, searchRequest.getRoundDown(), 0, null,
							searchRequest.getNoAccessStores()));
			
		    Map<String, Object> inputParams = new HashMap<String, Object>();
		    	    
			ESSortRequest esSortRequest = searchRequest.getEsSortRequest();

		    inputParams.put("@skus", esSortRequest==null?ApplicationUtil.longListToString(skus):null);
		    inputParams.put("@storeNos", esSortRequest==null?ApplicationUtil.longListToString(stores):null);
		    inputParams.put("@vendorNos", esSortRequest==null?ApplicationUtil.longListToString(vendors):null);
			inputParams.put("@salesStr1", searchRequest.getSalesStr1());
			inputParams.put("@startDt1", searchRequest.getStartDt1());
			inputParams.put("@endDt1", searchRequest.getEndDt1());
			inputParams.put("@salesStr2", searchRequest.getSalesStr2());
			inputParams.put("@startDt2", searchRequest.getStartDt2());
			inputParams.put("@endDt2", searchRequest.getEndDt2());
			inputParams.put("@multiStrFlag", searchRequest.getStoreNos().size() > 1 ? "Y" : "N");
			
			inputParams.put("@searchId", esSortRequest!=null?esSortRequest.getSearchId():null);
			inputParams.put("@start", esSortRequest!=null?esSortRequest.getStart():null);
			inputParams.put("@pageSize", esSortRequest!=null?esSortRequest.getLimit():null);
			inputParams.put("@orderCol", esSortRequest!=null?esSortRequest.getOrderBy():null);
			inputParams.put("@orderDir", esSortRequest!=null?esSortRequest.getOrderDir():null);
			
			if(esSortRequest!=null){
				LOGGER.debug("start row::" + esSortRequest.getStart());
				LOGGER.debug("Limit row::" + esSortRequest.getLimit());	
				LOGGER.debug("searchId::" + esSortRequest.getSearchId());	
			}
			Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams); 	    
	    }	
	    return detailsList;
	}
	
	
	/*
	 * Insert parametes for ES Sorting (salesstore1/salesstore2)
	 */
	private void insertSaveParameters(final List<SearchDetails> detailsList, final String searchId) throws Exception
	{
		String insertSQL = "Insert into SOPSVPARAM (SAVEID, STORE, SKU, VENDORNO, RECORDNO) " +		 			
		 		" Values (?, ?, ?, ?, ?)";			 

		getJdbcTemplate().batchUpdate(insertSQL, new BatchPreparedStatementSetter() {
		@Override
		public void setValues(PreparedStatement ps, int i) throws SQLException {
			SearchDetails searchDetails = detailsList.get(i);
			ps.setString(1, searchId);			
			ps.setLong(2, searchDetails.getStoreNo());
			ps.setLong(3, searchDetails.getSku());				
			ps.setLong(4, searchDetails.getVendorNo());
			ps.setInt(5, i+1); //Recordno should start from 1
		}
		@Override
		public int getBatchSize() {
			return (int) detailsList.size();
		}
		});						
	}	
	 
	private void insertSaveParameters(final SearchHit[] docs, final String searchId) throws Exception
	{
		String insertSQL = "Insert into SOPSVPARAM (SAVEID, STORE, SKU, RECORDNO) " +		 			
		 		" Values (?, ?, ?, ?)";			 

		getJdbcTemplate().batchUpdate(insertSQL, new BatchPreparedStatementSetter() {
		@Override
		public void setValues(PreparedStatement ps, int i) throws SQLException {
			SearchHit hit = docs[i];
			Map<String,Object> result = hit.getSourceAsMap(); 
			Integer sku = (Integer)result.get("ELEMENT_ID");
			Integer strore = (Integer)result.get("STORE_NUM");
			ps.setString(1, searchId);			
			ps.setInt(2, strore);
			ps.setInt(3, sku);				
			ps.setInt(4, i+1); //Recordno should start from 1
		}
		@Override
		public int getBatchSize() {
			return (int) docs.length;
		}
		});						
	}		
	
    private static class SearchDetailsMapper implements RowMapper<SearchDetails> {
			
		
		public List<SearchDetails> detailsList;
		public Double roundDown;
		public int startRow;
		public Map<String, SearchDetails> detailsMap;
		private List<Long> 	noAccessStores;

		
		public SearchDetailsMapper(List<SearchDetails> detailsList, 
				Double roundDown, int startRow, 
				Map<String,SearchDetails> detailsMap,
				List<Long> 	noAccessStores)
		{
			
			System.out.println("ElasticSearchDAO SearchDetailsMapper() SearchDetailsMapper 8 - 1  ######################");
			this.detailsList = detailsMap==null?detailsList:new ArrayList<SearchDetails>();
			this.roundDown = roundDown;
			this.startRow = startRow;
			this.detailsMap = detailsMap;			
			this.noAccessStores = noAccessStores;
		}
		
		public List<SearchDetails> getDetailsList(){
			return this.detailsList;
		}
		
		public Map<String, SearchDetails> getDetailsMap(){
			return this.detailsMap;
		}		
		
		public SearchDetails mapRow(ResultSet rs, int rowNum) throws SQLException {	
			System.out.println("ElasticSearchDAO mapRow() SearchDetailsMapper 9 - 1  ######################");
			SearchDetails srcdetails = null;			
			if(detailsMap != null){				
				 srcdetails = detailsMap.get(rs.getLong("sku") + ":" + rs.getLong("storeno") + ":" + rs.getLong("vendorno"));
				 this.detailsList.add(srcdetails);
			}
			else{
				srcdetails = detailsList.get(this.startRow+rowNum);
			}
			
			long soQty, casePack;
			Long onHand;
			String sws, importCode, restrictedFlag;
			
			srcdetails.setStoreNo(rs.getLong("storeno"));
			srcdetails.setSku(rs.getLong("sku"));
			srcdetails.setUpc(rs.getLong("upc"));
			
			//apply primary upc on <upc_token> on detailsObj.setVendorWebSkuDesc and detailsObj.setWebSkuDesc  
			String upcStr = String.valueOf(rs.getLong("upc"));
			String vendorWebSkuDesc = srcdetails.getVendorWebSkuDesc();
			
			vendorWebSkuDesc = vendorWebSkuDesc.replace("<upc_token>", upcStr);
			srcdetails.setVendorWebSkuDesc(vendorWebSkuDesc);
			
			String webSkuDesc = srcdetails.getWebSkuDesc();
			webSkuDesc = webSkuDesc.replace("<upc_token>", upcStr);
			srcdetails.setWebSkuDesc(webSkuDesc);
			return srcdetails;
	    }
	}
    /*
	public List<Vendor>  getVendorList(List<Long> vendorNoList, String vendorDesc, String country, boolean nolimit, String concept, String searchmode) throws Exception {
		Map<String,String>  currencyCodeMap = null;
		
		System.out.println("ElsticSearch DAO getVendorList vendorNoList = "+vendorNoList +" vendorDesc = "+vendorDesc +" country =  " +country);
		System.out.println("ElsticSearch DAO getVendorList nolimit = "+nolimit +" concept = "+concept +" searchmode =  " +searchmode);
//		if(country.equalsIgnoreCase("CAN")){
//			currencyCodeMap = getCurrencyCode("CAN");
//		} else{
//			currencyCodeMap = getCurrencyCode(concept);
//		}
		
		//if(country.equalsIgnoreCase("USA")){
		//	currencyCodeMap = getCurrencyCode("USA");
		//} 
		List<Vendor> vendorList = new ArrayList<Vendor>();		
		return  vendorList;
	}
 
	public List<Sku>  getSku(Integer sku, String skuDesc, String venPartNo, String country, Integer vendorno,String skuDescFromSearch, String concept, String searchMode) throws Exception{
		
		List<Sku> skuList = new ArrayList<Sku>();	
		
		return  skuList;
	}*/
    
    /**
	 * Get Search Index Name
	 * @param searchRequest
	 * @return
	 */
	/*public String getRankIndexName(SearchRequest searchRequest){
		String indexName = "soprank";
		String rankType = searchRequest.getRankType();
		if (rankType!=null && !rankType.trim().equals("") && !rankType.equals("TOP100")){
			indexName = rankType.trim().toLowerCase()+"rank"; 
		}
		return indexName;
	}*/
	
	
}
