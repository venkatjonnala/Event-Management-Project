package com.bedbath.ssm.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bedbath.ssm.common.util.ApplicationUtil;
/*
import com.bedbath.so.domain.BackPopulatedSkuData;
import com.bedbath.so.domain.SearchDetails;
import com.bedbath.so.domain.SearchRequest;
import com.bedbath.so.domain.Vendor;
import com.bedbath.so.exception.SSMException;
import com.bedbath.so.util.ApplicationUtil;
*/
import com.bedbath.ssm.common.util.ResponseEntity;
import com.bedbath.ssm.exception.CommonDataAccessException;
import com.bedbath.ssm.exception.SSMException;
import com.bedbath.ssm.model.EligibilityDetails;
import com.bedbath.ssm.model.SearchDetails;
import com.bedbath.ssm.model.SearchRequest;
import com.bedbath.ssm.model.Vendor;

@Repository
public class SearchDAOImpl extends BaseDaoSupport implements SearchDAO {

	private static final Logger logger = LoggerFactory.getLogger(SearchDAOImpl.class);
	/* The following methods used for caching prev/next pages
	 * Used for Thread
	 */
	
	private SearchRequest searchRequest = null;
	
	private Map<String, Object> searchDetails = null;
		public SearchRequest getSearchRequest() {
		return searchRequest;
	}
		
	public void setSearchRequest(SearchRequest searchRequest) {
		this.searchRequest = searchRequest;
	}
	
	public Map<String, Object> getSearchDetails() {
		return searchDetails;
	}
	
	public void setSearchDetails(Map<String, Object> searchDetails) {
		this.searchDetails = searchDetails;
	}	
	
	public SearchDAOImpl(){
		super();
	}
	
	@SuppressWarnings("unchecked")	
	public Map<String, Object> search(SearchRequest searchRequest)
			throws SSMException {
		
		System.out.println("SearchDAO search() 2 - 1  ######################");

		Map<String, Object> modelMap = new HashMap<String, Object>(4);

		JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
		jdbcTemplate.setResultsMapCaseInsensitive(true);


	    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);

	    simpleJdbcCall.withProcedureName("SOESEARCH");
	    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();

	    simpleJdbcCall.declareParameters(
	    		new SqlParameter("@storeNos", Types.VARCHAR),
	    		new SqlParameter("@statuses", Types.VARCHAR),
	    		new SqlParameter("@zeroActv", Types.CHAR),
	    		new SqlParameter("@vendorNos", Types.VARCHAR),
	    		new SqlParameter("@vendorNm", Types.VARCHAR),
	    		new SqlParameter("@venPartNo", Types.VARCHAR),
	    		new SqlParameter("@vpnLike", Types.CHAR),
	    		new SqlParameter("@ma", Types.CHAR),
	    		new SqlParameter("@depts", Types.VARCHAR),
	    		new SqlParameter("@subDepts", Types.VARCHAR),
	    		new SqlParameter("@class", Types.VARCHAR),
	    		new SqlParameter("@country", Types.CHAR),
	    		new SqlParameter("@concept", Types.CHAR),
	    		new SqlParameter("@salesStr1", Types.DECIMAL),
	    		new SqlParameter("@startDt1", Types.CHAR),
	    		new SqlParameter("@endDt1", Types.CHAR),
	    		new SqlParameter("@salesStr2", Types.DECIMAL),
	    		new SqlParameter("@startDt2", Types.CHAR),
	    		new SqlParameter("@endDt2", Types.CHAR),
	    		new SqlParameter("@rankPrd", Types.CHAR),
	    		new SqlParameter("@rankMsr", Types.CHAR),
	    		new SqlParameter("@multiStrFlag", Types.CHAR),
	    		new SqlParameter("@start", Types.NUMERIC),
	    		new SqlParameter("@pageSize", Types.NUMERIC),
	    		new SqlParameter("@maxCount",Types.NUMERIC),
	    		new SqlParameter("@orderCol", Types.CHAR),
	    		new SqlParameter("@orderDir", Types.CHAR),
	    		new SqlParameter("@lang", Types.CHAR),
	    		new SqlOutParameter("@count", Types.INTEGER));


	    simpleJdbcCall.returningResultSet("results",new SearchResultsMapper(searchRequest.getNoAccessStores()));
	    simpleJdbcCall.returningResultSet("buildTos",new BuildToMapper());

	    Map inputParams = new HashMap();

	    System.out.println("SearchDAO search() 2 - 1 - 2  ###################### getVendorName = "+searchRequest.getVendorName());
	    System.out.println("SearchDAO search() 2 - 1 - 3  ###################### getDepts = "+searchRequest.getDepts());
	    System.out.println("SearchDAO search() 2 - 1 - 4  ###################### getSearchType = "+searchRequest.getSearchType());

	    inputParams.put("@storeNos", ApplicationUtil.longListToString(searchRequest.getStoreNos()));
		inputParams.put("@statuses", ApplicationUtil.listToString(searchRequest.getStatuses()));
		
		if ("activeItems".equalsIgnoreCase(searchRequest.getSearchType())){
			inputParams.put("@zeroActv", "Y");
		} else {
			inputParams.put("@zeroActv", "N");
		}
		inputParams.put("@ma", searchRequest.getMerchAnalyz());

		if (searchRequest.getVendorNos()!=null && searchRequest.getVendorNos().size()>0) {
	    	inputParams.put("@vendorNos", ApplicationUtil.longListToString(searchRequest.getVendorNos()));
		} else {
			inputParams.put("@vendorNos", null);
		}

		if (searchRequest.getVendorName()!=null && !searchRequest.getVendorName().trim().equals("")) {
	    	if (searchRequest.getVenNameMode()!=null && searchRequest.getVenNameMode().indexOf('C')!=-1) {
	    		inputParams.put("@vendorNm", "%"+searchRequest.getVendorName().trim());
	    	} else {
	    		inputParams.put("@vendorNm", searchRequest.getVendorName().trim());
	    	}
		} else {
			inputParams.put("@vendorNm", null);
		}

		if (searchRequest.getDepts()!=null && searchRequest.getDepts().size()>0) {
	    	inputParams.put("@depts", ApplicationUtil.longListToString(searchRequest.getDepts()));
		} else {
			inputParams.put("@depts", null);
		}

    	if (searchRequest.getSubDepts()!=null && searchRequest.getSubDepts().size()>0) {
	    	inputParams.put("@subDepts", ApplicationUtil.longListToString(searchRequest.getSubDepts()));
    	} else {
    		inputParams.put("@subDepts", null);
    	}

	    if (searchRequest.getClas()!=null && searchRequest.getClas().size()>0) {
	    	inputParams.put("@class", ApplicationUtil.longListToString(searchRequest.getClas()));
	    } else {
	    	inputParams.put("@class", null);
	    }

	    if (searchRequest.getVendorPartNo() !=null && !searchRequest.getVendorPartNo().isEmpty()) {
	    	if (searchRequest.getVenPartMode()!=null && searchRequest.getVenPartMode().indexOf('C')!=-1) {
	    		inputParams.put("@venPartNo", "%"+searchRequest.getVendorPartNo());
	    	} else {
	    		inputParams.put("@venPartNo", searchRequest.getVendorPartNo());
	    	}
	    	inputParams.put("@vpnLike", searchRequest.getLikeMatch());

		} else {
			inputParams.put("@venPartNo", null);
	    	inputParams.put("@vpnLike", null);
		}

		inputParams.put("@country", searchRequest.getCountry());
		inputParams.put("@concept", searchRequest.getConcept());//eg: "BEDBATH"
		inputParams.put("@salesStr1", searchRequest.getSalesStr1());
		inputParams.put("@startDt1", searchRequest.getStartDt1());
		inputParams.put("@endDt1", searchRequest.getEndDt1());
		inputParams.put("@salesStr2", searchRequest.getSalesStr2());
		inputParams.put("@startDt2", searchRequest.getStartDt2());
		inputParams.put("@endDt2", searchRequest.getEndDt2());
		inputParams.put("@rankPrd", searchRequest.getRankPeriod());
		inputParams.put("@rankMsr", searchRequest.getRankBy());
		inputParams.put("@multiStrFlag", searchRequest.getStoreNos().size() > 1 ? "Y" : "N");
		inputParams.put("@start", new BigDecimal(searchRequest.getStart()));
		inputParams.put("@pageSize", new BigDecimal(searchRequest.getLimit()));
		inputParams.put("@maxCount", new BigDecimal(searchRequest.getMaxCount()));
		if(searchRequest.getOrderBy() != null && searchRequest.getOrderBy().equalsIgnoreCase("merchGroup")){
			searchRequest.setOrderBy("storeno,vendorno,merchGroup");
		}
		inputParams.put("@orderCol", searchRequest.getOrderBy());
		inputParams.put("@orderDir", searchRequest.getOrderDir());
		inputParams.put("@lang", searchRequest.getLanguage());

		Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams);
		int rowCount = (((Integer) resultMap.get("@count")).intValue());

		modelMap.put("data", (List<SearchDetails>) resultMap.get("results"));
        modelMap.put("total", rowCount);
        modelMap.put("buildTos", (List<HashMap<String, Object>>) resultMap.get("buildTos"));
        modelMap.put("success", true);

		return modelMap;

	}


	private static class SearchResultsMapper implements RowMapper<SearchDetails> {
		
		private List<Long> 	noAccessStores;
		
		public SearchResultsMapper(List<Long> noAccessStores)
		{
			this.noAccessStores = noAccessStores;
		}		
		
		public SearchDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			SearchDetails srcdetails = new SearchDetails();
			float retail=0;
			String top, kit, importCode,vendorDeptText, deptText, restrictedFlag;

				srcdetails.setVendorNo(rs.getLong("vendorno"));
				srcdetails.setVendorName(rs.getString("vendornm"));
				srcdetails.setStoreNo(rs.getLong("storeno"));				
				srcdetails.setSku(rs.getLong("sku"));
				srcdetails.setSkuDescription(rs.getString("skuDescription") != null? rs.getString("skuDescription").trim() : "");
				srcdetails.setUpc(rs.getLong("upc"));
//				srcdetails.setMultiUPC(rs.getString("multiupc") != null ? rs.getString("multiupc") : "");
				srcdetails.setDept( rs.getInt("dept"));
				srcdetails.setSubDept(rs.getInt("subDept"));
				srcdetails.setClas(rs.getInt("class"));
//				srcdetails.setSwsFlag(rs.getString("swsFlag"));
//				srcdetails.setCasePack(rs.getInt("casePack"));
//				srcdetails.setInnerPack(rs.getInt("innerPack"));
				srcdetails.setVendorMina(rs.getDouble("vendormina"));
				srcdetails.setVendorMinc(rs.getString("vendorminc"));
				
				//Adding forecast qty details
				if(rs.getString("eventname") != null) {
					srcdetails.setEventName(ApplicationUtil.toProperCase(rs.getString("eventname").trim()));
				}

				if(rs.getString("merchGroup") != null) {
					srcdetails.setMerchGroup(rs.getString("merchGroup").trim());
				}

				return srcdetails;
	    }
	}

	public List<Vendor> getVendorMinDetails(Long storeNo, Long vendorNo, Double roundDown) throws SSMException
	{
		JdbcTemplate jdbcTemplate = this.getJdbcTemplate();
		jdbcTemplate.setResultsMapCaseInsensitive(true);
	    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
	    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
	    Map<String, Object> inputParams = new HashMap<String, Object>();
	    String procname = "SOEVENDMIN";
	    vendorNo = vendorNo==0?null:vendorNo;
	    simpleJdbcCall.declareParameters(
	    		new SqlParameter("@storeNo", Types.NUMERIC),
	    		new SqlParameter("@vendorNo", Types.NUMERIC),
	    		new SqlParameter("@roundDown", Types.NUMERIC),
	    		new SqlOutParameter("@minType", Types.CHAR),
	    		new SqlOutParameter("@minAmount", Types.DECIMAL),
	    		new SqlOutParameter("@totalOrder", Types.DECIMAL)
	    );
	    simpleJdbcCall.withProcedureName(procname);
	    inputParams.put("@storeNo", storeNo);
	    inputParams.put("@vendorNo", vendorNo);
	    inputParams.put("@roundDown", roundDown);

	    simpleJdbcCall.returningResultSet("results",new SearchResultsMapper(null));
		Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams);
		String minType = (String) resultMap.get("@minType");
		BigDecimal bd = (BigDecimal) resultMap.get("@minAmount");
		Float minAmount = bd!=null?bd.floatValue():0f;
		bd = (BigDecimal) resultMap.get("@totalOrder");
		Float totalOrder = bd!=null?bd.floatValue():0f;

		Vendor vendor = new Vendor();
		vendor.setVendorNo(vendorNo);
		vendor.setMinType(minType);
		vendor.setMinAmount(minAmount);
		vendor.setTotalOrder(totalOrder);
		List<Vendor> list = new ArrayList<Vendor>();
		list.add(vendor);
		return list;
	}
	
	 private static class BuildToMapper implements RowMapper<Map<String, Object>> {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException {
			    HashMap<String, Object> map = new HashMap<String, Object>();
			    map.put("sku", rs.getString(1));
			    map.put("storeNo", rs.getString(2));
			    return map;

			}
	 }
	 
	 public ResponseEntity<SearchDetails>  saveEligibility(final List<SearchDetails> searchDetails,
			 //@RequestParam final String instantSavingsList,
			 //@RequestParam final String eligStates,
			 //@RequestParam final String ids,
			 @RequestParam final String userId,
			 @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws CommonDataAccessException {
		 
			System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### searchDetails = "+searchDetails);
			System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### concept = "+concept +" conceptShortName = "+conceptShortName);
			//System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### eligStates = "+eligStates +" ids = "+ids);
			System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### userId = "+userId);
			final ResponseEntity<SearchDetails> schedulebResponse = new ResponseEntity<SearchDetails>();	
					
	        StringBuffer skuRet = new StringBuffer("");
	        StringBuffer vendorRet = new StringBuffer("");
	        StringBuffer deptsRet = new StringBuffer("");
	        StringBuffer sdeptsRet = new StringBuffer("");
	        StringBuffer classesRet = new StringBuffer("");
	        StringBuffer eventsRet = new StringBuffer("");
	        StringBuffer merchanalsRet = new StringBuffer("");
	        StringBuffer eligStatesRet = new StringBuffer("");
	        StringBuffer idsRet = new StringBuffer("");	  
	       
	        for (int i = 0; searchDetails != null && i < searchDetails.size(); i++) {
	        	System.out.println("SearchDao saveEligibility Sku = "+searchDetails.get(i).getSku() +" Vendor = "+searchDetails.get(i).getVendorNo() +" MerchGroup = "+searchDetails.get(i).getMerchGroup() +" isid = "+searchDetails.get(i).getIsid()  +" eligStates = "+searchDetails.get(i).getSaveDeleteFlag() +" eventNumber = "+searchDetails.get(i).getEventName()); 
				   
				  /*
				  eligStatesRet.append(searchDetails.get(i).getSaveDeleteFlag());
			      if ( i != eligStatesRet.length()-1){
			    	  eligStatesRet.append(",");
			      }*/
			      
			      eligStatesRet.append(searchDetails.get(i).getSaveDeleteFlag() +",");
			      //if ( i != eligStatesRet.length()-1){
			    	//  eligStatesRet.append(",");
			      //}			      
			      idsRet.append(searchDetails.get(i).getIsid() +",");
			      
				  skuRet.append(searchDetails.get(i).getSku()  +",");
				  
			      //if ( i != skuRet.length()-1){
			    	//  skuRet.append(",");
			      //}
			      
			      vendorRet.append(searchDetails.get(i).getVendorNo()  +",");
			      //if ( i != vendorRet.length()-1){
			    	//  vendorRet.append(",");
			      //}
			      
			      deptsRet.append(searchDetails.get(i).getDept() +","); //if ( i != deptsRet.length()-1){deptsRet.append(",");}
			      
			      sdeptsRet.append(searchDetails.get(i).getSubDept() +","); // if ( i != sdeptsRet.length()-1){sdeptsRet.append(",");}
			      classesRet.append(searchDetails.get(i).getClas() +","); // if ( i != classesRet.length()-1){classesRet.append(",");}	
			      
			      String events = searchDetails.get(i).getEventName();
			      if(events == null){			    	  
			    	  //events = "123456";
			    	  events = "0";
			    	  //events = "1";
		    	  } 
			      
			      eventsRet.append(events +",")  ; 
			      //if ( i != eventsRet.length()-1){
			    	//  eventsRet.append(",");
			      //}
			      
			      String merchGroup = "";
			      if(searchDetails.get(i).getMerchGroup() == null){			    	  
			    	  //merchGroup = "";
			    	  merchGroup = "\"" + merchGroup + "\"";
		    	  } else {
		    		  merchGroup = "\"" + searchDetails.get(i).getMerchGroup() + "\"";
		    	  }
			      
			     // inputParams.put("@venPartNo", "\"" +searchRequest.getVendorPartNo() + "\"");
			      
			      merchanalsRet.append(merchGroup +",");
			      /*if ( i != merchanalsRet.length()-1){
			    	  System.out.println("SearchDao saveEligibility merchanalsRet = "+merchanalsRet);			    	  
			    	  merchanalsRet.append(",");
			      }*/
			      
			      /*
			      String eligStatesTemp = eligStates;
			      System.out.println("SearchDao saveEligibility 0 - 1 eligStatesTemp = "+eligStatesTemp +" eligStates = "+eligStates);
			      eligStatesRet.append(eligStatesTemp);
			      System.out.println("SearchDao saveEligibility 0 - 2 eligStatesRet = "+eligStatesRet +" eligStatesRet.length() = "+eligStatesRet.length());
			      eligStatesRet.append(",");
			      */
			      
			      /*
			      if ( i != eligStatesRet.length()-1){
			    	  System.out.println("SearchDao saveEligibility 0 - 3 eligStatesRet = "+eligStatesRet);
			    	  eligStatesRet.append(",");
			      }*/
			      System.out.println("SearchDao saveEligibility 0 - 4 eligStatesRet = "+eligStatesRet);
			      
			      /*
			      String idsTemp = ids;
			      idsRet.append(idsTemp);
			      idsRet.append(",");
			      //if ( i != idsRet.length()-1){
			      //	  idsRet.append(",");
			      //}*/
			      
			      System.out.println("SearchDao saveEligibility 0 - 4 - 1 idsRet = "+idsRet);
	        }	
	        
	        System.out.println("SearchDao saveEligibility 0 - 4 - 2 eligStatesRet = "+eligStatesRet);
	        System.out.println("SearchDao saveEligibility 0 - 4 - 3 idsRet = "+idsRet);
	        System.out.println("SearchDao saveEligibility 0 - 4 - 4 eventsRet = "+eventsRet);
	        System.out.println("SearchDao saveEligibility 0 - 4 - 5 skuRet = "+skuRet);
	        
	        System.out.println("SearchDao saveEligibility 0 - 4 - 6 deptsRet = "+deptsRet);
	        System.out.println("SearchDao saveEligibility 0 - 4 - 7 sdeptsRet = "+sdeptsRet);
	        System.out.println("SearchDao saveEligibility 0 - 4 - 8 classesRet = "+classesRet);
	        System.out.println("SearchDao saveEligibility 0 - 4 - 9 eventsRet = "+eventsRet);
	        System.out.println("SearchDao saveEligibility 0 - 4 - 10 merchanalsRet = "+merchanalsRet);
	        
	        if(skuRet.length()>0){skuRet.setLength(skuRet.length()-1);}
	        if(vendorRet.length()>0){vendorRet.setLength(vendorRet.length()-1);}
	        
	        if(deptsRet.length()>0){deptsRet.setLength(deptsRet.length()-1);}
	        if(sdeptsRet.length()>0){sdeptsRet.setLength(sdeptsRet.length()-1);}
	        if(classesRet.length()>0){classesRet.setLength(classesRet.length()-1);}
	        if(eventsRet.length()>0){eventsRet.setLength(eventsRet.length()-1);}
	        if(merchanalsRet.length()>0){merchanalsRet.setLength(merchanalsRet.length()-1);}
	        
	        if(eligStatesRet.length()>0){eligStatesRet.setLength(eligStatesRet.length()-1);}
	        if(idsRet.length()>0){idsRet.setLength(idsRet.length()-1);}
	        
	        System.out.println("SearchDao saveEligibility 0 - 5 eligStatesRet = "+eligStatesRet);
	        System.out.println("SearchDao saveEligibility 0 - 5 - 1 idsRet = "+idsRet);
	        System.out.println("SearchDao saveEligibility 0 - 5 - 2 skuRet = "+skuRet);
			
	        /*
	        logger.info("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 1 - 1 ##### skuRet = "+skuRet.toString());
	        logger.info("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 1 - 2 ##### vendorRet = "+vendorRet.toString());	        
	        logger.info("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 1 - 3 ##### skuRet = "+ApplicationUtil.delimit(skuRet.toString(),"'"));
	        logger.info("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 1 - 4 ##### vendorRet = "+ApplicationUtil.delimit(vendorRet.toString(),"'"));
	        */
	        
	        //String skuStr = CommonUtils.delimit(skuRet.toString(),"'");
	        //String schedulebStr = CommonUtils.delimit(schedulebRet.toString(),"'");	        
	        String skuStr = skuRet.toString();
	        String vendorStr = vendorRet.toString();
	        String deptsStr = deptsRet.toString();
	        String sdeptStr = sdeptsRet.toString();
	        String classesStr = classesRet.toString();
	        String eventsStr = eventsRet.toString();
	        String merchanalStr = merchanalsRet.toString();
	        String eligStatesStr = eligStatesRet.toString();
	        String idsStr = idsRet.toString();
	        
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 1 ##### skuRet = "+skuStr);
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 2 ##### eligStatesStr = "+eligStatesStr);
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 3 ##### vendorStr = "+vendorStr);
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 4 ##### deptsStr = "+deptsStr);
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 5 ##### sdeptStr = "+sdeptStr);
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 6 ##### classesStr = "+classesStr);
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 7 ##### eventsStr = "+eventsStr);
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 8 ##### merchanalStr = "+merchanalStr);
	        System.out.println("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 2 - 2 - 9 ##### idsStr = "+idsStr);
	        	        
	        String storeProc="SSEISVELGS"; 
		    
		    //JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceb);
		    /////////JdbcTemplate jdbcTemplate = getJdbcTemplate(getConceptName());	
		    JdbcTemplate jdbcTemplate = getJdbcTemplate();
			
			jdbcTemplate.setResultsMapCaseInsensitive(true);
		    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
		    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
		    Map<String, Object> inputParams = new HashMap<String, Object>();	
		    
		    simpleJdbcCall.declareParameters(	    		
		    		new SqlParameter("@skuString", Types.CHAR),
		    		new SqlParameter("@eligStatesStr", Types.CHAR),		    		
		    		new SqlParameter("@vendorString", Types.CHAR),		    		
		    		new SqlParameter("@deptsStr", Types.CHAR),
		    		new SqlParameter("@sdeptStr", Types.CHAR),
		    		new SqlParameter("@classesStr", Types.CHAR),
		    		new SqlParameter("@eventsStr", Types.CHAR),
		    		new SqlParameter("@merchanalStr", Types.CHAR),
		    		new SqlParameter("@idsStr", Types.CHAR),
		    		new SqlParameter("@userStr", Types.CHAR),
		    		
		    		new SqlOutParameter("@messageCd", Types.DECIMAL),
		    		new SqlOutParameter("@messageType", Types.CHAR)
		    		
		    		//new SqlOutParameter("@errorMessage", Types.DECIMAL)
		    		//new SqlOutParameter("@success", Types.CHAR)
		    		
		    );		  
		    
		    inputParams.put("@skuString",skuStr);
		    inputParams.put("@eligStatesStr", eligStatesStr);
		    
		    inputParams.put("@vendorString", vendorStr);
		    inputParams.put("@deptsStr", deptsStr);
		    inputParams.put("@sdeptStr", sdeptStr);
		    inputParams.put("@classesStr", classesStr);
		    inputParams.put("@eventsStr", eventsStr);
		    inputParams.put("@merchanalStr", merchanalStr);
		    inputParams.put("@idsStr", idsStr);
		    inputParams.put("@userStr", userId);
		  
		    
		    simpleJdbcCall.withProcedureName(storeProc);	    
		    /////simpleJdbcCall.returningResultSet("results",new ScheduleBheaderResultsMapper());	    
			Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams);
			//List<Scheduleb> schedulebList = (List<com.bedbath.scheduleb.domain.Scheduleb>) resultMap.get("results");
			
			System.out.println("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 2 ##### inputParams = "+inputParams);
			System.out.println("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 2 ##### resultMap = "+resultMap);			
			//logger.info("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 4 ##### success = "+resultMap.get("@success"));
			//logger.info("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 4 ##### errorMessage = "+resultMap.get("@errorMessage"));
			System.out.println("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 4 ##### messageCd = "+resultMap.get("@messageCd"));
			System.out.println("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 4 ##### messageType = "+resultMap.get("@messageType"));
			
			//String successFlag = (String) resultMap.get("@success");		
			//String errorMessage = (String) resultMap.get("@errorMessage");			
			//String errorMessage = resultMap.get("@messageType").toString();
			
			/*
			if(ApplicationUtil.isNotBlank(successFlag) && successFlag.equalsIgnoreCase("Y") ){	
				schedulebResponse.setSuccess(true);
			} else {
				schedulebResponse.setSuccess(false);
			}
			schedulebResponse.setReason(errorMessage);
			*/	
			
			if(resultMap.get("@messageCd") == null ){	
				schedulebResponse.setSuccess(true);
			} else {
				schedulebResponse.setSuccess(false);
			}			
			return schedulebResponse;
			
			//logger.info("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 3 ##### schedulebList.size() = "+schedulebList.size());
		    //inputParams.put("@skuString","'10116104,10116112'");
		    //inputParams.put("@schedulebString", "'1111112222,2222223333'");
		    //inputParams.put("@submitFlag", "N"); 
		    
		 
	 }
	 
	 public ResponseEntity<EligibilityDetails>  getEligibilityBySkus(
			 SearchRequest searchRequest)
				//final List<SearchDetails> searchDetails,
				 //@RequestParam final String instantSavingsList,
				 //@RequestParam final String skus,
				 //@RequestParam final String ids,
				 //@RequestParam final String userId,
				 //@RequestParam final String lang,  @RequestParam final String country,
				 //@RequestParam final String concept,  @RequestParam final String conceptShortName)
						 throws CommonDataAccessException {
		 
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 1 searchRequest = "+searchRequest);
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 2  skus = "+searchRequest.getSkus());
		    
		    //List<SearchDetails> detailsList,
		    List<Long> skus = searchRequest.getSkus();
			//List<Long> stores, List<Long> vendors)
		    
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 3  sks = "+ApplicationUtil.longListToString(skus));
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 4  Vendors = "+ApplicationUtil.longListToString(searchRequest.getVendorNos()));
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 5  Depts = "+ApplicationUtil.longListToString(searchRequest.getDepts()));
		
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 5 - 1  sks = "+ApplicationUtil.longListToStringWithQuotes(skus));
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 5 - 2  sks = "+ApplicationUtil.longListToStringWithSingleQuotes(skus));
		    
		    String skuSting_1 = ApplicationUtil.longListToStringWithSingleQuotes(skus);
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 5 - 3  skuSting = "+skuSting_1);
		    
		    String skuSting_2 = ApplicationUtil.longListToStringWithQuotes(skus);
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 5 - 4  skuSting_2 = "+skuSting_2);
		    
		    String skuSting = ApplicationUtil.longListToString(skus);
		    System.out.println("SchedulebDaoImpl getEligibilityBySkus() !!!!!!! 8 - 5 - 3  skuSting = "+skuSting);
		    
		    /*System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### concept = "+concept +" conceptShortName = "+conceptShortName);
			System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### skus = "+skus);
			System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### userId = "+userId);
			*/
			final ResponseEntity<EligibilityDetails> eligibilityDetailsResponse = new ResponseEntity<EligibilityDetails>();				
	        StringBuffer skuRet = new StringBuffer("");
	       	        	        
	        String storeProc="SSEISGTELS"; 
	        
		    /////////JdbcTemplate jdbcTemplate = getJdbcTemplate(getConceptName());	
		    JdbcTemplate jdbcTemplate = getJdbcTemplate();
			
			jdbcTemplate.setResultsMapCaseInsensitive(true);
		    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
		    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
		    Map<String, Object> inputParams = new HashMap<String, Object>();	
		   		    
		    simpleJdbcCall.declareParameters(	    		
		    		new SqlParameter("@skus", Types.CHAR)
		    );	
		    
		    inputParams.put("@skus", skuSting);	
		    
		    simpleJdbcCall.withProcedureName(storeProc);	    
		    simpleJdbcCall.returningResultSet("results",new EligibilityBySkuDetailsResultsMapper());	    
			Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams);
			
			System.out.println("SchedulebDaoImpl getEligibilityBySkus() 8 - 6 inputParams = "+inputParams);
			System.out.println("SchedulebDaoImpl getEligibilityBySkus() 8 - 7 resultMap = "+resultMap);
			System.out.println("SchedulebDaoImpl getEligibilityBySkus() 8 - 7 - 1 resultMap = "+resultMap.get("results"));
			
			List<EligibilityDetails> eligibilityDetailsList = (List<com.bedbath.ssm.model.EligibilityDetails>) resultMap.get("results");		
			
			System.out.println("SchedulebDaoImpl getEligibilityBySkus() 8 - 7 - 2 eligibilityDetailsList = "+eligibilityDetailsList);
			System.out.println("SchedulebDaoImpl getEligibilityBySkus() 8 - 7 - 3 eligibilityDetailsList size  = "+eligibilityDetailsList.size());
	
			/*
			if(ApplicationUtil.isNotBlank(successFlag) && successFlag.equalsIgnoreCase("Y") ){	
				eligibilityDetailsResponse.setSuccess(true);
			} else {
				eligibilityDetailsResponse.setSuccess(false);
			}			
			//schedulebResponse.setReason(errorMessage);
			*/
			
			System.out.println("SchedulebDaoImpl getEligibilityBySkus() 8 - 7 - 4 eligibilityDetailsResponse = "+eligibilityDetailsResponse);
			eligibilityDetailsResponse.setRows(eligibilityDetailsList);
			eligibilityDetailsResponse.setSuccess(true);
			
			return eligibilityDetailsResponse;		
	 }
	 
	 
	 
	 public ResponseEntity<EligibilityDetails>  getEligibilityByGroup()
						 throws CommonDataAccessException {
		 
		    System.out.println("SchedulebDaoImpl getEligibilityByGroup() 9 - 1");
			final ResponseEntity<EligibilityDetails> eligibilityDetailsResponse = new ResponseEntity<EligibilityDetails>();				
	        StringBuffer skuRet = new StringBuffer("");
	      
	        String storeProc="SSEISGTELG"; 		    
		        
		    //JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceb);
		    /////////JdbcTemplate jdbcTemplate = getJdbcTemplate(getConceptName());	
		    JdbcTemplate jdbcTemplate = getJdbcTemplate();
			
			jdbcTemplate.setResultsMapCaseInsensitive(true);
		    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
		    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
		    //Map<String, Object> inputParams = new HashMap<String, Object>();
		   		    
		    simpleJdbcCall.withProcedureName(storeProc);	    
		    simpleJdbcCall.returningResultSet("results",new EligibilityByGroupDetailsResultsMapper());	    
			//Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams);
			Map<String,Object> resultMap = simpleJdbcCall.execute();
			
			//System.out.println("SchedulebDaoImpl getEligibilityByGroup() 9 - 6 inputParams = "+inputParams);
			System.out.println("SchedulebDaoImpl getEligibilityByGroup() 9 - 7 resultMap = "+resultMap);
			System.out.println("SchedulebDaoImpl getEligibilityByGroup() 9 - 7 - 1 resultMap = "+resultMap.get("results"));
			
			List<EligibilityDetails> eligibilityGroupDetailsList = (List<com.bedbath.ssm.model.EligibilityDetails>) resultMap.get("results");		
			
			System.out.println("SchedulebDaoImpl getEligibilityByGroup() 9 - 7 - 2 eligibilityGroupDetailsList = "+eligibilityGroupDetailsList);
			System.out.println("SchedulebDaoImpl getEligibilityByGroup() 9 - 7 - 3 eligibilityGroupDetailsList size  = "+eligibilityGroupDetailsList.size());
			
			//System.out.println("SchedulebDaoImpl getEligibilityBySkus() ###@@##### 1 - 2 ##### inputParams = "+inputParams);
			//System.out.println("SchedulebDaoImpl getEligibilityBySkus() ###@@##### 1 - 2 ##### resultMap = "+resultMap);			
			
			
			//String successFlag = (String) resultMap.get("@success");		
			//String errorMessage = (String) resultMap.get("@errorMessage");			
			//String errorMessage = resultMap.get("@messageType").toString();
			
			/*
			if(ApplicationUtil.isNotBlank(successFlag) && successFlag.equalsIgnoreCase("Y") ){	
				eligibilityDetailsResponse.setSuccess(true);
			} else {
				eligibilityDetailsResponse.setSuccess(false);
			}			
			//schedulebResponse.setReason(errorMessage);
			*/
			
			System.out.println("SchedulebDaoImpl getEligibilityByGroup() 9 - 7 - 4 eligibilityDetailsResponse = "+eligibilityDetailsResponse);
			eligibilityDetailsResponse.setRows(eligibilityGroupDetailsList);
			eligibilityDetailsResponse.setSuccess(true);
			
			return eligibilityDetailsResponse;		
	 }
	 
	 private static class EligibilityBySkuDetailsResultsMapper implements RowMapper<EligibilityDetails> {
			public EligibilityDetails mapRow(ResultSet rs, int rowNum) throws SQLException {				
				EligibilityDetails obj = new EligibilityDetails();
				
				//System.out.println("EligibilityBySkuDetailsResultsMapper ################# ISINUMBR = "+rs.getInt("ISINUMBR"));
				obj.setIsinumbr(rs.getInt("ISINUMBR"));  // sku
				obj.setInstsavElig(rs.getInt("INSTSAVELIG"));
				obj.setIsAsnum(rs.getInt("ISASNUM"));   // vendor
				obj.setIsDept(rs.getInt("ISDEPT"));
				obj.setIsSdept(rs.getInt("ISSDEPT"));
				obj.setIsClas(rs.getInt("ISCLAS"));
				obj.setIsId(rs.getInt("ISID"));
				obj.setIsevt(rs.getString("ISEVT"));
				obj.setIsma(rs.getString("ISMA"));
				
				obj.setCreateUser(rs.getString("CREATEUSER"));
				obj.setCreatePgm(rs.getString("CREATEPGM"));				
				obj.setCreatetime(rs.getTimestamp("CREATETIME"));
				obj.setChangeUser(rs.getString("CHANGEUSER"));
				obj.setChangepgm(rs.getString("CHANGEPGM"));
				obj.setChangetime(rs.getTimestamp("CHANGETIME"));
			
				return obj;
		    }
	}
	 
	private static class EligibilityByGroupDetailsResultsMapper implements RowMapper<EligibilityDetails> {
			public EligibilityDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				EligibilityDetails obj = new EligibilityDetails();	
				//System.out.println("EligibilityByGroupDetailsResultsMapper ################");
				//System.out.println("EligibilityByGroupDetailsResultsMapper ################# SKU = "+rs.getInt("ISINUMBR"));				
				obj.setIsId(rs.getInt("ISID"));
				obj.setIsAsnum(rs.getInt("ISASNUM"));	   // vendor	
				obj.setIsDept(rs.getInt("ISDEPT"));
				obj.setIsSdept(rs.getInt("ISSDEPT"));
				obj.setIsClas(rs.getInt("ISCLAS"));
				obj.setIsinumbr(rs.getInt("ISINUMBR"));   // sku
				obj.setIsevt(rs.getString("ISEVT"));
				obj.setIsma(rs.getString("ISMA"));
				
				obj.setCreateUser(rs.getString("CREATEUSER"));
				obj.setCreatePgm(rs.getString("CREATEPGM"));				
				obj.setCreatetime(rs.getTimestamp("CREATETIME"));
				obj.setChangeUser(rs.getString("CHANGEUSER"));
				obj.setChangepgm(rs.getString("CHANGEPGM"));
				obj.setChangetime(rs.getTimestamp("CHANGETIME"));
				return obj;
		    }
	}
	 
	// This is for both Save and Delete 
	public @ResponseBody ResponseEntity<EligibilityDetails> saveEligibilityByGroup(
			 //final HttpServletRequest request, final HttpServletResponse response,
		     @RequestParam final String instSavingsType, String eligState,
		     @RequestParam final String vendorNos, @RequestParam final String depts, @RequestParam final String subdepts, @RequestParam final String clas,		     		     
			 @RequestParam final String userId, @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws CommonDataAccessException {	
		 
			System.out.println("SchedulebDaoImpl saveEligibilityByGroup() !!!!!!!###@@##### 1 ##### searchDetails = "+searchDetails);
			System.out.println("SchedulebDaoImpl saveEligibilityByGroup() !!!!!!!###@@##### 1 ##### concept = "+concept +" conceptShortName = "+conceptShortName);
			//System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### eligStates = "+eligStates +" ids = "+ids);
			System.out.println("SchedulebDaoImpl saveEligibilityByGroup() !!!!!!!###@@##### 1 ##### userId = "+userId);
			
			long vendorNo =0; long dept = 0; long subdept =0; long classs = 0;			
			if(vendorNos!=null && vendorNos.length()>0){
				vendorNo = Long.parseLong(vendorNos);
			}
			
			if(depts!=null && depts.length()>0){
				dept = Long.parseLong(depts);
			}
			
			if(subdepts!=null && subdepts.length()>0){
				subdept = Long.parseLong(subdepts);
			}
			
			if(clas!=null && clas.length()>0){
				classs = Long.parseLong(clas);
			}			
			System.out.println("saveEligibilityByGroup 7 - 5 ############### vendorNo = "+vendorNo +" dept = "+dept +" subdept = "+subdept +" classs = "+classs);
			
			
			String eligStateStr = ApplicationUtil.delimit(eligState.toString(),"'");
			System.out.println("saveEligibilityByGroup 7 - 5 ############### eligStateStr = "+eligStateStr);
			
			String userIdStr = ApplicationUtil.delimit(userId.toString(),"'");
			System.out.println("saveEligibilityByGroup 7 - 5 ############### userIdStr = "+userIdStr);
			
			final ResponseEntity<EligibilityDetails> searchResponse = new ResponseEntity<EligibilityDetails>();	
	      
	        String storeProc="SSEISVELGS"; 
	   
		    //JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceb);
		    /////////JdbcTemplate jdbcTemplate = getJdbcTemplate(getConceptName());	
		    JdbcTemplate jdbcTemplate = getJdbcTemplate();
			
			jdbcTemplate.setResultsMapCaseInsensitive(true);
		    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
		    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
		    Map<String, Object> inputParams = new HashMap<String, Object>();
		    
		    simpleJdbcCall.declareParameters(	    		
		    		new SqlParameter("@vendor", Types.DECIMAL),	    		
		    		new SqlParameter("@dept", Types.DECIMAL),		    		
		    		new SqlParameter("@sdept", Types.DECIMAL),
		    		new SqlParameter("@clas", Types.DECIMAL),
		    		new SqlParameter("@eligState", Types.CHAR),
		    		new SqlParameter("@userStr", Types.VARCHAR),
		    		
		    		new SqlOutParameter("@messageCd", Types.DECIMAL),
		    		new SqlOutParameter("@messageType", Types.CHAR)
		    );
		    
		    inputParams.put("@vendor",vendorNo);
		    inputParams.put("@dept", dept);		    
		    inputParams.put("@sdept", subdept);
		    inputParams.put("@clas", classs);
		    inputParams.put("@eligState", eligState);
		    inputParams.put("@userStr", userIdStr);		
		    
		    simpleJdbcCall.withProcedureName(storeProc);	    
		    /////simpleJdbcCall.returningResultSet("results",new ScheduleBheaderResultsMapper());	    
			Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams);
			//List<Scheduleb> schedulebList = (List<com.bedbath.scheduleb.domain.Scheduleb>) resultMap.get("results");
			
			System.out.println("saveEligibilityByGroup ###@@##### 1 - 2 ##### inputParams = "+inputParams);
			System.out.println("saveEligibilityByGroup ###@@##### 1 - 2 ##### resultMap = "+resultMap);	
			System.out.println("saveEligibilityByGroup ###@@##### 1 - 4 ##### messageCd = "+resultMap.get("@messageCd"));
			System.out.println("saveEligibilityByGroup ###@@##### 1 - 4 ##### messageType = "+resultMap.get("@messageType"));
			
			/*
			if(ApplicationUtil.isNotBlank(successFlag) && successFlag.equalsIgnoreCase("Y") ){	
				schedulebResponse.setSuccess(true);
			} else {
				schedulebResponse.setSuccess(false);
			}
			schedulebResponse.setReason(errorMessage);
			*/	
			
			if(resultMap.get("@messageCd") == null ){	
				searchResponse.setSuccess(true);
			} else {
				searchResponse.setSuccess(false);
			}			
			return searchResponse;
	 }
	
	 public ResponseEntity<EligibilityDetails>  saveInstantElgiByGroup(final List<EligibilityDetails> eligibilityDetails,
			 @RequestParam final String userId,
			 @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws CommonDataAccessException {
		 
		    System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() !!!!!!!###@@##### 1 ##### eligibilityDetails = "+eligibilityDetails);
			System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() !!!!!!!###@@##### 1 ##### concept = "+concept +" conceptShortName = "+conceptShortName);
			//System.out.println("SchedulebDaoImpl saveSchedulebChanges() !!!!!!!###@@##### 1 ##### eligStates = "+eligStates +" ids = "+ids);
			System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() !!!!!!!###@@##### 1 ##### userId = "+userId);
			final ResponseEntity<EligibilityDetails> response = new ResponseEntity<EligibilityDetails>();	
					
	        StringBuffer skuRet = new StringBuffer("");
	        StringBuffer vendorRet = new StringBuffer("");
	        StringBuffer deptsRet = new StringBuffer("");
	        StringBuffer sdeptsRet = new StringBuffer("");
	        StringBuffer classesRet = new StringBuffer("");
	        StringBuffer eventsRet = new StringBuffer("");
	        StringBuffer merchanalsRet = new StringBuffer("");
	        
	        StringBuffer eligStatesRet = new StringBuffer("");
	        //StringBuffer idsRet = new StringBuffer("");	
	        //StringBuffer ismaRet = new StringBuffer("");	
	        StringBuffer groupeligflRet = new StringBuffer("");	
	        StringBuffer isidRet = new StringBuffer("");
	        
	        for (int i = 0; eligibilityDetails != null && i < eligibilityDetails.size(); i++) {
	        	System.out.println("SearchDao saveEligibility Sku = "+eligibilityDetails.get(i).getIsinumbr() +" Vendor = "+eligibilityDetails.get(i).getIsAsnum() +" MerchGroup = "+eligibilityDetails.get(i).getIsma() +" isid = "+eligibilityDetails.get(i).getIsId()  +" GroupEligFl = "+eligibilityDetails.get(i).getGroupEligFl()); 
				   
	        	System.out.println("SearchDao saveEligibility Dept = "+eligibilityDetails.get(i).getIsDept() +" SDept = "+eligibilityDetails.get(i).getIsSdept() +" instsavElig = "+eligibilityDetails.get(i).getInstsavElig());
	        	//getInstsavElig
	        	
	        	////Integer i = null;
	        	///System.out.println(i == null ?"":i)	        	
	        	//preparedStatement.setInt(1, pimDataVo.getItemFlashMessageId() == 0? null : pimDataVo.getItemFlashMessageId());	        	
	        	//preparedStatement.setInt(1, pimDataVo.getItemFlashMessageId() == 0? null : pimDataVo.getItemFlashMessageId());
	        	Integer skuValue = 0;
	        	if(eligibilityDetails.get(i).getIsinumbr() == null){
	        		skuValue = 0;
	        	}
	        	//skuRet.append(eligibilityDetails.get(i).getIsinumbr() == null? 0 : eligibilityDetails.get(i).getIsinumbr() +",");
	        	skuRet.append(skuValue +",");
	        	
	        	eligStatesRet.append(eligibilityDetails.get(i).getInstsavElig() +",");    
	        	//skuRet.append(eligibilityDetails.get(i).getIsinumbr() +","); // sku
	        	vendorRet.append(eligibilityDetails.get(i).getIsAsnum() +",");  // vendor
	        	deptsRet.append(eligibilityDetails.get(i).getIsDept() +",");
	        	sdeptsRet.append(eligibilityDetails.get(i).getIsSdept() +",");
	        	classesRet.append(eligibilityDetails.get(i).getIsClas() +",");	  	        	
	        	
	        	String eventNumberValue = "";
	        	if(eligibilityDetails.get(i).getIsevt() == null){
	        		eventNumberValue = "";
	        	} else {
	        		eventNumberValue = eligibilityDetails.get(i).getIsevt();
	        	}
	        	//skuRet.append(eligibilityDetails.get(i).getIsinumbr() == null? 0 : eligibilityDetails.get(i).getIsinumbr() +",");
	        	eventsRet.append(eventNumberValue +",");
	        	
	        	//eventsRet.append(eligibilityDetails.get(i).getIsevt() +",");	        	
	        	//eventsRet.append(eligibilityDetails.get(i).getIsevt() == null? 0 : eligibilityDetails.get(i).getIsevt() +",");
	        	
	        	//merchanalsRet.append(eligibilityDetails.get(i).getIsma() +",");   
	        	//String merchGroup = "";	        	
	        	
	        	
	        	String merchGroup = "";
		        /*if(eligibilityDetails.get(i).getIsma() == null){		
		    	  merchGroup = "\"\"";
	    	    } else {
	    		  merchGroup = "\"" + eligibilityDetails.get(i).getIsma() + "\"";
	    	    }*/	
		        
	        	if(eligibilityDetails.get(i).getIsma() != null){
		        	merchGroup = eligibilityDetails.get(i).getIsma();
		        }

		        merchanalsRet.append(merchGroup);
		        System.out.println("SearchDao saveInstantElgiByGroup merchanalsRet = "+merchanalsRet +" length = "+merchGroup.length() );			    	  
		    	merchanalsRet.append(",");
	        	
	        	/*
	        	String merchGroupValue = "";
		        if(eligibilityDetails.get(i).getIsma() == null){		
		        	merchGroupValue = "";
	    	    } else {
	    	    	merchGroupValue =	eligibilityDetails.get(i).getIsma();
	    	    }
	        	merchanalsRet.append(eligibilityDetails.get(i).getIsma() +",");
	        	*/
		      
		        //if ( i != merchanalsRet.length()-1){
		    	//  System.out.println("SearchDao saveInstantElgiByGroup merchanalsRet = "+merchanalsRet);			    	  
		    	//  merchanalsRet.append(",");
                //}	      
	        	
	        	isidRet.append(eligibilityDetails.get(i).getIsId() +",");       // PK	        	
	        	//merchanalsRet.append(eligibilityDetails.get(i).getIsevt() +",");	        	
	        	//ismaRet.append(eligibilityDetails.get(i).getIsma() +",");	        	
	        	groupeligflRet.append(eligibilityDetails.get(i).getGroupEligFl() +",");	        	
	        	/*
	        	 int events = eligibilityDetails.get(i).getIsevt();
			      if(events == null){			    	  
			    	  events = "123456";
			    	  //events = "1";
		    	  } 
			      eventsRet.append(events); 
			      if ( i != eventsRet.length()-1){
			    	  eventsRet.append(",");
			      }*/
	       }	
	        
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 2 eligStatesRet = "+eligStatesRet);
	        //System.out.println("SearchDao saveEligibility 0 - 4 - 3 idsRet = "+idsRet);
	        //System.out.println("SearchDao saveEligibility 0 - 4 - 4 eventsRet = "+eventsRet);
	        
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 5 skuRet = "+skuRet);
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 5 vendorRet = "+vendorRet);
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 6 deptsRet = "+deptsRet);
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 7 sdeptsRet = "+sdeptsRet);
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 8 classesRet = "+classesRet);
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 9 eventsRet = "+eventsRet);
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 10 merchanalsRet = "+merchanalsRet);
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 11 isidRet = "+isidRet);
	        System.out.println("SearchDao saveInstantElgiByGroup 0 - 4 - 12 eventsRet = "+groupeligflRet);	        
	        
	        if(skuRet.length()>0){skuRet.setLength(skuRet.length()-1);}
	        if(vendorRet.length()>0){vendorRet.setLength(vendorRet.length()-1);}
	        
	        if(deptsRet.length()>0){deptsRet.setLength(deptsRet.length()-1);}
	        if(sdeptsRet.length()>0){sdeptsRet.setLength(sdeptsRet.length()-1);}
	        if(classesRet.length()>0){classesRet.setLength(classesRet.length()-1);}
	        
	        if(eventsRet.length()>0){eventsRet.setLength(eventsRet.length()-1);}
	        if(merchanalsRet.length()>0){merchanalsRet.setLength(merchanalsRet.length()-1);}
	        
	        if(eligStatesRet.length()>0){eligStatesRet.setLength(eligStatesRet.length()-1);}
	        
	        //if(idsRet.length()>0){idsRet.setLength(idsRet.length()-1);}
	        if(isidRet.length()>0){isidRet.setLength(isidRet.length()-1);}
	        if(groupeligflRet.length()>0){groupeligflRet.setLength(groupeligflRet.length()-1);}
	        
	      
	        /*
	        logger.info("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 1 - 1 ##### skuRet = "+skuRet.toString());
	        logger.info("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 1 - 2 ##### vendorRet = "+vendorRet.toString());	        
	        logger.info("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 1 - 3 ##### skuRet = "+ApplicationUtil.delimit(skuRet.toString(),"'"));
	        logger.info("SchedulebDaoImpl saveSchedulebChanges() ###@@##### 1 - 4 ##### vendorRet = "+ApplicationUtil.delimit(vendorRet.toString(),"'"));
	        */
	        
	        //String skuStr = CommonUtils.delimit(skuRet.toString(),"'");
	        //String schedulebStr = CommonUtils.delimit(schedulebRet.toString(),"'");	        
	        String skuStr = skuRet.toString();
	        String vendorStr = vendorRet.toString();
	        String deptsStr = deptsRet.toString();
	        String sdeptStr = sdeptsRet.toString();
	        String classesStr = classesRet.toString();
	        String eventsStr = eventsRet.toString();
	        String merchanalStr = merchanalsRet.toString();
	        String eligStatesStr = eligStatesRet.toString();
	        //String idsStr = idsRet.toString();
	        String isidStr = isidRet.toString();
	        String groupeligflStr = groupeligflRet.toString();
	        
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 1 ##### skuRet = "+skuStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 2 ##### eligStatesStr = "+eligStatesStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 3 ##### vendorStr = "+vendorStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 4 ##### deptsStr = "+deptsStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 5 ##### sdeptStr = "+sdeptStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 6 ##### classesStr = "+classesStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 7 ##### eventsStr = "+eventsStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 8 ##### merchanalStr = "+merchanalStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 9 ##### isidStr = "+isidStr);
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 10 ##### groupeligflStr = "+groupeligflStr);
	        
	        String merchGroupQuotes = "";	        
	        //merchGroupQuotes = "\"" + merchanalStr + "\"";		        
	        merchGroupQuotes = "'" + merchanalStr + "'";
	        System.out.println("SchedulebDaoImpl saveInstantElgiByGroup() ###@@##### 2 - 2 - 11 ##### merchGroupQuotes = "+merchGroupQuotes);	
	        
	        String storeProc="SSEISVELGS"; 
		    
		    //JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceb);
		    /////////JdbcTemplate jdbcTemplate = getJdbcTemplate(getConceptName());	
		    JdbcTemplate jdbcTemplate = getJdbcTemplate();
			
			jdbcTemplate.setResultsMapCaseInsensitive(true);
		    SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
		    simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
		    Map<String, Object> inputParams = new HashMap<String, Object>();	
		    
		    simpleJdbcCall.declareParameters(	    		
		    		new SqlParameter("@skuString", Types.CHAR),
		    		new SqlParameter("@eligStatesStr", Types.CHAR),		    		
		    		new SqlParameter("@vendorString", Types.CHAR),		    		
		    		new SqlParameter("@deptsStr", Types.CHAR),
		    		new SqlParameter("@sdeptStr", Types.CHAR),
		    		new SqlParameter("@classesStr", Types.CHAR),
		    		new SqlParameter("@eventsStr", Types.CHAR),
		    		new SqlParameter("@merchanalStr", Types.CHAR),
		    		new SqlParameter("@idsStr", Types.CHAR),
		    		new SqlParameter("@userStr", Types.CHAR),
		    		
		    		new SqlOutParameter("@messageCd", Types.DECIMAL),
		    		new SqlOutParameter("@messageType", Types.CHAR)
		    );		  
		    
		    inputParams.put("@skuString",skuStr);
		    inputParams.put("@eligStatesStr", eligStatesStr);		    
		    inputParams.put("@vendorString", vendorStr);
		    inputParams.put("@deptsStr", deptsStr);
		    inputParams.put("@sdeptStr", sdeptStr);
		    inputParams.put("@classesStr", classesStr);
		    inputParams.put("@eventsStr", eventsStr);
		    inputParams.put("@merchanalStr", merchanalStr);
		    //inputParams.put("@merchanalStr", merchGroupQuotes);
		    inputParams.put("@idsStr", isidStr);
		    inputParams.put("@userStr", userId);
		    
		    simpleJdbcCall.withProcedureName(storeProc);	    
		    /////simpleJdbcCall.returningResultSet("results",new ScheduleBheaderResultsMapper());	    
			Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams);
			//List<Scheduleb> schedulebList = (List<com.bedbath.scheduleb.domain.Scheduleb>) resultMap.get("results");
			
			System.out.println("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 2 ##### inputParams = "+inputParams);
			System.out.println("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 2 ##### resultMap = "+resultMap);			
			//logger.info("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 4 ##### success = "+resultMap.get("@success"));
			//logger.info("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 4 ##### errorMessage = "+resultMap.get("@errorMessage"));
			System.out.println("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 4 ##### messageCd = "+resultMap.get("@messageCd"));
			System.out.println("SchedulebDaoImpl headerGridResult() ###@@##### 1 - 4 ##### messageType = "+resultMap.get("@messageType"));
		
			
			if(resultMap.get("@messageCd") == null ){	
				response.setSuccess(true);
			} else {
				response.setSuccess(false);
			}
			
			response.setSuccess(true);
			
			return response;
			
	 }
	 
	 public ResponseEntity<EligibilityDetails>  getSkusByEventNumber(String eventNumber)
			 throws CommonDataAccessException {
			System.out.println("SchedulebDaoImpl getSKusByEventNumber() 9 - 1 eventNumber = "+eventNumber);
			final ResponseEntity<EligibilityDetails> eligibilityDetailsResponse = new ResponseEntity<EligibilityDetails>();				
						
			String storeProc="SSEISSRCH"; 
			//JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSourceb);			
			JdbcTemplate jdbcTemplate = getJdbcTemplate();
						
			jdbcTemplate.setResultsMapCaseInsensitive(true);
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate);
			simpleJdbcCall.withoutProcedureColumnMetaDataAccess();
			Map<String, Object> inputParams = new HashMap<String, Object>();
			
			simpleJdbcCall.declareParameters(	    		
		    		new SqlParameter("@eventnumber", Types.VARCHAR)
		    );		    
		    inputParams.put("@eventnumber",eventNumber);
					    
			simpleJdbcCall.withProcedureName(storeProc);	    
			simpleJdbcCall.returningResultSet("results",new SkusByEventNumberResultsMapper());	    
			Map<String,Object> resultMap = simpleJdbcCall.execute(inputParams);
			
			System.out.println("SchedulebDaoImpl getSKusByEventNumber() 9 - 6 inputParams = "+inputParams);
			System.out.println("SchedulebDaoImpl getSKusByEventNumber() 9 - 7 resultMap = "+resultMap);
			System.out.println("SchedulebDaoImpl getSKusByEventNumber() 9 - 7 - 1 resultMap = "+resultMap.get("results"));
			
			List<EligibilityDetails> eligibilityGroupDetailsList = (List<com.bedbath.ssm.model.EligibilityDetails>) resultMap.get("results");	
			System.out.println("SchedulebDaoImpl getSKusByEventNumber() 9 - 7 - 3 eligibilityGroupDetailsList size  = "+eligibilityGroupDetailsList.size());
			
			/*
			if(ApplicationUtil.isNotBlank(successFlag) && successFlag.equalsIgnoreCase("Y") ){	
				eligibilityDetailsResponse.setSuccess(true);
			} else {
				eligibilityDetailsResponse.setSuccess(false);
			}			
			//schedulebResponse.setReason(errorMessage);
			*/			
			eligibilityDetailsResponse.setRows(eligibilityGroupDetailsList);
			eligibilityDetailsResponse.setSuccess(true);			
			return eligibilityDetailsResponse;		
	 }
	 
	 private static class SkusByEventNumberResultsMapper implements RowMapper<EligibilityDetails> {
			public EligibilityDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
				EligibilityDetails obj = new EligibilityDetails();
				obj.setIsinumbr(rs.getInt("INUMBR"));   // sku
				
				return obj;
		    }
	}
   
}
