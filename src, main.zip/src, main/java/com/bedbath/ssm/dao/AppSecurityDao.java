package com.bedbath.ssm.dao;

import java.util.Map;
import com.bedbath.ssm.exception.SSMException;

public interface AppSecurityDao {

	public Map<String, Object> getUserPrivileges(String appCode, String country, String concept, String userId) throws SSMException;
	
}
