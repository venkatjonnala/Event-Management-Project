package com.bedbath.ssm.model;

import org.json.simple.JSONObject;

public interface JSONCapable {
	JSONObject toJSON();
	
}
