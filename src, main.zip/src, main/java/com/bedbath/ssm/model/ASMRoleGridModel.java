package com.bedbath.ssm.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;


public class ASMRoleGridModel implements JSONCapable {
	// APPID
	// ROLEID
	// ROLE_NAME
	// ROLE_DESCRIPTION 
	// CREATE_TIMESTAMP
	// UPDATE_TIMESTAMP
	// CRUPUSERID
	// AUDIT
	private long appId;
	private long roleId;
	private String roleName;
	private String roleDescription;
	private String createTS;
	private String updateTS;
	private String updateUser;
	private String auditFlag;

	public ASMRoleGridModel() {
		this.appId = 0;
		this.roleId = 0;
		this.roleName = "";
		this.roleDescription = "";
		this.createTS = "";
		this.updateTS = "";
		this.updateUser = "";
		this.auditFlag = "";
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("appId", this.appId);
		json.put("roleId", this.roleId);
		json.put("roleName", this.roleName);
		json.put("roleDescription", roleDescription);
		json.put("createTS", this.createTS);
		json.put("updateTS", this.updateTS);
		json.put("updateUser", this.updateUser);
		json.put("auditFlag", this.auditFlag);	
		return json;
	}
	
	public long getAppId() {
		return appId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getCreateTS() {
		return createTS;
	}

	public void setCreateTS(String createTS) {
		this.createTS = createTS;
	}

	public String getUpdateTS() {
		return updateTS;
	}

	public void setUpdateTS(String updateTS) {
		this.updateTS = updateTS;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getAuditFlag() {
		return auditFlag;
	}

	public void setAuditFlag(String auditFlag) {
		this.auditFlag = auditFlag;
	}




}
