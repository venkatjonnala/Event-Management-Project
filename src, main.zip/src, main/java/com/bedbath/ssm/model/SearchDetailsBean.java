package com.bedbath.ssm.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

//@JsonIgnoreProperties({"multiUPC","winDomain","crtUser","updUser","updtm","reportList"})
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchDetailsBean implements Serializable {
	
	private Long sku;
	private Long storeNo;
	private Long upc;
	private String multiUPC;
	private String skuDescription;
	private Long vendorNo;
	private String vendorName;
	private Integer dept;
	private Integer subDept;
	public Long getSku() {
		return sku;
	}
	public void setSku(Long sku) {
		this.sku = sku;
	}
	public Long getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(Long storeNo) {
		this.storeNo = storeNo;
	}
	public Long getUpc() {
		return upc;
	}
	public void setUpc(Long upc) {
		this.upc = upc;
	}
	public String getMultiUPC() {
		return multiUPC;
	}
	public void setMultiUPC(String multiUPC) {
		this.multiUPC = multiUPC;
	}
	public String getSkuDescription() {
		return skuDescription;
	}
	public void setSkuDescription(String skuDescription) {
		this.skuDescription = skuDescription;
	}
	public Long getVendorNo() {
		return vendorNo;
	}
	public void setVendorNo(Long vendorNo) {
		this.vendorNo = vendorNo;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public Integer getDept() {
		return dept;
	}
	public void setDept(Integer dept) {
		this.dept = dept;
	}
	public Integer getSubDept() {
		return subDept;
	}
	public void setSubDept(Integer subDept) {
		this.subDept = subDept;
	}
	
	
	
    
}    