package com.bedbath.ssm.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;


public class UserPrivilegeModel implements JSONCapable {
//	APPID NUMERIC(10),           
//	PRIVID NUMERIC(10),          
//	PRIVNAME VARCHAR(50),        
//	PRIVDESC VARCHAR(255),       
//	CRTDTTIME TIMESTAMP,         
//	UPDTTIME TIMESTAMP,          
//	CRUPUSERID VARCHAR(10),      
//	AUDIT  Char(1),              
	private long appId;
	private long privId;
	private String privName;
	private String privDescription;
	private String createTS;
	private String updateTS;
	private String updateUser;
	private String auditFlag;


	public UserPrivilegeModel() {
		this.appId = 0;
		this.privId = 0;
		this.privName = "";
		this.privDescription = "";
		this.createTS = "";
		this.updateTS = "";
		this.updateUser = "";
		this.auditFlag = "";
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("appId", this.appId);
		json.put("privId", this.privId);
		json.put("privName", this.privName);
		json.put("privDescription", privDescription);
		json.put("createTS", this.createTS);
		json.put("updateTS", this.updateTS);
		json.put("updateUser", this.updateUser);
		json.put("auditFlag", this.auditFlag);
		return json;
	}

	public long getAppId() {
		return appId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public long getPrivId() {
		return privId;
	}

	public void setPrivId(long privId) {
		this.privId = privId;
	}

	public String getPrivName() {
		return privName;
	}

	public void setPrivName(String privName) {
		this.privName = privName;
	}

	public String getPrivDescription() {
		return privDescription;
	}

	public void setPrivDescription(String privDescription) {
		this.privDescription = privDescription;
	}

	public String getCreateTS() {
		return createTS;
	}

	public void setCreateTS(String createTS) {
		this.createTS = createTS;
	}

	public String getUpdateTS() {
		return updateTS;
	}

	public void setUpdateTS(String updateTS) {
		this.updateTS = updateTS;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getAuditFlag() {
		return auditFlag;
	}

	public void setAuditFlag(String auditFlag) {
		this.auditFlag = auditFlag;
	}
	
}
