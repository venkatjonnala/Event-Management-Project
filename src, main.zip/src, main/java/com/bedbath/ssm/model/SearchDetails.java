package com.bedbath.ssm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

//Ignore report specific properties
//TODO please update with real properties
@JsonIgnoreProperties(ignoreUnknown = true)
//@JsonIgnoreProperties({"multiUPC","winDomain","crtUser","updUser","updtm","reportList"})
public class SearchDetails implements Serializable {
		
	private static final long serialVersionUID = 7163661992594745688L;
	private Long sku;
	private Long vendorNo;
	private String vendorName;
	private Integer dept;
	private Integer subDept;
	private Integer clas;
	private Long upc;
	private Boolean instSaveElig;
	private String skuDescription;
	private String instsaveElg;
	private Integer saveDeleteFlag;
	private Integer isid; // for Delete record
	private Boolean groupSelectionFlag = false;
	private String webSkuDesc;
	private String vendorWebSkuDesc;
	private String merchGroup;
	private Double vendormina;
	private String vendorminc;
	private String eventName;
	//private Integer eventNumber;
	private String eventNumber;
	private String status;
	private Long storeNo;
	private String enWebDesc;
	
/*
	private String multiUPC;
	private Integer casePack;
	private Integer innerPack;
	private String kit;
	private Boolean top;
	private Integer mu;
	private Float retail;
	private String storeRank;
	private String distRank;
	private String regRank;
	private String chainRank;
	private Long salesStore1;
	private Long salesStore2;
	private String sales1;
	private String sales2;
	private Integer weeks1;
	private Integer weeks2;
	private Long last4Weeks;
	private Long onHand;
	private Long onOrder;
	private Long onOrderPlus30;
	private String forecast;
	private Long soQty;
	private Long soQtyCopy;
	private Long buildTo;
	private Long buildToCopy;
	private Integer estimatedLeadDays;
	private String userLevel;
	private Boolean warehouseRestricted;
	private String bldDomain;
	private String bldDomainCopy;
	private String bldStatus;
	private int bldLevel;
	private int domainCount;
	private String skuNote;
	private String permNote;
	private String altShip;
	private Integer altShipCnt;
	private Integer curDmnAltShpCnt;
	private String ordNote;
	private String searchTimestamp;
	private String swsFlag;
	private Float sellByFactor;
	private String importCode;
	private String orderableSKU;
	private String orderableStore = "Y";
	private String startWk;
	private String endWk;
	private String bldAprvStatus;
	private float cost;
	private float weight;
	private String cpaltns;
	private Long bfoTYL4;
	private String onOrderPastDue;
	private String permNoteComment;
	private String permLastUpdateUser;
	private Timestamp permLastUpdateTm;
*/     
	//ASO Load
//	private Long asoBuildTo;
//	private String asoind;
//	private String asoOverride;
//	private String asoOverrideCopy;
//	private String rfind;
//	private String asoLoadBT;
	
	//PDF Reports specific 
//	private String winDomain;
//	private String crtUser;
//	private Timestamp crttm;
//	private String updUser;
//	private Timestamp updtm;
//	private String saveId;
//	private String ooShipping;
//	private String activationDate;	
//	private String comment;	
//	private String action;
//	private String hwsku;
	
	
/*
	public String getOoShipping() {
		return ooShipping;
	}
	public void setOoShipping(String ooShipping) {
		this.ooShipping = ooShipping;
	}
	public String getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

	
	public String getWinDomain() {
		return winDomain;
	}
	public void setWinDomain(String winDomain) {
		this.winDomain = winDomain;
	}
	public String getCrtUser() {
		return crtUser;
	}
	public void setCrtUser(String crtUser) {
		this.crtUser = crtUser;
	}
	public String getUpdUser() {
		return updUser;
	}
	public void setUpdUser(String updUser) {
		this.updUser = updUser;
	}
	public Timestamp getUpdtm() {
		return updtm;
	}
	public void setUpdtm(Timestamp updtm) {
		this.updtm = updtm;
	}
	public Timestamp getCrttm() {
		return crttm;
	}
	public void setCrttm(Timestamp crttm) {
		this.crttm = crttm;
	}
	public void setSearchTimestamp(String searchTimestamp) {
		this.searchTimestamp = searchTimestamp;
	}
	public String getStartWk() {
		return startWk;
	}
	public void setStartWk(String startWk) {
		this.startWk = startWk;
	}

	public String getEndWk() {
		return endWk;
	}
	public void setEndWk(String endWk) {
		this.endWk = endWk;
	}
	public String getSkuNote() {
		return skuNote;
	}
	public void setSkuNote(String skuNote) {
		skuNote = skuNote==null?"N":skuNote;
		this.skuNote = skuNote;
	}
	public String getPermNote() {
		return permNote;
	}
	public void setPermNote(String permNote) {
		permNote = permNote==null?"N":permNote;
		this.permNote = permNote;
	}
	public String getAltShip() {
		return altShip;
	}
	public void setAltShip(String altShip) {
		altShip = altShip==null?"N":altShip;
		this.altShip = altShip;
	}
	public Integer getAltShipCnt() {
		return altShipCnt;
	}
	public void setAltShipCnt(Integer altShipCnt) {
		this.altShipCnt = altShipCnt;
	}
	public Integer getCurDmnAltShpCnt() {
		return curDmnAltShpCnt;
	}
	public void setCurDmnAltShpCnt(Integer curDmnAltShpCnt) {
		this.curDmnAltShpCnt = curDmnAltShpCnt;
	}
*/
	
	public String getWebSkuDesc() {
		return webSkuDesc;
	}
	public void setWebSkuDesc(String webSkuDesc) {
		this.webSkuDesc = webSkuDesc;
	}
	public String getMerchGroup() {
		return merchGroup;
	}
	public void setMerchGroup(String merchGroup) {
		this.merchGroup = merchGroup;
	}
	public Long getSku() {
		return sku;
	}
	public void setSku(Long sku) {
		this.sku = sku;
	}
	public Long getUpc() {
		return upc;
	}
	public void setUpc(Long upc) {
		this.upc = upc;
	}
	public String getSkuDescription() {
		return skuDescription;
	}
	public void setSkuDescription(String skuDescription) {
		this.skuDescription = skuDescription;
	}
	public Long getVendorNo() {
		return vendorNo;
	}
	public void setVendorNo(Long vendorNo) {
		this.vendorNo = vendorNo;
	}
	
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public Integer getDept() {
		return dept;
	}
	public void setDept(Integer dept) {
		this.dept = dept;
	}
	public Integer getSubDept() {
		return subDept;
	}
	public void setSubDept(Integer subDept) {
		this.subDept = subDept;
	}
	public Integer getClas() {
		return clas;
	}
	public void setClas(Integer clas) {
		this.clas = clas;
	}
/*
	public Integer getCasePack() {
		return casePack;
	}
	public void setCasePack(Integer casePack) {
		this.casePack = casePack;
	}
	public String getKit() {
		return kit;
	}
	public void setKit(String kit) {
		this.kit = kit;
	}
	public Boolean getTop() {
		return top;
	}
	public void setTop(Boolean top) {
		this.top = top;
	}
*/	public Long getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(Long storeNo) {
		this.storeNo = storeNo;
	}/*
	public Integer getMu() {
		return mu;
	}
	public void setMu(Integer mu) {
		this.mu = mu;
	}
	public Float getRetail() {
		return retail;
	}
	public void setRetail(Float retail) {
		this.retail = retail;
	}
	public String getStoreRank() {
		return storeRank;
	}
	public void setStoreRank(String storeRank) {
		this.storeRank = storeRank;
	}
	public String getDistRank() {
		return distRank;
	}
	public void setDistRank(String districtRank) {
		this.distRank = districtRank;
	}
	public String getRegRank() {
		return regRank;
	}
	public void setRegRank(String regionRank) {
		this.regRank = regionRank;
	}
	public String getChainRank() {
		return chainRank;
	}
	public void setChainRank(String chainRank) {
		this.chainRank = chainRank;
	}
	public Long getLast4Weeks() {
		return last4Weeks;
	}
	public void setLast4Weeks(Long last4Weeks) {
		this.last4Weeks = last4Weeks;
	}
	public Long getOnHand() {
		return onHand;
	}
	public void setOnHand(Long onHand) {
		this.onHand = onHand;
	}
	public Long getOnOrder() {
		return onOrder;
	}
	public void setOnOrder(Long onOrder) {
		this.onOrder = onOrder;
	}
	public Long getOnOrderPlus30() {
		return onOrderPlus30;
	}
	public void setOnOrderPlus30(Long onOrderPlus30) {
		this.onOrderPlus30 = onOrderPlus30;
	}
	public String getForecast() {
		return forecast;
	}
	public void setForecast(String forecast) {
		this.forecast = forecast;
	}
	public Long getSoQty() {
		return soQty;
	}
	public void setSoQty(Long soQty) {
		this.soQty = soQty;
		this.soQtyCopy = soQty;
	}
	public Long getSoQtyCopy() {
		return soQtyCopy;
	}
	public void setSoQtyCopy(Long soQtyCopy) {
		this.soQtyCopy = soQtyCopy;
	}		
	public Long getBuildTo() {
		return buildTo;
	}
	public void setBuildTo(Long buildTo) {
		this.buildTo = buildTo;
		this.buildToCopy = buildTo;
	}
	public Long getBuildToCopy() {
		return buildToCopy;
	}
	public void setBuildToCopy(Long buildToCopy) {
		this.buildToCopy = buildToCopy;
	}	
	public Integer getEstimatedLeadDays() {
		return estimatedLeadDays;
	}
	public void setEstimatedLeadDays(Integer estimatedLeadDays) {
		this.estimatedLeadDays = estimatedLeadDays;
	}
	public String getUserLevel() {
		return userLevel;
	}
	public void setUserLevel(String userLevel) {
		this.userLevel = userLevel;
	}

	public Integer getInnerPack() {
		return innerPack;
	}
	public void setInnerPack(Integer innerPack) {
		this.innerPack = innerPack;
	}
	public Boolean getWarehouseRestricted() {
		return warehouseRestricted;
	}
	public void setWarehouseRestricted(Boolean warehouseRestricted) {
		this.warehouseRestricted = warehouseRestricted;
	}
	public String getBldDomain() {
		return bldDomain;
	}
	public void setBldDomain(String bldDomain) {		
		this.bldDomain = bldDomain == null?"":bldDomain;
		this.bldDomainCopy = this.bldDomain;
	}
	public String getBldDomainCopy() {
		return bldDomainCopy;
	}
	public void setBldDomainCopy(String bldDomainCopy) {		
		this.bldDomainCopy = bldDomainCopy;
	}
	
	public String getBldStatus() {
		return bldStatus;
	}
	public void setBldStatus(String bldStatus) {
		this.bldStatus = bldStatus == null?"":bldStatus;
	}		
	public void setBldLevel(int bldLevel) {
		this.bldLevel = bldLevel;
	}
	public int getBldLevel() {
		return bldLevel;
	}
	public Long getSalesStore1() {
		return salesStore1;
	}
	public void setSalesStore1(Long salesStore1) {
		this.salesStore1 = salesStore1;
	}
	public Long getSalesStore2() {
		return salesStore2;
	}
	public void setSalesStore2(Long salesStore2) {
		this.salesStore2 = salesStore2;
	}
	public String getSales1() {
		return sales1;
	}
	public void setSales1(String sales1) {
		this.sales1 = sales1;
	}
	public String getSales2() {
		return sales2;
	}
	public void setSales2(String sales2) {
		this.sales2 = sales2;
	}
	public Integer getWeeks1() {
		return weeks1;
	}
	public void setWeeks1(Integer weeks1) {
		this.weeks1 = weeks1;
	}
	public Integer getWeeks2() {
		return weeks2;
	}
	public void setWeeks2(Integer weeks2) {
		this.weeks2 = weeks2;
	}
	public String getSwsFlag() {
		return swsFlag;
	}
	public void setSwsFlag(String swsFlag) {
		this.swsFlag = swsFlag==null?"N":swsFlag;
	}
	public Float getSellByFactor() {
		return sellByFactor;
	}
	public void setSellByFactor(Float sellByFactor) {
		this.sellByFactor = sellByFactor;
	}
	public String getSearchTimestamp() {
		return searchTimestamp;
	}
	public void setSearchTimeStamp(String searchTimestamp) {
		this.searchTimestamp = searchTimestamp;
	}
	public String getImportCode() {
		return importCode;
	}
	public void setImportCode(String importCode) {
		//N --Not imported
		//to avoid nulls on importCodes array of UI
		importCode = importCode==null?"":importCode.trim();
		importCode = importCode.equals("")?"N":importCode;
		this.importCode = importCode;
	}
	public String getOrderableSKU() {
		return orderableSKU;
	}
	public void setOrderableSKU(String orderableSKU) {
		this.orderableSKU = orderableSKU;
	}
	public String getOrdNote() {
		return ordNote;
	}
	public void setOrdNote(String ordNote) {
		altShip = altShip==null?"N":altShip;
		this.ordNote = ordNote;
	}
	public String getBldAprvStatus() {
		return bldAprvStatus;
	}
	public void setBldAprvStatus(String bldAprvStatus) {
		this.bldAprvStatus = bldAprvStatus;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public String getCpaltns() {
		return cpaltns==null?"N":cpaltns;
	}
	public void setCpaltns(String cpaltns) {
		cpaltns = cpaltns==null?"N":cpaltns;
		this.cpaltns = cpaltns;
	}
	public String getMultiUPC() {
		return multiUPC;
	}
	public void setMultiUPC(String multiUPC) {
		this.multiUPC = multiUPC;
	}
	public String getSaveId() {
		return saveId;
	}
	public void setSaveId(String saveId) {
		this.saveId = saveId;
	}
*/
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVendorWebSkuDesc() {
		return vendorWebSkuDesc;
	}
	public void setVendorWebSkuDesc(String vendorWebSkuDesc) {
		this.vendorWebSkuDesc = vendorWebSkuDesc;
	}
	public Double getVendorMina() {
		return vendormina;
	}
	public void setVendorMina(Double vendormina) {
		this.vendormina = vendormina;
	}
	public String getVendorMinc() {
		return vendorminc;
	}
	public void setVendorMinc(String vendorminc) {
		this.vendorminc = vendorminc;
	}
/*	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sku == null) ? 0 : sku.hashCode());
		result = prime * result + ((storeNo == null) ? 0 : storeNo.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SearchDetails other = (SearchDetails) obj;
		if (sku == null) {
			if (other.sku != null)
				return false;
		} else if (!sku.equals(other.sku))
			return false;
		if (storeNo == null) {
			if (other.storeNo != null)
				return false;
		} else if (!storeNo.equals(other.storeNo))
			return false;
		return true;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getHwsku() {
		return hwsku;
	}
	public void setHwsku(String hwsku) {
		this.hwsku = hwsku;
	}
	public Long getBfoTYL4() {
		return bfoTYL4;
	}
	public void setBfoTYL4(Long bfoTYL4) {
		this.bfoTYL4 = bfoTYL4;
	}
	public String getOrderableStore() {
		return orderableStore;
	}
	public void setOrderableStore(String orderableStore) {
		this.orderableStore = orderableStore;
	}
	public String getOnOrderPastDue() {
		return onOrderPastDue;
	}
	public void setOnOrderPastDue(String onOrderPastDue) {
		this.onOrderPastDue = onOrderPastDue;
	}
	public String getPermNoteComment() {
		return permNoteComment;
	}
	public void setPermNoteComment(String permNoteComment) {
		this.permNoteComment = permNoteComment;
	}
	public String getPermLastUpdateUser() {
		return permLastUpdateUser;
	}
	public void setPermLastUpdateUser(String permLastUpdateUser) {
		this.permLastUpdateUser = permLastUpdateUser;
	}
	public Timestamp getPermLastUpdateTm() {
		return permLastUpdateTm;
	}
	public void setPermLastUpdateTm(Timestamp permLastUpdateTm) {
		this.permLastUpdateTm = permLastUpdateTm;
	}
	public Long getAsoBuildTo() {
		return asoBuildTo;
	}
	public void setAsoBuildTo(Long asoBuildTo) {
		this.asoBuildTo = asoBuildTo;
	}
	public String getAsoind() {
		return asoind;
	}
	public void setAsoind(String asoind) {
		this.asoind = asoind;
	}
	public String getAsoOverride() {
		return asoOverride;
	}
	public void setAsoOverride(String asoOverride) {
		this.asoOverride = asoOverride;
		this.asoOverrideCopy = asoOverride;
	}
	public String getAsoLoadBT() {
		return asoLoadBT;
	}
	public void setAsoLoadBT(String asoLoadBT) {
		this.asoLoadBT = asoLoadBT;
	}
	public int getDomainCount() {
		return domainCount;
	}
	public void setDomainCount(int domainCount) {
		this.domainCount = domainCount;
	}
	public String getRfind() {
		return rfind;
	}
	public void setRfind(String rfind) {
		this.rfind = rfind;
	}
	public String getAsoOverrideCopy() {
		return asoOverrideCopy;
	}
	public void setAsoOverrideCopy(String asoOverrideCopy) {
		this.asoOverrideCopy = asoOverrideCopy;
	}
*/
	public Boolean getInstSaveElig() {
		return instSaveElig;
	}
	public void setInstSaveElig(Boolean instSaveElig) {
		this.instSaveElig = instSaveElig;
	}
	public String getInstsaveElg() {
		return instsaveElg;
	}
	public void setInstsaveElg(String instsaveElg) {
		this.instsaveElg = instsaveElg;
	}
	public Integer getSaveDeleteFlag() {
		return saveDeleteFlag;
	}
	public void setSaveDeleteFlag(Integer saveDeleteFlag) {
		this.saveDeleteFlag = saveDeleteFlag;
	}
	public Integer getIsid() {
		return isid;
	}
	public void setIsid(Integer isid) {
		this.isid = isid;
	}
	public Boolean getGroupSelectionFlag() {
		return groupSelectionFlag;
	}
	public void setGroupSelectionFlag(Boolean groupSelectionFlag) {
		this.groupSelectionFlag = groupSelectionFlag;
	}
	public String getEnWebDesc() {
		return enWebDesc;
	}
	public void setEnWebDesc(String enWebDesc) {
		this.enWebDesc = enWebDesc;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventNumber() {
		return eventNumber;
	}
	public void setEventNumber(String eventNumber) {
		this.eventNumber = eventNumber;
	}
	
	
	
	
	
}
