package com.bedbath.ssm.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;


public class ASMCountryListModel implements JSONCapable {
	// CTRYCOD
	// CTRYNAM
	private String ctryCode;
	private String ctryName;

	public ASMCountryListModel() {
		this.ctryCode = "";
		this.ctryName = "";
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("ctryCode", this.ctryCode);
		json.put("ctryName", this.ctryName);
		return json;
	}

	public String getCtryCode() {
		return ctryCode;
	}

	public void setCtryCode(String ctryCode) {
		this.ctryCode = ctryCode;
	}

	public String getCtryName() {
		return ctryName;
	}

	public void setCtryName(String ctryName) {
		this.ctryName = ctryName;
	}


}
