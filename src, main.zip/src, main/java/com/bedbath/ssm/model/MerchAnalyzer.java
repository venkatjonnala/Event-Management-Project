package com.bedbath.ssm.model;

public class MerchAnalyzer {
	private  String 	merchAnalyzerDesc;
	private String 	merchAnalyzerCode;
	private String 	merchAnalyzerComb;
	
	
	public String getMerchAnalyzerDesc() {
		return merchAnalyzerDesc;
	}
	public void setMerchAnalyzerDesc(String merchAnalyzerDesc) {
		this.merchAnalyzerDesc = merchAnalyzerDesc;
	}
	public String getMerchAnalyzerCode() {
		return merchAnalyzerCode;
	}
	public void setMerchAnalyzerCode(String merchAnalyzerCode) {
		this.merchAnalyzerCode = merchAnalyzerCode;
	}
	public String getMerchAnalyzerComb() {
		return merchAnalyzerComb;
	}
	public void setMerchAnalyzerComb(String merchAnalyzerComb) {
		this.merchAnalyzerComb = merchAnalyzerComb;
	}
}
