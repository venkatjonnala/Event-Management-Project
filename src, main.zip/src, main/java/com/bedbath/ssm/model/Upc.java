package com.bedbath.ssm.model;

public class Upc {

	private  String inumbr;
	private String 	iupc;
	private String 	iuprt;
	private String 	iuvnd;
	private String 	iupccd;
	private String 	iustyl;
	private String 	iuasn;
	private String 	iuppda;
	private String 	iupppo;
	private String 	iuppdo;
	private String 	iuprim;
	private String 	iuprdt;
	public String getInumbr() {
		return inumbr;
	}
	public void setInumbr(String inumbr) {
		this.inumbr = inumbr;
	}
	public String getIupc() {
		return iupc;
	}
	public void setIupc(String iupc) {
		this.iupc = iupc;
	}
	public String getIuprt() {
		return iuprt;
	}
	public void setIuprt(String iuprt) {
		this.iuprt = iuprt;
	}
	public String getIuvnd() {
		return iuvnd;
	}
	public void setIuvnd(String iuvnd) {
		this.iuvnd = iuvnd;
	}
	public String getIupccd() {
		return iupccd;
	}
	public void setIupccd(String iupccd) {
		this.iupccd = iupccd;
	}
	public String getIustyl() {
		return iustyl;
	}
	public void setIustyl(String iustyl) {
		this.iustyl = iustyl;
	}
	public String getIuasn() {
		return iuasn;
	}
	public void setIuasn(String iuasn) {
		this.iuasn = iuasn;
	}
	public String getIuppda() {
		return iuppda;
	}
	public void setIuppda(String iuppda) {
		this.iuppda = iuppda;
	}
	public String getIupppo() {
		return iupppo;
	}
	public void setIupppo(String iupppo) {
		this.iupppo = iupppo;
	}
	public String getIuppdo() {
		return iuppdo;
	}
	public void setIuppdo(String iuppdo) {
		this.iuppdo = iuppdo;
	}
	public String getIuprim() {
		return iuprim;
	}
	public void setIuprim(String iuprim) {
		this.iuprim = iuprim;
	}
	public String getIuprdt() {
		return iuprdt;
	}
	public void setIuprdt(String iuprdt) {
		this.iuprdt = iuprdt;
	}
	

}
