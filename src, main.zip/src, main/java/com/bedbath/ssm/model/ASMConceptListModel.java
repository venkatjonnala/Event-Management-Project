package com.bedbath.ssm.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;


public class ASMConceptListModel implements JSONCapable {
	// CONCEPTDESC
	private String conceptDesc;

	public ASMConceptListModel() {
		this.conceptDesc = "";
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("conceptDesc", this.conceptDesc);
		return json;
	}

	public String getConceptDesc() {
		return conceptDesc;
	}

	public void setConceptDesc(String conceptDesc) {
		this.conceptDesc = conceptDesc;
	}

}
