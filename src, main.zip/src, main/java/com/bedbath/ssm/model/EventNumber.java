package com.bedbath.ssm.model;

public class EventNumber {
	
	private Long eventNumber;
	private String eventDesc;
	
	
	public EventNumber(){
		
	}
	public EventNumber(Long eventNumber, String eventDesc){
		this.eventNumber = eventNumber;
		this.eventDesc = eventDesc;
	}
	public Long getEventNumber() {
		return eventNumber;
	}
	public void setEventNumber(Long eventNumber) {
		this.eventNumber = eventNumber;
	}
	public String getEventDesc() {
		return eventDesc;
	}
	public void setEventDesc(String eventDesc) {
		this.eventDesc = eventDesc;
	}
}
