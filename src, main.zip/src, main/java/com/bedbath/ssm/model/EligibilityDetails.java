package com.bedbath.ssm.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
//@JsonIgnoreProperties({"multiUPC","winDomain","crtUser","updUser","updtm","reportList"})
public class EligibilityDetails implements Serializable {
	
	private static final long serialVersionUID = 7163661992594745688L;
	
	
	private Integer isAsnum;  // vendor
	private Integer instsavElig;	
	
	
	private Integer isinumbr;  // sku
	//private Long isinumbr;  // sku
	
	private Integer isDept;		
	private Integer isSdept;	
	private Integer isClas;	
	private Integer isId;	
	private String isevt;  // Event number		
	private String isma;    // MerchAnalyzer
	
	private String createUser;	
	private String createPgm;	  // Stored procedure name
	private Timestamp createtime;		
	private String changeUser;	
	private String changepgm;	
	private Timestamp changetime;
	
	//RC::
	private String groupElgFlag = "Add";
	private Boolean groupEligFl;
	
	
	
	public Integer getIsId() {
		return isId;
	}
	public void setIsId(Integer isId) {
		this.isId = isId;
	}
	public Integer getIsAsnum() {
		return isAsnum;
	}
	public void setIsAsnum(Integer isAsnum) {
		this.isAsnum = isAsnum;
	}
	public Integer getIsDept() {
		return isDept;
	}
	public void setIsDept(Integer isDept) {
		this.isDept = isDept;
	}
	public Integer getIsSdept() {
		return isSdept;
	}
	public void setIsSdept(Integer isSdept) {
		this.isSdept = isSdept;
	}
	public Integer getIsClas() {
		return isClas;
	}
	public void setIsClas(Integer isClas) {
		this.isClas = isClas;
	}
	public Integer getIsinumbr() {
		return isinumbr;
	}
	public void setIsinumbr(Integer isinumbr) {
		this.isinumbr = isinumbr;
	}
	public String getIsevt() {
		return isevt;
	}
	public void setIsevt(String string) {
		this.isevt = string;
	}
	public String getIsma() {
		return isma;
	}
	public void setIsma(String isma) {
		this.isma = isma;
	}
	public String getCreateUser() {
		return createUser;
	}
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	public String getCreatePgm() {
		return createPgm;
	}
	public void setCreatePgm(String createPgm) {
		this.createPgm = createPgm;
	}
	public Timestamp getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}
	public String getChangeUser() {
		return changeUser;
	}
	public void setChangeUser(String changeUser) {
		this.changeUser = changeUser;
	}
	public String getChangepgm() {
		return changepgm;
	}
	public void setChangepgm(String changepgm) {
		this.changepgm = changepgm;
	}
	public Timestamp getChangetime() {
		return changetime;
	}
	public void setChangetime(Timestamp changetime) {
		this.changetime = changetime;
	}
	public Integer getInstsavElig() {
		return instsavElig;
	}
	public void setInstsavElig(Integer instsavElig) {
		this.instsavElig = instsavElig;
	}
	public String getGroupElgFlag() {
		return groupElgFlag;
	}
	public void setGroupElgFlag(String groupElgFlag) {
		this.groupElgFlag = groupElgFlag;
	}
	public Boolean getGroupEligFl() {
		return groupEligFl;
	}
	public void setGroupEligFl(Boolean groupEligFl) {
		this.groupEligFl = groupEligFl;
	}
}
