package com.bedbath.ssm.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

//@JsonIgnoreProperties({"multiUPC","winDomain","crtUser","updUser","updtm","reportList"})
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchRequest implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9116164106236200694L;
	private List<Long> vendorNos;
	private String vendorName;
	private String vendorPartNo;
	private String merchAnalyz;
	private List<Long> 	skus;
	private String skuDescription;
	private List<String> statuses;
	private List<Long> 	storeNos;
	private List<Long> 	noAccessStores;
	private List<Long> 	depts;
	private List<Long> 	subDepts;
	private List<Long> 	upcs;
	private List<Long>  clas;
	private List<Long>  events;
	private Integer start;
	private Integer limit;	
	private String searchType; 
	private Long storeNo;
    private String status;
    private String country;
    private String rankPeriod;
    private String rankBy;
	private String concept;
	private String conceptShortName;
	private String rankConcept;
    private String swsConcept;
    private String top100FltType;
    private String mappingRequired;
    private Long salesStr1;
    private Long salesStr2;
    private String startDt1;
    private String endDt1;
    private String startDt2;
    private String endDt2;
    private String likeMatch;
    private String orderBy;
    private String orderDir;
    private String language;
    private Integer maxCount;
    private Double roundDown = 200.00;
    private String storeSku;
    private boolean elasticSearch;
    private String venNameMode;
    private String venPartMode;
    private String skuMode;
    private String currentDomain;
    private String rankType;
    private Integer largeSOQty;
    
    private String merchcatno;
    private Integer catno;
    private Integer shelfno;

    //If for Report/Excel set this parameter to true
    private boolean isReportRequest = false;     
    //This object used for only ESSearch salesStore1/salesStoer2/last4weeks sorting 
    private ESSortRequest esSortRequest;
    
    
    //Used for searchKey calculation
    private String userId;
    private String ipAddress;
    private String filters;
    private int searchKey;
    
    // Last 4 Weeks Dates
    private String last4WkStartDt;
    private String last4WkEndDt;
    
    //used for ASO search
    private String asoInd;
    
    
    
    
    
	public String getMerchcatno() {
		return merchcatno;
	}
	public void setMerchcatno(String merchcatno) {
		this.merchcatno = merchcatno;
	}
	public Integer getCatno() {
		return catno;
	}
	public void setCatno(Integer catno) {
		this.catno = catno;
	}
	public Integer getShelfno() {
		return shelfno;
	}
	public void setShelfno(Integer shelfno) {
		this.shelfno = shelfno;
	}
	public void setSearchKey(int searchKey) {
		this.searchKey = searchKey;
	}
	public String getVenNameMode() {
		return venNameMode;
	}
	public void setVenNameMode(String venNameMode) {
		this.venNameMode = venNameMode;
	}
	public String getVenPartMode() {
		return venPartMode;
	}
	public void setVenPartMode(String venPartMode) {
		this.venPartMode = venPartMode;
	}
	public String getSkuMode() {
		return skuMode;
	}
	public void setSkuMode(String skuMode) {
		this.skuMode = skuMode;
	}
	public String getStoreSku() {
		return storeSku;
	}
	public void setStoreSku(String storeSku) {
		this.storeSku = storeSku;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getLikeMatch() {
		return likeMatch;
	}
	public void setLikeMatch(String likeMatch) {
		this.likeMatch = likeMatch;
	}
	public String getConcept() {
		return concept;
	}
	public void setConcept(String concept) {
		this.concept = concept;
	}
	public String getConceptShortName() {
		return conceptShortName;
	}
	public void setConceptShortName(String conceptShortName) {
		this.conceptShortName = conceptShortName;
	}
	public String getSwsConcept() {
		return swsConcept;
	}
	public void setSwsConcept(String swsConcept) {
		this.swsConcept = swsConcept;
	}
    
    public Long getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(Long storeNo) {
		this.storeNo = storeNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	public List<Long> getUpcs() {
		return upcs;
	}
	public void setUpcs(List<Long> upcs) {
		this.upcs = upcs;
	}
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getLimit() {
		return limit;
	}
	public void setLimit(Integer limit) {
		this.limit = limit;
	}
	public List<Long> getVendorNos() {
		return vendorNos;
	}
	public void setVendorNos(List<Long> vendorNos) {
		this.vendorNos = vendorNos;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getVendorPartNo() {
		return vendorPartNo;
	}
	public void setVendorPartNo(String vendorPartNo) {
		this.vendorPartNo = vendorPartNo;
	}
	public String getMerchAnalyz() {
		return merchAnalyz;
	}
	public void setMerchAnalyz(String merchAnalyz) {
		this.merchAnalyz = merchAnalyz;
	}
	public List<Long> getSkus() {
		return skus;
	}
	public void setSkus(List<Long> skus) {
		this.skus = skus;
	}
	public String getSkuDescription() {
		return skuDescription;
	}
	public void setSkuDescription(String skuDescription) {
		this.skuDescription = skuDescription;
	}
	public List<String> getStatuses() {
		return statuses;
	}
	public void setStatuses(List<String> statuses) {
		this.statuses = statuses;
	}
	public List<Long> getStoreNos() {
		return storeNos;
	}
	public void setStoreNos(List<Long> storeNos) {
		this.storeNos = storeNos;
	}
	public List<Long> getDepts() {
		return depts;
	}
	public void setDepts(List<Long> depts) {
		this.depts = depts;
	}
	public List<Long> getSubDepts() {
		return subDepts;
	}
	public void setSubDepts(List<Long> subDepts) {
		this.subDepts = subDepts;
	}
	public List<Long> getClas() {
		return clas;
	}
	public void setClas(List<Long> clas) {
		this.clas = clas;
	}
	
	public List<Long> getEvents() {
		return events;
	}
	public void setEvents(List<Long> events) {
		this.events = events;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getCountry() {
		return country;
	}
	public String getRankPeriod() {
		return rankPeriod;
	}
	public void setRankPeriod(String rankPeriod) {
		this.rankPeriod = rankPeriod;
	}
	public String getRankBy() {
		return rankBy;
	}
	public void setRankBy(String rankBy) {
		this.rankBy = rankBy;
	}
	public Long getSalesStr1() {
		return salesStr1;
	}
	public void setSalesStr1(Long salesStr1) {
		this.salesStr1 = salesStr1;
	}
	public Long getSalesStr2() {
		return salesStr2;
	}
	public void setSalesStr2(Long salesStr2) {
		this.salesStr2 = salesStr2;
	}
	public String getStartDt1() {
		return startDt1;
	}
	public void setStartDt1(String startDt1) {
		this.startDt1 = startDt1;
	}
	public String getEndDt1() {
		return endDt1;
	}
	public void setEndDt1(String endDt1) {
		this.endDt1 = endDt1;
	}
	public String getStartDt2() {
		return startDt2;
	}
	public void setStartDt2(String startDt2) {
		this.startDt2 = startDt2;
	}
	public String getEndDt2() {
		return endDt2;
	}
	public void setEndDt2(String endDt2) {
		this.endDt2 = endDt2;
	}
	public String getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}
	public String getOrderDir() {
		return orderDir;
	}
	public void setOrderDir(String orderDir) {
		this.orderDir = orderDir;
	}
	public Integer getMaxCount() {
		return maxCount;
	}
	public void setMaxCount(Integer maxCount) {
		this.maxCount = maxCount;
	}
	public double getRoundDown() {
		return roundDown;
	}
	public void setRoundDown(double roundDown) {
		this.roundDown = roundDown;
	}
	public String getRankConcept() {
		return rankConcept;
	}
	public void setRankConcept(String rankConcept) {
		this.rankConcept = rankConcept;
	}
	public String getTop100FltType() {
		return top100FltType;
	}
	public void setTop100FltType(String top100FltType) {
		this.top100FltType = top100FltType;
	}
	public String getMappingRequired() {
		return mappingRequired;
	}
	public void setMappingRequired(String mappingRequired) {
		this.mappingRequired = mappingRequired;
	}
	public void setRoundDown(Double roundDown) {
		this.roundDown = roundDown;
	}
	public boolean isElasticSearch() {
		return elasticSearch;
	}
	public void setElasticSearch(boolean elasticSearch) {
		this.elasticSearch = elasticSearch;
	}
	public String getCurrentDomain() {
		return currentDomain;
	}
	public void setCurrentDomain(String currentDomain) {
		this.currentDomain = currentDomain;
	}
	public String getRankType() {
		return rankType;
	}
	public void setRankType(String rankType) {
		this.rankType = rankType;
	}
	public Integer getLargeSOQty() {
		return largeSOQty;
	}
	public void setLargeSOQty(Integer largeSOQty) {
		this.largeSOQty = largeSOQty;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getSearchKey() {
	    StringBuffer searchKey = new StringBuffer();
	    if(this.vendorNos !=null){
	    	searchKey = searchKey.append(this.vendorNos.toString().replace("[", "").replace("]", ""));
	    }
	    if(this.skus !=null){
	    	searchKey = searchKey.append(this.skus.toString().replace("[", "").replace("]", ""));
	    }
	    if(this.statuses !=null){
	    	searchKey = searchKey.append(this.statuses.toString().replace("[", "").replace("]", ""));
	    }
	    if(this.storeNos !=null){
	    	searchKey = searchKey.append(this.storeNos.toString().replace("[", "").replace("]", ""));
	    }
	    if(this.depts !=null){
	    	searchKey = searchKey.append(this.depts.toString().replace("[", "").replace("]", ""));
	    }	    
	    if(this.subDepts !=null){
	    	searchKey = searchKey.append(this.subDepts.toString().replace("[", "").replace("]", ""));
	    }
	    if(this.upcs !=null){
	    	searchKey = searchKey.append(this.upcs.toString().replace("[", "").replace("]", ""));
	    }
	    if(this.clas !=null){
	    	searchKey = searchKey.append(this.clas.toString().replace("[", "").replace("]", ""));
	    }
	    if(this.subDepts !=null){
	    	searchKey = searchKey.append(this.subDepts.toString().replace("[", "").replace("]", ""));
	    }	    	    
	    searchKey = searchKey.append((this.vendorName!=null?this.vendorName:""));
	    searchKey = searchKey.append((this.vendorPartNo!=null?this.vendorPartNo:""));
	    searchKey = searchKey.append((this.merchAnalyz!=null?this.merchAnalyz:""));
	    searchKey = searchKey.append((this.vendorPartNo!=null?this.vendorPartNo:""));
	    searchKey = searchKey.append((this.skuDescription!=null?this.skuDescription:""));
	    searchKey = searchKey.append((this.start));
	    searchKey = searchKey.append((this.limit));	    
	    searchKey = searchKey.append((this.storeNo));	    
	    searchKey = searchKey.append((this.searchType!=null?this.searchType:""));
	    searchKey = searchKey.append((this.status!=null?this.status:""));
	    searchKey = searchKey.append((this.country!=null?this.country:""));
	    
	    searchKey = searchKey.append((this.rankPeriod!=null?this.rankPeriod:""));
	    searchKey = searchKey.append((this.rankBy!=null?this.rankBy:""));
	    
	    searchKey = searchKey.append((this.concept!=null?this.concept:""));
	    searchKey = searchKey.append((this.conceptShortName!=null?this.conceptShortName:""));
	    searchKey = searchKey.append((this.rankConcept!=null?this.rankConcept:""));
	    searchKey = searchKey.append((this.swsConcept!=null?this.swsConcept:""));
	    searchKey = searchKey.append((this.top100FltType!=null?this.top100FltType:""));
	    searchKey = searchKey.append((this.mappingRequired!=null?this.mappingRequired:""));
	    
	    searchKey = searchKey.append((this.salesStr1));
	    searchKey = searchKey.append((this.salesStr2));
	    
	    searchKey = searchKey.append((this.startDt1!=null?this.startDt1:""));
	    searchKey = searchKey.append((this.endDt1!=null?this.endDt1:""));
	    searchKey = searchKey.append((this.startDt2!=null?this.startDt2:""));
	    searchKey = searchKey.append((this.endDt2!=null?this.endDt2:""));
	    searchKey = searchKey.append((this.likeMatch!=null?this.likeMatch:""));
	    searchKey = searchKey.append((this.orderBy!=null?this.orderBy:""));
	    searchKey = searchKey.append((this.orderDir!=null?this.orderDir:""));
	    searchKey = searchKey.append((this.storeSku!=null?this.storeSku:""));
	    searchKey = searchKey.append((this.currentDomain!=null?this.currentDomain:""));
	    searchKey = searchKey.append((this.rankType!=null?this.rankType:""));
	    searchKey = searchKey.append((this.userId!=null?this.userId:""));
	    searchKey = searchKey.append((this.filters!=null?this.filters:""));
	    
	    searchKey = searchKey.append((this.last4WkStartDt!=null?this.last4WkStartDt:""));	     
	    searchKey = searchKey.append((this.last4WkEndDt!=null?this.last4WkEndDt:""));	   
	    
	    searchKey = searchKey.append((this.merchcatno!=null?this.merchcatno:""));
	    searchKey = searchKey.append((this.catno!=null?this.catno:""));
	    searchKey = searchKey.append((this.shelfno!=null?this.shelfno:""));
	    
		return searchKey.toString().trim();
	}
	
	public String getFilters() {
		return filters;
	}
	public void setFilters(String filters) {
		this.filters = filters;
	}
	public String getLast4WkStartDt() {
		return last4WkStartDt;
	}
	public void setLast4WkStartDt(String last4WkStartDt) {
		this.last4WkStartDt = last4WkStartDt;
	}
	public String getLast4WkEndDt() {
		return last4WkEndDt;
	}
	public void setLast4WkEndDt(String last4WkEndDt) {
		this.last4WkEndDt = last4WkEndDt;
	}
	public ESSortRequest getEsSortRequest() {
		return esSortRequest;
	}
	public void setEsSortRequest(ESSortRequest esSortRequest) {
		this.esSortRequest = esSortRequest;
	}
	public List<Long> getNoAccessStores() {
		return noAccessStores;
	}
	public void setNoAccessStores(List<Long> noAccessStores) {
		this.noAccessStores = noAccessStores;
	}
	public boolean isReportRequest() {
		return isReportRequest;
	}
	public void setReportRequest(boolean isReportRequest) {
		this.isReportRequest = isReportRequest;
	}
	public String getAsoInd() {
		return asoInd;
	}
	public void setAsoInd(String asoInd) {
		this.asoInd = asoInd;
	}
}
