package com.bedbath.ssm.model;

import java.text.DecimalFormat;
import java.util.Date;

public class Sku {
	private Long storeNo;
	private String  skuDesc;
	private String 	sku;
	private Long	skuNo;
	private String 	venPartNo;
	private String 	asnum;
	private String buildDomain;
	private String 	invStatus;
	private Integer	onHand;
	private Integer	onOrder;
	private Long onOrderMinus30;
	private Long onOrderPlus30;
	private Integer	bldtoqty;
	private String 	domainconflict;
	private Integer	soQty;
	private Long shipId;
	private Double	shipprc;
	private String 	unOrd;
	private String 	altShp;
	private Integer altShipCnt;
	private String 	domWB;
	private String 	skuNote;
	private Double totalOrder;
	private Double	retail;
	private Double	casepack;
	private String shipDate;
	private Integer minType;
	private String totalOrderText;
	private String hold;
	private DecimalFormat dec = new DecimalFormat("#.00");
	private String hwsku;
	private String importcd;
	private String permNote;
	private String prevStatus;
	private String currStatus;
	private String changeReason;
	private Date statusUpdDate;
	private String statusUpdTime;
	private String statusUpdUser;
	private Long vendorNo;
	private String vendorName;
	private Integer dept;
	
	
	public String getPermNote() {
		return permNote;
	}
	public void setPermNote(String permNote) {
		this.permNote = permNote;
	}
	public String getHold() {
		return hold==null?"N":hold;
	}
	public void setHold(String hold) {
		this.hold = hold;
	}
	public Double getRetail() {
		return retail;
	}
	public void setRetail(Double retail) {
		this.retail = retail;
	}
	public Double getCasepack() {
		return casepack;
	}
	public void setCasepack(Double casepack) {
		this.casepack = casepack;
	}
	public Double getTotalOrder() {
		return totalOrder;
	}
	public void setTotalOrder(Double totalOrder) {		
		totalOrder = (totalOrder!=null && totalOrder<=0)?0:totalOrder;		
		if(totalOrder!=null && (this.minType == 1 || this.minType == 2)){			
			if(this.minType == 1){
				if(totalOrder == 0){
					this.setTotalOrderText("$0");
				}
				else{
					this.setTotalOrderText("$" + dec.format(totalOrder));
				}				
			}
			else{
				if(totalOrder == 0){
					this.setTotalOrderText("0");
				}
				else{
					this.setTotalOrderText(dec.format(totalOrder));
				}				
			}			
			totalOrder = Double.valueOf(dec.format(totalOrder));					
		}
		else if(totalOrder != null){
			this.setTotalOrderText(""+ totalOrder.intValue());
		}
		this.totalOrder = totalOrder;
	}
	public Long getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(Long skuNo) {
		this.skuNo = skuNo;
	}
	public String getBuildDomain() {
		return buildDomain;
	}
	public void setBuildDomain(String buildDomain) {
		this.buildDomain = buildDomain;
	}
	public String getInvStatus() {
		return invStatus;
	}
	public void setInvStatus(String invStatus) {
		this.invStatus = invStatus;
	}
	public Integer getOnHand() {
		return onHand;
	}
	public void setOnHand(Integer onHand) {
		this.onHand = onHand;
	}
	public Integer getOnOrder() {
		return onOrder;
	}
	public void setOnOrder(Integer onOrder) {
		this.onOrder = onOrder;
	}
	public Long getOnOrderMinus30() {
		return onOrderMinus30;
	}
	public void setOnOrderMinus30(Long onOrderMinus30) {
		this.onOrderMinus30 = onOrderMinus30;
	}
	public Long getOnOrderPlus30() {
		return onOrderPlus30;
	}
	public void setOnOrderPlus30(Long onOrderPlus30) {
		this.onOrderPlus30 = onOrderPlus30;
	}
	public Integer getBldtoqty() {
		return bldtoqty;
	}
	public void setBldtoqty(Integer bldtoqty) {
		this.bldtoqty = bldtoqty;
	}
	public String getDomainconflict() {
		return domainconflict;
	}
	public void setDomainconflict(String domainconflict) {
		this.domainconflict = domainconflict;
	}
	public Integer getSoQty() {
		return soQty;
	}
	public void setSoQty(Integer soQty) {
		this.soQty = soQty;
	}
	public Long getShipId() {
		return shipId;
	}
	public void setShipId(Long shipId) {
		this.shipId = shipId;
	}
	public Double getShipprc() {
		return shipprc;
	}
	public void setShipprc(Double shipprc) {
		this.shipprc = shipprc;
	}
	public String getUnOrd() {
		return unOrd;
	}
	public void setUnOrd(String unOrd) {
		this.unOrd = unOrd;
	}
	public String getAltShp() {
		return altShp;
	}
	public void setAltShp(String altShp) {
		this.altShp = altShp;
	}
	public Integer getAltShipCnt() {
		return altShipCnt;
	}
	public void setAltShipCnt(Integer altShipCnt) {
		this.altShipCnt = altShipCnt;
	}
	public String getDomWB() {
		return domWB;
	}
	public void setDomWB(String domWB) {
		this.domWB = domWB;
	}
	public String getSkuNote() {
		return skuNote;
	}
	public void setSkuNote(String skuNote) {
		this.skuNote = skuNote;
	}
	public String getSkuDesc() {
		return skuDesc;
	}
	public void setSkuDesc(String skuDesc) {
		this.skuDesc = skuDesc;
	}
	public String getVenPartNo() {
		return venPartNo;
	}
	public void setVenPartNo(String venPartNo) {
		this.venPartNo = venPartNo;
	}
	public String getAsnum() {
		return asnum;
	}
	public void setAsnum(String asnum) {
		this.asnum = asnum;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getShipDate() {
		return shipDate;
	}
	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}
	public Integer getMinType() {
		return minType;
	}
	public void setMinType(Integer minType) {
		this.minType = minType;
	}
	public String getTotalOrderText() {
		return totalOrderText;
	}
	public void setTotalOrderText(String totalOrderText) {
		this.totalOrderText = totalOrderText;
	}
	public Long getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(Long storeNo) {
		this.storeNo = storeNo;
	}
	public String getHwsku() {
		return hwsku;
	}
	public void setHwsku(String hwsku) {
		this.hwsku = hwsku;
	}
	public String getImportcd() {
		return importcd;
	}
	public void setImportcd(String importcd) {
		this.importcd = importcd;
	}
	public String getPrevStatus() {
		return prevStatus;
	}
	public void setPrevStatus(String prevStatus) {
		this.prevStatus = prevStatus;
	}
	public String getCurrStatus() {
		return currStatus;
	}
	public void setCurrStatus(String currStatus) {
		this.currStatus = currStatus;
	}
	public String getChangeReason() {
		return changeReason;
	}
	public void setChangeReason(String changeReason) {
		this.changeReason = changeReason;
	}
	public Date getStatusUpdDate() {
		return statusUpdDate;
	}
	public void setStatusUpdDate(Date statusUpdDate) {
		this.statusUpdDate = statusUpdDate;
	}
	public String getStatusUpdTime() {
		return statusUpdTime;
	}
	public void setStatusUpdTime(String statusUpdTime) {
		this.statusUpdTime = statusUpdTime;
	}
	public String getStatusUpdUser() {
		return statusUpdUser;
	}
	public void setStatusUpdUser(String statusUpdUser) {
		this.statusUpdUser = statusUpdUser;
	}
	public Long getVendorNo() {
		return vendorNo;
	}
	public void setVendorNo(Long vendorNo) {
		this.vendorNo = vendorNo;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public Integer getDept() {
		return dept;
	}
	public void setDept(Integer dept) {
		this.dept = dept;
	}

}
