package com.bedbath.ssm.model;

public class Vendor {
	private Long vendorNo;
	private String vendorDesc;
	private String minType;
	private Float minAmount;
	private Float totalOrder;
	
	public Vendor(){
		
	}
	public Vendor(Long vendorNo, String vendorDesc){
		this.vendorNo = vendorNo;
		this.vendorDesc = vendorDesc;
	}
	
	public String getVendorDesc() {
		return vendorDesc;
	}
	public void setVendorDesc(String vendorDesc) {
		this.vendorDesc = vendorDesc;
	}

	public Long getVendorNo() {
		return vendorNo;
	}

	public void setVendorNo(Long vendorNo) {
		this.vendorNo = vendorNo;
	}
	
	public String getMinType() {
		return minType;
	}
	public void setMinType(String minType) {
		this.minType = minType;
	}
	public Float getMinAmount() {
		return minAmount;
	}
	public void setMinAmount(Float minAmount) {
		this.minAmount = minAmount;
	}
	public Float getTotalOrder() {
		return totalOrder;
	}
	public void setTotalOrder(Float totalOrder) {
		this.totalOrder = totalOrder;
	}


	

}
