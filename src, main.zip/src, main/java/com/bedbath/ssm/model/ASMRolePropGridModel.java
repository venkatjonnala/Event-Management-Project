package com.bedbath.ssm.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;


public class ASMRolePropGridModel implements JSONCapable {
	// APPID
	// ROLEID
	// ROLE_NAME
	// ROLE_DESCRIPTION 
	// PROPERTY_ID
	// PROPERTY_NAME
	// PROPERTY_DESCRIPTION 
	// PROPERTY_VALUE
	// CREATE_TIMESTAMP
	// UPDATE_TIMESTAMP
	// CRUPUSERID
	private long appId;
	private long roleId;
	private String roleName;
	private String roleDescription;
	private long propId;
	private String propName;
	private String propDescription;
	private String propValue;
	private String createTS;
	private String updateTS;
	private String updateUser;

	public ASMRolePropGridModel() {
		this.appId = 0;
		this.roleId = 0;
		this.roleName = "";
		this.roleDescription = "";
		this.propId = 0;
		this.propName = "";
		this.propDescription = "";
		this.propValue = "";
		this.createTS = "";
		this.updateTS = "";
		this.updateUser = "";
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("appId", this.appId);
		json.put("roleId", this.roleId);
		json.put("roleName", this.roleName);
		json.put("roleDescription", roleDescription);
		json.put("propId", this.propId);
		json.put("propName", this.propName);
		json.put("propDescription", propDescription);
		json.put("propValue", propValue);
		json.put("createTS", this.createTS);
		json.put("updateTS", this.updateTS);
		json.put("updateUser", this.updateUser);
		return json;
	}
	
	public long getAppId() {
		return appId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public long getPropId() {
		return propId;
	}

	public void setPropId(long propId) {
		this.propId = propId;
	}

	public String getPropName() {
		return propName;
	}

	public void setPropName(String propName) {
		this.propName = propName;
	}

	public String getPropDescription() {
		return propDescription;
	}

	public void setPropDescription(String propDescription) {
		this.propDescription = propDescription;
	}

	public String getPropValue() {
		return propValue;
	}

	public void setPropValue(String propValue) {
		this.propValue = propValue;
	}
	
	public String getCreateTS() {
		return createTS;
	}

	public void setCreateTS(String createTS) {
		this.createTS = createTS;
	}

	public String getUpdateTS() {
		return updateTS;
	}

	public void setUpdateTS(String updateTS) {
		this.updateTS = updateTS;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}


}
