package com.bedbath.ssm.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;


public class ASMAppListModel implements JSONCapable {
	// APPCODE
	// APP_NAME
	// APP_DISPLAY
	private String appCode;
	private String appName;
	private String appDisplay;

	public ASMAppListModel() {
		this.appCode = "";
		this.appName = "";
		this.appDisplay = "";
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("appCode", this.appCode);
		json.put("appName", this.appName);
		json.put("appDisplay", appDisplay);
		return json;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppDisplay() {
		return appDisplay;
	}

	public void setAppDisplay(String appDisplay) {
		this.appDisplay = appDisplay;
	}

}
