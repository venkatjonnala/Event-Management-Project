package com.bedbath.ssm.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;


public class ASMAppGridModel implements JSONCapable {
	// APPID
	// APPCODE
	// APP_NAME
	// APP_DESCRIPTION 
	// COUNTRY
	// CONCEPT
	// EFFECTIVE_FROM
	// EFFECTIVE_TO
	// CREATE_TIMESTAMP
	// UPDATE_TIMESTAMP
	// CRUPUSERID
	// AUDIT
	private long appId;
	private String appCode;
	private String appName;
	private String appDescription;
	private String countryCode;
	private String conceptCode;
	private Date effectiveFromDate;
	private Date effectiveToDate;
	private String createTS;
	private String updateTS;
	private String updateUser;
	private String auditFlag;

	public ASMAppGridModel() {
		this.appId = 0;
		this.appCode = "";
		this.appName = "";
		this.appDescription = "";
		this.countryCode = "";
		this.conceptCode = "";
		this.effectiveFromDate = new Date(0L);
		this.effectiveToDate = new Date(0L);
		this.createTS = "";
		this.updateTS = "";
		this.updateUser = "";
		this.auditFlag = "";
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("appId", this.appId);
		json.put("appCode", this.appCode);
		json.put("appName", this.appName);
		json.put("appDescription", appDescription);
		json.put("countryCode", this.countryCode);
		json.put("conceptCode", this.conceptCode);
		json.put("effectiveFromDate", this.effectiveFromDate);
		json.put("effectiveToDate", this.effectiveToDate);
		json.put("createTS", this.createTS);
		json.put("updateTS", this.updateTS);
		json.put("updateUser", this.updateUser);
		json.put("auditFlag", this.auditFlag);	
		return json;
	}
	
	public long getAppId() {
		return appId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppDescription() {
		return appDescription;
	}

	public void setAppDescription(String appDescription) {
		this.appDescription = appDescription;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getConceptCode() {
		return conceptCode;
	}

	public void setConceptCode(String conceptCode) {
		this.conceptCode = conceptCode;
	}

	public Date getEffectiveFromDate() {
		return effectiveFromDate;
	}

	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}

	public Date getEffectiveToDate() {
		return effectiveToDate;
	}

	public void setEffectiveToDate(Date effectiveToDate) {
		this.effectiveToDate = effectiveToDate;
	}

	public String getCreateTS() {
		return createTS;
	}

	public void setCreateTS(String createTS) {
		this.createTS = createTS;
	}

	public String getUpdateTS() {
		return updateTS;
	}

	public void setUpdateTS(String updateTS) {
		this.updateTS = updateTS;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getAuditFlag() {
		return auditFlag;
	}

	public void setAuditFlag(String auditFlag) {
		this.auditFlag = auditFlag;
	}




}
