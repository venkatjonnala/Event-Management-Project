package com.bedbath.ssm.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;


public class ASMPropGridModel implements JSONCapable {
	// APPID
	// PROPERTY_ID
	// PROPERTY_NAME
	// PROPERTY_DESCRIPTION 
	// PROPERTY_VALUE
	// CREATE_TIMESTAMP
	// UPDATE_TIMESTAMP
	// CRUPUSERID
	// AUDIT
	private long appId;
	private long propId;
	private String propName;
	private String propDescription;
	private String propValue;
	private String createTS;
	private String updateTS;
	private String updateUser;
	private String auditFlag;

	public ASMPropGridModel() {
		this.appId = 0;
		this.propId = 0;
		this.propName = "";
		this.propDescription = "";
		this.propValue = "";
		this.createTS = "";
		this.updateTS = "";
		this.updateUser = "";
		this.auditFlag = "";
	}

	public JSONObject toJSON() {
		JSONObject json = new JSONObject();
		json.put("appId", this.appId);
		json.put("propId", this.propId);
		json.put("propName", this.propName);
		json.put("propDescription", propDescription);
		json.put("propValue", propValue);
		json.put("createTS", this.createTS);
		json.put("updateTS", this.updateTS);
		json.put("updateUser", this.updateUser);
		json.put("auditFlag", this.auditFlag);	
		return json;
	}

	public long getAppId() {
		return appId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public long getPropId() {
		return propId;
	}

	public void setPropId(long propId) {
		this.propId = propId;
	}

	public String getPropName() {
		return propName;
	}

	public void setPropName(String propName) {
		this.propName = propName;
	}

	public String getPropDescription() {
		return propDescription;
	}

	public void setPropDescription(String propDescription) {
		this.propDescription = propDescription;
	}

	public String getPropValue() {
		return propValue;
	}

	public void setPropValue(String propValue) {
		this.propValue = propValue;
	}

	public String getCreateTS() {
		return createTS;
	}

	public void setCreateTS(String createTS) {
		this.createTS = createTS;
	}

	public String getUpdateTS() {
		return updateTS;
	}

	public void setUpdateTS(String updateTS) {
		this.updateTS = updateTS;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getAuditFlag() {
		return auditFlag;
	}

	public void setAuditFlag(String auditFlag) {
		this.auditFlag = auditFlag;
	}
	
}
