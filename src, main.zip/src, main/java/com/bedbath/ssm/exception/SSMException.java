package com.bedbath.ssm.exception;

public class SSMException extends Exception {
	private static final long serialVersionUID = 1L;
	private String errorCd;
	private String errorMessage;

	public SSMException() {
		super();
		init();
	}

	public SSMException(String message) {
		super(message);
		init();
		this.errorMessage = message;
	}

	public SSMException(String message, Throwable e) {
		super(message, e);
		init();
		this.errorMessage = message;
	}

	public SSMException(Throwable e) {
		super(e);
		init();
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCd() {
		return errorCd;
	}

	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	private void init() {
		errorCd = null;
		errorMessage = null;
	}

}
