package com.bedbath.ssm.exception;

/**
 * Application level exception class for Data Access Object.
 * 
 */
public class CommonDataAccessException extends Exception {

	/**
	 * default serial versionId.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * constructor passes given message to the super class.
	 * 
	 * @param msg
	 *            it is message to be displayed with the Exception.
	 */
	public CommonDataAccessException(final String msg) {
		super(msg);
	}

	/**
	 * constructor passes given message with the actual exception object to the
	 * super class.
	 * 
	 * @param msg
	 *            it is message to be displayed with the Exception.
	 * @param thr
	 *            it is java.lang.Throwable object.
	 */
	public CommonDataAccessException(final String msg, final Throwable thr) {
		super(msg, thr);
	}
}
