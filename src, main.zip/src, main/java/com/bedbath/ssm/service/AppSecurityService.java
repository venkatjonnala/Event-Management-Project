package com.bedbath.ssm.service;

import java.util.Map;

public interface AppSecurityService {
	
	public Map<String, Object> getUserPrivileges(String appCode, String country, String concept, String userId) throws Exception;

}
