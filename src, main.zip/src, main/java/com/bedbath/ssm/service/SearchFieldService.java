package com.bedbath.ssm.service;

import java.util.List;

import com.bedbath.ssm.model.MerchAnalyzer;
import com.bedbath.ssm.model.Sku;
import com.bedbath.ssm.model.Vendor;

public interface SearchFieldService {

	public List<Vendor>  getVendorList(List<Long> vendorNoList, String vendorDesc, String country, String concept, String searchmode) throws Exception;
	public List<Sku>  getSku(Integer sku, String skuDesc, String venPartNo, String country, Integer vendorno, String concept, String searchMode) throws Exception;
//	public List<Department>  getDepartment(Integer dept, Integer subDept, Integer deptClass) throws Exception;
	public List<MerchAnalyzer>  getMerchAnalyzer(String merchComb,String country,String concept) throws Exception;

}
