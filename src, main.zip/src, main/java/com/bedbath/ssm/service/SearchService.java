package com.bedbath.ssm.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bedbath.ssm.common.util.ResponseEntity;
import com.bedbath.ssm.exception.CommonDataAccessException;
import com.bedbath.ssm.exception.SSMException;
import com.bedbath.ssm.model.EligibilityDetails;
import com.bedbath.ssm.model.SearchDetails;
import com.bedbath.ssm.model.SearchRequest;

public interface SearchService {

	public Map<String, Object> search(SearchRequest searchRequest) throws Exception;
	public Map<String, Object> esSearch(SearchRequest searchRequest) throws Exception;
	public Map<String, Object> skuSearch(SearchRequest searchRequest) throws Exception;
	
		
	public ResponseEntity<SearchDetails>  saveEligibility(final List<SearchDetails> searchDetails,
			 //@RequestParam final String instantSavingsList,
			 //@RequestParam final String eligStates,
			 //@RequestParam final String ids,
			 @RequestParam final String userId,
			 @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws SSMException;
	
	
	public ResponseEntity<EligibilityDetails>  getEligibilityBySkus(
			SearchRequest searchRequest )
			//final List<SearchDetails> searchDetails,
			 //@RequestParam final String instantSavingsList,
			// @RequestParam final String skus,
			 //@RequestParam final String ids,
			 //@RequestParam final String userId,
			 //@RequestParam final String lang,  @RequestParam final String country,
			 //@RequestParam final String concept,  @RequestParam final String conceptShortName)
			throws SSMException;
	
	public ResponseEntity<EligibilityDetails>  getEligibilityByGroup()				
			 throws SSMException;
	
	public @ResponseBody ResponseEntity<EligibilityDetails> saveEligibilityByGroup(
			 //final HttpServletRequest request, final HttpServletResponse response,
		     @RequestParam final String instSavingsType, String eligState,
		     @RequestParam final String vendorNos, @RequestParam final String depts, @RequestParam final String subdepts, @RequestParam final String clas,		     		     
			 @RequestParam final String userId, @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws SSMException;
	
	public ResponseEntity<EligibilityDetails>  saveInstantElgiByGroup(final List<EligibilityDetails> eligibilityDetails,
			 @RequestParam final String userId,
			 @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws SSMException;
	
	public ResponseEntity<EligibilityDetails>  getSkusByEventNumber(String eventNumber)	throws SSMException;			
			 
}
