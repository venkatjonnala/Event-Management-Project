package com.bedbath.ssm.service;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
@Scope("singleton")
public class ESClientService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ESClientService.class);
	
	@Value("${esNode1}")
	private String esNode1;
	
	@Value("${esPort}")
	private String esPort;

	private RestHighLevelClient   myclient = null;
	
	public RestHighLevelClient getESClient() throws Exception {
		
		if (myclient == null) {
			LOGGER.info("myclient is null");
			
			myclient = new RestHighLevelClient(RestClient.builder(
		              new HttpHost(esNode1, Integer.parseInt(esPort), "http"))
					);
			 
		}
        return myclient;
	}
}

