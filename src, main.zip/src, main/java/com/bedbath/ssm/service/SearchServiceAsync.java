package com.bedbath.ssm.service;

import java.util.Map;

import com.bedbath.ssm.model.SearchRequest;

public interface SearchServiceAsync {	
	public Map<String, Object> search(SearchRequest searchRequest) throws Exception;		
	public Map<String, Object> esSearch(SearchRequest searchRequest) throws Exception;
	public Map<String, Object> skuSearch(SearchRequest searchRequest) throws Exception;
	
	/*
	public Map<String, Object> searchQLinks(SearchRequest searchRequest) throws Exception;
	public Map<String, Object> searchExceptionSKus(SearchRequest searchRequest) throws Exception;
	public Map<String, Object>  searchForecastQty(SearchRequest searchRequest) throws Exception;	
	
	public void saveESSkusWithBT(SearchRequest searchRequest, final String saveId, final String saveAction) throws Exception;
	public List<SearchDetails> getConflictRecords(List<String> errorSkusStrs, List<SearchDetails> searchDetails) throws SSMException;	
	
	public void clearCache(String searchKey) throws Exception;
	public void clearCache(User user) throws Exception;
	
	public User getUserSearchKeys(String userKey) throws Exception;
	public User refreshSearchKeys(String userKey, List<String> searchKeys) throws Exception;
	*/
	
}
