package com.bedbath.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bedbath.ssm.dao.ElasticSearchDAO;
import com.bedbath.ssm.model.MerchAnalyzer;
import com.bedbath.ssm.model.Sku;
import com.bedbath.ssm.model.Vendor;

@Service
public class SearchFieldServiceImpl implements  SearchFieldService{

	@Autowired
	//@Autowired(required = true)
	private ElasticSearchDAO elasticSearchDAO = null;	
	
	public List<Vendor>  getVendorList(List<Long> vendorNoList, String vendorDesc, String country, String concept, String searchmode) throws Exception{
		return elasticSearchDAO.getVendorList(vendorNoList, vendorDesc, country,false,concept,searchmode);
	}
	
	public List<Sku>  getSku(Integer sku, String skuDesc, String venPartNo, String country, Integer vendorno, String concept, String searchMode) throws Exception{
		if(vendorno != null){
			if(venPartNo != null && !venPartNo.isEmpty()){
				///////return elasticSearchDAO.getVendorPart(venPartNo, country, vendorno,concept, searchMode);
			}else {
				return elasticSearchDAO.getSku(sku, skuDesc, null, country, vendorno,null,concept, searchMode);
			}
		}else{
			if((venPartNo != null && !venPartNo.isEmpty()) || (skuDesc != null && !skuDesc.isEmpty())){
				return elasticSearchDAO.getSku(sku, skuDesc, venPartNo, country, null,null,concept, searchMode);
			}else{
				return null;
			}
		}
		
		return null;
	}
	
	
//	public List<Department>  getDepartment(Integer dept, Integer subDept, Integer deptClass) throws Exception{
//		return elasticSearchDAO.getDepartment(dept, subDept, deptClass);
//	}
	
	public List<MerchAnalyzer>  getMerchAnalyzer(String merchComb,String country,String concept) throws Exception{
		return elasticSearchDAO.getMerchAnalyzer(merchComb,country,concept);
	}
	


}
