package com.bedbath.ssm.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bedbath.ssm.dao.ASMSearchDao;

@Service
public class ASMSearchServiceImpl implements ASMSearchService {

	@Autowired(required = true)
	ASMSearchDao asmSearchDao;

	@Override
	public Map<String, Object> getAppList() throws Exception {
		Map<String, Object> returnMap = null;
		return asmSearchDao.getAppList();
	}
	
	@Override
	public Map<String, Object> getCountryList() throws Exception {
		Map<String, Object> returnMap = null;
		return asmSearchDao.getCountryList();
	}

	@Override
	public Map<String, Object> getConceptList() throws Exception {
		Map<String, Object> returnMap = null;
		return asmSearchDao.getConceptList();
	}

	@Override
	public Map<String, Object> getAppGrid(String appCode, String countryCode, String conceptCodeS, int start, int limit, HashMap<String, String> sortMap) throws Exception {
		Map<String, Object> returnMap = null;
		return asmSearchDao.getAppGrid(appCode, countryCode, conceptCodeS, start, limit, sortMap);
	}

	@Override
	public Map<String, Object> getRoleGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws Exception {
		Map<String, Object> returnMap = null;
		return asmSearchDao.getRoleGrid(appId, start, limit, sortMap);
	}

	@Override
	public Map<String, Object> getPropGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws Exception {
		Map<String, Object> returnMap = null;
		return asmSearchDao.getPropGrid(appId, start, limit, sortMap);
	}
	
	@Override
	public Map<String, Object> getRolePropGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws Exception {
		Map<String, Object> returnMap = null;
		return asmSearchDao.getRolePropGrid(appId, start, limit, sortMap);
	}

}
