package com.bedbath.ssm.service;

import java.util.HashMap;
import java.util.Map;


public interface ASMSearchService {
	public Map<String, Object> getAppList() throws Exception;
	
	public Map<String, Object> getCountryList() throws Exception;

	public Map<String, Object> getConceptList() throws Exception;
	
	public Map<String, Object> getAppGrid(String appCode, String countryCode, String conceptCodeS, int start, int limit, HashMap<String, String> sortMap) throws Exception;

	public Map<String, Object> getRoleGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws Exception;

	public Map<String, Object> getPropGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws Exception;

	public Map<String, Object> getRolePropGrid(long appId, int start, int limit, HashMap<String, String> sortMap) throws Exception;
}
