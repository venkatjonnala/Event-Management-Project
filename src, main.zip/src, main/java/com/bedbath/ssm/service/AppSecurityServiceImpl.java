package com.bedbath.ssm.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bedbath.ssm.dao.AppSecurityDao;


@Service
public class AppSecurityServiceImpl implements AppSecurityService{
	
	@Autowired(required = true)
	private AppSecurityDao appSecurityDao;
	
	@Override
	public Map<String, Object> getUserPrivileges(String appCode, String country, String concept, String userId) throws Exception {
		Map<String, Object> returnCode = appSecurityDao.getUserPrivileges(appCode, country, concept, userId);
		return returnCode;
	}
		
}
