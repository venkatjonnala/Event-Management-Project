package com.bedbath.ssm.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bedbath.common.datasource.DataSourceContextHolder;
import com.bedbath.ssm.dao.ElasticSearchDAO;
import com.bedbath.ssm.dao.SearchDAO;
import com.bedbath.ssm.model.SearchDetails;
import com.bedbath.ssm.model.SearchRequest;
import com.bedbath.ssm.model.Sku;
import com.bedbath.ssm.model.Upc;

import com.bedbath.ssm.exception.SSMException;

import com.bedbath.ssm.common.util.AppConstants;
import com.bedbath.ssm.common.util.ApplicationUtil;


@Service
public class SearchServiceAsyncImpl implements SearchServiceAsync {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SearchServiceImpl.class);

	@Autowired
	private ElasticSearchDAO elasticSearchDAO = null;	
	@Autowired
	private SearchDAO searchDAO = null;	
	//@Autowired
    //private CacheManager cacheManager;
	
	@Async
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public  Map<String, Object> skuSearch(SearchRequest searchRequest) throws Exception{		
		Map<String, Object> resultsMap = new HashMap<String, Object>();
		List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();
		List<Upc> upcList = null;
		List<Long> skuList = new ArrayList<Long>();
		//set datasource
		DataSourceContextHolder.setDataSource(searchRequest.getCountry()+"_"+ searchRequest.getConcept());
		//Upc
		if (searchRequest != null && searchRequest.getUpcs() != null && searchRequest.getUpcs().size() > 0){
			upcList =  elasticSearchDAO.getUpc(searchRequest.getUpcs(), null,searchRequest.getConceptShortName()) ;
			//Setting sku#s list to search request
			if (upcList != null){
				for(Upc upc : upcList){
					skuList.add(Long.parseLong(upc.getInumbr()));
				}
				searchRequest.setSkus(skuList);
			}
		}
		
		//Sku description
		if (searchRequest != null && searchRequest.getSkuDescription() != null && !searchRequest.getSkuDescription().isEmpty()){
			List<Sku> skuDescList =  elasticSearchDAO.getSku(null, null, null, searchRequest.getCountry(), null, searchRequest.getSkuDescription(),searchRequest.getConcept(), searchRequest.getSkuMode());
			for(Sku sku : skuDescList){
				skuList.add(Long.parseLong(sku.getSku()));
			}
			searchRequest.setSkus(skuList);
		}
		
		
		if (searchRequest.getSkus() == null || searchRequest.getSkus().isEmpty() ) {
			return resultsMap;
		} else {
			LOGGER.debug("Searching QLinks for Sku Search...");
			///resultsMap = searchDAO.searchQLinks(searchRequest);
//			searchDetailsList  = elasticSearchDAO.search(searchRequest);
//			resultsMap.put("data", searchDetailsList);
//			resultsMap.put("total", searchDetailsList.size());
		}
		
		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
		Integer totalCount = (Integer)resultsMap.get("total"); 
				
		if (searchDetailsList != null && totalCount > searchRequest.getMaxCount()){
			resultsMap.clear(); 
			SSMException ex = new SSMException();
			ex.setErrorMessage("EXCEEDS_MAX"+"-"+totalCount);
			throw ex;
		}else if (searchRequest.getVendorPartNo() != null && searchDetailsList != null && searchDetailsList.size() > 0){
			List<SearchDetails> searchDetailsCopy = new ArrayList<SearchDetails>(searchDetailsList);
			for (SearchDetails searchDetails: searchDetailsList){
				if(searchDetails.getVendorNo() != Integer.parseInt(""+searchRequest.getVendorNos().get(0))){
					searchDetailsCopy.remove(searchDetails);
				}
			}
			resultsMap.put("data", searchDetailsCopy);
		}

		return resultsMap;

	}	
	
	@Async
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public  Map<String, Object>  search(SearchRequest searchRequest) throws Exception{
		System.out.println("SearchSearviceSync search() 3 - 2  ######################");
		
		Map<String, Object> resultsMap = new HashMap<String, Object>();
		List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();
		
		DataSourceContextHolder.setDataSource(searchRequest.getCountry()+"_"+ searchRequest.getConcept());

		resultsMap = searchDAO.search(searchRequest);

		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
		Integer totalCount = (Integer)resultsMap.get("total"); 
				
		if (searchDetailsList != null && totalCount > searchRequest.getMaxCount()){
			resultsMap.clear(); 
			SSMException ex = new SSMException();
			ex.setErrorMessage("EXCEEDS_MAX"+ "-"+ totalCount);
			throw ex;
		}
		
		return resultsMap;
	}
	
	@Override
	@Async
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public Map<String, Object> esSearch(SearchRequest searchRequest)
			throws Exception {

		System.out.println("SearchSearviceSync esSearch() 3 - 1  ######################");
		
		Map<String, Object> resultsMap = new HashMap<String, Object>();
		List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();
		
		DataSourceContextHolder.setDataSource(searchRequest.getCountry()+"_"+ searchRequest.getConcept());
		resultsMap = elasticSearchDAO.getESSkus(searchRequest);

		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
		Long totalCount = (Long)resultsMap.get("total"); 
				
		if (searchDetailsList != null && totalCount > searchRequest.getMaxCount()){
			resultsMap.clear(); 
			SSMException ex = new SSMException();
			ex.setErrorMessage("EXCEEDS_MAX"+ "-"+ totalCount);
			throw ex;
		}
		
		return resultsMap;

	}
	
	
	
	/*
	@Async
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public  Map<String, Object>  searchExceptionSKus(SearchRequest searchRequest) throws Exception{
		Map<String, Object> resultsMap = new HashMap<String, Object>();
		List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();		
		if(searchRequest.getSearchType().equalsIgnoreCase("exceptionSKUs")) {
			LOGGER.debug("searchRequest.getConcept()::"+searchRequest.getConcept());
			
			String searchId = "ES:EXP:" + searchRequest.getUserId() + ":" + 
					searchRequest.getStart() + ":"+
					searchRequest.getIpAddress() + ":"+ 
					SOUtil.formatDateUtc(new Date()) + ":" + System.nanoTime();					
			searchRequest.setStoreSku(searchId);
			elasticSearchDAO.searchExceptionSKus(searchRequest);
			resultsMap = searchDAO.searchQLinks(searchRequest);
		}
		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
				
		Integer totalCount = (Integer)resultsMap.get("total"); 
				
		if (searchDetailsList != null && totalCount > searchRequest.getMaxCount())
		{
			resultsMap.clear(); 
			SOException ex = new SOException();
			ex.setErrorMessage("EXCEEDS_MAX"+ "-"+ totalCount);
			throw ex;
		}
		
		return resultsMap;
	}
	@Async
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public  Map<String, Object>  searchQLinks(SearchRequest searchRequest) throws Exception{
		
		DataSourceContextHolder.setDataSource(searchRequest.getCountry()+"_"+ searchRequest.getConcept());
		if (searchRequest.isElasticSearch() && 
				! "SWS".equals(searchRequest.getTop100FltType()) &&
				searchRequest.getSearchType() != null && 
				searchRequest.getSearchType().indexOf("top100")  != -1) {
				
				LOGGER.debug("Invoking ES for Top 100 filter: "+searchRequest.getTop100FltType());
				return elasticSearchDAO.getESTop100(searchRequest);
			
		}
		
		Map<String, Object> resultsMap = new HashMap<String, Object>();;
		 List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();
		resultsMap = searchDAO.searchQLinks(searchRequest);
		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
		
		Integer totalCount = (Integer)resultsMap.get("total"); 

		if(searchRequest.getSearchType() != null && 
				!searchRequest.getSearchType().equalsIgnoreCase("sotypes"))
		{
			if (searchDetailsList != null && totalCount > searchRequest.getMaxCount())
			{
				resultsMap.clear(); 
				SOException ex = new SOException();
				ex.setErrorMessage("EXCEEDS_MAX"+ "-"+ totalCount);
				throw ex;
			}
		}
		
		
		String whrReturnCode = (String)resultsMap.get("@whrReturnCode"); 
		if(whrReturnCode!= null && whrReturnCode.equalsIgnoreCase("*WRN001")){
			SOException ex = new SOException();
			ex.setErrorMessage("WAREHOUSE_RESTRICTED_ERROR");		
			throw ex;			
		}
		return resultsMap;
	}	
	@Async
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public  Map<String, Object>  searchForecastQty(SearchRequest searchRequest) throws Exception {
		//set datasource
		DataSourceContextHolder.setDataSource(searchRequest.getCountry()+"_"+ searchRequest.getConcept());

		Map<String, Object> resultsMap = new HashMap<String, Object>();
		List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();

		resultsMap = searchDAO.searchQLinks(searchRequest);
		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
		Integer totalCount = (Integer)resultsMap.get("total"); 
				
		if (searchDetailsList != null && totalCount > 1200){
			resultsMap.clear(); 
			SOException ex = new SOException();
			ex.setErrorMessage("EXCEEDS_MAX"+ "-"+ totalCount);
			throw ex;
		}
		
		return resultsMap;
	}
	
	public void saveESSkusWithBT(SearchRequest searchRequest, final String saveId, final String saveAction) throws Exception {
		//set datasource
		DataSourceContextHolder.setDataSource(searchRequest.getCountry()+"_"+ searchRequest.getConcept());
		elasticSearchDAO.saveESSkusWithBT(searchRequest, saveId, saveAction);
	}
	
	//Since skusearch will search sku/stores for all the Skus we may have non-conflict records also
	//so we need to get just conflict records only from the list.
	//
	public List<SearchDetails> getConflictRecords(List<String> errorSkusStrs, List<SearchDetails> searchDetailsList) throws SOException
	{
		List<SearchDetails> conflictSerachDetails = new ArrayList<SearchDetails>();
		SearchDetails searchDetail = null;
		String errorSkuStr = "";
		for(int i=0; i<errorSkusStrs.size(); i++){
			errorSkuStr = (String)errorSkusStrs.get(i);
			for(int j=0; j<searchDetailsList.size(); j++){
				searchDetail = searchDetailsList.get(j);
				if(errorSkuStr.equalsIgnoreCase(searchDetail.getSku()+"-"+searchDetail.getStoreNo())){
					conflictSerachDetails.add(searchDetail);
					break;
				}
			}
		}		
		return conflictSerachDetails;
	}	
	@Cacheable(value="searchKeys", key="#userKey")
	public User getUserSearchKeys(String userKey) throws Exception{
		User user = null;
		Cache cache = cacheManager.getCache("searchKeys");
		Element element = cache.get(userKey);
		if(element!=null){
			user = (User)element.getObjectValue();
		}		
		return user;		
	}
	@Async
	@CachePut(value="searchKeys", key="#userKey")	
	public User refreshSearchKeys(String userKey,  List<String> newSearchKeys){
		Cache cache = cacheManager.getCache("searchKeys");
		Element element = cache.get(userKey);
		User user = null;
		List<String> searchKeys = null;		
		if(element != null && element.getObjectValue()!=null){
			user = (User)element.getObjectValue();
			searchKeys = user.getSearchKeys();
			if(newSearchKeys!=null){
			    for (String newSearchKey : newSearchKeys) {
			    	if(!searchKeys.contains(newSearchKey)){
			    		searchKeys.add(newSearchKey);
			    	}			    	
		        }				
			}
		}
		else{
			user = new User();	
			user.setUserKey(userKey);
			if(newSearchKeys!=null){
				searchKeys = newSearchKeys;				
			}
		}
		user.setSearchKeys(searchKeys);		
		return user;
	}
	@CacheEvict(value="searchResults", key="#searchKey")
	public void clearCache(String searchKey){
		//Removes searchKey cache
		LOGGER.debug("Removes all the cache for the serachKey::" + searchKey);
	}	
	
	@CacheEvict(value="searchKeys", key="#user.userKey")	
	public void clearCache(User user){
		//Removes searchKey cache
		LOGGER.debug("Removes all the cache for the user::" + user.getUserKey());
	}	
	*/
}