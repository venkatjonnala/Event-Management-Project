package com.bedbath.ssm.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.bedbath.ssm.common.util.ApplicationUtil;
import com.bedbath.ssm.common.util.ResponseEntity;
import com.bedbath.ssm.dao.ElasticSearchDAO;
import com.bedbath.ssm.dao.SearchDAO;
import com.bedbath.ssm.exception.CommonDataAccessException;
import com.bedbath.ssm.exception.SSMException;
import com.bedbath.ssm.model.EligibilityDetails;
import com.bedbath.ssm.model.SearchDetails;
import com.bedbath.ssm.model.SearchRequest;
import com.bedbath.ssm.model.Sku;
import com.bedbath.ssm.model.Upc;






/*
import com.bedbath.so.dao.ElasticSearchDAO;
import com.bedbath.so.dao.SearchDAO;
import com.bedbath.so.domain.SearchDetails;
import com.bedbath.so.domain.SearchRequest;
import com.bedbath.so.domain.Sku;
import com.bedbath.so.domain.Upc;
import com.bedbath.so.domain.Vendor;
import com.bedbath.so.exception.SSMException;
import com.bedbath.so.util.ApplicationUtil;
*/
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Service
public class SearchServiceImpl implements SearchService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SearchServiceImpl.class);

	@Autowired
	private ElasticSearchDAO elasticSearchDAO = null;	
	@Autowired
	private SearchDAO searchDAO = null;	
	//@Autowired
    //private CacheManager cacheManager;
	
	private static final Logger logger = LoggerFactory.getLogger(SearchServiceImpl.class);
	
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public  Map<String, Object>  skuSearch(SearchRequest searchRequest) throws Exception{

		//System.out.println("SearchServiceImpl skuSearch() 5 - 1  ######################");
		Map<String, Object> resultsMap = new HashMap<String, Object>();
		List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();
		List<Upc> upcList = null;
		List<Long> skuList = new ArrayList<Long>();

		//Upc
		if (searchRequest != null && searchRequest.getUpcs() != null && searchRequest.getUpcs().size() > 0){
			upcList =  elasticSearchDAO.getUpc(searchRequest.getUpcs(), null,searchRequest.getConceptShortName()) ;
			//Setting sku#s list to search request
			if (upcList != null){
				for(Upc upc : upcList){
					skuList.add(Long.parseLong(upc.getInumbr()));
				}
				searchRequest.setSkus(skuList);
			}
		}
		
		//Sku description
		if (searchRequest != null && searchRequest.getSkuDescription() != null && !searchRequest.getSkuDescription().isEmpty()){
			List<Sku> skuDescList =  elasticSearchDAO.getSku(null, null, null, searchRequest.getCountry(), null, searchRequest.getSkuDescription(),searchRequest.getConcept(), searchRequest.getSkuMode());
			for(Sku sku : skuDescList){
				skuList.add(Long.parseLong(sku.getSku()));
			}
			searchRequest.setSkus(skuList);
		}
		
		
		if (searchRequest.getSkus() == null || searchRequest.getSkus().isEmpty() ) {
			return resultsMap;
		} else {
			LOGGER.debug("Searching QLinks for Sku Search...");
			///resultsMap = searchDAO.searchQLinks(searchRequest);
			
//			searchDetailsList  = elasticSearchDAO.search(searchRequest);
//			resultsMap.put("data", searchDetailsList);
//			resultsMap.put("total", searchDetailsList.size());
		}
		
		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
		Integer totalCount = (Integer)resultsMap.get("total"); 
				
		if (searchDetailsList != null && totalCount > searchRequest.getMaxCount()){
			resultsMap.clear(); 
			SSMException ex = new SSMException();			
			ex.setErrorMessage("EXCEEDS_MAX"+"-"+totalCount);
			throw ex;
		}else if (searchRequest.getVendorPartNo() != null && searchDetailsList != null && searchDetailsList.size() > 0){
			List<SearchDetails> searchDetailsCopy = new ArrayList<SearchDetails>(searchDetailsList);
			for (SearchDetails searchDetails: searchDetailsList){
				if(searchDetails.getVendorNo() != Integer.parseInt(""+searchRequest.getVendorNos().get(0))){
					searchDetailsCopy.remove(searchDetails);
				}
			}
			resultsMap.put("data", searchDetailsCopy);
		}

		return resultsMap;

	}	
	
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public  Map<String, Object> search(SearchRequest searchRequest) throws Exception{

		System.out.println("SearchServiceImpl search() 5 - 2  ######################");
		Map<String, Object> resultsMap = new HashMap<String, Object>();
		List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();
		
		resultsMap = searchDAO.search(searchRequest);

		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
		Integer totalCount = (Integer)resultsMap.get("total"); 
				
		if (searchDetailsList != null && totalCount > searchRequest.getMaxCount()){
			resultsMap.clear(); 
			SSMException ex = new SSMException();			
			ex.setErrorMessage("EXCEEDS_MAX"+ "-"+ totalCount);
			throw ex;
		}
		
		return resultsMap;
	}
	
	@Override
	@Cacheable(value="searchResults", key="#searchRequest.searchKey", unless="#result.size() <= 0")
	public Map<String, Object> esSearch(SearchRequest searchRequest)
			throws Exception {
		
		System.out.println("SearchServiceImpl esSearch() 5 - 3  ######################");
		Map<String, Object> resultsMap = new HashMap<String, Object>();
		List<SearchDetails> searchDetailsList = new ArrayList<SearchDetails>();
		
		resultsMap = elasticSearchDAO.getESSkus(searchRequest);
		
		searchDetailsList = (List<SearchDetails>)resultsMap.get("data");
		Long totalCount = (Long)resultsMap.get("total"); 
		System.out.println("SearchServiceImpl esSearch() 5 - 3 - 1  ###################### totalCount = "+totalCount +" searchRequest.getMaxCount() = "+searchRequest.getMaxCount());
		System.out.println("SearchServiceImpl esSearch() 5 - 3 - 1 - 1  ###################### searchRequest.getSearchType() = "+searchRequest.getSearchType());
		
		
		/*
		if("sku".equalsIgnoreCase(searchRequest.getSearchType()) &&
				searchRequest.getStart()==0)
		{					
			if(ApplicationUtil.listToString(searchRequest.getStatuses()).equalsIgnoreCase("'A','I'") ||
					ApplicationUtil.listToString(searchRequest.getStatuses()).equalsIgnoreCase("'I','A'"))					
			{
				System.out.println("SearchServiceImpl esSearch() 5 - 3 - 2  ######################");
				SearchRequest searchRequestNDCheck = new SearchRequest();
				BeanUtils.copyProperties(searchRequest, searchRequestNDCheck);
				
				searchRequestNDCheck.setStatuses(Arrays.asList("A", "I", "N", "D"));
				Map<String, Object> resultsMapND  = elasticSearchDAO.getESSkus(searchRequestNDCheck);
				System.out.println("SearchServiceImpl esSearch() 5 - 3 - 3  ###################### = "+resultsMapND.get("total"));
				
				Long totalCountND = (Long)resultsMapND.get("total");
				if(totalCountND > totalCount){
					resultsMap.put("ndSkus", true);
				}
				else{
					resultsMap.put("ndSkus", false);
				}
			}			
		}*/
		
		if (searchDetailsList != null && totalCount > searchRequest.getMaxCount()){
			resultsMap.clear(); 
			SSMException ex = new SSMException();			
			ex.setErrorMessage("EXCEEDS_MAX"+ "-"+ totalCount);
			throw ex;
		}		
		return resultsMap;
	}
	
	public ResponseEntity<SearchDetails>  saveEligibility(final List<SearchDetails> searchDetails,
			 //@RequestParam final String instantSavingsList,
			 //@RequestParam final String eligStates,
			 //@RequestParam final String ids,
			 @RequestParam final String userId,
			 @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws SSMException {
		
		try {
		    //ResponseEntity<Scheduleb> schedulebGridResultList = schedulebDao.saveSchedulebChanges(schedulebList);
		    //return schedulebGridResultList;
			//final ResponseEntity<SearchDetails> searchDetailsResponse = searchDAO.saveEligibility(searchDetails, eligStates, ids, userId,
			final ResponseEntity<SearchDetails> searchDetailsResponse = searchDAO.saveEligibility(searchDetails, userId,
					lang, country, concept, conceptShortName );
			
			return searchDetailsResponse;
			
		} catch (CommonDataAccessException e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "	+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while Saveing Instant Savings Skus: "	+ "---" + e.getMessage());
			e.printStackTrace();
			//throw new SSMException("Issue  while Saveing Instant Savings Skus.", e);
			throw new SSMException("Issue  while Saveing Instant Savings Skus..", e);
		} catch (Exception e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error While Saveing Instant Savings Skus : " + "---" + e.getMessage());
			e.printStackTrace();
			//throw new SSMException("Issue while Saveing Instant Savings Skus.", e);
			throw new SSMException("Issue while Saveing Instant Savings Skus.", e);
		}	
		
	}
	
	public ResponseEntity<EligibilityDetails> getEligibilityBySkus(
			SearchRequest searchRequest
			//final List<SearchDetails> searchDetails,
			 //@RequestParam final String instantSavingsList,
			 //@RequestParam final String skus,
			 //@RequestParam final String ids,
			 //@RequestParam final String userId,
			 //@RequestParam final String lang,  @RequestParam final String country,
			 //@RequestParam final String concept,  @RequestParam final String conceptShortName
			 ) throws SSMException {
		
		try {
			final ResponseEntity<EligibilityDetails> eligibilityDetailsResponse = searchDAO.getEligibilityBySkus(searchRequest );			
			return eligibilityDetailsResponse;
			
		} catch (CommonDataAccessException e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "	+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while finding all getEligibilityBySkus info : "	+ "---" + e.getMessage());
			//e.printStackTrace();
			throw new SSMException("Issue while finding all getEligibilityBySkus info.", e);
		} catch (Exception e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while finding all getEligibilityBySkus info : " + "---" + e.getMessage());
			//e.printStackTrace();
			throw new SSMException("Issue while finding all getEligibilityBySkus info.", e);
		}	
	}
	
	public ResponseEntity<EligibilityDetails>  getEligibilityByGroup()				
			 throws SSMException {
		
		try {		   
			 final ResponseEntity<EligibilityDetails> eligibilityDetailsResponse = searchDAO.getEligibilityByGroup();	
			 
			 return eligibilityDetailsResponse;
			
		} catch (CommonDataAccessException e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "	+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while finding all getEligibilityByGroup info : "	+ "---" + e.getMessage());
			//e.printStackTrace();
			throw new SSMException("Issue while finding all getEligibilityByGroup info.", e);
		} catch (Exception e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while finding all getEligibilityByGroup info : " + "---" + e.getMessage());
			//e.printStackTrace();
			throw new SSMException("Issue while finding all getEligibilityByGroup info.", e);
		}
	}
	
	public @ResponseBody ResponseEntity<EligibilityDetails> saveEligibilityByGroup(
			 //final HttpServletRequest request, final HttpServletResponse response,
		     @RequestParam final String instSavingsType, String eligState,
		     @RequestParam final String vendorNos, @RequestParam final String depts, @RequestParam final String subdepts, @RequestParam final String clas,		     		     
			 @RequestParam final String userId, @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws SSMException {
		
		try {		   
			final ResponseEntity<EligibilityDetails> eligibilityDetailsResponse = searchDAO.saveEligibilityByGroup(
					                //request, response,
					                instSavingsType, eligState, vendorNos,depts,subdepts,
					                clas, userId, lang, country, concept, conceptShortName  );			
			return eligibilityDetailsResponse;
			
		} catch (CommonDataAccessException e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "	+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while SaveEligibilityByGroup info : "	+ "---" + e.getMessage());
			//e.printStackTrace();
			throw new SSMException("Issue while SaveEligibilityByGroup info.", e);
		} catch (Exception e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while SaveEligibilityByGroup info : " + "---" + e.getMessage());
			//e.printStackTrace();
			throw new SSMException("Issue while SaveEligibilityByGroup info.", e);
		}
		
	}
	
	public ResponseEntity<EligibilityDetails>  saveInstantElgiByGroup(final List<EligibilityDetails> eligibilityDetails,
			 @RequestParam final String userId,
			 @RequestParam final String lang,  @RequestParam final String country,
			 @RequestParam final String concept,  @RequestParam final String conceptShortName) throws SSMException {
		
		try {
		    //ResponseEntity<Scheduleb> schedulebGridResultList = schedulebDao.saveSchedulebChanges(schedulebList);
		    //return schedulebGridResultList;
			//final ResponseEntity<SearchDetails> searchDetailsResponse = searchDAO.saveEligibility(searchDetails, eligStates, ids, userId,
			final ResponseEntity<EligibilityDetails> eligibilityDetailsResponse = searchDAO.saveInstantElgiByGroup(eligibilityDetails, userId,
					                                                                                lang, country, concept, conceptShortName );
			
			return eligibilityDetailsResponse;
			
		} catch (CommonDataAccessException e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "	+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error whileSaveEligibilityByGroup: "	+ "---" + e.getMessage());
			e.printStackTrace();
			//throw new SSMException("Issue  while Saveing Instant Savings Skus.", e);
			throw new SSMException("Issue  while SaveEligibilityByGroup..", e);
		} catch (Exception e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while SaveEligibilityByGroup: " + "---" + e.getMessage());
			e.printStackTrace();
			//throw new SSMException("Issue while Saveing Instant Savings Skus.", e);
			throw new SSMException("Issue while SaveEligibilityByGroup.", e);
		}	
	}
	
	public ResponseEntity<EligibilityDetails>  getSkusByEventNumber(String eventNumber)				
			 throws SSMException {
		
		try {		   
			 //final ResponseEntity<EligibilityDetails> eligibilityDetailsResponse = searchDAO.getEligibilityByGroup();
			 
			 final ResponseEntity<EligibilityDetails> skusByEventNumberResponse = searchDAO.getSkusByEventNumber(eventNumber);			
			 
			  return skusByEventNumberResponse;
			
		} catch (CommonDataAccessException e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "	+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while finding all getSkusByEventNumber info : "	+ "---" + e.getMessage());
			//e.printStackTrace();
			throw new SSMException("Issue while finding all getSkusByEventNumber info.", e);
		} catch (Exception e) {
			//LOGGER.error("[ASAccountServiceImpl] Error while updating accounts : "+ aSAccountList + "---" + e.getMessage());
			logger.error("[SearchServiceImpl] Error while finding all getSkusByEventNumber info : " + "---" + e.getMessage());
			//e.printStackTrace();
			throw new SSMException("Issue while finding all getSkusByEventNumber info.", e);
		}
	}
	
}