Ext.define('SSM.store.combo.SKUStatus', {
    extend: 'Ext.data.SimpleStore',
    alias: 'store.skustatus',
    storeId: 'skustatus',
    fields:['id', 'value'],
    data:[        
        ['A', 'A'],
        ['I', 'I'],
        ['N', 'N'],
        ['D', 'D']]});

