Ext.define('SSM.store.InstantSavingsSkuStore', {
    extend: 'Ext.data.Store',
    alias: 'store.instantsavingsskustore',
    storeId: 'instantsavingsskustore',
    model: 'SSM.model.InstantSavingsSkuModel',
    autoLoad:false,    
    requires: ['SSM.model.InstantSavingsSkuModel'],
    
    //_store1Loaded : true,
    
    simpleSortMode: true,
    //remoteSort: true,
    //remoteGroup: true,
    //groupField: 'sku',
    sortOnLoad : false,
    pageSize : params.pageSize,
    //buffered: true,
   

	proxy: {
 		type: 'ajax',
 		//waitMsg:'sn_i18n.message.Loading',
 		//url: skuServiceUrl + 'weeklysales', 
 		
 		//@RequestMapping(value = "/search.htm")
 		url: 'search.htm?action=search',
 		
 		extraParams : {
			outputType : 'JSON'
		},
 		reader: {
 		    type: 'json',
 		    rootProperty: 'data'
 		}
     },
     listeners: {
          'load' :  function(store,records,options) {
                  //alert("Store listeners $$$ records = "+records +" records.length = "+records.length);
                  //alert("Store listeners $$$ records.length = "+records.length);
                  /////alert("ForumThreadStore # listeners load selected = "+selected);
                  //store.loaded = true; 
        	      /*
        	      this._saveDeleteFlag = false;
        	      console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Store listeners $$$ this._saveDeleteFlag = "+this._saveDeleteFlag);  
        	      console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Store listeners $$$ params.concept = "+params.concept);
        	      console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Store listeners $$$ params.shipdate = "+params.shipdate);
        	      console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Store listeners $$$ params.instantSavingSaveDelFlg = "+params.instantSavingSaveDelFlg);
        	      //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Store listeners $$$ globalvar.instantSavingSaveDelFlg = "+globalvar.instantSavingSaveDelFlg);
        	      
        	      params.instantSavingSaveDelFlg = false
        	      params.globalvar = false;
        	      params.shipdate = 'no';
        	      */
        	    
        	      
        	      //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Store listeners $$$ SSM.app.gloabals.testGlobal = "+SSM.app.gloabals.testGlobal);
        	      
        	      //SSM.app.gloabals.testGlobal = 100;
        	      
        	      //this._store1Loaded = true
        	      //console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Store listeners $$$ this._store1Loaded = "+this._store1Loaded);

                  var grid = Ext.ComponentQuery.query('#instantSavingsSkuGrid')[0];
                  console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Store listeners $$$  grid = "+grid);

                  var rowsToSelect = [1,2];
                  Ext.each(records, function(rec, index){
                        //console.log("$$$$$$$$$$$$$$$$ Store listeners $$$ LOOP sku = "+rec.data.sku +" item.data = "+rec.data.instsaveElg +" index = "+index);
                        if(rec.data.instsaveElg == 'selected' || rec.data.instsaveElg== 'selected'){
                            //alert("Store listeners $$$ LOOP rec = "+rec +" item.data = "+rec.data.forumid +" index = "+index);
                            //grid.getSelectionModel().select(index);
                            grid.getSelectionModel().select(index,true,false);
                        }

                       // rowsToSelect.push(this.store.indexOfId(item));
                  },this);
                  
           },
           'afterload' : function(store,records,options) {
               alert("ForumThreadStore ############### listeners afterload selected = "+selected);
               
               this._saveDeleteFlag = false;
     	       console.log("$$$$$$$$$$$$$11111 AFTER Store listeners $$$ this._saveDeleteFlag= "+this._saveDeleteFlag);
           }
        }
});
