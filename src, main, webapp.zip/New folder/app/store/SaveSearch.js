Ext.define('SSM.store.SaveSearch', {
    extend: 'Ext.data.Store',
    alias: 'store.savesearch',
    storeId: 'savesearch',
    model: 'SSM.model.SaveSearch',
    autoLoad:false,    
    requires: ['SSM.model.SaveSearch'],

	proxy: {
 		type: 'ajax',
 		//waitMsg:'sn_i18n.message.Loading',
 		//url: skuServiceUrl + 'weeklysales', 
 		//url: 'searchfield.htm?action=getVendor',
 		url: 'savedSearches.htm',
 		
 		extraParams : {
			outputType : 'JSON'
		},
 		reader: {
 		    type: 'json',
 		    rootProperty: 'data'
 		}
     } 
});