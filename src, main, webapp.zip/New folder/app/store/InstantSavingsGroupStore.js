///InstantSavingsGroupStore.js
Ext.define('SSM.store.InstantSavingsGroupStore', {
    extend: 'Ext.data.Store',
    alias: 'store.instantsavingsgroupstore',
    storeId: 'instantsavingsgroupstore',
    model: 'SSM.model.InstantSavingsGroupModel',
    autoLoad:false,    
    requires: ['SSM.model.InstantSavingsGroupModel'],
 
    
    simpleSortMode: true,
    //remoteSort: true,
    //remoteGroup: true,
    //groupField: 'sku',
    sortOnLoad : false,
    pageSize : params.pageSize,
    //buffered: true,
	proxy: {
 		type: 'ajax',
 		//waitMsg:'sn_i18n.message.Loading',
 		//url: skuServiceUrl + 'weeklysales', 
 		
 		//@RequestMapping(value = "/search.htm")
 		url: 'search.htm?action=instantsavingsgroupsearch',
 		
 		extraParams : {
			outputType : 'JSON'
		},
 		reader: {
 		    type: 'json',
 		    //rootProperty: 'data'
 		    rootProperty: 'rows'
 		}
     },
     listeners: {
          'load' :  function(store,records,options) {
             
                  
                  
           }
        }
});