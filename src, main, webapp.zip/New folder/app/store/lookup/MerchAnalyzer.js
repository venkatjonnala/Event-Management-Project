Ext.define('SSM.store.lookup.MerchAnalyzer', {
    extend: 'Ext.data.Store', 
    alias: 'store.lookupmerchanalyzer',
    storeId: 'lookupmerchanalyzer', 
    requires: 'SSM.model.lookup.MerchAnalyzer',
    model: 'SSM.model.lookup.MerchAnalyzer',  
    autoLoad:false, 
    
	proxy: {
 		type: 'ajax',
 		waitMsg:'i18n.message.Loading',
 		//url: 'searchfield.htm?action=getEventNumber',
 		//url: base_lookup_url + 'lookup_merchandiseanalyzer/_search',
 		url: params.base_lookup_url + 'lookup_merchandiseanalyzer/_search',
 		//headers: { 'Content-Type': 'application/json' },     
    	//noCache:false,	//for local dev
 		
 		timeout: 60000, //2 minutes
 		actionMethods : {
 		   	 read : 'POST',
 		   	 create: 'POST',
 		   	 destroy: 'POST',
 		   	 update: 'POST'
 		}, 		
 		//extraParams : {
		//	outputType : 'JSON'
		//},		
		reader: {
			type: 'json',
		    rootProperty: 'hits.hits',
		    totalProperty: 'hits.total'
		},
 		
 		listeners:{
 			beforeload: function(store, operation,eOpts) {
 			delete operation.limit;
 			delete operation.page;
 			delete operation.start;
 			delete operation.filters;
 			delete operation.params;
 			}
 		}
    } 
});