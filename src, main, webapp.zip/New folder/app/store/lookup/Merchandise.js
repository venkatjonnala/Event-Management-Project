Ext.define('SSM.store.lookup.Merchandise', {
    extend: 'Ext.data.Store',
    alias: 'store.lookupmerchandise',
    storeId: 'lookupmerchandise',    
    model: 'SSM.model.lookup.Merchandise',
    autoLoad:false,
    requires: ['SSM.model.lookup.Merchandise'],

	proxy: {
 		type: 'ajax',
 		waitMsg:'i18n.message.Loading',
 		url: 'searchfield.htm?action=getMerchandise',
 		extraParams : {
 			country: params.country,
 			concept: params.concept,
			outputType : 'JSON'
		},
 		reader: {
 		    type: 'json',
 		    rootProperty: 'data'
 		}
     } 
});
