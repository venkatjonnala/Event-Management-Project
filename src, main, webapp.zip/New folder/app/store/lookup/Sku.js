Ext.define('SSM.store.lookup.Sku', {
    extend: 'Ext.data.Store',
    alias: 'store.lookupsku',
    storeId: 'lookupsku',
    
    model: 'SSM.model.lookup.Sku',
    autoLoad:false,    
    requires: ['SSM.model.lookup.Sku'],

	proxy: {
 		type: 'ajax',
 		waitMsg:'i18n.message.Loading',
 		url: 'searchfield.htm?action=getSku',
 		
 		extraParams : {
			outputType : 'JSON'
		},
 		reader: {
 		    type: 'json',
 		    rootProperty: 'data'
 		}
     } 
});


/*
Ext.define('SSM.store.lookup.Sku', {
    extend: 'Ext.data.Store',
    requires: 'SSM.model.lookup.Sku',
    model: 'SSM.model.lookup.Sku'
});
*/