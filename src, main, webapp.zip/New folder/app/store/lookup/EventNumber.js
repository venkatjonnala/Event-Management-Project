Ext.define('SSM.store.lookup.EventNumber', {
    extend: 'Ext.data.Store',
    alias: 'store.lookupeventnumber',
    storeId: 'lookupeventnumber',     
    requires: 'SSM.model.lookup.EventNumber',
    model: 'SSM.model.lookup.EventNumber',  
    autoLoad:false,
	listeners:{
		beforeload: function(store, operation,eOpts) {
		delete operation._limit;
		delete operation._page;
		delete operation._start;
		delete operation._filters;
		delete operation._params;
		}
	}
    /*,     
	proxy: {
 		type: 'ajax',
 		waitMsg:'i18n.message.Loading',
 		url: params.base_lookup_url + 'lookup_event/_search',
 		headers: { 'Content-Type': 'application/json' },     
 		noCache: false,
 		timeout: 60000, //2 minutes
 		actionMethods : {
 		   	 read : 'POST',
 		   	 create: 'POST',
 		   	 destroy: 'POST',
 		   	 update: 'POST'
 		},
		reader: {
			type: 'json',
		    rootProperty: 'hits.hits',
		    totalProperty: 'hits.total'
		},
 		
 		listeners:{
            beforeload: function(store, operation,eOpts) {
 				delete operation.limit;
 				delete operation.page;
 				delete operation.start;
 				delete operation.filters;
 				delete operation.params;
 			}
 		}
    } */
});
