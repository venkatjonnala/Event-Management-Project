Ext.define('SSM.store.lookup.Vendor', {
    extend: 'Ext.data.Store', 
    alias: 'store.lookupvendor',
    storeId: 'lookupvendor', 
    requires: 'SSM.model.lookup.Vendor',
    model: 'SSM.model.lookup.Vendor',  
    autoLoad:false, 
	listeners:{
		beforeload: function(store, operation,eOpts) {
		delete operation._limit;
		delete operation._page;
		delete operation._start;
		delete operation._filters;
		delete operation._params;
		}
	}
});