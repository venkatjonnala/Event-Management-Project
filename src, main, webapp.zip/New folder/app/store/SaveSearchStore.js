Ext.define('SSM.store.SaveSearchStore', {
    extend: 'Ext.data.Store',
    alias: 'store.savesearchstore',
    storeId: 'savesearchstore',
    model: 'SSM.model.SaveSearch',
    autoLoad:true,    
    requires: ['SSM.model.SaveSearch'],

	proxy: {
 		type: 'ajax',
 		//waitMsg:'sn_i18n.message.Loading',
 		//url: skuServiceUrl + 'weeklysales', 
 		//url: 'searchfield.htm?action=getVendor',
 		//url: 'savedSearches.htm',
 		
 		url: 'output.json',
        headers: {
            'Content-Type': 'application/json'
        },
 		
 		extraParams : {
			outputType : 'JSON'
		},
 		reader: {
 		    type: 'json',
 		    rootProperty: 'data'
 		}
     } 
});

