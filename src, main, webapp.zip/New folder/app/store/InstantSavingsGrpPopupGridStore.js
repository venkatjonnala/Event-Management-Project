Ext.define('SSM.store.InstantSavingsGrpPopupGridStore', {
    extend: 'Ext.data.Store',
    alias: 'store.instantsavingsgrppopupgridstore',
    storeId: 'instantsavingsgrppopupgridstore',
    model: 'SSM.model.InstantSavingsGroupModel',
    autoLoad:false,    
    requires: ['SSM.model.InstantSavingsGroupModel'],
    simpleSortMode: true,
    sortOnLoad : false,
    pageSize : 25, 
	proxy: {
 		type: 'ajax',
 		url: 'search.htm?action=instantsavingsgroupdetails', 		
 		extraParams : {
			outputType : 'JSON'
		},
 		reader: {
 		    type: 'json',
 		    rootProperty: 'rows'
 		}
     }
});