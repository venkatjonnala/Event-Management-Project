//InstantSavingsGroupModel.js

Ext.define('SSM.model.InstantSavingsGroupModel', {
    extend: 'Ext.data.Model',
    fields: [        	
        {
            name: 'isAsnum'  // vendor
        },
        {
            name: 'instsavElig'
        },
        {
        	name: 'isinumbr'  // sku
        },
        {
        	name: 'isDept'
        },
        {
        	name: 'isSdept'
        },    
        {
        	name: 'isClas'
        },
        {
        	name: 'isId'
        },        
        {
        	name: 'isevt'  // event
        },
        {
        	name: 'isma'  // Merch
        },

       
        //RC::
        {
            name: 'instsaveElg'
        }, 
        {
            name: 'saveDeleteFlag'
        },
        {
            name: 'isid'
        },
        {
            name: 'groupEligFl'
        } 
        
        
    ]
});