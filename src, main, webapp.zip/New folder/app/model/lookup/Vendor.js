Ext.define('SSM.model.lookup.Vendor', {
    extend: 'Ext.data.Model',
    fields: [
             {name: 'VENDORNO', mapping : '_source.VENDORNO'},
             {name: 'NAME', mapping : '_source.NAME'}
        ],
    	proxy: {
     		type: 'ajaxwithpayload',
     		waitMsg:'i18n.message.Loading',
     		url: params.base_lookup_url + 'lookup_vendor/_search',
     		headers: { 'Content-Type': 'application/json' },     
     		noCache: false,
     		timeout: 60000, //2 minutes
     		actionMethods : {
     		   	 read : 'POST',
     		   	 create: 'POST',
     		   	 destroy: 'POST',
     		   	 update: 'POST'
     		},
    		reader: {
    			type: 'json',
    		    rootProperty: 'hits.hits',
    		    totalProperty: 'hits.total'
    		}
        } 
});