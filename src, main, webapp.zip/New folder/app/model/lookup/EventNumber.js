Ext.define('SSM.model.lookup.EventNumber', {
    extend: 'Ext.data.Model',
    fields: [
             {name: 'EVENTNO', mapping : '_source.EVENTNO'}
    ] ,
	proxy: {
 		type: 'ajaxwithpayload',
 		waitMsg:'i18n.message.Loading',
 		url: params.base_lookup_url + 'lookup_event/_search',
 		headers: { 'Content-Type': 'application/json' },     
 		noCache: false,
 		timeout: 60000//, //2 minutes
// 		actionMethods : {
// 		   	 read : 'POST',
// 		   	 create: 'POST',
// 		   	 destroy: 'POST',
// 		   	 update: 'POST'
// 		},
//		reader: {
//			type: 'json',
//		    rootProperty: 'hits.hits',
//		    totalProperty: 'hits.total'
//		}

    } 
});