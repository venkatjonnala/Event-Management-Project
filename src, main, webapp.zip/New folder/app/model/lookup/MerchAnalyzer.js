Ext.define('SSM.model.lookup.MerchAnalyzer', {
    extend: 'Ext.data.Model',
    fields: [
         {name: 'CODE', mapping : '_source.CODE'},
         {name: 'NAME', mapping : '_source.NAME'},
         {name: 'GP_COMBINED', mapping : '_source.GP_COMBINED'}
    ]
});
