Ext.define('SSM.model.lookup.Sku', {
    extend: 'Ext.data.Model',
    fields: [
         {
             name: 'sku'
         },
         {
             name: 'skuDesc'
         },
         {
         	name: 'venPartNo'
         },
         {
         	name: 'asnum'
         }
        
    ]    
});

/*
Ext.define('SSM.model.lookup.Sku', {
    extend: 'Ext.data.Model',

    fields: [
        {
            name: 'sku'
        },
        {
            name: 'skuDesc'
        },
        {
        	name: 'venPartNo'
        },
        {
        	name: 'asnum'
        }
    ],

    proxy: {
        type: 'ajax',
          url: 'searchfield.htm?action=getSku',
        reader: {
            type: 'json',
            root: 'data'
        }
    }
});*/