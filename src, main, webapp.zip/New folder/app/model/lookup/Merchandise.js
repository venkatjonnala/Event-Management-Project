Ext.define('SSM.model.lookup.Merchandise', {
    extend: 'Ext.data.Model',
    fields: [
			{
			    name: 'merchAnalyzerDesc'
			},
			{
			    name: 'merchAnalyzerCode'
			},
			{
				name: 'merchAnalyzerComb'
			}
    ]    
});
