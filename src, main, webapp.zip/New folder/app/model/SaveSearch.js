Ext.define('SSM.model.SaveSearch', {
    extend: 'Ext.data.Model',
    fields: [
             {name: 'searchName'},
             {name: 'savedSearchStr'}
            ] 
});
