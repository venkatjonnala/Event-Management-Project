//Ext.define('BCS.data.proxy.AjaxWithPayload', {
Ext.define('SSM.model.AjaxWithPayload', {
    extend: Ext.data.proxy.Ajax,
    alias: 'proxy.ajaxwithpayload',
    actionMethods: {
        create: "POST",
        destroy: "POST",
        read: "POST",
        update: "POST"
    },
    buildRequest: function(operation) {
        var me = this,
            request = me.callParent([
                operation
            ]);
        request.jsonData = me.jsonData;
        return request;
    }
});
