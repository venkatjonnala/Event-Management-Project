Ext.define('SSM.model.WeeklySalesModel', {
    extend: 'Ext.data.Model',
    fields: [
         {
        	 name: 'currentYearWeek'
         },
         {
        	 name: 'currentPeriod'
         },
         {
        	 name: 'currentYearWeekEndDate', type: 'date', dateFormat: 'c'
         },
         {
        	 name: 'currentYearTotal'
         },
         {
        	 name: 'currentYearPercentTotal'
         },
         {
        	 name: 'previousYearWeek'
         },
         {
        	 name: 'previousPeriod'
         },
         {
        	 name: 'previousYearWeekEndDate', type: 'date', dateFormat: 'c'
         },
         {
        	 name: 'previousYearTotal'
         },
         {
        	 name: 'previousYearPercentTotal'
         },
         {
        	 name: 'option'
         }
    ]    
});