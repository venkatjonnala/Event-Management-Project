Ext.define('SSM.model.InstantSavingsSkuModel', {
    extend: 'Ext.data.Model',
    fields: [
        {
            name: 'sku'
        },
        {
            name: 'storeNo'
        },
        {
        	name: 'skuDescription', convert: function (value) { return  value != null ? value.toUpperCase() : value }
        },
        {
        	name: 'vendorNo'
        },
        {
        	name: 'vendorName'
        },
        {
            name: 'mu'
        },
        {
            name: 'retail'
        },
        {
            name: 'storeRank'
        },
        {
            name: 'distRank'
        },
        {
            name: 'regRank'
        },
        {
            name: 'chainRank'
        },
        {
            name: 'salesStore1'
        },
        {
            name: 'salesStore2'
        },
        {
            name: 'sales1'
        },
        {
            name: 'sales2'
        },
        {
            name: 'weeks1'
        },
        {
            name: 'weeks2'
        },
        {
        	name: 'dept'
        },
        {
        	name: 'subDept'
        },
        {
        	name: 'clas'
        },
        {
        	name: 'casePack'
        },
        {
        	name: 'kit'
        },
        {
        	name: 'top'
        },
        {
            name: 'last4Weeks'
        },
        {
            name: 'onHand'
        },
        {
            name: 'onOrder'
        },
        {
            name: 'onOrderPlus30'
        },
        {
            name: 'status', convert: function (value) { return  value != null ? value.toUpperCase() : value }
        },
        {
        	name: 'estimatedLeadDays'
        },	
        {
            name: 'forecast'
        },
        {
            name: 'buildTo'
        },
        {
            name: 'buildToCopy'
        },        
        {
            name: 'rf'
        },
        {
            name: 'soQty'
        },
        {
            name: 'soQtyCopy'
        },        
        {
            name: 'wos'
        },
        {
            name: 'ExpDeliveryDate'
        },
        {
            name: 'altShip'
        },
        {
            name: 'altShipCnt'
        },
        {
        	name: 'curDmnAltShpCnt'
        },
        {
            name: 'skuNote'
        },
        {
            name: 'permNote'
        },
        {
            name: 'ordNote'
        },
        {
            name: 'warehouseRestricted'
        },
        {
            name: 'bldLevel'
        },
        {
            name: 'domainCount'
        },        
        {
            name: 'bldDomain'
        },
        {
            name: 'bldDomainCopy'
        },        
        {
            name: 'bldStatus'
        },
        {
            name: 'webSkuDesc', convert: function (value) { return  value != null ? value.toUpperCase() : value }
        },
        {
            name: 'vendorWebSkuDesc'
        },
        {
            name: 'swsFlag'
        },
        {
            name: 'importCode'
        },        
        {
            name: 'sellByFactor'
        },  
        {
        	name: 'searchTimestamp'
        },
        {
            name: 'newBuildTo'
        },  
        {
        	name: 'errorSku'
        },
        {
        	name: 'buildToBeforeError'
        },
        {
        	name: 'orderableSKU'
        },
        {
        	name: 'orderableStore'
        },        
        {
        	name: 'eventName'
        },
        {
        	name: 'startWk'
        },
        {
        	name: 'endWk'
        },
        {
        	name: 'bldAprvStatus'
        },
        {
        	name: 'cpadjust'
        },
        {
        	name: 'minType'
        },
        {
        	name: 'vendorMin'
        },
        {
        	name: 'totalOrder'
        },
        {
        	name: 'cost'
        },        
        {
        	name: 'weight'
        },
        {
            name: 'cpaltns'
        },
        {
        	name: 'merchGroup', convert: function (value) { return  value != null ? value.toUpperCase() : value }
        },
        {
        	name: 'upc'
        },
        {
        	name: 'multiUPC'
        },
        {
            name: 'action'
        },
        {
            name: 'ooShipping'
        },
        {
            name: 'activationDate'
        },
        {
            name: 'comment'
        },
        {
            name: 'bfoTYL4'
        },
        {
            name: 'onOrderPastDue'
        },
        {
            name: 'permNoteComment'
        },
        {
            name: 'permLastUpdateUser'
        },
        {
            name: 'permLastUpdateTm'
        },
        {
            name: 'rfind'
        },        
        {
            name: 'asoBuildTo'
        },
        {
            name: 'asoind'
        },
        {
            name: 'asoOverride'
        },
        {
            name: 'asoOverrideCopy'
        },                  
        {
            name: 'asoLoadBT'
        },
        //RC::
        {
            name: 'instSaveElig'
        }, 
        {
            name: 'instsaveElg'
        }, 
        {
            name: 'saveDeleteFlag'
        },
        {
            name: 'isid'
        },
        {
            name: 'enWebDesc', convert: function (value) { return  value != null ? value.toUpperCase() : value }
        } ,
        {
            name: 'eventNumber'
        }
    ]
});