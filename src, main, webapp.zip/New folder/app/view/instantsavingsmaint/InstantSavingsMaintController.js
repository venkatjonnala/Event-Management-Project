var globalVendorControl = '0';
Ext.define('SSM.view.instantsavingsmaint.InstantSavingsMaintController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.instantSavingsMaintController',
    
    models: ['InstantSavingsMaintModel'],
    stores: ['SSM.store.lookup.Vendor','SSM.store.lookup.Sku', 'SSM.store.combo.SKUStatus', 'SSM.store.lookup.MerchAnalyzer', 'SSM.store.lookup.SKUDesc'],
    views: ['instantsavingsmaint', 'SSM.view.instantsavingsmaint.InstantSavingsMaintSearch'],     
    _modifedInstantRecords: [],
    _deletedInstantRecords: [],
    _saveDeleteFlag: true,
    
    refs: [	    
   	    {ref: 'instantsavingsmaint', selector: 'instantsavingsmaint'},
   	    {ref: 'InstantSavingsGrpPopup', selector: 'instantsavingsgrppopup'}
   	 ],  
     
     init: function (window) {
         this.control({
             'instantsavingsmaint *': {
                 specialkey: function (field, e) {
                     if (e.getKey() == e.ENTER) {                    	 
                    	  var searchBtn = Ext.ComponentQuery.query('#searchBtn')[0]; 
                          searchBtn.fireEvent('click', searchBtn);       
                          this.searchBtnHandler(searchBtn, 'newSearch');
                     }
                 }
             },            
             'instantsavingsmaint button[action=venNameMode]': {
                 click: this.venNameModeClick
             },
             'instantsavingsmaint button[action=skuMode]': {
                 click: this.skuModeClick
             },
             
             'instantsavingsmaint combo[name=vendorName]': {
             	 //change:this.vendorNameControl,
             	 change:this.vendorNameControlProxyURL,
             	 select:this.vendorNameSelect,
                 blur:this.vendorNameBlur
             },
             'instantsavingsmaint combo[name=skuDesc]': {
                 //change: this.disableBySkuDesc,
                 change: this.disableBySkuDescProxyURL,                 
                 select  : this.skuDescSelect,
                 blur: this.skuDescBlur
             },
             
             'instantsavingsmaint pagingtoolbar[name=pagingBar]': {
                 //refreshPage: this.doRefresh,
                 //beforechange: this.saveModifiedBTRecords,
                 //beforechange: this.saveInstantSavingsPaging,
                 //TODO: Group and SKU use different techniques
            	 //beforechange: this.saveInstantSavingsGrpBeforeChange,
                 //change: this.changed
             },
             
             'instantSavingsSkuGrid pagingtoolbar[name=pagingBar]' : {
					//click : this.saveModifiedInstantPagingClick
			  },
             
             'instantSavingsGroupGrid pagingtoolbar[name=pagingBar]' : {
					//click : this.saveModifiedInstantPagingClick
			  },
	             
             /*
             'instantsavingsmaint pagingtoolbar[name=pagingBar]': {
                 //refreshPage: this.doRefresh,
                 beforechange: this.saveModifiedBTRecords,
                 //change: this.changed
             },*/
             
             //////
             'instantsavingsmaint lookup[itemId="skus"]' : {
         		'postLookupValidate': this.skusPostLookupValidate,
 				'preLookupLaunch':function(lookup){
 					if(!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
 						lookup.setValue('');
 	            		return true;
 					}
             	}
         	 },
         	 'instantsavingsmaint lookup[itemId="upcs"]' : {
         		
 				'postLookupValidate': this.upcsPostLookupValidate,
 				'preLookupLaunch':function(lookup){
 					if(!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
 						lookup.setValue('');
 	            		return true;
 					}
             	}
         	},
             'instantsavingsmaint lookup[name=vendorNos]': {
             	'preLookupLaunch':function(lookup){
 					if(!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
 						lookup.setValue('');
 	            		return true;
 					}
             	},
 				'postLookupValidate': this.vendorNosPostLookupValidate,
 				 change:this.vendorNumberControl,
                 blur: this.vendorNumberControl
             },
             'instantsavingsmaint trigger[name=skus]': {
                 change: this.disableBySku
             },
             'instantsavingsmaint lookup[name=depts]': {
             	change:this.disableByDepts
             },
             'instantsavingsmaint lookup[name=subdepts]': {
             	change:this.disableBySubDepts
             },
             'instantsavingsmaint trigger[name=upcs]': {
                 change: this.disableByUpc
             },
             'instantSavingsGroupGrid': { 
                cellclick: this.instaSavingsGroupGridCellclick
             },
             'instantSavingsSkuGrid': { 
                  cellclick: this.instantSavingsSkuGridCellclick
             },
             'instantsavingsmaint lookup[name=merchAnalyzerComb]': {
              	'preLookupLaunch':function(lookup){
              		console.log("merchAnalyzerComb preLookupLaunch");
  					if(!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
  						lookup.setValue('');
  	            		return true;
  					}
              	},
  				'postLookupValidate': this.merchAnalyzerCombPostLookupValidate,
  				 change:this.merchAnalyzerCombControl,
                 blur: this.merchAnalyzerCombControl
             },
             
             'instantsavingsmaint combo[itemId=merchAnalyzer]' : {
 				change : this.merchAnalyzerProxyURL
 			 },
 			 'instantsavingsmaint combo[itemId=eventnumber]' : {
  				change : this.eventNumberrProxyURL
  			 },
  			/*  'instantsavingsmaint combo[name=eventnumbercombo]': {
             	 change:this.eventNumberComboControl,
             	 select:this.eventNumberComboSelect,
                 blur:this.eventNumberComboBlur
             },
            'instantsavingsmaint textfield[name=eventnumber]': {
             	 change:this.eventNumberControl,
                 blur:this.eventNumberBlur
             },*/
             'instantsavingsmaintsearch': {
            	 afterrender: this.instantSavingsMaintsearchAfterRender
             }      
         });
         
         ////this.createGearMenu();
     },
     

     
     instantSavingsMaintsearchAfterRender : function() {
    	//this.getView().down('#depts').focus(true, true);
      	//var deptsLookup = Ext.ComponentQuery.query('#depts')[0];
      	//deptsLookup.focus(true, true);
     },
     createGearMenu : function() {
		var me = this;
		var view = me.getView();

		//Build country store
		var countrylist = 'usa,canada';
		var countryData = '';
		
		if (countrylist != null) {
			countryData = countrylist.split(",");
		}
		var countryStore = Ext.create('Ext.data.ArrayStore', {
			fields : [
				{
					name : 'country',
					type : 'string'
				}
			]
		});
		countryStore.loadData(countryData, false);

		//Build country / concept store
		console.log("MainController 1 - 2 params.countryConceptlist = "+params.countryConceptlist);
		var countryConceptlist = 'BEDBATH,CTS';
		var countryConceptData = '';
		if (countryConceptlist != null) {
			countryConceptData = countryConceptlist.split(",");
		}
		var countryConceptStore = Ext.create('Ext.data.ArrayStore', {
			fields : [
				{
					name : 'countryconcept',
					type : 'string'
				}
			]
		});
		countryConceptStore.loadData(countryConceptData, false);

		//Build language store
		console.log("MainController 1 - 3 params.langlist = "+params.langlist);
		var langlist ='en,es';
		var langData = '';
		if (langlist != null) {
			langData =langlist.split(",");
		}

		var langStore = Ext.create('Ext.data.ArrayStore', {
			fields : [
				{
					name : 'language',
					type : 'string'
				}
			]
		});
		langStore.loadData(langData, false);

		//Create empty menu
		me.gearMenu = Ext.create('Ext.menu.Menu',
			{
				width : 230,
				shadow : 'frame'
			});
		
		//////////////////////////////////////////////////////////

		//Load language menu items
		var langItem = "";
		var i18nLang = "";
		Ext.each(langStore.data.items, function(item) {
			if (item.data && (typeof item.data === 'string' || item.data instanceof String) && item.data.trim().length > 0) {
				var langChecked = false;
				i18nLang = (item.data).toLowerCase();
				if (params.lang.toLowerCase() === i18nLang) {
					langChecked = true;
				}
				//App supports only english and spanish
				//for other langs, need app_lang_? file
				if (i18nLang == 'en' || i18nLang == 'es') {
					i18nLang = eval('i18n.text.' + (item.data).toLowerCase());
				}
				langItem = Ext.create('Ext.menu.CheckItem', {
					langid : item.data,
					iconCls : 'no_flag',
					text : i18nLang,
					checked : langChecked,
					group : 'langgroup',
					handler : function() {
						if (this.langid != params.lang) {
							document.location = me.buildSwitchLanguageUrl(this.langid);
						}
					}
				});
				me.gearMenu.add(langItem);
			}
		});
		me.gearMenu.add(Ext.create('Ext.menu.Separator', {}));

		
		/*
		//Load country / concept menu items
		var cntryflag = "";
		var cnytryItem = "";
		var i18nCntry = "";
		Ext.each(countryConceptStore.data.items, function(item) {
			if (item.data && (typeof item.data === 'string' || item.data instanceof String) && item.data.trim().length > 0) {
				var cntryChecked = false;
				var paramCntryConcept = params.country.toUpperCase() + '_' + params.concept.toUpperCase();
				if (paramCntryConcept === item.data.toUpperCase()) {
					cntryChecked = true;
				}
				cntryflag = "no_flag";
				if (item.data.indexOf('USA') != -1) {
					cntryflag = "flag_us";
				}
				else if (item.data.indexOf('CAN') != -1) {
					cntryflag = "flag_ca";
				}
				else if (item.data.indexOf('MEX') != -1) {
					cntryflag = "flag_mx";
				}
				i18nCntry = item.data;
				i18nCntry = eval('i18n.text.' + i18nCntry.toLowerCase());

				var cntryItem = Ext.create('Ext.menu.CheckItem', {
					cntryid : item.data,
					iconCls : cntryflag,
					checked : cntryChecked,
					checkHandler : function(item, checked) {
						return me.onItemCheck(item, checked);
					},
					text : i18nCntry,
					group : 'cntrygroup',
					handler : function() {
						var countryConceptCntry = this.cntryid.substring(0, this.cntryid.indexOf('_'));
						var countryConceptConcpt = this.cntryid.substring(this.cntryid.indexOf('_') + 1, this.cntryid.length);
						var countryChangeMessage = '<font size="2"> <b>' + i18n.text.cntryChangeMsg + eval('i18n.text.' + this.cntryid.toLowerCase()) + '</b></font>';
						var cntryChangeWindow = Ext.create('SSM.view.main.CountryChangeWindow');
						cntryChangeWindow.getViewModel().set("countryChangeMessage", countryChangeMessage);
						cntryChangeWindow.changeCountry = countryConceptCntry;
						cntryChangeWindow.changeConcept = countryConceptConcpt;
						cntryChangeWindow.down('#countryChg').value = countryConceptCntry;
						cntryChangeWindow.down('#conceptChg').value = countryConceptConcpt;

						var countryStoreList = '';
						if (this.cntryid.indexOf('USA') != -1)
							countryStoreList = params.USA;
						else if (this.cntryid.indexOf('CAN') != -1)
							countryStoreList = params.CAN;
						else if (this.cntryid.indexOf('MEX') != -1)
							countryStoreList = params.MEX;
						countryStoreList = removeLastCharComma(countryStoreList);
						if (countryStoreList.charAt(0) === ',') {
							countryStoreList = countryStoreList.substr(1, countryStoreList.length);
						}

						var cntryStore = cntryChangeWindow.down('#cntryStore');
						cntryStore.lookupconfig.disabledfields = [ {
							name : 'country'
						} ];
						cntryStore.lookupconfig.defaultfields = [ {
							name : 'country',
							value : countryConceptCntry
						}, {
							name : 'concept',
							value : countryConceptConcpt
						} ];
						cntryStore.lookupconfig.validList = countryStoreList;
						cntryChangeWindow.show();
						cntryStore.focus(false, true);
					}
				});
				me.gearMenu.add(cntryItem);
			}
		});

		me.gearMenu.add(Ext.create('Ext.menu.Separator', {}));

		//Load about box menu item
		var aboutItem = Ext.create('Ext.menu.Item', {
			text : 'About',
			handler : function() {
				if (!view.aboutBox) {
					view.aboutBox = Ext.create('SSM.view.AboutWindow');
					var msg = view.aboutBox.down("#message");

					Ext.Ajax.request({
						url : 'MANIFEST.MF',
						success : function(response, opts) {
							msg.setValue(response.responseText);
						},
						failure : function(response, opts) {
							msg.setValue('server-side failure with status code ' + response.status);
						}
					});

					view.aboutBox.show();
					view.aboutBox.center();

				}
				else {
					view.aboutBox.show();
					view.aboutBox.center();
				}
			}
		});
		me.gearMenu.add(aboutItem);
		*/

    },
	
     
    venNameModeClick: function (btn) {
         console.log("venNameModeClick Clcik!!!!!");
         
        // console.log("Dashboard.js venNameMode !!!!!!!!!!!!!!!!!!!!!!!!");
     	var buttonText = btn.getText();
     	 //console.log("Dashboard.js venNameMode !!!!!!!!!!!!!!!!!!!!!!!! form = "+btn.up('form'));
     	 
     	 
     	var venNameField = btn.up('form').down('#vendorName');
     	venNameField.reset();
     	venNameField.focus(false,true);
     	if (buttonText == i18n.label.startWith){
     		btn.setText(i18n.label.contains);
     		btn.setTooltip(i18n.tooltip.contains);
     	}else if (buttonText == i18n.label.contains){
     		btn.setText(i18n.label.startWith);
     		btn.setTooltip(i18n.tooltip.startWith);
     	}
     },
     
     skuModeClick: function(btn){
     	var buttonText = btn.getText(); 
     	var skuDescField = btn.up('form').down('#skuDesc');
     	skuDescField.reset();
     	skuDescField.focus(false,true);
     	if (buttonText == i18n.label.startWith){
     		btn.setText(i18n.label.contains);
     		btn.setTooltip(i18n.tooltip.contains);
     	}else if (buttonText == i18n.label.contains){
     		btn.setText(i18n.label.startWith);
     		btn.setTooltip(i18n.tooltip.startWith);
     	}
     },
     
     /*
     vendorNameControl:function(field){     	
     	var view = this.getView()
     	var searchForm = field.up('form');	
     	var store = field.getStore();     	
     	var vendorNos = searchForm.down('#vendorNos');
     	var vendorName = searchForm.down('#vendorName');
     	var venNameMode = searchForm.down('#venNameMode');
     	
     	//console.log("DashBord.js vendorNameControl @@@@!!! 2 - 1 searchForm = "+searchForm);     	
     	//console.log("DashBord.js vendorNameControl @@@@!!! 2 - 2 field = "+field +" venNameMode.getText() = "+venNameMode.getText());
     	//console.log("DashBord.js vendorNameControl @@@@!!! 2 - 3 field store = "+field.getStore());
     	console.log("DashBord.js vendorNameControl @@@@!!! 2 - 4  userid = "+params.userid +" lang = "+params.lang +" country = "+params.country +" concept = "+params.concept);
     	console.log("DashBord.js vendorNameControl @@@@!!! 2 - 5 vendorName.getValue() = "+vendorName.getValue());
     	//console.log("DashBord.js vendorNameControl @@@@!!! 2 - 5 - 1 this.getLookupVendorStore()= "+this.getLookupVendorStore());
          	
     	 var extraParams = {};
         var extraParams = {             
        	 searchMode: venNameMode.getText(),    
        	 vendorDesc: vendorName.getValue(),
             userId: params.userid,
             lang: params.lang,
             country: params.country,
             //concept: params.concept
             concept: 'BB',
             conceptShortName: 'BB'
         };
     	
         store.proxy.extraParams = extraParams;
         store.load();
   
         //////////////////////  
     	if((vendorName.getValue() != null && vendorName.getValue().length != 0))
     	{
     		//console.log("Dashboard.js 2 - 4 vendorNameControl ");
     		if((vendorNos.getValue() == null || vendorNos.getValue().length == 0))
         	{
     			//console.log("Dashboard.js 2 - 5 vendorNameControl ");
     			vendorNos.setValue(null);
     			vendorNos.setDisabled(true);
         	}
     	}
     	else
     	{
     		//console.log("Dashboard.js 2 - 7 vendorNameControl globalVendorControl = "+globalVendorControl);
     		if(globalVendorControl === '0') {
     			vendorNos.setDisabled(false);
     		}
     	}
     },*/
     
     vendorNameControlProxyURL : function(combo, newValue, oldValue, eOpts) {	 
    	 //This is called on change of vendor name.  Field may not be validated yet.
    	 console.log("vendorNameControlProxyURL 10 ### newValue = "+newValue +" combo.getItemId() = "+combo.getItemId());
	    	var searchForm=combo.up('form'); 
	     	//var skuDesc = searchForm.down('#skuDesc');
	     	//var skuDescMode = searchForm.down('#skuMode').getText(); 
	     	var vendorNos = searchForm.down('#vendorNos');
	     	var vendorName = searchForm.down('#vendorName');
	     	//var venNameMode = searchForm.down('#venNameMode');
	     	var venNameMode = searchForm.down('#venNameMode').getText(); 
	     	//console.log("vendorNameControlProxyURL 1 venNameMode = "+searchForm.down('#venNameMode'));
	     	//console.log("vendorNameControlProxyURL 1 venNameMode = "+venNameMode);
	     	
	     	//Make sure the vendor name field is valid (e.g at least 3 characters) before processing
	     	var invalidFields = [];
		    Ext.suspendLayouts();
		    //this.form.getFields().filterBy(function(field) {
		    searchForm.form.getFields().filterBy(function(field) {
		        if (field.validate()) return;
		        if (field.itemId === 'vendorName'){
		        	invalidFields.push(field);
		        }
		    });
		    Ext.resumeLayouts(true);
		    
		    //exit if any fields are invalid
		    //TODO: exit if vendor name is invalid
		    if (invalidFields.length > 0){
            	combo.getStore().removeAll();
	 	    	return;
	 	    }

	     	venNameMode = venNameMode.replace('<b>', !Ext.isEmpty(newValue) ? '' : '');
	     	venNameMode = venNameMode.replace('</b>', !Ext.isEmpty(newValue) ? '' : '');	     	
	     	
	    	var elasticQuery = null;
	 		if (!Ext.isEmpty(newValue)) {
	 			newValue = newValue.replace('"', '\\"');
	 		}
	 	
	 		if (combo.getItemId() === 'vendorName') {	
	 			if (venNameMode === 'S') {
					//elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "bedbath"}}, {"term":{"DESCRIPTION.DESCRIPTION_AUTOCOMPLETE":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[{ "DESCRIPTION.DESCRIPTION_SORT" : "asc"}],"aggregations":{}}';
					//elasticQuery = '{"query":{"bool":{"must":[{"prefix":{"NAME._NAME":"bath"}},{"query_string":{"default_field":"COUNTRY","query":"USA"}},{"query_string":{"default_field":"CONCEPT","query":"BEDBATH"}}]}},"from":0,"size":50,"sort":[{"NAME.NAME_SORT":"asc"}]}';
					elasticQuery = '{"query":{"bool":{"must":[{"prefix":{"NAME._NAME":"AAA"}},{"query_string":{"default_field":"COUNTRY","query":"USA"}},{"query_string":{"default_field":"CONCEPT","query":"BEDBATH"}}]}},"from":0,"size":50,"sort":[{"NAME.NAME_SORT":"asc"}]}';
					elasticQuery = elasticQuery.replace('AAA', !Ext.isEmpty(newValue) ? newValue.toLowerCase() : '');
				}
				else {
					//elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "bedbath"}}, {"term":{"DESCRIPTION.DESCRIPTION_CONTAINS":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[{ "DESCRIPTION.DESCRIPTION_SORT" : "asc"}],"aggregations":{}}';
					elasticQuery = '{"query":{"bool":{"must":[{"wildcard":{"NAME._NAME":"AAA"}},{"query_string":{"default_field":"COUNTRY","query":"USA"}},{"query_string":{"default_field":"CONCEPT","query":"BEDBATH"}}]}},"from":0,"size":50,"sort":[{"NAME.NAME_SORT":"asc"}]}';
					elasticQuery = elasticQuery.replace('AAA', !Ext.isEmpty(newValue) ? '*'+newValue.toLowerCase()+'*' : '');
				}
	 		}
	 		
	 		console.log("vendorNameControlProxyURL 10 - 1 ### elasticQuery = "+elasticQuery);	
	 		console.log("vendorNameControlProxyURL 10 - 2 ### params.concept = "+params.concept +" country = "+params.country);	
	 		var url = params.vendorNameUrl.substring(0, params.vendorNameUrl.indexOf("?"));
	 		
	        Ext.Ajax.request({
	            url: base_lookup_url + 'lookup_vendor/_search',
	            //url: 'http://192.168.192.160/elasticsearch/lookups5/' + 'lookup_vendor/_search',
	            //url: url,
	            method: 'POST',
	        	noCache:false,
	            headers: {
	                'Content-Type': 'application/json'
	            },
	            timeout: 60000, //2 minutes
	            jsonData : elasticQuery,      
	            scope: this,
	            success: function (response) {
	                var jsonResp = Ext.JSON.decode(response.responseText);
	                var vendorDescData = [];

	                if (jsonResp.hits.hits.length===0){
	                	combo.getStore().removeAll();
	                }else {
		                for (var i = 0; i < jsonResp.hits.hits.length; i++) {
		                    var country = jsonResp.hits.hits[i]._source.COUNTRY;
		                    var concept = jsonResp.hits.hits[i]._source.CONCEPT;
		                    //var skuDescription = jsonResp.hits.hits[i]._source.DESCRIPTION;	                    
		                    //var sku = jsonResp.hits.hits[i]._source.SKU;
		                    //var upc = jsonResp.hits.hits[i]._source.UPC;
		                    var vendorno = jsonResp.hits.hits[i]._source.VENDORNO;
		                    //var vendorName = jsonResp.hits.hits[i]._source.VENDORNAME;
		                    var vendorName = jsonResp.hits.hits[i]._source.NAME;
		                    //console.log("vendorNameControlProxyURL 1 - 4 ###  vendorno = "+vendorno +" vendorName = "+vendorName +" country = "+country );
		                   	                    
		                    vendorDescData.push({
			                     //'DESCRIPTION': skuDescription,
			                     //'sku': sku
			                     //,'upc': upc
			                 	'NAME': vendorName,
			                    'VENDORNO': vendorno
		                    });
		                    
							var store = Ext.create('Ext.data.Store', {
								//fields: ['DESCRIPTION', 'sku'],
								fields: ['NAME', 'VENDORNO'],
								data: vendorDescData
							});
		                    combo.bindStore(store);	                    
		                    if (Ext.isEmpty(newValue)) {
		            			combo.getStore().removeAll();
		            		}
		                }
		            }
	            }
	        });
	      
	     	console.log("vendorNameControlProxyURL 10 - 3 disableBySkuDesc  params.country = "+params.country);
	     	console.log("vendorNameControlProxyURL 10 - 4 disableBySkuDesc  params.concept = "+params.concept +" params.conceptShortName = "+params.conceptShortName);
	     	console.log("vendorNameControlProxyURL 10 - 5 disableBySkuDesc  vendorName.getValue() = "+vendorName.getValue()+", Search Mode="+venNameMode);
	     	
	     	if((vendorName.getValue() != null && vendorName.getValue().length != 0))
	     	{
	     		console.log("Dashboard.js 10 - 6 vendorNameControl vendorNos.getValue() = "+vendorNos.getValue());
	     		if((vendorNos.getValue() == null || vendorNos.getValue().length == 0))
	         	{
	     			//console.log("Dashboard.js 2 - 5 vendorNameControl ");
	     			vendorNos.setValue(null);
	     			vendorNos.setDisabled(true);
	         	}
	     	}
	     	else
	     	{
	     		console.log("Dashboard.js 10 - 7 vendorNameControl globalVendorControl = "+globalVendorControl);
	     		if(globalVendorControl === '0') {
	     			vendorNos.setDisabled(false);
	     		}
	     	}
	 },
     vendorNameBlur: function(combo){console.log("Dashboard.js 11 - 1 vendorNameBlur  combo = "+combo +" combo.rawValue = "+combo.rawValue);
		var value=Ext.String.trim(toProperCase(combo.rawValue)); 		
  		
      	if(!Ext.isEmpty(Ext.String.trim(combo.rawValue))){
      	  console.log("Dashboard.js 11 - 1 vendorNameBlur  combo.getStore().getCount() = "+combo.getStore().getCount() +" value = "+value);	
      	  if(combo.getStore().getCount()==1){
      		  
       		  //var rec=combo.getStore().findRecord('vendorDesc',value);
       		  var rec=combo.getStore().findRecord('NAME',value);
       		  console.log("Dashboard.js 11 - 1 - 1 vendorNameBlur  rec = "+rec +" rec.data = "+rec.data);
       		  console.log("Dashboard.js 11 - 1 - 2 vendorNameBlur  VENDORNO = "+rec.data.VENDORNO);
       				
       		  var form=combo.up('form');
       		  var vendorNo=form.down('lookup[itemId=vendorNos]');
       		  console.log("Dashboard.js 11 - 2 vendorNameBlur  vendorNo = "+vendorNo +" rec = "+rec +" rec.data.vendorNo = "+rec.data.VENDORNO);
       		  
       		  if(!(Ext.isEmpty(rec))){
       			console.log("Dashboard.js 11 - 3 vendorNameBlur  vendorNo = "+vendorNo +" rec = "+rec);
       			vendorNo.setValue(rec.data.VENDORNO);
       			vendorNo.isLookupValid();
       			vendorNo.setDisabled(true);
       			combo.setDisabled(false);
       			form.down('#venNameMode').setDisabled(false);
       		  }
       	  }
      	}else{
      		console.log("Dashboard.js 11 - 4 vendorNameBlur  combo = "+combo  );   
      		combo.up('form').down('lookup[itemId=vendorNos]').setValue(null);
            combo.up('form').down('lookup[itemId=vendorNos]').setDisabled(false);
            combo.setRawValue(value);
      	}
      	
      	if((Ext.isEmpty(combo.value))&&(!Ext.isEmpty(combo.rawValue))){
      	    console.log("Dashboard.js 11 - 5 vendorNameBlur  combo = "+combo  );
            combo.up('form').down('lookup[itemId=vendorNos]').setValue(null);
            combo.up('form').down('lookup[itemId=vendorNos]').setDisabled(true);
            combo.setRawValue(value);
         }
     },
     
     vendorNameSelect: function(combo, records, eOpts){
     	    console.log("Dashboard.js 4 - 3 vendorNameSelect  records.data.sku= "+records.data +" records.data.VENDORNO = "+records.data.VENDORNO);
      	    var vendorNo=combo.up('form').down('lookup[itemId=vendorNos]');   	
      	     	
      	    //vendorNo.setValue(field.getValue());
      	    vendorNo.setValue(records.data.VENDORNO);
        	vendorNo.isLookupValid();
        	vendorNo.setDisabled(true);
        	combo.setDisabled(false);
        	combo.getStore().removeAll();
        	combo.up('form').down('#venNameMode').setDisabled(false);
      },
      // delete
      /*
      vendorNameSelect_old: function(field){
       	var soSearchForm = field.up('form');
       	console.log("Dashboard.js 4 - 4 vendorNameSelect  soSearchForm = "+soSearchForm);
       	var vendorNo=soSearchForm.down('lookup[itemId=vendorNos]');
       	
       	console.log("Dashboard.js 4 - 4 - 1 vendorNameSelect  vendorNo = "+vendorNo +" field.getValue() = "+field.getValue());
       	
       	vendorNo.setValue(field.getValue());
       	vendorNo.isLookupValid();
       	vendorNo.setDisabled(true);
       	field.setDisabled(false);
       	soSearchForm.down('#venNameMode').setDisabled(false);
       	//soSearchForm.down('#vendorPartNo').setDisabled(false);
       	//soSearchForm.down('#venPartMode').setDisabled(false);
       },*/
     
      //delete
      /*
     ///////////////////////////
     //after changeing to google type
     disableBySkuDesc_old:function(field){
    	console.log("Dashboard.js 3 - 1 disableBySkuDesc  field = "+field);
    	 
     	var searchForm = field.up('form');
     	var skuDesc = searchForm.down('#skuDesc');
     	var sku = searchForm.down('#skus');
     	var vendorNo = searchForm.down('#vendorNos');
     	var vendorName = searchForm.down('#vendorName');
     	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');
     	///console.log("Dashboard.js 3 - 2 disableBySkuDesc  merchAnalyzer = "+merchAnalyzer);
     	
     	
     	var upcs= searchForm.down('#upcs');
     	var depts = searchForm.down('#depts');
     	var subDepts = searchForm.down('#subdepts');
     	var clas = searchForm.down('#clas');
     	//var venPartMode = searchForm.down('#venPartMode');     	
     	var venNameMode = searchForm.down('#venNameMode');
     	//var skuMode = searchForm.down('#skuMode');
     	var skuMode = searchForm.down('#skuMode');     	
     	console.log("Dashboard.js 3 - 1 disableBySkuDesc  params.country = "+params.country);
     	console.log("Dashboard.js 3 - 1 disableBySkuDesc  params.concept = "+params.concept +" params.conceptShortName = "+params.conceptShortName);
		
     	var store = field.getStore();
     	 var extraParams = {};
         var extraParams = {             
        	 searchMode: skuMode.getText(),    
        	 vendorNo: vendorNo.getValue(),
        	 sku: sku.getValue(),
        	 skuDesc: skuDesc.getValue(),
        	 venPartNo: '',
        	 
             userId: params.userid,
             lang: params.lang,
             country: params.country,
             //concept: params.concept
             concept: 'BB',
             conceptShortName: 'BB'
         };
     	
         store.proxy.extraParams = extraParams;
         store.load();
         //////////////////////////////////////////////////////////////////////////////////
     	
         console.log("Dashboard.js 3 - 3 disableBySkuDesc  skuDesc.getValue() = "+skuDesc.getValue() ); //+" sku = "+sku);
     	
     	if(skuDesc.getValue() == null && sku == null){
     		console.log("Dashboard.js 3 - 3 - 1 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
     		vendorNo.setDisabled(false);
     		if(!Ext.isEmpty(vendorName.getValue())){
     			vendorName.setDisabled(true);
     		}else{
     		vendorName.setDisabled(false);
     		}
     		merchAnalyzer.setDisabled(false);
     		sku.setDisabled(false);
     		upcs.setDisabled(false);
     		
     		if(!Ext.isEmpty(depts.getValue)){
     			depts.setDisabled(false);
     			subDepts.setDisabled(false);
     			clas.setDisabled(false);
     		}else{
     			depts.setDisabled(false);
     		}
     	}else if(skuDesc.isDisabled() && (globalVendorControl === '1' || globalVendorControl === '0') ){
     		console.log("Dashboard.js 3 - 3 - 2 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
     		skuDesc.setDisabled(true);
     		skuMode.setDisabled(true);
     	}else if(!skuDesc.isDisabled() && globalVendorControl === '1' && skuDesc.getValue() != null){
     		console.log("Dashboard.js 3 - 3 - 3 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
     		vendorNo.setDisabled(true);
     		vendorName.setDisabled(true);
     		venNameMode.setDisabled(true);
     		skuDesc.setDisabled(false);
     		skuMode.setDisabled(false);
     		sku.setDisabled(true);
     		upcs.setDisabled(true);
     		depts.setDisabled(true);
     		subDepts.setDisabled(true);
     		clas.setDisabled(true);
     		// RC::
     		//merchAnalyzer.setDisabled(true);
     	}else if(skuDesc.isDisabled() && (globalVendorControl === '2') ){
     		console.log("Dashboard.js 3 - 3 - 4 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
     		//DO nothing
     	}else if(!skuDesc.isDisabled() && (globalVendorControl === '2') ){
     		console.log("Dashboard.js 3 - 3 - 5 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
     		//DO nothing
     	}else{
     		
     		console.log("Dashboard.js 3 - 3 - 6 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
     		if(skuDesc.getValue() == null || (skuDesc.getValue() != null && skuDesc.getValue().length === 0)){
     			console.log("Dashboard.js 3 - 3 - 7 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
     			vendorNo.setDisabled(false);
     			if(!Ext.isEmpty(vendorName.getValue())){
         			vendorName.setDisabled(true);
         			venNameMode.setDisabled(true);
         			//vendorPartNo.setDisabled(false);
         		}else{
         		vendorName.setDisabled(false);
         		venNameMode.setDisabled(false);
         		//vendorPartNo.setDisabled(true);
         		}
         		///venPartMode.setDisabled(true);
         		sku.setDisabled(false);
         		upcs.setDisabled(false);
         		if(!Ext.isEmpty(depts.getValue)){
         			depts.setDisabled(false);
         			subDepts.setDisabled(false);
         			clas.setDisabled(false);
         		}else{
         			depts.setDisabled(false);
         		}
     		}
     		else
     		{
     			console.log("Dashboard.js 3 - 3 - 8 disableBySkuDesc  skuDesc.getValue() = "+skuDesc +" globalVendorControl = "+globalVendorControl);
     			vendorNo.setDisabled(true);
     			vendorNo.setValue(null);

 	    		vendorName.setDisabled(true);
 	    		venNameMode.setDisabled(true);
 	    		vendorName.setValue(null); 	
 	    		///vendorPartNo.setDisabled(true);
 	    		///venPartMode.setDisabled(true);
 	    		////vendorPartNo.setValue(null); 	
 	    		sku.setDisabled(true);
 	    		sku.setValue(null);
 	    		upcs.setDisabled(true);
 	    		upcs.setValue(null);
 	
 		    	depts.setDisabled(true);
 		    	depts.setValue(null);
     		}
     	}
     },*/
     
     skuDescSelect:function(combo, records, eOpts){    	 
    	console.log("Dashboard.js 4 - 1 skuDescSelect  combo = "+combo +" records = "+records);
    	//console.log("Dashboard.js 4 - 2 skuDescSelect  records[0] = "+records[0] );
    	console.log("Dashboard.js 4 - 3 skuDescSelect  records.data.sku= "+records.data +" records.data.sku = "+records.data.sku);    	
    	//console.log("Dashboard.js 4 - 1 skuDescSelect  records[0].data.sku = "+records[0].data.sku );
    	 
     	var skuNo=combo.up('form').down('lookup[itemId=skus]'); 
     	skuNo.setValue(records.data.sku);
     	skuNo.isLookupValid();
     	skuNo.setDisabled(true);
     	combo.setDisabled(false);
     	this.disableBySkuDesc(combo);
     	combo.getStore().removeAll();
     },
     
     skuDescBlur:function(combo){
    	 console.log("Dashboard.js 5 - 1 skuDescBlur  combo = "+combo +" combo.rawValue = "+combo.rawValue);
    	 
     	var value=null;
     	if(!Ext.isEmpty(combo.rawValue)){
         	value=Ext.String.trim(toProperCase(combo.rawValue));    		
     	}
//     	else{--not required
//     		value=Ext.String.trim(combo.rawValue); 
//     	}--not required
     	var form=combo.up('form');
     	var sku=form.down('lookup[itemId=skus]');
     	var subdept=form.down('lookup[itemId=subdepts]');
     	var clas=form.down('lookup[itemId=clas]');
     	
     	var vendorNo = form.down('#vendorNos');
     	var vendorName = form.down('#vendorName');    	
     	var depts = form.down('#depts');
     	var venNameMode = form.down('#venNameMode');
     	console.log("Dashboard.js 5 - 2 skuDescBlur  combo = "+combo +" combo.getStore() = "+combo.getStore());
     	
     	if(!Ext.isEmpty(value)){
     	   console.log("Dashboard.js 5 - 3 skuDescBlur  combo.getStore().getCount() = "+combo.getStore().getCount());
     				
     	   if(combo.getStore().getCount()==1){
      		  var rec=combo.getStore().findRecord('skuDesc',value);
      		  var form=combo.up('form');
      		  var skuNo=form.down('lookup[itemId=skus]');
      		  
      		  if(!(Ext.isEmpty(rec))){
      			console.log("Dashboard.js 5 - 3 - 1 skuDescBlur ");
      			skuNo.setValue(rec.data.sku);
      			skuNo.isLookupValid();
      			skuNo.setDisabled(true);
      			combo.setDisabled(false);
      			combo.focus(true);
//      			form.down('lookup[itemId=vendorNos]').setDisabled(false);
//           	  form.down('lookup[itemId=vendorNos]').setValue('');
//           	  form.down('lookup[itemId=depts]').setValue('');
      		  }
      	    }
//     if(combo.getStore().getCount()>1){
//  	   combo.up('form').down('lookup[itemId=skus]').setValue(null);
//  	   combo.up('form').down('lookup[itemId=skus]').isLookupValid();
//  	   combo.setValue(value);
//  	   combo.up('form').down('combo[itemId=vendorPartNo]').setDisabled(true);
// 	   combo.up('form').down('#venPartMode').setDisabled(true);
//     }
     	}else{
     		sku.setDisabled(false);
     		sku.setValue(null);
     	}
     	
     	console.log("Dashboard.js 5 - 3 - 1 - 2 skuDescBlur combo.value = "+combo.value +" combo.rawValue = "+combo.rawValue);
     	if((Ext.isEmpty(combo.value))&&(!Ext.isEmpty(Ext.String.trim(combo.rawValue)))){
//            combo.up('form').down('lookup[itemId=skus]').setValue(null);
//            combo.up('form').down('lookup[itemId=skus]').setDisabled(true);
//            combo.setRawValue(value);
//      	   combo.up('form').down('combo[itemId=vendorPartNo]').setDisabled(true);
//     	   combo.up('form').down('#venPartMode').setDisabled(true);
     		console.log("Dashboard.js 5 - 3 - 2 skuDescBlur ");
     		sku.setValue(null);
     		sku.isLookupValid();
     		vendorNo.setValue(null);
     		vendorNo.isLookupValid();
     		depts.setValue(null);
     		subdept.setValue(null);
     		clas.setValue(null);
      	    combo.setValue(value);
      	    ////vendorPartNo.setDisabled(true);
     	    ///combo.up('form').down('#venPartMode').setDisabled(true);
         } else if((Ext.isEmpty(combo.value))&&(Ext.isEmpty(Ext.String.trim(combo.rawValue)))){
        	 console.log("Dashboard.js 5 - 3 - 3 skuDescBlur ");
         } 
     },
     
     skusPostLookupValidate : function (lookup,validList,inValidList){
     	console.log("Dashbord.js skusPostLookupValidate 6 - 1  ####### validList = "+validList);
 		skuValidList = true;
 		upcValidList = true;
 		deptValidList = true;
 		subDeptValidList = true;
 		clasValidList = true;
 		storeValidList = true;
 		vendorValidList = true;
 		
 		console.log("Dashbord.js skusPostLookupValidate 6 - 2  ####### globalVendorControl = "+globalVendorControl +" lookup.isDisabled() = "+lookup.isDisabled());
 		if(globalVendorControl != '2' || !lookup.isDisabled())
 		{
 			if(lookup.value.indexOf(',') === -1 && validList.length > 0 ) 
 			{
 				globalVendorControl = '1';
 				var soSearchForm = lookup.up('form');
 				var skuVal = Ext.String.trim(lookup.value.replace(/^(0+)/g, ''));
 				var skuDesc = lookup.getRecord(skuVal).get('description');
 				var upc = lookup.getRecord(skuVal).get('upc');
 				var skuDept = lookup.getRecord(skuVal).get('deptno');
 				var skuSubDept = lookup.getRecord(skuVal).get('subdeptno');
 				var skuClass = lookup.getRecord(skuVal).get('classno');
 				var vendor = lookup.getRecord(skuVal).get('vendorno');
 				var vendorname = lookup.getRecord(skuVal).get('vendorname');
 				soSearchForm.down('#vendorNos').setValue(vendor);
 				console.log("Dashbord.js skusPostLookupValidate 6 - 3  ####### upc = "+upc +" vendorname = "+vendorname +" skuClass = "+skuClass); 				
 				//console.log("Dashbord.js skusPostLookupValidate 6 - 3 - 1  ####### vendorNos = "+soSearchForm.down('#vendorNos'));
 				//console.log("Dashbord.js skusPostLookupValidate 6 - 3 - 2  ####### vendorName = "+soSearchForm.down('#vendorName'));
 				//console.log("Dashbord.js skusPostLookupValidate 6 - 3 - 3  ####### skuDesc = "+soSearchForm.down('#skuDesc') +" skuDesc = "+skuDesc); 				
 				//console.log("Dashbord.js skusPostLookupValidate 6 - 3 - 4  ####### skuDesc = "+soSearchForm.down('#skuDesc') +" skuDesc = "+skuDesc);
 				//console.log("Dashbord.js skusPostLookupValidate 6 - 3 - 5  ####### vendorName = "+soSearchForm.down('#vendorName') +" vendorName = "+vendorname);
 				///oSearchForm.down('#vendorName').setValue(Ext.String.trim(vendorname)); 
 				///console.log("Dashbord.js skusPostLookupValidate 6 - 3 - 5  ####### skuDesc = "+soSearchForm.down('#skuDesc') +" skuDesc = "+skuDesc);
 				///soSearchForm.down('#skuDesc').setValue(Ext.String.trim(Ext.String.trim(skuDesc))); 				
 				//soSearchForm.down('#vendorName').setValue(this.toProperCase(Ext.String.trim(vendorname)));
 				//soSearchForm.down('#skuDesc').setValue(Ext.String.trim(this.toProperCase(Ext.String.trim(skuDesc))));
 				
 				//RC::
 				var vendorNameField = soSearchForm.down('#vendorName');
 				console.log("Dashbord.js skusPostLookupValidate 6 - 3 - 1  ####### vendorNameField = "+vendorNameField);
 				vendorNameField.setValue(vendorname);
 				vendorNameField.setDisabled(true); 
 				//RC::
 				
 				//soSearchForm.down('#vendorName').setValue(toProperCase(Ext.String.trim(vendorname)));
 				soSearchForm.down('#skuDesc').setValue(Ext.String.trim(toProperCase(Ext.String.trim(skuDesc)))); 				
 				//console.log("Dashbord.js skusPostLookupValidate 6 - 4  ####### soSearchForm = "+soSearchForm); 				
 				//console.log("Dashbord.js skusPostLookupValidate 6 - 4 - 1 ####### depts = "+soSearchForm.down('#depts')); 
 				var upcs = soSearchForm.down('#upcs');
 				upcs.setValue(upc);
 				upcs.setDisabled(true); 				
 				
 				soSearchForm.down('#depts').setValue(skuDept);
 				var subdepts = soSearchForm.down('#subdepts');
 				subdepts.setValue(skuSubDept);
 				subdepts.setDisabled(true);
 				console.log("Dashbord.js skusPostLookupValidate 6 - 5  ####### soSearchForm = "+soSearchForm);
 				
 				var clas = soSearchForm.down('#clas');
 				clas.setValue(skuClass);
 				clas.setDisabled(true);
 				lookup.setValue(parseInt(lookup.value.replace(/^(0+)/g, '')));
 				console.log("Dashbord.js skusPostLookupValidate 6 - 6  ####### skuSubDept = "+skuSubDept);
 			}
 			if(inValidList.length > 0){
 				
 				skuValidList = false;
 				return false;
 			}
 		}
     },
     
     vendorNumberControl:function(field){
     	console.log("Dashbord.js vendorNumberControl  2 - 1 ####### ");
     	var searchForm = field.up('form');
     	var vendorNos = searchForm.down('#vendorNos');
     	var vendorName = searchForm.down('#vendorName');
     	//var vendorPartNo = searchForm.down('#vendorPartNo');
     	var venNameMode = searchForm.down('#venNameMode');
     	//var venPartMode = searchForm.down('#venPartMode');
     	params.vendorNos = vendorNos.getValue();
     	var depts = searchForm.down('#depts');
     	var eventnumber = searchForm.down('#eventnumber'); 
     	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');     	
     	var hiddenInstSavingsType = Ext.ComponentQuery.query('#hiddenInstSavingsType')[0];      	
     	//console.log("Dashbord.js vendorNumberControl  2 - 1 ####### vendorNos.getValue() = "+vendorNos.getValue() + " globalVendorControl = "+globalVendorControl);
     	//console.log("Dashbord.js vendorNumberControl  2 - 1 ####### hiddenInstSavingsType.getValue() = "+hiddenInstSavingsType.getValue());
     	
     	if((vendorNos.getValue() != null && vendorNos.getValue().length != 0))
     	{
     		//console.log("Dashbord.js vendorNumberControl  2 - 2 ####### vendorNos.getValue() = "+vendorNos.getValue());
     		if((vendorName.getValue() == null || vendorName.getValue().length == 0))
         	{
     			vendorName.setDisabled(true);
     			venNameMode.setDisabled(true);
     			vendorName.setValue(null);
         	}
     		     		
         	if(vendorNos.getValue().indexOf(',') != -1){  
     		}
         	if(!(vendorNos.isDisabled())){
             	vendorName.setDisabled(true);
         		vendorName.setValue(null);
             }
//         	vendorName.setDisabled(true);
 			venNameMode.setDisabled(true);
//     		vendorName.setValue(null);
     	}else if(vendorNos.getValue() != null && vendorNos.getValue().length === 0){
     		//console.log("Dashbord.js vendorNumberControl  2 - 3 ####### vendorNos.getValue() = "+vendorNos.getValue());
             if(!(vendorNos.isDisabled())){
             	vendorName.setDisabled(false);
         		vendorName.setValue(null);
             }
 			venNameMode.setDisabled(false);
 			
 			// RC::
 			//console.log("Dashbord.js vendorNumberControl  2 - 3 - 1 #######depts.getValue() = "+depts.getValue() +" depts.getValue().length = "+depts.getValue().length);
 			if(depts.getValue() != null && depts.getValue().length === 0){
 				if (hiddenInstSavingsType.getValue() == 'searchInsSavingsByGroup') {
 				   merchAnalyzer.setDisabled(false);
 				   eventnumber.setDisabled(false)
 				}
     	    }	
     	}
     	else
     	{
     		//console.log("Dashbord.js vendorNumberControl  2 - 4 ####### vendorNos.getValue() = "+vendorNos.getValue());
     		if(globalVendorControl === '0') {
 	    		vendorName.setDisabled(false);
 	    		venNameMode.setDisabled(false);
     		}
     		
     	}
     },
     
     
     
     //delete
     /*
     vendorNameSelect_1: function(combo, records, eOpts){
    	 
    	// console.log("Dashboard.js 4 - 1 vendorNameSelect  combo = "+combo +" records = "+records);
     	//console.log("Dashboard.js 4 - 2 skuDescSelect  records[0] = "+records[0] );
     	//console.log("Dashboard.js 4 - 3 vendorNameSelect  records.data.sku= "+records.data +" records.data.sku = "+records.data.sku);
    	console.log("Dashboard.js 4 - 3 vendorNameSelect  records.data.sku= "+records.data +" records.data.vendorNo = "+records.data.vendorNo);
     	
    	 
     	var soSearchForm = combo.up('form');
     	console.log("Dashboard.js 4 - 4 vendorNameSelect  soSearchForm = "+soSearchForm);
     	
     	var vendorNo=soSearchForm.down('lookup[itemId=vendorNos]');
     	
     	//vendorNo.setValue(field.getValue());
     	vendorNo.setValue(records.data.vendorNo);
     	
     	vendorNo.isLookupValid();
     	vendorNo.setDisabled(true);
     	
     	//field.setDisabled(false);
     	vendorNo.setDisabled(false);
     	
     	console.log("Dashboard.js 4 - 5 vendorNameSelect  venNameMode = "+soSearchForm.down('#venNameMode'));
     	
     	soSearchForm.down('#venNameMode').setDisabled(false);
     	//soSearchForm.down('#vendorPartNo').setDisabled(false);
     	//soSearchForm.down('#venPartMode').setDisabled(false);
     },*/
     
     vendorNosPostLookupValidate : function (lookup,validList,inValidList) 
     {
     	console.log("Dashbord.js vendorNosPostLookupValidate  1 - 1 ####### ");
     	skuValidList = true;
 		upcValidList = true;
 		deptValidList = true;
 		subDeptValidList = true;
 		clasValidList = true;
 		storeValidList = true;
 		vendorValidList = true;
 		var searchForm = lookup.up('form');
 		var vendorName = searchForm.down('#vendorName');
 		var venNameMode = searchForm.down('#venNameMode'); 		
 		var depts = searchForm.down('#depts');
      	var eventNumber = searchForm.down('#eventnumber'); 
 		var merchAnalyzer = searchForm.down('#merchAnalyzerComb');
 		var hiddenInstSavingsType = Ext.ComponentQuery.query('#hiddenInstSavingsType')[0];
 		
 		console.log("Dashbord.js vendorNosPostLookupValidate 1 - 1 - 1 ####### validList.length = "+validList.length +" inValidList.length  = "+inValidList.length );
 		
 		if(lookup.value.indexOf(',') === -1 && validList.length > 0) {
 			var venName = lookup.getRecord(Ext.String.trim(lookup.value.replace(/^(0+)/g, ''))).get('name'); 
 			console.log("Dashbord.js vendorNosPostLookupValidate 1 - 1 - 2 ####### venName = "+venName +" vendorName = "+vendorName);
 			
 			vendorName.setValue(Ext.String.trim(this.toProperCase(Ext.String.trim(venName))));
 			//vendorName.setValue(Ext.String.trim(venName));
 			//vendorName.setValue(venName);
 			//vendorName.setValue("test");
 			//vendorName.setValue(Ext.String.trim(toProperCase(Ext.String.trim(venName))));
 			if(!(lookup.isDisabled())){
 				vendorName.setDisabled(true);
 				venNameMode.setDisabled(true);
 			}
 			
 			// RC::
 			if (hiddenInstSavingsType.getValue() == 'searchInsSavingsByGroup') {
 			   merchAnalyzer.setDisabled(true);
 			   eventNumber.setDisabled(true);
 			}
 		} else {
 			console.log("Dashbord.js vendorNosPostLookupValidate 1 - 1 - 3 ####### venName = "+venName);
 			vendorName.setValue("");
 			vendorName.setDisabled(true);
 			venNameMode.setDisabled(true);
 		}
 		if(inValidList.length > 0){
 			console.log("Dashbord.js vendorNosPostLookupValidate 1 - 1 - 4 ####### venName = "+venName);
 			vendorValidList = false;
 		}
 	},
 	
 	disableByDepts:function(field){
    	console.log("Dashbord.js disableByDepts 9 - 1 ####### ");
    	var searchForm = field.up('form');
    	var depts = searchForm.down('#depts');
    	var subdepts = searchForm.down('#subdepts');
    	var clas = searchForm.down('#clas');
    	var vendorno = searchForm.down('#vendorNos');
    	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');
    	var eventnumber = searchForm.down('#eventnumber'); 
        var hiddenInstSavingsType = Ext.ComponentQuery.query('#hiddenInstSavingsType')[0]; 
        
    	if (Ext.isEmpty(depts.getValue())
    		|| (depts.getValue().indexOf(",") !== -1)) {
    		console.log("Dashbord.js disableByDepts 9 - 1 - 1 ####### ");
    		subdepts.setValue("");
    		subdepts.setDisabled(true);
    		clas.setValue("");
    		clas.setDisabled(true);
    	} else{    
    		console.log("Dashbord.js disableByDepts 9 - 1 - 2 ####### ");
    		subdepts.setDisabled(false);
    		Ext.apply(subdepts.lookupconfig,{
				defaultfields: [{'name':'deptno',value:depts.getValue()},
				                {name:'country',value: params.country},
				                {name:'concept',value:params.concept}]
			});
    		Ext.apply(clas.lookupconfig,{
    			defaultfields: [{'name':'deptno',value:depts.getValue()}, 
    			                {'name':'subdeptno',value:subdepts.getValue()},
    			                {name:'country',value: params.country},
    			                {name:'concept',value:params.concept}]				
			});
    		
    		
    	}
    	
    	console.log("Dashbord.js disableByDepts 9 - 1 - 2 ####### depts.getValue().length = "+depts.getValue().length +" hiddenInstSavingsType = "+hiddenInstSavingsType.getValue());
    	if(depts.getValue() != null && depts.getValue().length > 0){
    		if (hiddenInstSavingsType.getValue() == 'searchInsSavingsByGroup') {
    		  merchAnalyzer.setValue("");
      		  eventnumber.setValue("");	
    		  merchAnalyzer.setDisabled(true);
    		  eventnumber.setDisabled(true);
    		}
		} else if(depts.getValue() != null && depts.getValue().length === 0 && vendorno.getValue().length === 0){
			if (hiddenInstSavingsType.getValue() == 'searchInsSavingsByGroup') {
			  merchAnalyzer.setValue("");
	      	  eventnumber.setValue("");	
			  merchAnalyzer.setDisabled(false);
    		  eventnumber.setDisabled(false);
			}
		}
    },
    disableBySubDepts:function(field){
    	console.log("Dashbord.js disableBySubDepts  ####### ");
    	var searchForm = field.up('form');
    	var depts = searchForm.down('#depts');
    	var subdepts = searchForm.down('#subdepts');
    	var clas = searchForm.down('#clas');
    	
    	if (Ext.isEmpty(subdepts.getValue())
    		||	(subdepts.getValue().indexOf(",") !== -1)) {
    		clas.setValue("");
    		clas.setDisabled(true);
    	} else{
    		clas.setDisabled(false);
    		Ext.apply(clas.lookupconfig,{
    			defaultfields: [{'name':'deptno',value:depts.getValue()}, 
    			                {'name':'subdeptno',value:subdepts.getValue()},
    			                {name:'country',value: params.country},{name:'concept',value:params.concept}]				
			});
    	}
    },
    
    upcsPostLookupValidate : function (lookup,validList,inValidList){
		console.log("Dashbord.js upcsPostLookupValidate 7 - 1 ####### ");
		skuValidList = true;
		upcValidList = true;
		deptValidList = true;
		subDeptValidList = true;
		clasValidList = true;
		storeValidList = true;
		vendorValidList = true;
		
		console.log("Dashbord.js upcsPostLookupValidate 7 - 2 ####### ");
		if(!lookup.isDisabled() && lookup.value.indexOf(',') === -1 && validList.length > 0 ) {
			globalVendorControl = '2';
			var soSearchForm = lookup.up('form');
			var upcVal = Ext.String.trim(lookup.value.replace(/^(0+)/g, ''));
			var skuDesc = lookup.getRecord(upcVal).get('description');
			var sku = lookup.getRecord(upcVal).get('sku');
			var skuDept = lookup.getRecord(upcVal).get('deptno');
			var skuSubDept = lookup.getRecord(upcVal).get('subdeptno');
			var skuClass = lookup.getRecord(upcVal).get('classno');
			var vendor = lookup.getRecord(upcVal).get('vendorno');
			var vendorname = lookup.getRecord(upcVal).get('vendorname');
			console.log("Dashbord.js upcsPostLookupValidate 7 - 3 !####### vendorname = "+vendorname);
			
			soSearchForm.down('#vendorNos').setValue(vendor);
			soSearchForm.down('#vendorName').setValue(toProperCase(Ext.String.trim(vendorname)));
			soSearchForm.down('#skus').setValue(sku);
			soSearchForm.down('#skuDesc').setValue(toProperCase(Ext.String.trim(skuDesc)));
			soSearchForm.down('#depts').setValue(skuDept);
			var subdepts = soSearchForm.down('#subdepts');
			
			subdepts.setDisabled(true);
			subdepts.setValue(skuSubDept);
			var clas = soSearchForm.down('#clas');
			clas.setDisabled(true);
			clas.setValue(skuClass);
			lookup.setValue(parseInt(lookup.value.replace(/^(0+)/g, '')));
		}
		if(inValidList.length > 0){
			upcValidList = false;
			return false;
		}
	},
	
	disableByUpc:function(field){
    	console.log("Dashbord.js disableByUpc  7 - 1 ####### ");
    	var searchForm = field.up('form');
    	var skus = searchForm.down('#skus');
    	var skuDesc = searchForm.down('#skuDesc');
    	var skuDepts = searchForm.down('#depts');
    	var skuSubDepts = searchForm.down('#subdepts');
    	var skuClass = searchForm.down('#clas');
    	var vendorNo = searchForm.down('#vendorNos');
    	var vendorName = searchForm.down('#vendorName');
    	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');
    	var upcs = searchForm.down('#upcs');
    	var venNameMode = searchForm.down('#venNameMode');
    	var skuMode = searchForm.down('#skuMode');
    	if( upcs.getValue() != null
    			&& upcs.getValue().replace(/^\s+|\s+$/g,"").length == 0){
    		
    		if(globalVendorControl === '1'){
    			// Do nothing
    		}
    		else{ 
    			if(globalVendorControl === '2'){
    				console.log("Dashbord.js disableByUpc  7 - 2 ####### ");
    				vendorNo.setDisabled(false);
        			if(vendorName.getValue() != null && vendorName.getValue().length != 0) {
        				vendorName.setDisabled(true);
        				venNameMode.setDisabled(true);
        			}else{
        				vendorName.setDisabled(false);
        				venNameMode.setDisabled(false);
        			}
        			skus.setDisabled(false);
        			skus.setValue(null);
        			skuDesc.setDisabled(false);
    	    		skuMode.setDisabled(false);
    	    		skuDesc.setValue(null);
    	    		skuDepts.setDisabled(false);
    	    		skuSubDepts.setDisabled(false);
    	    		skuClass.setDisabled(false);
    			}else{
    				console.log("Dashbord.js disableByUpc  7 - 3 ####### ");
    				vendorNo.setDisabled(false);
    				vendorName.setDisabled(false);
		    		venNameMode.setDisabled(false);
		    		merchAnalyzer.setDisabled(false);
		    		skus.setDisabled(false);
		    		skuDesc.setDisabled(false);
		    		skuMode.setDisabled(false);
		    		skuDepts.setDisabled(false);
    			}
    		}
    	}else if(upcs.isDisabled()){
    		//    		do not do anything;
    	}else{
			if(globalVendorControl === '1' && upcs.isDisabled())
			{
    		}
			else if(globalVendorControl === '2' || !upcs.isDisabled())
			{
    			if(upcs.getValue().indexOf(',') === -1)
    			{
    				console.log("Dashbord.js disableByUpc  7 - 4 ####### ");
        			vendorNo.setDisabled(true);
        			skuDepts.setDisabled(true);
        			vendorName.setDisabled(true);
        			skuSubDepts.setDisabled(true);
        			skuClass.setDisabled(true);
        			skuDesc.setDisabled(true);
        			skus.setDisabled(true);
    	    		venNameMode.setDisabled(true);
    	    		skuMode.setDisabled(true);
    			}
    			if(upcs.getValue().indexOf(',') !== -1)
    			{
    				console.log("Dashbord.js disableByUpc  7 - 5 ####### ");
    				vendorNo.setValue(null);
        			vendorName.setValue(null);
        			skuDepts.setValue(null);;
        			skuSubDepts.setValue(null);
        			skuClass.setValue(null);
        			skuDesc.setValue(null);
        			skus.setValue(null);    				
        			vendorNo.setDisabled(true);
        			skuDepts.setDisabled(true);
        			vendorName.setDisabled(true);
        			skuSubDepts.setDisabled(true);
        			skuClass.setDisabled(true);
        			skuDesc.setDisabled(true);
        			skus.setDisabled(true);
    	    		venNameMode.setDisabled(true);
    	    		skuMode.setDisabled(true);
    			}
    		} 
    		else
    		{
    			console.log("Dashbord.js disableByUpc  7 - 6 ####### ");
    			vendorNo.setDisabled(true);
    			vendorNo.setValue(null);
	
	    		vendorName.setDisabled(true);
	    		vendorName.setValue(null);	
	    		skus.setDisabled(true);
	    		skus.setValue(null);
	
	    		skuDesc.setDisabled(true);
	    		skuDesc.setValue(null);
	
	    		skuDepts.setDisabled(true);
	    		skuDepts.setValue(null);
	    		
	    		venNameMode.setDisabled(true);
	    		skuMode.setDisabled(true);
    		}
    	}
    },
    
    
    loadSavedSearchesHandler: function (btn) {
    	console.log("Dashbord.js loadSavedSearchesHandler 1  !!!!####### ");    	
    	var searchForm = btn.up('form');
    }, 	
    
    saveInsSavingsSelectionHandler: function (btn) {
    	console.log("Dashbord.js saveInsSavingsSelectionHandler 1  ####### ");    	
    	var searchForm = btn.up('form');
    }, 	
    
    savedSearchesBtnHandler: function (btn) {
    	console.log("Dashbord.js savedSearchesBtnHandler 2 ####### ");    	
    	var searchForm = btn.up('form');
    }, 	
       
    resetIsmBtn: function (btn) {    	
    	var searchForm = btn.up('form');
    	var hiddenInstSavingsType = searchForm.down('#hiddenInstSavingsType').getValue();
    	//var venPartMode = searchForm.down('#venPartMode');
    	var venNameMode = searchForm.down('#venNameMode');
    	var skuMode = searchForm.down('#skuMode');
    
		searchForm.getForm().reset(); 		
    	
    	//set the store# to dashboard load storeNo
		//searchForm.down('#storeNos').setValue(params.storeNo);
		var vendorNos = searchForm.down('#vendorNos');
		vendorNos.setDisabled(false);
		vendorNos.focus(true, true);
    	searchForm.down('#vendorName').setDisabled(false);
    	venNameMode.setDisabled(false);
    	venNameMode.setText(i18n.label.startWith);
    	venNameMode.setTooltip(i18n.tooltip.startWith);
    	
    	searchForm.down('#merchAnalyzerComb').setDisabled(false);
    	searchForm.down('#skus').setDisabled(false);
    	searchForm.down('#skuDesc').setDisabled(false);
    	
    	skuMode.setDisabled(false);
    	skuMode.setText(i18n.label.startWith);
    	skuMode.setTooltip(i18n.tooltip.startWith);
    	
    	searchForm.down('#upcs').setDisabled(false);
    	searchForm.down('#depts').setDisabled(false);
    	searchForm.down('#subdepts').setDisabled(true);
    	searchForm.down('#clas').setDisabled(true);
    	//searchForm.down('#storeNos').setDisabled(params.multiStoreUser?false:true);
    	//searchForm.down('#skuStatus').setValue(['A','I']);
    	searchForm.down('#hiddenInstSavingsType').setValue(hiddenInstSavingsType);
    	    	
    	if(hiddenInstSavingsType == 'searchInsSavingsByGroup'){
			searchForm.down('#skuStatus').setValue('');	
			searchForm.down('#skus').setDisabled(true);
			searchForm.down('#upcs').setDisabled(true);
			searchForm.down('#skuDesc').setDisabled(true);
			searchForm.down('#skuMode').setDisabled(true);
			searchForm.down('#skuStatus').setDisabled(true);
			searchForm.down('#selectedCriteria').setDisabled(true);
		} 
    },
  
 	toProperCase : function (str) 
 	{
 		var strArray = str.split(' ');
 		var properCaseStr = '';
 		for (i = 0; i < strArray.length; i++)
 		{
 			properCaseStr = properCaseStr + strArray[i].substr(0,1).toUpperCase() +
 							strArray[i].substr(1).toLowerCase() + ' ';
 		}
 		return properCaseStr;
 	},/*  TODO: Delete after checking in with commentss
 	validateField: function(fld){
 		console.log(fld);
 		//switch (fld)
 	},
    validateForm: function(btn) {
    	var vm = this.getViewModel();
    	

    	
	    //SO technique
	    var searchForm = btn.up('form');
	    var valid = false;
		//get all lookup fields
	    var depts = removeLastComma(searchForm.down('#depts'));
		var subdepts = removeLastComma(searchForm.down('#subdepts'));
		var clas = removeLastComma(searchForm.down('#clas'));
		var vendorNos = removeLastComma(searchForm.down('#vendorNos'));
		var vendorName = searchForm.down('#vendorName');
		var skus = removeLastComma(searchForm.down('#skus'));
		var upcs = removeLastComma(searchForm.down('#upcs'));
		var merchAnalyzerComb = searchForm.down('#merchAnalyzerComb');
		if(depts.isLookupValid() && subdepts.isLookupValid() && clas.isLookupValid() &&
				skus.isLookupValid() && upcs.isLookupValid() && 
				vendorNos.isLookupValid() &&
				searchForm.getForm().isValid()){
			//if(!Ext.isEmpty(skus.getValue()) || !Ext.isEmpty(upcs.getValue()))
			//{
			//	vendorPartNo.setDisabled(true);
			//	venPartMode.setDisabled(true);
			//}
			valid = true;
    	}


    	
    	var invalidFieldFocus = null;
    	if (!this.lookupReference ('depts').isLookupValid()) {
    		invalidFieldFocus = this.lookupReference ('depts'); 
    	}
    	if (!this.lookupReference ('subdepts').isLookupValid()) {
    		if (invalidFieldFocus === null) {
    			invalidFieldFocus = this.lookupReference ('subdepts');	
    		}    		 
    	}    	
    	if (!this.lookupReference ('clas').isLookupValid()) {
    		if (invalidFieldFocus === null) {
    			invalidFieldFocus = this.lookupReference ('clas');	
    		}    		 
    	}    	
    	if (!this.lookupReference ('vendorNos').isLookupValid()) {
    		if (invalidFieldFocus === null) {
    			invalidFieldFocus = this.lookupReference ('vendorNos');
    			invalidFieldFocus.keyValidation(invalidFieldFocus);
    		}    		 
    	}
    	// TODO: vendorName.isLookupValid() not defined
    	//if (!this.lookupReference ('vendorName').isLookupValid()) {
    	//	if (invalidFieldFocus === null) {
    	//		invalidFieldFocus = this.lookupReference ('vendorName');	
    	//	}    		 
    	//}    	
    	// TODO: vendorName.isLookupValid() not defined
    	//if (!this.lookupReference ('eventnumber').isLookupValid()) {
    	//	if (invalidFieldFocus === null) {
    	//		invalidFieldFocus = this.lookupReference ('eventnumber');	
    	//	}    		 
    	//}
    	if (!this.lookupReference ('skus').isLookupValid()) {
    		if (invalidFieldFocus === null) {
    			invalidFieldFocus = this.lookupReference ('skus');	
    		}    		 
    	}
    	if (!this.lookupReference ('upcs').isLookupValid()) {
    		if (invalidFieldFocus === null) {
    			invalidFieldFocus = this.lookupReference ('upcs');	
    		}    		 
    	}
    	//TODO: Do we need isLookupValid here?
    	if (!this.lookupReference ('skuDesc').isValid()) {
    		if (invalidFieldFocus === null) {
    			invalidFieldFocus = this.lookupReference ('skuDesc');	
    		}    		 
    	}
    	if (!this.lookupReference ('skustatus').isValid()) {
    		if (invalidFieldFocus === null) {
    			invalidFieldFocus = this.lookupReference ('skustatus');	
    		}    		 
    	}
    	if (!this.lookupReference ('merchAnalyzerComb').isLookupValid()) {
    		if (invalidFieldFocus === null) {
    			invalidFieldFocus = this.lookupReference ('merchAnalyzerComb');	
    		}    		 
    	}
    	
    	//ratingFlagList
    	//var fRatingList = this.getView().ratingFlagList;    
    	//for (var i=0; i < fRatingList.length; i++) {
    	//	if (!fRatingList[i].isValid()) {
    	//		if (invalidFieldFocus === null) {
    	//			invalidFieldFocus = fRatingList[i];	
    	//		}    		     			
    	//	}    			
    	//}

        if (invalidFieldFocus !== null) {
        	invalidFieldFocus.focus();
        	return false;
        } 
        return true;
    },*/	

 	searchBtnHandler: function (btn, origin, suppressWarning) {
	    var view = this.getView();
	    var searchForm = view.down('instantsavingsmaintsearch'); 	
    	var instSavingsType = searchForm.down('#hiddenInstSavingsType').getValue();
	    var store;
	    var searchMode;
    	if (instSavingsType == 'searchInsSavingsBySku') {
	           store = view.down('#instantSavingsSkuGrid').getStore();
	           searchMode = 'SearchSku';
	    } else if (instSavingsType == 'searchInsSavingsByGroup') {
	           store = view.down('#instantSavingsGroupGrid').getStore();
	           searchMode = 'SearchGroup';
	    }
 		if (this.checkAndPromptAboutUnsavedChanges(store, searchMode, btn, origin, suppressWarning)){
 	    	this.searchExecute(btn, origin, suppressWarning);
 	    }
 	},
 	searchExecute: function (btn, origin, suppressWarning) {
 		var view = this.getView();
 		var searchForm = btn.up('form');
 		var instantSavingsSkuGrid = Ext.ComponentQuery.query('#instantSavingsSkuGrid')[0]
 		       
     	var deptsLookup = Ext.ComponentQuery.query('#depts')[0];
     	var selectedCriteria = searchForm.down('#selectedCriteria').getValue();
     			
     	var vendorNo = searchForm.down('#vendorNo');
		var vendorNos = removeLastComma(searchForm.down('#vendorNos'));
		var vendorName = searchForm.down('#vendorName');
		var skus = removeLastComma(searchForm.down('#skus'));
		var skuDesc = searchForm.down('#skuDesc');		
		var upcs = removeLastComma(searchForm.down('#upcs'));
		var depts = removeLastComma(searchForm.down('#depts'));
		var subdepts = removeLastComma(searchForm.down('#subdepts'));
		var clas = removeLastComma(searchForm.down('#clas'));
		var statuses = searchForm.down('#skuStatus').getValue()
		
		/*
		console.log("Dashbord.js searchBtnHandler 3  ####### btn, origin = "+btn, origin +" origin = "+origin);
     	console.log("Dashbord.js searchBtnHandler  ####### searchForm = "+searchForm +" deptsLookup = "+deptsLookup);     	
     	console.log("Dashbord.js searchBtnHandler 3 - 1  ####### selectedCriteria = "+selectedCriteria);
		console.log("Dashbord.js searchBtnHandler 3 - 2  ####### skuStatus = "+searchForm.down('#skuStatus'));
		console.log("Dashbord.js searchBtnHandler 3 - 2 - 1  ####### skuStatus = "+searchForm.down('#skuStatus').getValue());
		console.log("Dashbord.js searchBtnHandler 3 - 2 - 2  ####### statuses = "+statuses);		
		*/
		
		if(Ext.isEmpty(statuses)){
			statuses = 'A,I,N,D'
		}
		//console.log("Dashbord.js searchBtnHandler 3 - 2 - 2  ####### statuses = "+statuses);		
		//console.log("Dashbord.js searchBtnHandler 3 - 3  ####### storeNos = "+searchForm.down('#storeNos'));		
		//var storeNos = removeLastComma(searchForm.down('#storeNos'));
		//var storeNo = removeLastComma(searchForm.down('#storeNo'));
		
		var skuMode = searchForm.down('#skuMode');    	
		var venNameMode = searchForm.down('#venNameMode');		
		var merchAnalyzerComb = searchForm.down('#merchAnalyzerComb');
		var eventNumber = searchForm.down('#eventnumber');	
		//var merchcatno = searchForm.down('#merchcatno');
		var hiddenInstSavingsType = searchForm.down('#hiddenInstSavingsType').getValue();
		
		//console.log("Dashbord.js searchBtnHandler  3 - 3 - 1 eventNumber = "+eventNumber.getValue() +" hiddenInstSavingsType = "+hiddenInstSavingsType);
		//console.log("Dashbord.js searchBtnHandler  3 - 3 - 2 merchAnalyzerComb.isValid() = "+merchAnalyzerComb.isValid() +" MerchAnalyzer = "+merchAnalyzerComb.getValue());
		//console.log("Dashbord.js searchBtnHandler  3 - 3 - 3 hasInvalidField = "+searchForm.getForm().hasInvalidField() +" isValid = "+searchForm.getForm().isValid());
       	
		//Using isValid() was causing the error mouseover to go blank.  Seems like a bug. 
		//   Using wasValid fixed it.  Fields are validated onBlur every time so wasValid is fine. 
		var valid = searchForm.getForm().wasValid;
		//var valid = searchForm.getForm().isValid();
		if (valid && searchForm.getForm().hasInvalidField() ) {
			valid=false;
		}
		//TODO: consolidate 'valid' branches
		//Check google-type fields
		if (valid && (!this.validateMerchAnalyzer(merchAnalyzerComb) 
				      || !this.validateEventNumber(eventNumber) )){
			valid=false;
		}
		var blankFrm = false;
		var strErr = i18n.message.formerrors;
		
		//at least one search field must be filled in, or a filter
 		console.log("Dashbord.js searchBtnHandler 3 - 3 - 4  #######! ");
		if ( 
			Ext.isEmpty(vendorNos.getValue()) &&
			Ext.isEmpty(vendorName.getValue()) &&    			
			(Ext.isEmpty(merchAnalyzerComb.getValue())) &&
			Ext.isEmpty(skuDesc.getValue()) &&
			Ext.isEmpty(skus.getValue()) &&
			Ext.isEmpty(upcs.getValue()) &&
			Ext.isEmpty(depts.getValue()) &&
			Ext.isEmpty(subdepts.getValue()) &&
			Ext.isEmpty(clas.getValue()) && 
			Ext.isEmpty(eventNumber.getValue()) &&
			Ext.isEmpty(merchAnalyzerComb.getValue())
		) { 
			blankFrm = true;
		    //Blank form is only invalid when searching SKUs
			var hiddenInstSavingsTypeField = Ext.ComponentQuery.query('#hiddenInstSavingsType')[0]
			if (hiddenInstSavingsTypeField.getValue()==='searchInsSavingsBySku') {
				valid = false;
				strErr = i18n.message.refinesearch;
			}
		}

		if (!valid) {
			if (suppressWarning === undefined || suppressWarning===false){
    			Ext.Msg.show({
    				title:i18n.title.AppName,
    				msg: strErr,
    				buttons: Ext.Msg.OK,
    				modal:true,
    				closable : true,
    				minWidth: 200,
    				icon: Ext.MessageBox.ERROR,
    				fn: function(btn, text)
        			{
		    			var depts = searchForm.down('#depts');
		    			depts.focus(true, true);
        			}
    			}, this);
			}
			instantSavingsSkuGrid.getStore().removeAll();
			instantSavingsSkuGrid.down('#pagingBar').onLoad();
			return true;
		}

     	///////////////////////////////////////////////////////////////
     	//Clear grid before loading new results
     	//Only clear after check for a valid search
     	instantSavingsSkuGrid.getStore().removeAll();
		instantSavingsSkuGrid.down('#pagingBar').onLoad();
		
		var filters = searchForm.down('#filters'); ////
		var elasticSearch = searchForm.down('#elasticSearch');
		var start = searchForm.down('#start');
		var limit = searchForm.down('#limit');
		var maxCount = searchForm.down('#maxCount');
		var sort = searchForm.down('#sort');
		var dir = searchForm.down('#dir');
		
		var lang = searchForm.down('#lang'); 
		var country = searchForm.down('#country');
		var conceptShortName = searchForm.down('#conceptShortName');
		var concept = searchForm.down('#concept');
		var use53FiscalWeeks = searchForm.down('#use53FiscalWeeks');   //////		
		var valid=false;
		
		console.log("Dashbord.js searchBtnHandler 3 - 4  ####### vendorNo = "+searchForm.down('#vendorNo'));
	    console.log("Dashbord.js searchBtnHandler 3 - 5  ####### clas = "+clas.getValue());
	      
	    console.log("Dashbord.js searchBtnHandler 3 - 5  ####### skuMode = "+skuMode.getText());
	    console.log("Dashbord.js searchBtnHandler 3 - 5  ####### venNameMode = "+venNameMode.getText());
		
    	var extraParams = {};
        var extraParams = {         
        		
         vendorNo: '', // vendorNo.getValue(),	
         vendorNos: vendorNos.getValue(),
         vendorName : vendorName.getRawValue(),
         skus: skus.getValue(),
         skuDesc: skuDesc.getValue(),
         upcs: upcs.getValue(),
         depts: depts.getValue(),
         subdepts: subdepts.getValue(),
         clas: clas.getValue(),
         statuses: statuses, // 'A,I', //statuses.getValue(),
         storeNos: '1' , //storeNos.getValue(),
         storeNo: '1', // storeNo.getValue(),
         skuMode: skuMode.getText(),
         venNameMode: venNameMode.getText(),
         
         merchAnalyzerComb: merchAnalyzerComb.getValue(),
         merchcatno: '',  //merchcatno.getValue(),  /////
         //eventNumber: eventNumber.getValue(),
         events: eventNumber.getValue(),
         selectedCriteria: selectedCriteria,
         //filters: '',
         elasticSearch: true,
         maxCount: 60000,
         
         //appconstant
         //start: '',
         //limit: '',
         //maxCount: '',
         //sort: '',
         //dir: '',         
      	 lang: params.lang,
         userId: params.userid,        
         country: params.country,
         concept: params.concept,
         conceptShortName: params.conceptShortName
        };
       
    	var instSavingsType = searchForm.down('#hiddenInstSavingsType').getValue();
    	console.log("Dashbord.js searchBtnHandler 3 - 6 - 1  ####### instSavingsType = "+instSavingsType);
	       
	    var store = '';
	    if (instSavingsType == 'searchInsSavingsBySku') {
	           store = view.down('#instantSavingsSkuGrid').getStore();
	    } else if (instSavingsType == 'searchInsSavingsByGroup') {
	           //store = view.down('#instantSavingsMaintGroupGrid').getStore();
	           store = view.down('#instantSavingsGroupGrid').getStore();
	    } else {
	           store = view.down('#instantSavingsSkuGrid').getStore();
	    }

	    //RC ::  Do it later   
	  	if (Ext.isDefined(store.sorters) && store.sorters != null) {
	  		store.sorters.clear();
	  	}
	    
        store.proxy.extraParams = extraParams;
		store.loadPage(1);
		store.load({
			callback: function(records, operation, success) {
    			if(!success){
    				if(!Ext.isEmpty(operation._response))
        			{
        				var json = Ext.decode(operation._response.responseText);     				
            			if(!Ext.isEmpty(json) && !Ext.isEmpty(json.error))
            			{ 
            				Ext.MessageBox.show({	
		    					title:i18n.title.AppName,
		    					msg: json.error, //homeStore+i18n.text.securtyError5,
		    					buttons: Ext.Msg.OK,
		    					modal:true,
		    					closable : true,
		    					minWidth: 200,
		    					icon: Ext.MessageBox.ERROR,
		    					fn: function(button,text){
		    						//storeLookup.markInvalid(homeStore+i18n.text.securtyError5);
		    						//storeLookup.focus(true, true);
		    					}
		    				});	 
            			}
        			}	
    		    } 
    			deptsLookup.focus(true, true);
    		},
            scope: this
    	});
    
   }, 
   validateMerchAnalyzer: function(combo){
		if (!combo.value || combo.value.length === 0){
			return true;
		} else {
			if (combo.value.length === 0){
	   			combo.unsetActiveError();
				return true;
			} else {
				combo.store.load({
					   params:{merchAnalyzer: combo.getRawValue()},
					   loadtimer: 60000
	 			});
	    		if (combo.store.find('merchAnalyzerComb', combo.getRawValue(), 0, false, false, true) == -1) { 
	    			//found
	        		combo.markInvalid(combo.getRawValue() + ' is invalid. Please click one of the suggestions.');
	        		return false;
	    		} else {
	    			//not found
	    			combo.unsetActiveError();
	    			return true;
	    		}
			}
		}
	},
   validateEventNumber: function(combo){
		if (!combo.value || combo.value.length === 0){
			return true;
		} else {
			if (combo.value.length === 0){
	   			combo.unsetActiveError();
				return true;
			} else {
				/*
				var eventNums = combo.value.split(",");
    			combo.unsetActiveError();
				//TODO: Add validation for multiple
    			for (i = 0; i < eventNums.length; i++)
		 		{
		 			//TODO: Does reload work this quickly.  
					combo.store.load({
						   params:{EVENTNO: eventNums[i]},
						   loadtimer: 60000
		 			});
		    		if (combo.store.find('EVENTNO', eventNums[i], 0, false, false, true) == -1) { 
		    			//found
		        		combo.markInvalid(eventNums[i] + ' is invalid. Please click one of the suggestions.');
		        		return false;
		    		} else {
		    			//not found
		    		}
		 		}
    			return true;
*/
				if (combo.value.indexOf(",") >= 0){
					//TODO: Add validation for multiple
		   			combo.unsetActiveError();
					return true;
				} else {
					combo.store.load({
						   params:{EVENTNO: combo.value},
						   loadtimer: 60000
		 			});
		    		if (combo.store.find('EVENTNO', combo.value, 0, false, false, true) == -1) { 
	    			//found
	        		combo.markInvalid(combo.value + ' is invalid. Please click one of the suggestions.');
	        		return false;
		    		} else {
		    			//not found
		    			combo.unsetActiveError();
		    			return true;
		    		}
		    		
				}
			}
		}
	},
   /*
   getInstantSavingsRecords: function() {	
	    var view = this.getView();  
	    var grid = view.down('#instantSavingsSkuGrid');
		var instantSavingsList = [];
       console.log("getInstantSavingsRecords 5 - 0 - 1 this._deletedInstantRecords.length = "+this._deletedInstantRecords.length +" _modifedInstantRecords.length = "+this._modifedInstantRecords.length);
       console.log("getInstantSavingsRecords 5 - 0 - 1 this._deletedInstantRecords = "+this._deletedInstantRecords +" _modifedInstantRecords = "+this._modifedInstantRecords);

       //Greg
		var store = view.down('#instantSavingsSkuGrid').getStore();
		var instantSavingsChanges = [];
		var rs = store.getModifiedRecords();
		for (var i = 0, ln = rs.length; i < ln; i++) {
			instantSavingsList.push(rs[i]);
			instantSavingsChanges.push(rs[i].getChanges());
		}
		console.dir(instantSavingsList);
		console.dir(instantSavingsChanges);
		
		Ext.each(instantSavingsList, function(record, index){
       	record.data.saveDeleteFlag = (record.data.instSaveElig ? 1 : 0)
	    },this);
		
		return instantSavingsList;
   },*/
   saveInstantSavingsSkuHandler: function(btn, pagingClickFlag) {
	   this.saveInstantSavingsBySku(pagingClickFlag)
   },
   saveInstantSavingsGrpHandler: function(btn, pagingClickFlag) {
	   this.saveInstantSavingsByGrp(pagingClickFlag)
   },
   saveInstantSavingsSkuBeforeChange: function(pagingtoolbar, newPage, eOpts) {
	   //return this.saveInstantSavingsBeforeChange(pagingtoolbar, newPage, eOpts);
	   //return this.checkAndPromptAboutUnsavedChangs(pagingtoolbar.store, "testFunc", newPage);
	   var action="SkuSave";
	   if (newPage==pagingtoolbar.store.currentPage){
		   
		   action="Refresh";
	   }
	   return this.checkAndPromptAboutUnsavedChanges(pagingtoolbar.store, action, newPage);
   },
   saveInstantSavingsGrpBeforeChange: function(pagingtoolbar, newPage, eOpts) {
	   var action="GroupSave";
	   if (newPage==pagingtoolbar.store.currentPage){
		   
		   action="Refresh";
	   }
	   return this.checkAndPromptAboutUnsavedChanges(pagingtoolbar.store, action, newPage);
	   //return this.saveInstantSavingsBeforeChange(pagingtoolbar, newPage, eOpts);
   },
   checkAndPromptAboutUnsavedChanges: function(gridStore, onSuccessFunc, arg1, arg2, arg3) {
		 	console.log("InstantSavingsMaintController checkAndPromptAboutUnsavedChanges !!!");
		
		    var unsavedChanges = false;
		    if (gridStore.getModifiedRecords().length >0){
	            unsavedChanges = true;
		    }
		
	    	var me=this;
		    if (unsavedChanges) {
		    	var title = 'Unsaved Changes';
		    	var prompt = 'Before navigating to a different page, your changes will be saved.  Save changes and continue to the requested page?';
		    	var buttons = Ext.Msg.YESNO;
		    	var butTextYes = 'Yes';
		    	var butTextNo = 'No';
		    	var butTextCancel;
		    	var iconMsgBox = Ext.Msg.QUESTION;
		    	var arrButtons = {
                    	yes: butTextYes,
                        no: butTextNo
                    };
            	switch (onSuccessFunc){
            		case 'SwitchToGroup':
	        		case 'SwitchToSku':
	        		case 'SearchSku':
	        		case 'SearchGroup':
	        			prompt = 'Before leaving this page, what do you want to do with your unsaved changes?';
	        			buttons = Ext.Msg.YESNOCANCEL;
                        butTextYes = 'Save & Continue';
                        butTextNo = 'Continue w/o Saving';
                        butTextCancel = 'Return to Editing';
                        arrButtons = {
                            	yes: butTextYes,
                                no: butTextNo ,
                                cancel: butTextCancel
                        };
	        			break;
	        		case 'Refresh':
	        			prompt = 'Refreshing will lose any changes that have been made.  Continue?';
	        			buttons = Ext.Msg.YESNO;
	        			break;
	        		case 'SkuSave':
	        		case 'GroupSave':
	        		default:
	        			prompt = 'Before navigating to a different page, what do you want to do with your unsaved changes?';
	        			buttons = Ext.Msg.YESNOCANCEL;
	                    butTextYes = 'Save & Continue';
	                    butTextNo = 'Continue w/o Saving';
	                    butTextCancel = 'Return to Editing';
                        arrButtons = {
                            	yes: butTextYes,
                                no: butTextNo ,
                                cancel: butTextCancel
                        };
	        	}
            	Ext.Msg.show({
                    title : title,
                    msg : prompt,
                    width : 450,
                    closable : false,
                    buttons : buttons,
                    icon : iconMsgBox,
                    buttonText : arrButtons,
                    multiline : false,
		            fn: function(button,text) {
		             	console.log("InstantSavingsMaintController checkAndPromptAboutUnsavedChanges !!!  "+onSuccessFunc);
	                	switch (onSuccessFunc){
                			case 'Refresh':
        		                if (button === 'yes'){
        		                	gridStore.loadPage(arg1);
        		        			me.updateHeaderCheckBoxSku();
        		        			me.updateHeaderCheckBoxGroup();
        		                }
	                			break;
	                		case 'SkuSave':
        		                if (button === 'yes'){
        		                	me.saveInstantSavingsBySku(true,false);
        		                }
        		                if (button === 'yes' || button === 'no'){
        		                	gridStore.loadPage(arg1);
        		        			me.updateHeaderCheckBoxSku();
        		                }
			                    break;
	                		case 'GroupSave':
        		                if (button === 'yes'){
        		                	me.saveInstantSavingsByGrp(true,false);
        		                }
        		                if (button === 'yes' || button === 'no'){
        		                	gridStore.loadPage(arg1);
        		        			me.updateHeaderCheckBoxGroup();
        		                }
	                			break;
	                		case 'SwitchToSku':
        		                if (button === 'yes'){
        		                	me.saveInstantSavingsByGrp(true,false);
        		                }
        		                if (button === 'yes' || button === 'no'){
        		                	me.LoadSkuGridView(arg1);   //if Yes or No (not Cancel)
        		        			me.updateHeaderCheckBoxSku();
        		                }
	                			break;
	                		case 'SwitchToGroup':
        		                if (button === 'yes'){
        		                	me.saveInstantSavingsBySku(true,false);
        		                }
        		                if (button === 'yes' || button === 'no'){
        		                	me.LoadGroupGridView(arg1);
        		        			me.updateHeaderCheckBoxGroup();
        		                }
	                			break;
	                		case 'SearchSku':
        		                if (button === 'yes'){
        		                	me.saveInstantSavingsBySku(true,false);
        		                }
        		                if (button === 'yes' || button === 'no'){
        		                	me.searchExecute(arg1, arg2, arg3);
        		        			me.updateHeaderCheckBoxSku();
        		                }
	                			break;
	                		case 'SearchGroup':
        		                if (button === 'yes'){
        		                	me.saveInstantSavingsByGrp(true,false);
        		                }
        		                if (button === 'yes' || button === 'no'){
        		                	me.searchExecute(arg1, arg2, arg3);
        		        			me.updateHeaderCheckBoxGroup();
        		                }
	                			break;
	                		default:
			                    //do nothing.  event has already been cancelled
	                	}
	                    return true;
		            }
                });
				return false;
		    } else {
		    	//No unsaved changes. Clear header checkbox
            	switch (onSuccessFunc){
	    			case 'Refresh':
	        			break;
	        		case 'SkuSave':
	        		case 'SwitchToSku':
	        		case 'SearchSku':
	    		 		//TODO: Move to function
	        			me.updateHeaderCheckBoxSku();
	        			//var instantSavingsSkuGrid = Ext.ComponentQuery.query('#instantSavingsSkuGrid')[0]
	        			//var checkboxEl = instantSavingsSkuGrid.getEl().down("."+Ext.baseCSSPrefix+'grid-checkcolumn')
    	                //checkboxEl.removeCls(Ext.baseCSSPrefix + 'grid-checkcolumn-checked');
	                    break;
	        		case 'GroupSave':
	        		case 'SwitchToGroup':
	        		case 'SearchGroup':
	    		 		//TODO: Move to function
	        			me.updateHeaderCheckBoxGroup();
	    		 		//var instantSavingsGroupGrid = Ext.ComponentQuery.query('#instantSavingsSkuGrid')[0]
	        			//var checkboxEl = instantSavingsGroupGrid.getEl().down("."+Ext.baseCSSPrefix+'grid-checkcolumn')
    	                //checkboxEl.removeCls(Ext.baseCSSPrefix + 'grid-checkcolumn-checked');
	        			break;
	        	}
		    	return true;
		    }
		},
	updateHeaderCheckBoxSku: function(){
		this.updateHeaderCheckBox(Ext.ComponentQuery.query('#instantSavingsSkuGrid')[0]);
	},
	updateHeaderCheckBoxGroup: function(){
		this.updateHeaderCheckBox(Ext.ComponentQuery.query('#instantSavingsGroupGrid')[0]);
	},
	updateHeaderCheckBox: function(grid){
		var checkboxEl = grid.getEl().down("."+Ext.baseCSSPrefix+'grid-checkcolumn')
        checkboxEl.removeCls(Ext.baseCSSPrefix + 'grid-checkcolumn-checked');
	},
	saveInstantSavingsBySku: function(suppressNoChangesMsg, bShowSuccessMsg) {	
	    var view = this.getView();  
	    var grid = view.down('#instantSavingsSkuGrid');
 		var instantSavingsList = [];
        //console.log("saveInstantSavingsBySku 5 - 0 - 1 this._deletedInstantRecords.length = "+this._deletedInstantRecords.length +" _modifedInstantRecords.length = "+this._modifedInstantRecords.length);
        //console.log("saveInstantSavingsBySku 5 - 0 - 1 this._deletedInstantRecords = "+this._deletedInstantRecords +" _modifedInstantRecords = "+this._modifedInstantRecords);
        //console.log("saveInstantSavingsBySku 5 - 0 - 1 suppressNoChangesMsg = "+suppressNoChangesMsg);

        //Greg
 		var store = view.down('#instantSavingsSkuGrid').getStore();
 		var instantSavingsChanges = [];
 		var rs = store.getModifiedRecords();
 		for (var i = 0, ln = rs.length; i < ln; i++) {
 			instantSavingsList.push(rs[i]);
 			instantSavingsChanges.push(rs[i].getChanges());
 		}
 		console.dir(instantSavingsList);
 		console.dir(instantSavingsChanges);
 		
 		Ext.each(instantSavingsList, function(record, index){
        	record.data.saveDeleteFlag = (record.data.instSaveElig ? 1 : 0);
        	
        	//When saving SKUs, populate the other fields used for groups with 0
        	record.data.vendorNo = 0;
        	record.data.dept = 0;
        	record.data.subDept = 0;
        	record.data.clas = 0;
        	record.data.eventName = 0;
        	record.data.merchGroup = "";
	    },this);
 		
 		//Anything to save?
 		if(instantSavingsList.length == 0){
			console.log("saveInstantSavingsBySku 5 - 0 - 2 suppressNoChangesMsg = "+suppressNoChangesMsg);
 			if(suppressNoChangesMsg !== undefined && !suppressNoChangesMsg){
				Ext.Msg.show({
					title:i18n.title.AppName,
			        //msg        : 'Please make changes to update.',
			        msg		   : i18n.message.makechangestoupdate,
			        width      : 270,
			        buttons    : Ext.MessageBox.OK,				        
			        icon       : Ext.MessageBox.INFO
			     });
 			} 			 
 			return;
		}

	 	var instantSavingsListData = [];
		Ext.each(instantSavingsList, function(rec, index){
			instantSavingsListData.push(rec.data);	
	    });			

	 	this.saveInstantSavingsAjaxCall(instantSavingsListData, grid, bShowSuccessMsg);	
 		//grid.editingPlugin.getEditor().form.reset();
	 	store.load();
	 	grid.getView().refresh();
	 
	},	
	saveInstantSavingsAjaxCall: function(instantSavingsListParam, grid, bShowSuccessMsg) {	
		    console.log("saveInstantSavingsAjaxCall Click");		    
		    //var eligStates = '1';
			//var ids = '0';
			//var userId = '1';		    
			Ext.getBody().mask("Please wait...");			
			Ext.Ajax.request({
				//url : FSUtils.contextAccountMaintenance + 'SaveChanges',
				url: 'search.htm?action=saveInstantSavings', 
				method : 'POST',
				params : {
					//instantSavingsList : JSON.stringify(instantSavingsList),
					instantSavingsList : JSON.stringify(instantSavingsListParam),
					//eligStates: eligStates,
					//ids: ids,
					userId: params.userid,
			        lang: params.lang,
			        country: params.country,
			        concept: params.concept,
			        conceptShortName: params.conceptShortName
				},
				success: function(request, result){						
					var response = Ext.JSON.decode(request.responseText);				
					console.log("saveInstantSavingsAjaxCall Click response ==  "+response);
					
					Ext.getBody().unmask();		
					if(response.success){	
						grid.getStore().load();
						grid.getView().refresh();
						
						//Ext.Msg.alert('Success', 'Instant Savings has been saved successfully.');
						if (bShowSuccessMsg === undefined || bShowSuccessMsg){
							Ext.Msg.alert('Success', i18n.message.successmessage);
						}	
					}else{					
						grid.getSelectionModel().deselectAll();
						//Ext.Msg.alert('Failure', response.reason);
						//Ext.Msg.alert('Failure', 'Some or All Instant Savings was not successfully process, please re-transmit');
						Ext.Msg.alert('Failure', i18n.message.failuremessage);
					}
				}
			});
		    
	}, 
	 
	showObject: function(obj ) {
		  var result = "";
		  for (var p in obj) {
		    if( obj.hasOwnProperty(p) ) {
		      result += p + " , " + obj[p] + "\n";
		    } 
		  }              
		  return result;
	 },
	 
	 instantSavingObject: function(sku, storeNo, vendorNo, dept, subDept  ) {
		    this.sku = sku; 
		    this.storeNo = storeNo; 
		    this.vendorNo = vendorNo;  
		    this.dept = dept; 
		    this.subDept = subDept;
	} ,
	 
	 checkboxSelectionChange_old: function(sm, record, index, eOpts) {
     	console.log("!!!! 1 @@@@ onCheckboxModelSelect record.length = "+record.length);
     	
     	//var instantSavingsList = new Array();
     	var instantSavingsList = [];
     	var schedulebList = new Array();
     	//var gridModel = this.getViewModel();
     	
     	var view = this.getView();              	
     	var grid = view.down('#instantSavingsSkuGrid');

		var upadateFlag = true;
		var upadateErrorFlag = true;
		
	
		for (var j = 0; j < schedulebList.length; j++){
			  //console.log("sku 1 - 2 ====== "+schedulebList[j].sku);			  
			  var student = new this.instantSavingObject(schedulebList[j].sku, schedulebList[j].storeNo, schedulebList[j].vendorNo, schedulebList[j].dept, schedulebList[j].subDept); 
			  instantSavingsList.push(student);
			  
			}
		
		
		Object.keys(instantSavingsList).forEach(function(key) {
		    console.log(" 1 - 4  ------>"+key, instantSavingsList[key]);
		});
     },
     
	 checkboxSelectionChange: function(sm, records, index, eOpts) {
     	
     	//var instantSavingsList = new Array();
     	var instantSavingsList = [];
     	var schedulebList = new Array();
     	//var gridModel = this.getViewModel();
     	
     	var view = this.getView();              	
     	var grid = view.down('#instantSavingsSkuGrid');
		var upadateFlag = true;
		var upadateErrorFlag = true;
		//////////////////////////////////////////////
		
		Ext.each(records, function(rec, index){
			instantSavingsList.push(rec.data);	
	    	//console.log("---------------> rec.data = "+rec.data +" sku = "+rec.data.sku);
	    });
		//Object.keys(instantSavingsList).forEach(function(key) {
		//    console.log(" 1 - 4  ------>"+key, instantSavingsList[key]);
		//});
     },
     
     checkArray: function (arr, skuValue) {
         if(arr != null && arr.length >0){
             for(var i=0;i<arr.length;i++){
                 if(arr[i] == skuValue)
                     return true;
             }
         }
          return false;
      },
      removeItemFromArray: function (array, skuValue) {
          var index = array.indexOf(skuValue);
          if (index> -1) {
             array.splice(index, 1);
          }
      },
      
     showCheckBoxSelection: function (model, record, index, eOpts) {
         record.data.instsaveElg="selected";
         
         if(!this.checkArray(this._modifedInstantRecords, record.data.sku)){
              this._modifedInstantRecords.push(record.data.sku);
          }

          this.removeItemFromArray(this._deletedInstantRecords, record.data.sku);
     },

     showCheckBoxUnSelection: function (model, record, index, eOpts) {
         record.data.instsaveElg=null;

          if(!this.checkArray(this._deletedInstantRecords, record.data.sku)){
              this._deletedInstantRecords.push(record.data.sku);
          }
          console.log("checkBoxUnSelection 3 - 1  BEFORE _deletedInstantRecords = "+this._deletedInstantRecords.length +" _modifedInstantRecords.length = "+this._modifedInstantRecords.length);

          this.removeItemFromArray(this._modifedInstantRecords, record.data.sku);
     },

     saveDataHandler: function (btn) {
        var grid = Ext.ComponentQuery.query('#usergrid')[0];
        //var instantSavingsList = new Array();
      	var instantSavingsList = [];      	
      	var modifedRecords = grid.getSelectionModel().getSelection();
 		console.log("saveDataHandler 4 - 2 modifedRecords = "+modifedRecords +" modifedRecords.length = "+modifedRecords.length);

        /*
        Ext.each(records, function(rec, index){
             //alert("Store listeners $$$ LOOP rec = "+rec +" item.data = "+rec.data.forumid +" index = "+index);
             //if(rec.data.forumid == 40 || rec.data.forumid==41){
             if(rec.data.postid == 602876 || rec.data.postid==602456){
                 //alert("Store listeners $$$ LOOP rec = "+rec +" item.data = "+rec.data.forumid +" index = "+index);
                 //grid.getSelectionModel().select(index);
                 grid.getSelectionModel().select(index,true,false);
             }
        },this);
        */

     },

     /*saveInstantSavingsPaging: function(button) {
    	    var instantSavingsRecords = this.getInstantSavingsRecords();
    	    console.log("saveInstantSavingsPaging paing click 77 - 2 Click instantSavingsRecords length =  "+instantSavingsRecords.length);
    	    
//    	    if(instantSavingsRecords.length > 0){    	    	
//    	    	Ext.Msg.show({
//                    title:'Close confirmation'
//                   ,msg:'Do you want to save modified records?'
//                   ,buttons:Ext.Msg.YESNO
//                   ,callback:function(btn) {
//                       if('yes' === btn) {                  	   
//                    	   this.saveInstantSavingsBySku(button, true);
//                       } else {
//                    	   return;
//                       }
//                   }
//               });
//    	    }
    	    
		    var view = this.getView(); 
	        this.saveInstantSavingsBySku(button, true);
	 },*/
	 
	 saveModifiedRecordsPaging: function(records) {	
			Ext.getBody().mask("Please wait...");
			
			Ext.Ajax.request({
				url: 'search.htm?action=saveInstantSavings', 
				method : 'POST',
				params : {
					//schedulebBeans : JSON.stringify(schedulebList),
					schedulebBeans : JSON.stringify(records),
					updateSchedbFlag : 'N'
				},
				success: function(request, result){						
					var response = Ext.JSON.decode(request.responseText);				
					console.log("saveModifiedRecordsPaging paing click 77 - 2 Click response =  "+response);
					console.log("saveModifiedRecordsPaging paing click 77 - 2 Click response =  "+response.success);
					
					Ext.getBody().unmask();
					if(response.success){							
						//myMask.hide();
						//alert("scheduleBFinalSubmitFlag 2 = "+Scheduleb.util.Utils.scheduleBFinalSubmitFlag);
						//Scheduleb.util.Utils.scheduleBFinalSubmitFlag=true;
						/*grid.getStore().load({
							//params : {
							//	schedulebList : schedulebList
							//}
						});*/
						//Ext.Msg.alert('Success', 'Instant Savings has been saved successfully.');
						Ext.Msg.alert('Success', i18n.message.successmessage);
					}else{					
						////////////////////////////////////////grid.getSelectionModel().deselectAll();
						//Ext.Msg.alert('Failure', response.reason);
						//Ext.Msg.alert('Failure', 'Some or All Instant Savings was not successfully process, please re-transmit.');
						Ext.Msg.alert('Failure', i18n.message.failuremessage);
					}
					//alert("scheduleBFinalSubmitFlag 2 = "+Scheduleb.util.Utils.scheduleBFinalSubmitFlag);
				}
			});		
	 },
	 saveModifiedInstantPagingClick: function(button) {	
		    console.log("saveModifiedInstantPagingClick paing click66 Click");
	 },
	 
	 ShowInsSavingsByGroupHandler: function (btn) {
	   if (this.checkAndPromptAboutUnsavedChanges(Ext.getStore('instantsavingsskustore'), 'SwitchToGroup', btn)){
		   this.LoadGroupGridView(btn);
	   }
	 },
	 LoadGroupGridView: function (btn) {
	   var view = this.getView();	
       var grid = view.down('#instantSavingsGroupGrid');
       store = grid .getStore();
       store.removeAll();
       grid.down('#pagingBar').onLoad();
	   var instantsavingsmaintsearch = view.down('instantsavingsmaintsearch'); 	
	   //instantsavingsmaintsearch.getForm().reset();
	   this.retainFormData(btn)

	   
	   var hiddenInstSavingsTypeField = Ext.ComponentQuery.query('#hiddenInstSavingsType')[0]
	   console.log("win 1 ShowInsSavingsByGroupHandler hiddenInstSavingsTypeField ====!! "+hiddenInstSavingsTypeField);	 
	   hiddenInstSavingsTypeField.setValue('searchInsSavingsByGroup');
	   
	   instantsavingsmaintsearch.down('#skus').setValue("");
	   instantsavingsmaintsearch.down('#upcs').setValue("");
	   instantsavingsmaintsearch.down('#skuDesc').setValue("");
	   instantsavingsmaintsearch.down('#skuStatus').setValue("");	
	   instantsavingsmaintsearch.down('#skus').setDisabled(true);
	   instantsavingsmaintsearch.down('#upcs').setDisabled(true);
	   instantsavingsmaintsearch.down('#skuDesc').setDisabled(true);
	   instantsavingsmaintsearch.down('#skuMode').setDisabled(true);
	   instantsavingsmaintsearch.down('#skuStatus').setDisabled(true);
	   instantsavingsmaintsearch.down('#selectedCriteria').setDisabled(true);
	   
	   var searchBtn = Ext.ComponentQuery.query('#searchBtn')[0]; 
	   console.log("win 3 searchBtn = "+searchBtn)
       searchBtn.fireEvent('click', searchBtn);       
       this.searchExecute(searchBtn, 'newSearch');
       
       var ct = this.lookupReference('instantsavingsmaintcard');
       console.log("win 4 ct = "+ct)
       ct.getLayout().setActiveItem(1);
    },

    ShowInsSavingsBySkuHandler: function (btn) {
		   if (this.checkAndPromptAboutUnsavedChanges(Ext.getStore('instantsavingsgroupstore'), 'SwitchToSku', btn)){
			   this.LoadSkuGridView(btn);
		   }
	},
	LoadSkuGridView: function (btn) {
       var view = this.getView();
       var grid = view.down('#instantSavingsSkuGrid');
       store = grid .getStore();
       store.removeAll();
       //store.removeAll(true);  // clear store without firing events
       grid.down('#pagingBar').onLoad();
       
 	   var instantsavingsmaintsearch = view.down('instantsavingsmaintsearch'); 	
       //instantsavingsmaintsearch.getForm().reset();
       this.retainFormData(btn)
    	 
       var hiddenInstSavingsTypeField = Ext.ComponentQuery.query('#hiddenInstSavingsType')[0]
  	   hiddenInstSavingsTypeField.setValue('searchInsSavingsBySku');
       
       instantsavingsmaintsearch.down('#skus').setDisabled(false);
	   instantsavingsmaintsearch.down('#upcs').setDisabled(false);
	   instantsavingsmaintsearch.down('#skuDesc').setDisabled(false);
	   instantsavingsmaintsearch.down('#skuMode').setDisabled(false);
	   instantsavingsmaintsearch.down('#skuStatus').setDisabled(false);
	   instantsavingsmaintsearch.down('#selectedCriteria').setDisabled(false);	   
	   //instantsavingsmaintsearch.down('#skuStatus').setValue(['A','I','N','D']);	
  	   
  	   var searchBtn = Ext.ComponentQuery.query('#searchBtn')[0]; 
       searchBtn.fireEvent('click', searchBtn);       
       this.searchExecute(searchBtn, 'newSearch', true);
       
       var ct = this.lookupReference('instantsavingsmaintcard');
       ct.getLayout().setActiveItem(0);
   },
   
   retainFormData: function (btn) {  
	    var view = this.getView();
	   	//var searchForm = btn.up('form');
	    var searchForm = view.down('instantsavingsmaintsearch'); 	
	   	
	   	var hiddenInstSavingsType = searchForm.down('#hiddenInstSavingsType').getValue();
	   	var venNameMode = searchForm.down('#venNameMode');
	   	var skuMode = searchForm.down('#skuMode');
	   	
	   	var deptsValue = searchForm.down('#depts').getValue();
	   	var subdeptsValue = searchForm.down('#subdepts').getValue();
	   	var clasValue = searchForm.down('#clas').getValue();
	   	var vendorNosValue = searchForm.down('#vendorNos').getValue();
	   	var vendorNameValue = searchForm.down('#vendorName').getValue();
	   	var skusValue = searchForm.down('#skus').getValue();
	   	var upcsValue = searchForm.down('#upcs').getValue();
	   	var skuDescValue = searchForm.down('#skuDesc').getValue();
	   	var skuStatusValue = searchForm.down('#skuStatus').getValue();
	   	//console.log(" retainFormData skuStatusValue = "+skuStatusValue);
	   	var eventNumValue = searchForm.down('#eventnumber').getValue();
	   	var merchAnalyzerValue = searchForm.down('#merchAnalyzerComb').getRawValue();
	   
		searchForm.getForm().reset(); 		
		
		searchForm.down('#depts').setValue(deptsValue);
		searchForm.down('#subdepts').setValue(subdeptsValue);
		searchForm.down('#clas').setValue(clasValue);
		searchForm.down('#vendorNos').setValue(vendorNosValue);
		searchForm.down('#vendorName').setValue(vendorNameValue);
		searchForm.down('#skus').setValue(skusValue);
		searchForm.down('#upcs').setValue(upcsValue);
		searchForm.down('#skuDesc').setValue(skuDescValue);
		searchForm.down('#depts').setValue(deptsValue);		
		searchForm.down('#skuStatus').setValue([skuStatusValue]);
		searchForm.down('#eventnumber').setValue(eventNumValue);		
		
		//Do not allow both event and Merch to Group search
		if (btn.itemId="ShowGroupElgiBtn"){
			if ( (eventNumValue===null) || (merchAnalyzerValue===null)){
				searchForm.down('#merchAnalyzerComb').setValue(merchAnalyzerValue);
			}
		} else {
			searchForm.down('#merchAnalyzerComb').setValue(merchAnalyzerValue);	
		}
		
		//searchForm.down('#skuStatus').setValue(['A','I']);
		//if(hiddenInstSavingsType != 'searchInsSavingsByGroup'){
		//	searchForm.down('#skuStatus').setValue(['A','I','N','D']);	
		//}
   },
   
   saveByGroupBtnHandler_old: function (btn) {
       var view = this.getView();	
	   var instantsavingsmaintsearch = view.down('instantsavingsmaintsearch'); 
	   var formData = instantsavingsmaintsearch.getForm();	   
	   console.log("saveByGroupBtnHandler formData = "+formData);	  
	   
	   var eligState= 1;
	   // later get it from hideen fields
	   var hiddenInstSavingsType = instantsavingsmaintsearch.down('#hiddenInstSavingsType').getValue();
	   var vendorNos = instantsavingsmaintsearch.down('#vendorNos').getValue();
       var depts = instantsavingsmaintsearch.down('#depts').getValue();
       var subdepts = instantsavingsmaintsearch.down('#subdepts').getValue();
       var clas = instantsavingsmaintsearch.down('#clas').getValue();
       //var merchAnalyzerComb = instantsavingsmaintsearch.down('#merchAnalyzerComb').getValue();
       //var eventnumber = instantsavingsmaintsearch.down('#clas').getValue();
       
       console.log("saveByGroupBtnHandler vendorNos = "+vendorNos +" depts = "+depts +" subdepts = "+subdepts +" clas = "+clas);
       console.log("saveByGroupBtnHandler hiddenInstSavingsType = "+hiddenInstSavingsType);

        Ext.getBody().mask("Please wait...");			
		Ext.Ajax.request({
			url: 'search.htm?action=saveinstantsavingsbygroup', 
			method : 'POST',
			params : {
				//instantSavingsSearchForm : JSON.stringify(formData),				
				instSavingsType: hiddenInstSavingsType,
				vendorNos: vendorNos,
				depts: depts,
				subdepts: subdepts,
				clas: clas,
				eligState: eligState,
				
				
				userId: params.userid,
		        lang: params.lang,
		        concept: params.concept,
		        conceptShortName: params.conceptShortName
			},
			success: function(request, result){						
				var response = Ext.JSON.decode(request.responseText);				
				console.log("saveInstantSavingsAjaxCall Click response =  "+response);
				
				Ext.getBody().unmask();		
				if(response.success){	
					//Ext.Msg.alert('Success', 'Instant Savings Group has been saved successfully.');	
					Ext.Msg.alert('Success', i18n.message.groupsuccessmessage);
				}else{					
					//grid.getSelectionModel().deselectAll();
					//Ext.Msg.alert('Failure', response.reason);
					//Ext.Msg.alert('Failure', 'Some or All Instant Savings Group was not successfully process, please re-transmit');
					Ext.Msg.alert('Success', i18n.message.groupfailuremessage);
				}
			}
		});	
    },
    
    saveByGroupBtnHandler: function (btn) {
	       var view = this.getView();			   
		   var eligState= 1;
		   this.saveDeleteByGroupAjaxCall(btn,eligState)
    },
    
    deleteByGroupBtnHandler: function (btn) {
	       var view = this.getView();	   
		   var eligState= 0;
		   this.saveDeleteByGroupAjaxCall(btn,eligState)
    },
    
    saveDeleteByGroupAjaxCall: function (btn, eligState) {
	       var view = this.getView();			   
		   var instantsavingsmaintsearch = view.down('instantsavingsmaintsearch'); 
		   var formData = instantsavingsmaintsearch.getForm();	   
		   console.log("saveDeleteByGroupAjaxCall formData = "+formData);	  
		   
		   //var eligState= 1;
		   // later get it from hideen fields
		   var hiddenInstSavingsType = instantsavingsmaintsearch.down('#hiddenInstSavingsType').getValue();
		   var vendorNos = instantsavingsmaintsearch.down('#vendorNos').getValue();
	       var depts = instantsavingsmaintsearch.down('#depts').getValue();
	       var subdepts = instantsavingsmaintsearch.down('#subdepts').getValue();
	       var clas = instantsavingsmaintsearch.down('#clas').getValue();
	       //var merchAnalyzerComb = instantsavingsmaintsearch.down('#merchAnalyzerComb').getValue();
	       //var eventnumber = instantsavingsmaintsearch.down('#clas').getValue();
	       
	       console.log("saveDeleteByGroupAjaxCall vendorNos = "+vendorNos +" depts = "+depts +" subdepts = "+subdepts +" clas = "+clas);
	       console.log("saveDeleteByGroupAjaxCall hiddenInstSavingsType = "+hiddenInstSavingsType);

	        Ext.getBody().mask("Please wait...");			
			Ext.Ajax.request({
				//url : FSUtils.contextAccountMaintenance + 'SaveChanges',
				url: 'search.htm?action=saveinstantsavingsbygroup', 
				method : 'POST',
				params : {
					//instantSavingsSearchForm : JSON.stringify(formData),
					instSavingsType: hiddenInstSavingsType,
					vendorNos: vendorNos,
					depts: depts,
					subdepts: subdepts,
					clas: clas,
					eligState: eligState,
					
					userId: params.userid,
			        lang: params.lang,
			        concept: params.concept,
			        conceptShortName: params.conceptShortName
				},
				success: function(request, result){						
					var response = Ext.JSON.decode(request.responseText);				
					console.log("saveDeleteByGroupAjaxCall Click response =  "+response);
					
					Ext.getBody().unmask();						
					if(response.success){	
						/*
						grid.getStore().load({
							//params : {
							//	schedulebList : schedulebList
							//}
						});*/
						//Ext.Msg.alert('Success', 'Instant Savings Group has been saved successfully.');							
						Ext.Msg.alert('Success', i18n.message.groupsuccessmessage);
					}else{					
						//grid.getSelectionModel().deselectAll();
						//Ext.Msg.alert('Failure', response.reason);
						//Ext.Msg.alert('Failure', 'Some or All Instant Savings Group was not successfully process, please re-transmit');
						Ext.Msg.alert('Failure', i18n.message.groupfailuremessage);
					}
				}
			});	 
      },
     
      instaSavingsGroupGridCellclick: function (grid, td, colIndex, record, tr, rowIndex, e, eOpts) {
	       var view = this.getView();	
	       var fieldName = grid.getGridColumns()[colIndex].dataIndex;
	       
	       if(fieldName === 'isId'){
	    	   var vendorNos = record.get('isAsnum');
		       var depts = record.get('isDept');
		       var subdepts = record.get('isSdept');
		       var clas = record.get('isClas');		      
		       var eventnumber = record.get('isevt');
		       var merchAnalyzer = record.get('isma');
		       var isid = record.get('isId');
		       var groupElgFlag = record.get('groupElgFlag');
		       
		       console.log("instaSavingsGroupGridCellclick vendorNos = "+vendorNos +" depts = "+depts +" subdepts = "+subdepts +" clas = "+clas +" isid = "+isid);
		       console.log("instaSavingsGroupGridCellclick merchAnalyzer = "+merchAnalyzer +" eventnumber = "+eventnumber +" groupElgFlag = "+groupElgFlag);
		       
		       var eligState= 1;
		       if(groupElgFlag == 'Delete'){
		    	   eligState= 0;
		       }
		       this.saveDeleteByGroupCellAjaxCall(grid, vendorNos, depts, subdepts, clas, eligState);
	       }
      },  
      
      saveDeleteByGroupCellAjaxCall: function (grid, vendorNos, depts, subdepts, clas, eligState) {
	       var view = this.getView();	
		   var instantsavingsmaintsearch = view.down('instantsavingsmaintsearch'); 		   
		   //var formData = this.up('form').getForm();
		   //var formData = instantsavingsmaintsearch.down('#hiddenInstSavingsType').getForm();
		   var formData = instantsavingsmaintsearch.getForm();	 
		   var hiddenInstSavingsType = instantsavingsmaintsearch.down('#hiddenInstSavingsType').getValue();	       
	       console.log("saveDeleteByGroupCellAjaxCall vendorNos = "+vendorNos +" depts = "+depts +" subdepts = "+subdepts +" clas = "+clas);
	       console.log("saveDeleteByGroupCellAjaxCall hiddenInstSavingsType = "+hiddenInstSavingsType);

	        Ext.getBody().mask("Please wait...");			
			Ext.Ajax.request({
				//url : FSUtils.contextAccountMaintenance + 'SaveChanges',
				url: 'search.htm?action=saveinstantsavingsbygroup', 
				method : 'POST',
				params : {
					//instantSavingsSearchForm : JSON.stringify(formData),
					instSavingsType: hiddenInstSavingsType,
					vendorNos: vendorNos,
					depts: depts,
					subdepts: subdepts,
					clas: clas,
					eligState: eligState,					
					userId: params.userid,
			        lang: params.lang,
			        concept: params.concept,
			        conceptShortName: params.conceptShortName
				},
				success: function(request, result){						
					var response = Ext.JSON.decode(request.responseText);				
					console.log("saveDeleteByGroupAjaxCall Click response =  "+response);
					
					Ext.getBody().unmask();						
					if(response.success){	
						grid.getStore().load({
							//params : {
							//	schedulebList : schedulebList
							//}
						});
						//Ext.Msg.alert('Success', 'Instant Savings Group has been saved successfully.');	
						Ext.Msg.alert('Success', i18n.message.groupsuccessmessage);
					}else{					
						//grid.getSelectionModel().deselectAll();
						//Ext.Msg.alert('Failure', response.reason);
						//Ext.Msg.alert('Failure', 'Some or All Instant Savings Group was not successfully process, please re-transmit');
						Ext.Msg.alert('Failure', i18n.message.groupfailuremessage);
					}
				}
			});	 
     },
     
     saveInstantSavingsByGrp: function(suppressNoChangesMsg, bShowSuccessMsg) {	
	    //console.log("saveInstantSavingsGrpHandler 5 Click btn ="+btn +" pagingClickFlag = "+pagingClickFlag);	
	    var view = this.getView();  
	    var grid = view.down('#instantSavingsGroupGrid');
 		var instantSavingsList = [];
         //Greg
 		var store = view.down('#instantSavingsGroupGrid').getStore();
 		var instantSavingsChanges = [];
 		var rs = store.getModifiedRecords();
 		for (var i = 0, ln = rs.length; i < ln; i++) {
 			instantSavingsList.push(rs[i]);
 			instantSavingsChanges.push(rs[i].getChanges());
 		}
 		console.dir(instantSavingsList);
 		console.dir(instantSavingsChanges);
 		
 		Ext.each(instantSavingsList, function(record, index){
    	   //old
 		   record.data.instsavElig = (record.data.groupEligFl ? 1 : 0);
        	//TODO:
        	//New: aftering changing to use same Ajax call as save by SKU 
 			//record.data.saveDeleteFlag = (record.data.groupEligFl ? 1 : 0);
           	//When saving Groups, populate the SKU with 0
            //record.data.isinumbr = 0;
           	//record.data.dept = 1;
         },this);
    	    
    	 if(instantSavingsList.length == 0){
  			if(suppressNoChangesMsg !== undefined && !suppressNoChangesMsg){
 				Ext.Msg.show({
 					title:i18n.title.AppName,
 			        //msg        : 'Please make changes to update.',
 			        msg		   : i18n.message.makechangestoupdate,
 			        width      : 270,
 			        buttons    : Ext.MessageBox.OK,				        
 			        icon       : Ext.MessageBox.INFO
 			     });
  			}		 
			return;
   		}
    
        var instantSavingsListData = [];
		Ext.each(instantSavingsList, function(rec, index){
			instantSavingsListData.push(rec.data);	
	    });			

		//this.saveDeleteByGroupAjaxCall_1(instantSavingsListData, grid);
	 	this.saveInstantSavingsByGroupAjaxCall(instantSavingsListData, grid, bShowSuccessMsg);
		//this.saveInstantSavingsAjaxCall(instantSavingsListData, grid, bShowSuccessMsg);	
	 	store.load();
 	    grid.getView().refresh();
   	 	
    },
    
    //saveDeleteByGroupAjaxCall_1: function(instantSavingsListParam, grid) {	
    saveInstantSavingsByGroupAjaxCall: function(instantSavingsListParam, grid, bShowSuccessMsg) {	
	    console.log("saveDeleteByGroupAjaxCall_1 Click");		    
	    //var eligStates = '1';
		//var ids = '0';
		//var userId = '1';		    
		Ext.getBody().mask("Please wait...");			
		Ext.Ajax.request({
			url: 'search.htm?action=saveInstantelgibygroup', 
			method : 'POST',
			params : {
				instantSavingsList : JSON.stringify(instantSavingsListParam),
				userId: params.userid,
		        lang: params.lang,
		        country: params.country,
		        concept: params.concept,
		        conceptShortName: params.conceptShortName
			},
			success: function(request, result){						
				var response = Ext.JSON.decode(request.responseText);				
				console.log("saveInstantSavingsAjaxCall Click response =  "+response);
				
				Ext.getBody().unmask();						
				if(response.success){	
					grid.getStore().load();
					grid.getView().refresh();
					//Ext.Msg.alert('Success', 'Instant Savings has been saved successfully.');							
					if (bShowSuccessMsg === undefined || bShowSuccessMsg){
						Ext.Msg.alert('Success', i18n.message.successmessage);
					}
				}else{					
					grid.getSelectionModel().deselectAll();
					//Ext.Msg.alert('Failure', response.reason);
					//Ext.Msg.alert('Failure', 'Some or All Instant Savings was not successfully process, please re-transmit.');
					Ext.Msg.alert('Failure', i18n.message.failuremessage);
				}
			}
		});
    }, 
    
    instantSavingsSkuGridCellclick: function (grid, td, colIndex, record, tr, rowIndex, e, eOpts) {
       var view = this.getView();	
       var fieldName = grid.getGridColumns()[colIndex].dataIndex; 
       
       if (record.get('groupSelectionFlag') == true ) {       
	       if(fieldName === 'groupSelectionFlag'){	    
	    	   
	    	    var editWindow;
	    	    /*
		   		if (this.InstantSavingsGrpPopup()) {
		   			editWindow = this.getInstantSavingsGrpPopup();
		   		} else {
		   			editWindow = Ext.create('SSM.view.instantsavingsmaint.InstantSavingsGrpPopup');
		   		}*/	   		
		   		editWindow = Ext.create('SSM.view.instantsavingsmaint.InstantSavingsGrpPopup');		
		   		editWindow.setTitle("Instant Savings Groups for SKU : " +record.get('sku'));
		   		//editWindow.setTitle(i18n.text.message + record.get('sku'));
			
		   	    ////editWindow.down('instantsavingsgrppopupgrid').getStore().removeAll();
				var grid = editWindow.down('instantsavingsgrppopupgrid');
		        var store = editWindow.down('instantsavingsgrppopupgrid').getStore();
		        
		        var instantSavingsListData = [];
				Ext.each(record, function(rec, index){
					instantSavingsListData.push(rec.data);	
			    });	
		        
				//console.dir(instantSavingsListData);
				var extraParams = {};
				extraParams.instantSavingsList = JSON.stringify(instantSavingsListData);
		        store.proxy.extraParams = extraParams;
		         
				store.load({
		    		callback: function(records, operation, success) {
		    		
		    		},
		            scope: this
		    	});		   		
		   		editWindow.show();
	       }
       }
    },
    
    merchAnalyzerCombPostLookupValidate : function (lookup,validList,inValidList) 
    {
       console.log("Dashbord.js merchAnalyzerCombPostLookupValidate  1 - 1 ####### ");
    },
    
    merchAnalyzerCombControl:function(field){
     	//console.log("Dashbord.js merchAnalyzerCombControl  2 - 1 ####### ");
     	var searchForm = field.up('form');     	
     	var depts = searchForm.down('#depts');
     	var subDepts = searchForm.down('#subdepts');
     	var clas = searchForm.down('#clas');     	
     	var vendorNos = searchForm.down('#vendorNos');
     	var vendorName = searchForm.down('#vendorName');
     	var venNameMode = searchForm.down('#venNameMode');     	
     	var sku = searchForm.down('#skus');
     	var upcs= searchForm.down('#upcs');
     	var skuDesc = searchForm.down('#skuDesc');
     	var skuMode = searchForm.down('#skuMode');   
     	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');
     	var eventnumber = searchForm.down('#eventnumber'); 
     	var hiddenInstSavingsType = Ext.ComponentQuery.query('#hiddenInstSavingsType')[0]; 
      	console.log("Dashbord.js merchAnalyzerCombControl  2 - 3 #######  hiddenInstSavingsType = "+hiddenInstSavingsType.getValue() +" merchAnalyzer = "+merchAnalyzer.getValue());
      	
     	if (hiddenInstSavingsType.getValue() == 'searchInsSavingsByGroup') {
	     	if((merchAnalyzer.getValue() != null && merchAnalyzer.getValue().length != 0))
	     	{
	     		depts.setDisabled(true);
	     		subDepts.setDisabled(true);
	     		clas.setDisabled(true);
	     		vendorNos.setDisabled(true);	     		
	     		vendorName.setDisabled(true);
	     		venNameMode.setDisabled(true);	     		
	     		sku.setDisabled(true);
	     		upcs.setDisabled(true);
	     		skuDesc.setDisabled(true);
	     		skuMode.setDisabled(true);
	     		eventnumber.setDisabled(true);
	     		
	     	} else if(merchAnalyzer.getValue().length == 0){
	     		depts.setDisabled(false);
	     		subDepts.setDisabled(false);
	     		clas.setDisabled(false);
	     		vendorNos.setDisabled(false);
	     		vendorName.setDisabled(false);
	     		venNameMode.setDisabled(false);
	     		sku.setDisabled(true);
	     		upcs.setDisabled(true);
	     		skuDesc.setDisabled(true);
	     		skuMode.setDisabled(true);
	     		eventnumber.setDisabled(false);
	     	}
     	}
    },
    eventNumberComboControl:function(field){ 
    	console.log("eventNumberComboControl");
     	var view = this.getView()    
     	var searchForm = field.up('form');
     	
     	var vendorNos = searchForm.down('#vendorNos');
     	var vendorName = searchForm.down('#vendorName');
     	var venNameMode = searchForm.down('#venNameMode');
     	var eventNumber = searchForm.down('#eventnumber'); 
     	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');     	
     
     	console.log("DashBord.js eventNumberControl @@@@!!! 2 - 3 field = "+field +" eventNumber.getValue() = "+eventNumber.getValue());
     	//console.log("DashBord.js eventNumberControl @@@@!!! 2 - 4 field store = "+field.getStore());
     	var store = field.getStore();     	
     	//console.log("DashBord.js eventNumberControl @@@@!!! 2 - 5  userid = "+params.userid +" lang = "+params.lang +" country = "+params.country +" concept = "+params.concept);
     	
     	 var extraParams = {};
         var extraParams = {             
        	 //searchMode: venNameMode.getText(),    
        	 //vendorDesc: vendorName.getValue(),
        	 eventNumber: eventNumber.getValue(),
             userId: params.userid,
             lang: params.lang,
             concept: params.concept,
             conceptShortName: params.conceptShortName
         };
     	
         store.proxy.extraParams = extraParams;
         store.load();
         /*
         console.log("Dashboard.js 2 - 1 vendorNameControl  combo.getStore().getCount() = "+store.getCount() +" store = "+store);	
         
         var value=Ext.String.trim(toProperCase(combo.rawValue)); 
         var rec=combo.getStore().findRecord('vendorDesc',value);
         
         if(!(Ext.isEmpty(rec))){
   			console.log("Dashboard.js 2 - 2 vendorNameControl  vendorNo = "+vendorNo +" rec = "+rec);
   			vendorNo.setValue(rec.data.vendorNo);
         }	*/
     },
     
     eventNumberComboBlur: function(combo){  
    	 console.log("eventNumberComboBlur");
    	var searchForm=combo.up('form'); 		  
     	//var searchForm = field.up('form');     	
      	var depts = searchForm.down('#depts');
      	var subDepts = searchForm.down('#subdepts');
      	var clas = searchForm.down('#clas');     	
      	var vendorNos = searchForm.down('#vendorNos');
      	var vendorName = searchForm.down('#vendorName');
      	var venNameMode = searchForm.down('#venNameMode');     	
      	var sku = searchForm.down('#skus');
      	var upcs= searchForm.down('#upcs');
      	var skuDesc = searchForm.down('#skuDesc');
      	var skuMode = searchForm.down('#skuMode');   
      	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');
      	var eventnumber = searchForm.down('#eventnumber');
      	
     	console.log("Dashboard.js 1 - 1 eventNumberComboBlur  combo.value = "+combo.value +" combo.rawValue = "+combo.rawValue);
 		var value=Ext.String.trim(toProperCase(combo.rawValue)); 		
 		
     	if(!Ext.isEmpty(Ext.String.trim(combo.rawValue))){
     	  console.log("Dashboard.js 1 - 2 eventNumberComboBlur  combo.getStore().getCount() = "+combo.getStore().getCount() +" store = "+combo.getStore());	
     	 
     	  if(combo.getStore().getCount() > 0){
      		    //var rec=combo.getStore().findRecord('vendorDesc',value);
             	console.log("Dashboard.js 1 - 3 eventNumberComboBlur  eventnumber.getValue() = "+eventnumber.getValue() +" length = "+eventnumber.getValue().length);
             	
             	if((eventnumber.getValue() != null && eventnumber.getValue().length != 0))
             	{
             		depts.setDisabled(true);
             		subDepts.setDisabled(true);
             		clas.setDisabled(true);
             		vendorNos.setDisabled(true);
             		vendorName.setDisabled(true);
             		venNameMode.setDisabled(true);
             		sku.setDisabled(true);
             		upcs.setDisabled(true);
             		skuDesc.setDisabled(true);
             		skuMode.setDisabled(true);
             		merchAnalyzer.setDisabled(true);
             	} 
      	  }
     	}else{
     		console.log("Dashboard.js 1 - 4 eventNumberComboBlur  combo = "+combo +" value = "+value );  
            combo.setRawValue(value);
            
            depts.setDisabled(false);
     		subDepts.setDisabled(false);
     		clas.setDisabled(false);
     		vendorNos.setDisabled(false);
     		vendorName.setDisabled(false);
     		venNameMode.setDisabled(false);
     		sku.setDisabled(false);
     		upcs.setDisabled(false);
     		skuDesc.setDisabled(false);
     		skuMode.setDisabled(false);
     		merchAnalyzer.setDisabled(false);
     	}
     	
     	if((Ext.isEmpty(combo.value))&&(!Ext.isEmpty(combo.rawValue))){     		
     	   console.log("Dashboard.js 1 - 5 eventNumberComboBlur  combo = "+combo +" value = "+value );          
           combo.setRawValue(value);
        }
     	
     },
     
     eventNumberComboBlur: function(field){
    	 console.log("eventNumberComboBlur 1");
      	var searchForm = field.up('form');  
      	/*
     	var depts = searchForm.down('#depts');
     	var subDepts = searchForm.down('#subdepts');
     	var clas = searchForm.down('#clas');     	
     	var vendorNos = searchForm.down('#vendorNos');
     	var vendorName = searchForm.down('#vendorName');
     	var venNameMode = searchForm.down('#venNameMode');     	
     	var sku = searchForm.down('#skus');
     	var upcs= searchForm.down('#upcs');
     	var skuDesc = searchForm.down('#skuDesc');
     	var skuMode = searchForm.down('#skuMode');   
     	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');
     	var eventnumber = searchForm.down('#eventnumber'); 
     	console.log("Dashboard.js 4 - 4 eventNumberSelect  eventnumber.getValue() = "+eventnumber.getValue() +" length = "+eventnumber.getValue().length);
     	
     	if((eventnumber.getValue() != null && eventnumber.getValue().length != 0))
     	{
     		depts.setDisabled(true);
     		subDepts.setDisabled(true);
     		clas.setDisabled(true);
     		vendorNos.setDisabled(true);
     		vendorName.setDisabled(true);
     		venNameMode.setDisabled(true);
     		sku.setDisabled(true);
     		upcs.setDisabled(true);
     		skuDesc.setDisabled(true);
     		skuMode.setDisabled(true);
     		merchAnalyzer.setDisabled(true);
     	} else if(eventnumber.getValue().length == 0){
     		depts.setDisabled(false);
     		subDepts.setDisabled(false);
     		clas.setDisabled(false);
     		vendorNos.setDisabled(false);
     		vendorName.setDisabled(false);
     		venNameMode.setDisabled(false);
     		sku.setDisabled(false);
     		upcs.setDisabled(false);
     		skuDesc.setDisabled(false);
     		skuMode.setDisabled(false);
     		merchAnalyzer.setDisabled(false);
     	}  */   	
     }, 
     eventNumberBlur:function(field){ 
      	var view = this.getView()    
      	var searchForm = field.up('form');      	
      	var vendorNos = searchForm.down('#vendorNos');
      	var vendorName = searchForm.down('#vendorName');
      	var venNameMode = searchForm.down('#venNameMode');
      	var eventNumber = searchForm.down('#eventnumber'); 
      	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');     
      	console.log("DashBord.js eventNumberBlur @@@@!!! 2 - 3 field = "+field +" eventNumber.getValue() = "+eventNumber.getValue() +" length = "+eventNumber.getValue().length);
      	
      	if((eventNumber.getValue() != null && eventNumber.getValue().length != 0))
      	   this.getSkusByEventNumberAjaxCall(eventNumber.getValue(), eventNumber);
      },
      
      eventNumberControl: function(field){
       	var searchForm = field.up('form');  
       	
      	var depts = searchForm.down('#depts');
      	var subDepts = searchForm.down('#subdepts');
      	var clas = searchForm.down('#clas');     	
      	var vendorNos = searchForm.down('#vendorNos');
      	var vendorName = searchForm.down('#vendorName');
      	var venNameMode = searchForm.down('#venNameMode');     	
      	var sku = searchForm.down('#skus');
      	var upcs= searchForm.down('#upcs');
      	var skuDesc = searchForm.down('#skuDesc');
      	var skuMode = searchForm.down('#skuMode');   
      	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');
      	var eventNumber = searchForm.down('#eventnumber'); 
      	console.log("Dashboard.js 4 - 4 eventNumberControl  eventnumber.getValue() = "+eventNumber.getValue() +" length = "+eventNumber.getValue().length);      	
      	// this.getSkusByEventNumberAjaxCall(eventnumber.getValue());
      	
      	// 8/30/2017
      	var hiddenInstSavingsType = Ext.ComponentQuery.query('#hiddenInstSavingsType')[0]; 
      	console.log("Dashboard.js 4 - 4 eventNumberControl  hiddenInstSavingsType = "+hiddenInstSavingsType);
      	console.log("Dashboard.js 4 - 4 eventNumberControl  hiddenInstSavingsType.getValue() = "+hiddenInstSavingsType.getValue());
      	
      	if (hiddenInstSavingsType.getValue() == 'searchInsSavingsByGroup') {
	      	if((eventNumber.getValue() != null && eventNumber.getValue().length != 0))
	      	{
	      		depts.setDisabled(true);
	      		subDepts.setDisabled(true);
	      		clas.setDisabled(true);
	      		vendorNos.setDisabled(true);
	      		vendorName.setDisabled(true);
	      		venNameMode.setDisabled(true);
	      		sku.setDisabled(true);
	      		upcs.setDisabled(true);
	      		skuDesc.setDisabled(true);
	      		skuMode.setDisabled(true);
	      		merchAnalyzer.setDisabled(true);
	      	} else if(eventNumber.getValue().length == 0){
	      		depts.setDisabled(false);
	      		subDepts.setDisabled(false);
	      		clas.setDisabled(false);
	      		vendorNos.setDisabled(false);
	      		vendorName.setDisabled(false);
	      		venNameMode.setDisabled(false);
	      		sku.setDisabled(true);
	      		upcs.setDisabled(true);
	      		skuDesc.setDisabled(true);
	      		skuMode.setDisabled(true);
	      		merchAnalyzer.setDisabled(false);
	      	} 
      	}
      },
      
      getSkusByEventNumberAjaxCall: function(eventNumber, field) {	
			Ext.getBody().mask("Please wait...");			
			Ext.Ajax.request({
				url: 'search.htm?action=skusbyeventnumber', 
				method : 'GET',
				params : {
					eventNumber: eventNumber
				},
				success: function(request, result){						
					var response = Ext.JSON.decode(request.responseText);
					
					Ext.getBody().unmask();	
					if(response.success){	
					}else{					
						//Ext.Msg.alert('Failure', i18n.message.failuremessage);
						Ext.Msg.alert('Failure', 'Please enter valid Event Number.');
						field.setValue("");
					}
				}
			});		    
	}, 
	instantSavingsGrpPopupHandler: function(btn) {	
		console.log("InstantSavingsGrpPopup");
		
		
		//this.getInstantSavingsGrpPopup().close();	
		
		//ShowInsSavingsByGroupHandler
		 var view = this.getView()
		 me = this;
         me.getView().close();
		
		//this.getSchedulebBulkUpdateWindow().close()
	},
	
	merchAnalyzerProxyURL : function(combo, newValue, oldValue, eOpts) {
	    	console.log("setProxyURL 1 ### combo = "+combo +" newValue = "+newValue +" oldValue = "+oldValue);	 		
	    	var elasticQuery = null;
	 		if (!Ext.isEmpty(newValue)) {
	 			newValue = newValue.replace('"', '\\"');
	 		}
	 	
	 		if (combo.getItemId() === 'merchAnalyzer') {
	 			elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "cts"}}, {"term":{"GP_COMBINED.GP_COMBINED_CONTAINS":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[ {"GP_COMBINED.GP_COMBINED_SORT" : "asc"}],"aggregations":{}}';
	 			elasticQuery = elasticQuery.replace('AAA', !Ext.isEmpty(newValue) ? newValue.toLowerCase() : '');
	 		}
	
	 		//console.log("setProxyURL 1 - 1 ### elasticQuery = "+elasticQuery);
	 		//console.log("setProxyURL 1 - 2 ### params.maSearchUrl = "+params.maSearchUrl);
	 		//console.log("setProxyURL 1 - 3 ### params.base_lookup_url = "+params.base_lookup_url);
	 		console.log("setProxyURL 1 - 4 ### params.concept = "+params.concept +" country = "+params.country);
	 		//console.log("setProxyURL 1 - 5 ### params.vipurl = "+params.vipurl);


	 		params.maSearchUrl = params.vipurl + 'elasticsearch/lookups5/' + 'lookup_merchandiseanalyzer/_search?source=';
	 		console.log("setProxyURL 1 - 6 ### params.maSearchUrl = "+params.maSearchUrl);
	 		console.log("setProxyURL 1 - 7 ###!! jsonData = "+combo.getStore().proxy.jsonData);
	 		console.log("setProxyURL 1 - 7 ### url = "+combo.getStore().proxy.url);	 		
	 		console.log("setProxyURL 1 - 8 ### url = "+combo.getStore().getProxy.url);
	 		
	 		 //////////////////////////////////////////////////////
	        Ext.Ajax.request({
	            url: base_lookup_url + 'lookup_merchandiseanalyzer/_search',
	            //url: 'http://192.168.192.160/elasticsearch/lookups5/' + 'lookup_merchandiseanalyzer/_search',
	            method: 'POST',
	            headers: {
	                'Content-Type': 'application/json'
	            },
	            timeout: 60000, //2 minutes
	            jsonData : elasticQuery,
	            //jsonData: Ext.encode(elasticQuery),	         
	            scope: this,
	            success: function (response) {
	                var jsonResp = Ext.JSON.decode(response.responseText);
	                var merchAnalyData = [];
	                //console.log("regioncombo LOAD !! 1 - 1 jsonResp = " + jsonResp + " jsonResp.length = " + jsonResp.hits.total);

	                for (var i = 0; i < jsonResp.hits.hits.length; i++) {
	                    //console.log("countrycombo beforeselec name = " + jsonResp.hits.hits[i]._source.NAME + " country = " + jsonResp.hits.hits[i]._source.COUNTRY + " concept = " + jsonResp.hits.hits[i]._source.CONCEPT);
	                    var country = jsonResp.hits.hits[i]._source.COUNTRY;
	                    var concept = jsonResp.hits.hits[i]._source.CONCEPT;
	                    var fullname = jsonResp.hits.hits[i]._source.NAME;
	                    fullname = Ext.String.trim(fullname);
	                    var code = jsonResp.hits.hits[i]._source.CODE;
	                    var gpCombined = jsonResp.hits.hits[i]._source.GP_COMBINED;
	                    //console.log("countrycombo beforeselec code = " + code +" gpCombined = "+gpCombined);
	                    //conceptval.toLowerCase();
	                   	                    
	                    merchAnalyData.push({
                            'CODE': code,
                            "GP_COMBINED": gpCombined
                        });
	                    
	                    var store = Ext.create('Ext.data.Store', {
                            fields: ['GP_COMBINED', 'CODE'],
                            data: merchAnalyData
                        });
	                    combo.bindStore(store);
	                    
	                    if (Ext.isEmpty(newValue)) {
	            			combo.getStore().removeAll();
	            		}
	                }
	            }
	        });
	 },
	 
	 eventNumberrProxyURL : function(combo, newValue, oldValue, eOpts) {
	    	var elasticQuery = null;
	 		if (!Ext.isEmpty(newValue)) {
	 			newValue = newValue.replace('"', '\\"');
	 		}	 	
	 		
	 		if (combo.getItemId() === 'eventnumber') {
	 			//elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "cts"}}, {"term":{"EVENTNO.EVENTNO_AC":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[ {"EVENTNO.EVENTNO_SORT" : "asc"}]}';
	 			elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "bedbath"}}, {"term":{"EVENTNO.EVENTNO_AC":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50}';
	 			elasticQuery = elasticQuery.replace('AAA', !Ext.isEmpty(newValue) ? newValue.toLowerCase() : '');
	 		}
	 	
	 		//console.log("setProxyURL 1 - 3 ### params.base_lookup_url = "+params.base_lookup_url);
//	 		console.log("setProxyURL 1 - 4 ### params.concept = "+params.concept +" country = "+params.country);	 		
//	 		console.log("setProxyURL 1 - 6 ### params.eventNumberUrl = "+params.eventNumberUrl);
	 		var url = params.eventNumberUrl.substring(0, params.eventNumberUrl.indexOf("?"));
	 	
            if (Ext.isEmpty(newValue) || newValue.length<3) {
    			combo.getStore().removeAll();
    		} else {
		        Ext.Ajax.request({
		            url: url,
		            method: 'POST',
		            headers: {
		                'Content-Type': 'application/json'
		            },
		        	noCache:false,
		            timeout: 60000, //2 minutes
		            jsonData : elasticQuery,       
		            scope: this,
		            success: function (response) {
		                var jsonResp = Ext.JSON.decode(response.responseText);
		                var eventNumberData = [];
		                //console.log("regioncombo LOAD !! 1 - 1 jsonResp = " + jsonResp + " jsonResp.length = " + jsonResp.hits.total);
	
		                if (jsonResp.hits.hits.length===0){
		                	combo.getStore().removeAll();
		                }else {
			                for (var i = 0; i < jsonResp.hits.hits.length; i++) {
			                    //console.log("countrycombo beforeselec name = " + jsonResp.hits.hits[i]._source.NAME + " country = " + jsonResp.hits.hits[i]._source.COUNTRY + " concept = " + jsonResp.hits.hits[i]._source.CONCEPT);
			                    var country = jsonResp.hits.hits[i]._source.COUNTRY;
			                    var concept = jsonResp.hits.hits[i]._source.CONCEPT;
			                    var eventno = jsonResp.hits.hits[i]._source.EVENTNO;
			                    //console.log("countrycombo beforeselec eventno = " + eventno +" country = "+country +" concept = "+concept);
			                   	                    
			                    eventNumberData.push({
		                           'EVENTNO': eventno
		                        });
			                }
		                    var store = Ext.create('Ext.data.Store', {
		                    	fields: ['EVENTNO'],
		                    	data: eventNumberData
	    	                });
	        	            combo.bindStore(store);
		                }
	                    Ext.getBody().unmask();
		            },
		            failure: function(){
		            	alert('failed');
		            }
		        });
    		}
     },
	 disableBySkuDescProxyURL : function(combo, newValue, oldValue, eOpts) {	    	
	    	var searchForm=combo.up('form'); 
	     	var skuDesc = searchForm.down('#skuDesc');
	     	var skuDescMode = searchForm.down('#skuMode').getText(); 	     	
	     	skuDescMode = skuDescMode.replace('<b>', !Ext.isEmpty(newValue) ? '' : '');
	     	skuDescMode = skuDescMode.replace('</b>', !Ext.isEmpty(newValue) ? '' : '');
	     	console.log("disableBySkuDescProxyURL 1 ### skuDescMode = "+skuDescMode);
	     	
	    	var elasticQuery = null;
	 		if (!Ext.isEmpty(newValue)) {
	 			newValue = newValue.replace('"', '\\"');
	 		}
	 	
	 		if (combo.getItemId() === 'skuDesc') {	
	 			if (skuDescMode === 'S') {
					elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "bedbath"}}, {"term":{"DESCRIPTION.DESCRIPTION_AUTOCOMPLETE":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[{ "DESCRIPTION.DESCRIPTION_SORT" : "asc"}],"aggregations":{}}';
				}
				else {
					elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "bedbath"}}, {"term":{"DESCRIPTION.DESCRIPTION_CONTAINS":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[{ "DESCRIPTION.DESCRIPTION_SORT" : "asc"}],"aggregations":{}}';
				}
				elasticQuery = elasticQuery.replace('AAA', !Ext.isEmpty(newValue) ? newValue.toLowerCase() : '');
	 		}
	 	
	 		//console.log("setProxyURL 1 - 2 ### params.maSearchUrl = "+params.maSearchUrl);
	 		console.log("disableBySkuDescProxyURL 1 - 4 ### params.concept = "+params.concept +" country = "+params.country);	 		
	 		var url = params.skuDescSearchUrl.substring(0, params.skuDescSearchUrl.indexOf("?"));
	 		
	        Ext.Ajax.request({
	            //url: 'http://192.168.192.160/elasticsearch/lookups5/' + 'lookup_sku/_search',
	            url: url,
	            method: 'POST',
	            headers: {
	                'Content-Type': 'application/json'
	            },
	            timeout: 60000, //2 minutes
	            jsonData : elasticQuery,      
	            scope: this,
	            success: function (response) {
	                var jsonResp = Ext.JSON.decode(response.responseText);
	                var skuDescData = [];

	                for (var i = 0; i < jsonResp.hits.hits.length; i++) {
	                    var country = jsonResp.hits.hits[i]._source.COUNTRY;
	                    var concept = jsonResp.hits.hits[i]._source.CONCEPT;
	                    var skuDescription = jsonResp.hits.hits[i]._source.DESCRIPTION;
	                    
	                    var sku = jsonResp.hits.hits[i]._source.SKU;
	                    var upc = jsonResp.hits.hits[i]._source.UPC;
	                    var vendorno = jsonResp.hits.hits[i]._source.VENDORNO;
	                    var vendorName = jsonResp.hits.hits[i]._source.VENDORNAME;
	                    console.log("disableBySkuDescProxyURL 1 - 4 ### sku = "+sku +" upc = "+upc +" vendorno = "+vendorno +" vendorName = "+vendorName);
	                   	                    
	                    skuDescData.push({
                           'DESCRIPTION': skuDescription,
                           'sku': sku
                           //,'upc': upc
                        });
	                    
	                    var store = Ext.create('Ext.data.Store', {
                          fields: ['DESCRIPTION', 'sku'],
                          data: skuDescData
                        });
	                    combo.bindStore(store);	                    
	                    if (Ext.isEmpty(newValue)) {
	            			combo.getStore().removeAll();
	            		}
	                }
	            }
	        });
	        	      
	     	var sku = searchForm.down('#skus');
	     	var vendorNo = searchForm.down('#vendorNos');
	     	var vendorName = searchForm.down('#vendorName');
	     	var merchAnalyzer = searchForm.down('#merchAnalyzerComb');	     	
	     	var upcs= searchForm.down('#upcs');
	     	var depts = searchForm.down('#depts');
	     	var subDepts = searchForm.down('#subdepts');
	     	var clas = searchForm.down('#clas');  	
	     	var venNameMode = searchForm.down('#venNameMode');
	     	var skuMode = searchForm.down('#skuMode');     	
	     	console.log("Dashboard.js 3 - 1 disableBySkuDesc  params.country = "+params.country);
	     	console.log("Dashboard.js 3 - 1 disableBySkuDesc  params.concept = "+params.concept +" params.conceptShortName = "+params.conceptShortName);			
	     	
	     	if(skuDesc.getValue() == null && sku == null){
	     		console.log("Dashboard.js 3 - 3 - 1 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
	     		vendorNo.setDisabled(false);
	     		if(!Ext.isEmpty(vendorName.getValue())){
	     			vendorName.setDisabled(true);
	     		}else{
	     		vendorName.setDisabled(false);
	     		}
	     		merchAnalyzer.setDisabled(false);
	     		sku.setDisabled(false);
	     		upcs.setDisabled(false);
	     		
	     		if(!Ext.isEmpty(depts.getValue)){
	     			depts.setDisabled(false);
	     			subDepts.setDisabled(false);
	     			clas.setDisabled(false);
	     		}else{
	     			depts.setDisabled(false);
	     		}
	     	}else if(skuDesc.isDisabled() && (globalVendorControl === '1' || globalVendorControl === '0') ){
	     		console.log("Dashboard.js 3 - 3 - 2 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
	     		skuDesc.setDisabled(true);
	     		skuMode.setDisabled(true);
	     	}else if(!skuDesc.isDisabled() && globalVendorControl === '1' && skuDesc.getValue() != null){
	     		console.log("Dashboard.js 3 - 3 - 3 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
	     		vendorNo.setDisabled(true);
	     		vendorName.setDisabled(true);
	     		venNameMode.setDisabled(true);
	     		skuDesc.setDisabled(false);
	     		skuMode.setDisabled(false);
	     		sku.setDisabled(true);
	     		upcs.setDisabled(true);
	     		depts.setDisabled(true);
	     		subDepts.setDisabled(true);
	     		clas.setDisabled(true);
	     		// RC::
	     		//merchAnalyzer.setDisabled(true);
	     	}else if(skuDesc.isDisabled() && (globalVendorControl === '2') ){
	     		console.log("Dashboard.js 3 - 3 - 4 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
	     		//DO nothing
	     	}else if(!skuDesc.isDisabled() && (globalVendorControl === '2') ){
	     		console.log("Dashboard.js 3 - 3 - 5 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
	     		//DO nothing
	     	}else{
	     		
	     		console.log("Dashboard.js 3 - 3 - 6 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
	     		if(skuDesc.getValue() == null || (skuDesc.getValue() != null && skuDesc.getValue().length === 0)){
	     			console.log("Dashboard.js 3 - 3 - 7 disableBySkuDesc  skuDesc.getValue() = "+skuDesc);
	     			vendorNo.setDisabled(false);
	     			if(!Ext.isEmpty(vendorName.getValue())){
	         			vendorName.setDisabled(true);
	         			venNameMode.setDisabled(true);
	         		}else{
	         		vendorName.setDisabled(false);
	         		venNameMode.setDisabled(false);
	         		}
	         		
	         		sku.setDisabled(false);
	         		upcs.setDisabled(false);
	         		if(!Ext.isEmpty(depts.getValue)){
	         			depts.setDisabled(false);
	         			subDepts.setDisabled(false);
	         			clas.setDisabled(false);
	         		}else{
	         			depts.setDisabled(false);
	         		}
	     		}
	     		else
	     		{
	     			console.log("Dashboard.js 3 - 3 - 8 disableBySkuDesc  skuDesc.getValue() = "+skuDesc +" globalVendorControl = "+globalVendorControl);
	     			vendorNo.setDisabled(true);
	     			vendorNo.setValue(null);

	 	    		vendorName.setDisabled(true);
	 	    		venNameMode.setDisabled(true);
	 	    		vendorName.setValue(null); 	
	 	    		sku.setDisabled(true);
	 	    		sku.setValue(null);
	 	    		upcs.setDisabled(true);
	 	    		upcs.setValue(null);
	 	
	 		    	depts.setDisabled(true);
	 		    	depts.setValue(null);
	     		}
	      }		
	 },
	 
	 // delete below 
	 disableBySkuDesc : function(combo, newValue, oldValue, eOpts) {
		       console.log("Dashboard.js 3 - 1 disableBySkuDesc  combo = "+combo +" newValue = "+newValue);
		       console.log("Dashboard.js 3 - 1 - 1 ### params.concept = "+params.concept +" country = "+params.country);
	 
	    		var elasticQuery = null;
	    		if (!Ext.isEmpty(newValue)) {
	    			newValue = newValue.replace('"', '\\"');
	    		}
	    		if (combo.getItemId() === 'skuDesc') {
	    			elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "cts"}}, {"term":{"DESCRIPTION.DESCRIPTION_AUTOCOMPLETE":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[{ "DESCRIPTION.DESCRIPTION_SORT" : "asc"}],"aggregations":{}}';
	    			/*
	    			if (skuDescMode === 'S') {
	    				elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "cts"}}, {"term":{"DESCRIPTION.DESCRIPTION_AUTOCOMPLETE":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[{ "DESCRIPTION.DESCRIPTION_SORT" : "asc"}],"aggregations":{}}';
	    			}
	    			else {
	    				elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "cts"}}, {"term":{"DESCRIPTION.DESCRIPTION_CONTAINS":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[{ "DESCRIPTION.DESCRIPTION_SORT" : "asc"}],"aggregations":{}}';
	    			}*/
	    			elasticQuery = elasticQuery.replace('AAA', !Ext.isEmpty(newValue) ? newValue.toLowerCase() : '');
	    		}
	    		
	    		//console.log("setProxyURL 1 - 4 ### params.concept = "+params.concept +" country = "+params.country);
	    		//params['googleLikeElasticSearchUrl'] = base_lookup_url+'lookup_sku/_search?source=';
	    		// url: 'http://192.168.192.160/elasticsearch/lookups5/' + 'lookup_event/_search',
	    		//jsonData
	    		 
	    		 //var googleLikeElasticSearchUrl = 'http://192.168.192.160/elasticsearch/lookups5/' + 'lookup_sku/_search';
	    		 var googleLikeElasticSearchUrl = base_lookup_url  + 'lookup_sku/_search';
                
	    		//elasticQuery = encodeURIComponent(elasticQuery);
	    		if (combo.getItemId() === 'merchAnalyzer') {
//	    			combo.getStore().model.proxy.url = params.maSearchUrl + elasticQuery;
	    			combo.getStore().model.proxy.url = params.maSearchUrl.substring(0, params.maSearchUrl.indexOf("?"));
	    			combo.getStore().model.proxy.jsonData= elasticQuery;
	    		}
	    		else {
	    			console.log("Dashboard.js 3 - 1 - 2 disableBySkuDesc  combo = "+combo);
//	    			combo.getStore().model.proxy.url = params.googleLikeElasticSearchUrl + elasticQuery;
	    			//combo.getStore().model.proxy.url = params['googleLikeElasticSearchUrl'].substring(0, params['googleLikeElasticSearchUrl'].indexOf("?"));
	    			//combo.getStore().model.proxy.url = googleLikeElasticSearchUrl.substring(0, googleLikeElasticSearchUrl.indexOf("?"));
	    			//combo.getStore().model.proxy.jsonData= elasticQuery;
	    			
	    			combo.getStore().proxy.url = googleLikeElasticSearchUrl.substring(0, googleLikeElasticSearchUrl.indexOf("?"));
	    			combo.getStore().proxy.jsonData= elasticQuery;
	    			
	    		}
	    		if (Ext.isEmpty(newValue)) {
	    			combo.getStore().removeAll();
	    		}
	 },
	 	
	 merchAnalyzerProxyURL_OLD : function(combo, newValue, oldValue, eOpts) {
    	console.log("setProxyURL 1 ### combo = "+combo +" newValue = "+newValue +" oldValue = "+oldValue);
 		
    	var elasticQuery = null;
 		if (!Ext.isEmpty(newValue)) {
 			newValue = newValue.replace('"', '\\"');
 		}
 		
 		if (combo.getItemId() === 'merchAnalyzer') {
 			elasticQuery = '{"query":{"bool":{"must":[{"term" : {"COUNTRY" : "usa"}}, {"term" : {"CONCEPT" : "cts"}}, {"term":{"GP_COMBINED.GP_COMBINED_CONTAINS":"AAA"}}],"must_not":[],"should":[]}},"from":0,"size":50,"sort":[ {"GP_COMBINED.GP_COMBINED_SORT" : "asc"}],"aggregations":{}}';
 			elasticQuery = elasticQuery.replace('AAA', !Ext.isEmpty(newValue) ? newValue.toLowerCase() : '');
 		}
 		
 		console.log("setProxyURL 1 - 1 ### elasticQuery = "+elasticQuery);
 		console.log("setProxyURL 1 - 2 ### params.maSearchUrl = "+params.maSearchUrl);
 		console.log("setProxyURL 1 - 3 ### params.concept = "+params.concept);
 		console.log("setProxyURL 1 - 4 ### params.vipurl = "+params.vipurl);
 		console.log("setProxyURL 1 - 5 ### params.base_lookup_url = "+params.base_lookup_url);
 		
 		params.maSearchUrl = params.vipurl + 'elasticsearch/lookups5/' + 'lookup_merchandiseanalyzer/_search?source=';
 		console.log("setProxyURL 1 - 6 ### params.maSearchUrl = "+params.maSearchUrl);
 		console.log("setProxyURL 1 - 7 ###!!!!! jsonData = "+combo.getStore().proxy.jsonData);
        
 		/*
 		//elasticQuery = encodeURIComponent(elasticQuery);
 		if (combo.getItemId() === 'merchAnalyzer') {
 			
 			console.log("setProxyURL ### 1 - 7 combo.getStore().model.proxy.url = "+combo.getStore().model.proxy.url);
// 			combo.getStore().model.proxy.url = params.maSearchUrl + elasticQuery;
 			combo.getStore().model.proxy.url = params.maSearchUrl.substring(0, params.maSearchUrl.indexOf("?"));
 			combo.getStore().model.proxy.jsonData= elasticQuery;
 		}
 		else {
// 			combo.getStore().model.proxy.url = params.googleLikeElasticSearchUrl + elasticQuery;
 			combo.getStore().model.proxy.url = params['googleLikeElasticSearchUrl'].substring(0, params['googleLikeElasticSearchUrl'].indexOf("?"));
 			combo.getStore().model.proxy.jsonData= elasticQuery;
 			
 		}		
 		
 		if (Ext.isEmpty(newValue)) {
 			combo.getStore().removeAll();
 		}*/
        
        //combo.getStore().proxy.extraParams = elasticQuery; //extraParams;
        //combo.getStore().proxy.jsonData = elasticQuery;
        //combo.getStore().proxy.Proxy =  elasticQuery;
        combo.getStore().load({
        	//jsonData: elasticQuery,
    		callback: function(records, operation, success) {
    			if(!success){
    				//if(!Ext.isEmpty(operation._response))
        			//{
        				
        			//}	
    		    }     			
    		},
            scope: this
    	});
 	}
	
});