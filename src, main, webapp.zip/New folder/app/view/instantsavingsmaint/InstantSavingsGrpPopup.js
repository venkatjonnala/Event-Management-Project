Ext.define('SSM.view.instantsavingsmaint.InstantSavingsGrpPopup', {
			extend : 'Ext.Window',
			alias : 'widget.instantsavingsgrppopup',			
			width : 800,
			height : 200,			
			modal : true,
			title : i18n.text.grouppopup,
			closable : true,
			autoScroll: true,
		    autoShow: true,
			layout: "fit",
			layoutConfig: {
			    align : 'stretch',
			    pack  : 'start'
			},
		    header:{
                //titlePosition: 0,
                items:[{
		        	xtype : 'displayfield',
		        	itemId: 'skuForGroupId',
		        	name: 'skuForGroupId',
		        	value: ''
		        	//width : 160
		        }]    
            },
            requires : [
                        'Ext.grid.GridPanel',
                        'SSM.view.instantsavingsmaint.InstantSavingsGrpPopupGrid'
                        ],
			
			items : [{
				xtype : 'instantsavingsgrppopupgrid'
			}]	
});	

