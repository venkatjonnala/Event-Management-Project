Ext.define('SSM.view.instantsavingsmaint.InstantSavingsGrpPopupGrid', {
	extend: 'Ext.grid.Panel',   
    alias: 'widget.instantsavingsgrppopupgrid',
    itemId: 'instantsavingsgrppopupgrid',
    name: 'instantsavingsgrppopupgrid',
    store: {
        type: 'instantsavingsgrppopupgridstore'
    },
    columnLines: true,
    region: 'center',
    flex: 1,
    border: true,
    frame: false,
    //autoHeight : true,
    //height: 670,
    //padding: '0px 2px 0px 2px',
    viewConfig: {
        deferEmptyText: false,
        emptyText: i18n.text.NoResults
    },
    
    dockedItems: [
		{
		    xtype: 'toolbar',
		    dock: 'bottom',
		    border: true,
		    frame: true,
		    autoWidth: true,
		    style: {
		        background: '#F5F8FB'
		    },
		    defaults: {
		        scale: 'small'
		    },
		    items: ['->',
		        {
	   	    	   xtype:'button',
	  	    	   itemId: 'InstantSavingsGrpPopup',    	  
	  	    	   width: 75,
	               style: {
	            	   background: '#476FA7',
	                   borderColor: '#476FA7'
	               },
	  	    	   maxHeight:22,
	  	    	   text:'<span style="color:white">Ok</span>',
	  	    	   //handler: 'instantSavingsGrpPopupHandler'
	  	    		 handler: function(){	  	    			
	  	    			this.up('instantsavingsgrppopup').close();
	                 }
	    	     }
		    ]
		}
	],
    columns: {
        defaults: {
            style: 'text-align:center',
            draggable: false,
            autoExpandColumn: true,
            menuDisabled: true,
            //sortable: false,
            resizable: true,
            hideable: false
        },
        items: [/*{
            xtype: 'fiddlecheckcolumn',
            dataIndex: 'groupEligFl',
            text: 'Active',
            autoExpandColumn: true,
            sortable: false,
            sortDir: 'DESC',
            align: 'center',
            style: 'text-align:center',
            flex: .5
        },*/{
            xtype: 'gridcolumn',
            dataIndex: 'isAsnum',
            itemId: 'isAsnum',
            text: i18n.header.vendor,
            autoExpandColumn: true,
            //menuDisabled: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'isDept',
            text: i18n.header.dept,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'isSdept',
            text: i18n.header.subdept,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,           
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        },         
        {
            xtype: 'gridcolumn',
            dataIndex: 'isClas',
            text: i18n.header.clas,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,           
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        },         
        {
            xtype: 'gridcolumn',
            dataIndex: 'isevt',
            text: i18n.header.eventname,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'isma',
            text: i18n.header.merchanalyz,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'right',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'isinumbr',
            text: i18n.header.sku,
            autoExpandColumn: true,
            menuDisabled: true,
            hidden: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .5,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        }, 
        {
            xtype: 'gridcolumn',
            dataIndex: 'isId',
            text: 'isId',
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'right',
            style: 'text-align:center',
            flex: .7,
            hidden: true
        },
        {
            xtype: 'gridcolumn',
            dataIndex: 'isId',
            text: 'Action',
            autoExpandColumn: true,
            sortable: false,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            hidden: true,
            flex: .26,
            renderer: function (v, m, r) {
                var id = Ext.id();
                Ext.defer(function () {
                    Ext.widget('button', {
                        renderTo: id,
                        //text: 'Edit: ' + r.get('groupElgFlag'),
                        text:  r.get('groupElgFlag'),
                        width: 75
                        //handler: function () { Ext.Msg.alert('Info', r.get('isId')) },
                        //handler: 'instSavingsSaveDelHandler',
                    });
                }, 50);
                return Ext.String.format('<div id="{0}"></div>', id);
            }
        }
        ]
    }
});
