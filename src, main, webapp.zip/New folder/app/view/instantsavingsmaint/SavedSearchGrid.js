Ext.define('SSM.view.instantsavingsmaint.SavedSearchGrid', {
	extend: 'Ext.grid.Panel',   
    alias: 'widget.savedsearchgrid',
    itemId: 'savedsearchgrid',
    name: 'savedsearchgrid',
    store: {
        type: 'savesearchstore'
    },
    
    forceFit: true,
	hideHeaders: true,
	flex : 1,
	scroll :true,
	padding : 1,
	width: 200,
	height: 110,
    
	/*
    columnLines: true,
    region: 'center',
    flex: 1,
    border: true,
    frame: false,
    padding: '0px 2px 0px 2px',    
    viewConfig: {
        deferEmptyText: false,
        emptyText: i18n.text.NoResults
    },*/

   
    columns : [
	           {
	        	   xtype : 'gridcolumn',
	        	   width : 170,
	        	   dataIndex : 'searchName'
	           },
	           {
	        	   xtype  : 'actioncolumn',
	        	   itemId : 'deleteSavedSearch',
	        	   name   : 'deleteSavedSearch',
	        	   width  : 30,
	        	   //iconCls: 'logout'
	        	   //iconCls: 'x-fa fa-book',
	        	   //iconCls: 'x-fa fa-check',
	        	   //iconCls: 'x-fa fa-delete_black1',
	        	   //iconCls: 'x-fa fa-Delete',
	        	   iconCls: 'x-fa fa-trash'
	        	   /*items:[
	        	          {
	        	        	  getClass : function(v, meta, rec)
	        	        	  {
	        	        		  return Ext.decode(params.userPrivileges).indexOf("Save_Search_By_Store") === -1 ? 'hide_action_column' : 'delete';
	        	        	  }
	        	          }
	        	          ]*/
	           }
	]

   
});
