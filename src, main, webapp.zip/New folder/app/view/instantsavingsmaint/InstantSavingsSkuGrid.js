Ext.define('SSM.view.instantsavingsmaint.InstantSavingsSkuGrid', {
	extend: 'Ext.grid.Panel',   
    alias: 'widget.instantSavingsSkuGrid',
    itemId: 'instantSavingsSkuGrid',
    name: 'instantSavingsSkuGrid',
    store: {
        type: 'instantsavingsskustore'
    },
    columnLines: true,
    region: 'center',
    flex: 1,
    border: true,
    frame: false,
    //height: 420,
    //autoScroll: true,
    padding: '0px 2px 0px 2px',
    //this adds a checkbox which when checked also highlights the row. No red dirty indicator
    //selModel: Ext.create('Ext.selection.CheckboxModel'),
    viewConfig: {
        deferEmptyText: false,
        emptyText: i18n.text.NoResults
    },
    dockedItems: [
		{
		    xtype: 'toolbar',
		    dock: 'top',
		    border: false,
		    frame: false,
		    style: {
		        background: '#F5F8FB'
		    },
		    defaults: {
		        scale: 'small'
		    },
		    items: [
		        {
		        	xtype : 'displayfield',
		        	value: i18n.text.instantsavingsbysku,
		        	width : 160
		        }, {
	     	    	   xtype:'button',
	    	    	   itemId: 'ShowGroupElgiBtn',
	    	    	   action: 'ShowGroupElgiBtn',    	    	  
	    	    	   width: 130,
	    	    	   /* Old Blue
	                   style: {
	                       background: '#476FA7',
	                       borderColor: '#476FA7'
	                   },*/
	    	    	   /* New Blue */
	                   style: {
	                       background: '#157FCC',
	                       borderColor: '#157FCC'
	                   },
	    	    	   //text: 'Switch to Group',
	    	    	   text: '<div style="color: white">Switch to Group</div>', 
	    	    	   handler: 'ShowInsSavingsByGroupHandler'
		    	}
		    ]
		},
		{
		    xtype: 'toolbar',
		    dock: 'bottom',
		    border: true,
		    frame: true,
		    autoWidth: true,
		    style: {
		        background: '#F5F8FB'
		    },
		    defaults: {
		        scale: 'small'
		    },
		    items: ['->',
		        {
     	    	   xtype:'button',
    	    	   itemId: 'saveInstantSavings',
    	    	   action: 'saveInstantSavings', /* saveInstantSavingsBySku ?? */     	    	  
    	    	   width: 75,
    	    	   /* Orange
                   style: {
                       background: '#E49501',
                       borderColor: '#CE8600'
                   },*/
    	    	   /* New Blue */
                   style: {
                       background: '#157FCC',
                       borderColor: '#157FCC'
                   },
    	    	   maxHeight:22,
    	    	   text:'<span style="color:white">Save</span>',
    	    	   handler: 'saveInstantSavingsSkuHandler'
	    	     }
		    ]
		},
        {
            xtype: 'pagingtoolbar',
            dock:'bottom',
            name: 'pagingBar',
            itemId: 'pagingBar',
            displayInfo: true,
            displayMsg: 'Displaying data {0} - {1} of {2}',
            emptyMsg: i18n.text.NoResults,
            border: true,
            frame: true,
            enableFocusableContainer : true,
            style: {
                background: '#F5F8FB'
            },
            defaults: {
                scale: 'small'
            },
            items: [],
            listeners:{
	         	beforechange: 'saveInstantSavingsSkuBeforeChange' 
            }
        }
    ],
    columns: {
        defaults: {
            style: 'text-align:center',
            draggable: false,
            autoExpandColumn: true,
            menuDisabled: true,
            //sortable: false,
            resizable: true,
            hideable: false
        },
        items: [
        {
            xtype: 'fiddlecheckcolumn',
            dataIndex: 'instSaveElig',
            text: 'Active',
            autoExpandColumn: true,
            sortable: false,
            sortDir: 'DESC',
            align: 'center',
            style: 'text-align:center',
            flex: .1
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'vendorNo',
            itemId: 'order',
            text: i18n.header.vendor,
            autoExpandColumn: true,
            //menuDisabled: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .2
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'dept',
            text: i18n.header.dept,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'left',
            style: 'text-align:center',
            flex: .15

        }, {
            xtype: 'gridcolumn',
            dataIndex: 'subDept',
            text: i18n.header.subdept,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,           
            align: 'left',
            style: 'text-align:center',
            flex: .2
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'clas',
            text: i18n.header.clas,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,           
            align: 'left',
            style: 'text-align:center',
            flex: .15
        },  {
            xtype: 'gridcolumn',
            dataIndex: 'groupSelectionFlag',
            text: 'Group',
            autoExpandColumn: true,
            sortable: false,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .20,
            renderer: function (value, metaData, record, rowIndex, colIndex, store, view) {
                return this.ordRenderer(value, record);
            }
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'sku',
            text: i18n.header.sku,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .25
        },
        {
            xtype: 'gridcolumn',
            dataIndex: 'skuDescription',
            text: i18n.header.skuupcdesc,
            autoExpandColumn: true,
            //menuDisabled: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .5,
            renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
            	 if (!Ext.isEmpty(value)) {
            			return '<div data-qtip="' + Ext.util.Format.htmlEncode(value) + '">' + Ext.util.Format.htmlEncode(value) +'</div>';
            	 } else{
            			return value;
            	 }	
           }
        },{
            xtype: 'gridcolumn',
            dataIndex: 'enWebDesc',
            text: 'Web Desc', //i18n.header.skuupcdesc,
            autoExpandColumn: true,
            //menuDisabled: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .5,            
            renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
             	 if (!Ext.isEmpty(value)) {
            			return '<div data-qtip="' + Ext.util.Format.htmlEncode(value) + '">' + Ext.util.Format.htmlEncode(value) +'</div>';
             	 } else{
             			return value;
             	 }	
            }
        },          
        {
            xtype: 'gridcolumn',
            dataIndex: 'eventNumber',
            text: i18n.header.eventname,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'left',
            style: 'text-align:center',
            flex: .3,
            renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
            	 if (!Ext.isEmpty(value)) {
            			return '<div data-qtip="' +value + '">' + value +'</div>';
            	 } else{
            			return value;
            	 }	
           }
            //type: 'int'
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'merchGroup',
            text: i18n.header.merchanalyz,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'left',
            style: 'text-align:center',
            flex: .3,
            renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
            	 if (!Ext.isEmpty(value)) {
            			return '<div data-qtip="' +value + '">' + value +'</div>';
            	 } else{
            			return value;
            	 }	
           }
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'instsaveElg',
            text: 'Flag',
            autoExpandColumn: true,
            //menuDisabled: true,
            sortable: false,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .5,
            hidden: true
        },
        {
            xtype: 'gridcolumn',
            dataIndex: 'isid',
            text: 'Isid',
            autoExpandColumn: true,
            sortable: false,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .5,
            hidden: true
        },
        {
            xtype: 'gridcolumn',
            dataIndex: 'status',
            text: 'Status',
            autoExpandColumn: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .12,
            hidden: false
        }
        ]
    },
    ordRenderer: function (value, record) {    	
    	var grouped = 'Groups';
    	if (record.get('groupSelectionFlag') == false ) {grouped =''; };
    	
        if (record.get('groupSelectionFlag') == true ) {
            return Ext.String.format(
                '<a href="javascript:void(0);">{0}</a>',
                grouped);
        }
        return grouped;
    }
});
