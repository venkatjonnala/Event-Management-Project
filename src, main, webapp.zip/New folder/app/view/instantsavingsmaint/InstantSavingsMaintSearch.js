Ext.define('SSM.view.instantsavingsmaint.InstantSavingsMaintSearch', {
    	//extend: 'Ext.container.Container', 
    	extend: Ext.form.FormPanel,
        alias: 'widget.instantsavingsmaintsearch',
        itemId: 'instantsavingsmaintsearch',
        name: 'instantsavingsmaintsearch',
        reference: 'instantsavingsmaintsearch',
		requires: [
		    'Ext.form.ComboBox', 
		    'SSM.model.lookup.Vendor',
			'SSM.store.lookup.Vendor',
			'SSM.store.combo.SKUStatus',
			'SSM.store.lookup.EventNumber',
			'SSM.model.lookup.EventNumber',
			'SSM.store.lookup.Merchandise',
			'SSM.model.lookup.Merchandise',
			'SSM.store.lookup.MerchAnalyzer',
			'SSM.model.lookup.MerchAnalyzer',
			'Ext.menu.Menu'
		],    
    //width : 800,
    bodyStyle : 'background-color:#F7F7F7; padding: 2px 0px 1px 0px',
    items: [{
    	layout: {
            type: 'vbox',
             align: 'stretch'
        },

    init: function () {
    	
    },        
    xtype: 'fieldset',
    bodyStyle: 'background-color:#F7F7F7;',
    title: i18n.label.searchform,
    itemId: 'weeklySalesFormFieldSet',
    name: 'weeklySalesFormFieldSet',
    defaultType: 'textfield',
    defaultFocus:'#depts',
    collapsible: true,
    margin: 2,
    layout: 'anchor',
    defaults: {
        anchor: '100%'
    },    
    layout: {
        type: 'vbox'
    },   
    items: [{
                xtype: 'container',
                border: false,
                layout: {
                    type: 'hbox'
                },
                layoutConfig: {
                    align: 'stretch'
                },
                items: [{
                	xtype:'lookup',
    	        	fieldLabel: '<b>'+i18n.label.dept+'</b>',
    	        	itemId: 'depts',
    	        	name: 'depts',
					reference: 'depts',
					maskRe: /[0-9,]+/,
    	        	//maskRe: /^$|[0-9,]/,
                	//Without this validator then the default
                	// ExtJS validate was overriding lookupValidate 
					// and clearing errors on Search
	                //	allowBlank: true,
	                //	validateBlank: true,
	                validator: function(){
	                	if (arguments.length>0 && arguments[0].length===0){
	                		return true;
	                	} else {
	                   		return this.isLookupValid(arguments);
	                	}
	                },
                    width: 265,
                    labelWidth: 70,
                    padding: '4 0 0 0',                    
    	        	value:'', 
    	        	disabledCls: "disabledComboTestCls",
    	        	lookupconfig:{
    	        		lookuptype:'departmentlookup',
    	        		idcolumn: 'deptno',
    	        		maxselections: '5',
    	        		pageSize: '25',
    	        		defaultfields: [{name:'country',value: params.country},{name:'concept',value:[params.concept]},{name:'deptconcept',value:[params.concept], searchType:'nosearch'}]
    	        	},
    	        	listeners:{
    	        		'preLookupLaunch':function(lookup){
  	        			//lookup.lookupconfig.defaultfields = [{name:'country',value: params.country},{name:'concept',value:[params.concept]},{name:'deptconcept',value:[params.concept]}];
    	        			if(!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
    	        				lookup.setValue('');
    	        				return true;
    	        			}
    	        		},
    	        		'postLookupValidate': function (lookup,validList,inValidList){
    	        			lookup.lookupconfig.defaultfields = [{name:'country',value: params.country},{name:'concept',value:[params.concept]}];
    	        			skuValidList = true;
    	        			upcValidList = true;
    	        			deptValidList = true;
    	        			subDeptValidList = true;
    	        			clasValidList = true;
    	        			storeValidList = true;
    	        			vendorValidList = true;
    	        			if(inValidList.length > 0){
    	        				deptValidList = false;
    	        			}
    	        		},
    	        		afterrender: function(field) {
		        		   Ext.defer(function() {
		        		       field.focus(true, 100);
		        		   }, 1);
    	    	        }
    	        	}
                }, {
                	xtype:'lookup',
    	        	fieldLabel: '<b>'+i18n.label.subdept+'</b>',
    	        	itemId: 'subdepts',
    	        	name: 'subdepts',             
					reference: 'subdepts',
    	        	maskRe: /[0-9,]+/,
                	//Without this validator then the default
                	// ExtJS validate was overriding lookupValidate 
					// and clearing errors on Search
                	validator: function(){
                        return this.isLookupValid(arguments);
                	},
    	        	disabled: true,
                    labelWidth: 100,
                    width: 275,
                    padding: '4 0 0 15',
    	        	disabledCls: "disabledComboTestCls",
    	        	value:'', 
    	        	lookupconfig:{
    	        		lookuptype:'subdepartmentlookup',
    	        		idcolumn: 'subdeptno',
    	        		maxselections: '5',
    	        		defaultfields: [{name:'country',value: params.country},{name:'concept',value:params.concept},{'name':'deptno',value:''}],
    	        		pageSize: '25'
    	        	},
    	        	listeners:{
    	        		'preLookupLaunch':function(lookup){
    	        			if(!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
    	        				lookup.setValue('');
    	        				return true;
    	        			}
    	        		},
    	        		'postLookupValidate': function (lookup,validList,inValidList){
    	        			skuValidList = true;
    	        			upcValidList = true;
    	        			deptValidList = true;
    	        			subDeptValidList = true;
    	        			clasValidList = true;
    	        			storeValidList = true;
    	        			vendorValidList = true;
    	        			if(inValidList.length > 0){
    	        				subDeptValidList = false;
    	        			}
    	        		}
    	        	}
                }, {
                	xtype:'lookup',
    	        	fieldLabel: i18n.label.clas,
    	        	itemId: 'clas',
    	        	name: 'clas',                                                 
					reference: 'clas',
    	        	disabled: true,
    	        	disabledCls: "disabledComboTestCls",
                	allowBlank: true,
    	        	maskRe: /[0-9,]+/,
                	//Without this validator then the default
                	// ExtJS validate was overriding lookupValidate 
					// and clearing errors on Search
                	validator: function(){
                        return this.isLookupValid(arguments);
                	},
                    width: 250,
                    labelWidth: 100,
                    padding: '4 0 0 15',
    	        	lookupconfig:{
    	        		lookuptype:'classlookup',
    	        		idcolumn: 'classno',
    	        		maxselections: '5',
    	        		defaultFields: [{name:'country',value: params.country},{name:'concept',value:params.concept},{'name':'deptno',value:''},{'name':'subdeptno',value:''}],
    	        		pageSize: '25'
    	        	},
    	        	listeners:{
    	        		'preLookupLaunch':function(lookup){
    	        			if(!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
    	        				lookup.setValue('');
    	        				return true;
    	        			}
    	        		},
    	        		'postLookupValidate': function (lookup,validList,inValidList){
    	        			skuValidList = true;
    	        			upcValidList = true;
    	        			deptValidList = true;
    	        			subDeptValidList = true;
    	        			clasValidList = true;
    	        			storeValidList = true;
    	        			vendorValidList = true;
    	        			if(inValidList.length > 0){
    	        				clasValidList = false;
    	        			}
    	        		}
    	        	}
                }
            ]
            }, 
            ///////////////////// 2///////////////////////////////////
            {
                xtype: 'container',
                border: false,
                layout: {
                    type: 'hbox'
                },
                items: [{
                	xtype:'lookup',
                	fieldLabel: i18n.label.vendorno,
                	itemId: 'vendorNos',
                	name: 'vendorNos',
					reference: 'vendorNos',
					maskRe: /[0-9,]/,
                	//Without this validator then the default
                	// ExtJS validate was overriding lookupValidate 
					// and clearing errors on Search
                	validator: function(){
                        return this.isLookupValid(arguments);
                	},
                	width: 265,
                	labelWidth: 70,
                	padding: '4 0 0 0',
                	disabledCls: "disabledComboTestCls",
                	allowBlank: true,
                	value:'', 
                	lookupconfig:{
                		lookuptype:'vendorlookup',
                		idcolumn: 'vendorno',
                		maxselections: '5',
                		pageSize: '25',
                		defaultfields: [{name:'country',value: params.country},{name:'concept',value:params.concept}]
                	}
                },
                {
            		xtype: 'combo',
	        		fieldLabel: i18n.label.vendorname,
	        		labelWidth: 100,
	                width: 250,   
	                padding: '4 1 0 15',  
	        		itemId: 'vendorName',
	                name: 'vendorName',
					reference: 'vendorName',
	        		hidden: false,    	        		
	        		displayField: 'NAME',
	        		valueField: 'NAME',
	        		queryParam:'NAME',
	        		
	        		hideTrigger: 'true',
	        		triggerAction:'query',
	        		disabledCls: "disabledComboTestCls",
                	allowBlank: true,
	        		autoSelect: false,   
	        		store: {
	                   type: 'lookupvendor'
	        		},
	        		minChars:3,
	        		queryMode: 'remote',
	        		enforceMaxLength:true,
	        		minLength:3,
	        		maxLength:30,
	        		matchFieldWidth:false,
	        		lastQuery: '',
					listeners:{
                          afterrender:{
                              fn:function(combo){
                                 combo.getPicker().setWidth(270);
                                 combo.getPicker().setBorder(0);
                              }
                           },
                           beforequery: function(qe){
                                   delete qe.combo.lastQuery;
			               },
				            specialkey: function(combo, e){
				            	if (e.getKey() == e.BACKSPACE || e.getKey() == e.DELETE) {
    	        					combo.getStore().removeAll();
    	        				}
				            	/*
				            	if (e.getKey() === e.BACKSPACE || e.getKey() === e.DELETE || e.getKey() === e.TAB) {			                           
				                    combo.getStore().removeAll();
				                    if(e.getKey() === e.TAB && (!combo.getRawValue() || combo.getRawValue() === ''))
				                    {
				                         combo.setValue(null);
				                    }
			                    }*/
				             }
					}
			    },				
     	       {
     	    	   xtype:'button',
    	    	   itemId: 'venNameMode',
    	    	   action: 'venNameMode',
    	    	   width: 25,
    	    	   maxHeight:22,
    	    	   margin: '5 0 7 0',
    	    	   //margin: '7 7 7 0',
    	    	   text: i18n.label.startWith,
    	    	   tooltip:i18n.tooltip.startWith
    	       }, {
                	xtype: 'textfield',
                    align: 'left',
                    itemId: 'eventnumber_1',
                    name: 'eventnumber_1',
                    flex: 1,
                    fieldLabel: i18n.label.eventnumber,
                    width: 250, 
                    labelWidth: 100,  
                    padding: '4 0 0 15',
                    hidden: true
                }, {
	        		xtype: 'combo',
	        		fieldLabel: i18n.label.eventnumber,
        		    maskRe: /[0-9]*/, 
        		    //maskRe: /^[a-zA-Z0-9-.\'\"%#&()\/,@$*!]/, 
	        		labelWidth: 100,
                    width: 250,
                    padding: '4 1 0 15',
	        		//name:'eventnumbercombo',
	        		//itemId:'eventnumbercombo',
	        		itemId: 'eventnumber',
	                name: 'eventnumber',
					reference: 'eventnumber',
	        		hidden: false,
	        		
	        		//displayField: 'GP_COMBINED',
					//valueField: 'CODE',
					//queryParam:'CODE',
	        		
	        		//displayField: 'eventNumber',
	        		//valueField: 'eventNumber',
	        		//queryParam:'eventNumber',
	        		
	        		displayField: 'EVENTNO',
	        		valueField: 'EVENTNO',
	        		queryParam:'EVENTNO',
	        		
	        		hideTrigger: 'true',
	        		triggerAction:'query',
	        		disabledCls: "disabledComboTestCls",
                	allowBlank: true,
	        		autoSelect: false,   
	        		store: {
	                   type: 'lookupeventnumber'
	        		},
	        		minChars:3,
	        		queryMode: 'remote',
	        		enforceMaxLength:true,
	        		minLength:3,
	        		//maxLength:6,
	        		maxLength:34,
	        		matchFieldWidth:false,
	        		lastQuery: '',
                	//Moved this to a function called on submit
	        		/*validator: function(combo){
                		if (combo.length === 0){
                			return true;
                		} else if (combo.length < 3){
                    		//TODO: Fix validation. Commented out below. Loading... not going away with this enabled
                    		//return combo + ' is invalid.';
                		} else {
                			if (this.store.lastOptions && this.store.lastOptions.params && this.store.lastOptions.params.EVENTNO==combo){
                    		//TODO: Fix validation. Commented out below. Loading... not going away with this enabled
		            			//this.store.load({params:{EVENTNO:combo}});
                			} 
	                		if (this.store.find('EVENTNO', combo, 0, false, false, true) == -1) { 
                    			//does not exists
                        		return true;
	                    		//TODO: Fix validation. Commented out below. Loading... not going away with this enabled
	                			//this.store.removeAll();
	                			//return combo + ' is invalid.';
                    		} else {
                    			//return true or an error message string
                    			return true;
                    		}
                		}
                	},*/
	        		listeners:{
	        			afterrender:{
	        				fn:function(combo){
	        					combo.getPicker().setWidth(210);
	        					combo.getPicker().setBorder(0);
	        				}
	        			},
	        			beforequery: function(qe){
	        				delete qe.combo.lastQuery;
	        			},
	        			change: function( combo, newValue, oldValue, eOpts ){
	        				if(combo.getValue() == null || combo.getValue() == '') {
	        					combo.getStore().removeAll();
	        					combo.setRawValue(null);
	        					combo.setValue(null);
	        					var form=combo.up('form');
	        					if(!(combo.isDisabled())){
	        						form.down('lookup[itemId=skus]').setValue(null);
	        						form.down('lookup[itemId=upcs]').setValue(null);
	        						form.down('lookup[itemId=vendorNos]').setDisabled(false);
	        					}
	        				}
	        			},
	        			specialkey: function(combo, e){
	        				if (e.getKey() == e.BACKSPACE || 
	        						e.getKey() == e.DELETE) {
	        					combo.getStore().removeAll();
	        				}
	        			}
	        		}
                }
                ]
            },            
            //////////////////////// 3 ///////////////////////////////////////////////            
            {
                xtype: 'container',
                border: false,
                layout: {
                    type: 'hbox'
                },
                items: [{
                	xtype:'lookup',
    	        	fieldLabel: i18n.label.sku,
    	        	itemId: 'skus',
    	        	name: 'skus',             
					reference: 'skus',
    	        	maskRe: /[0-9,]+/,
                	//Without this validator then the default
                	// ExtJS validate was overriding lookupValidate 
					// and clearing errors on Search
                	validator: function(){
                        return this.isLookupValid(arguments);
                	},
    	        	fieldLabel: i18n.label.sku,
	                width: 265,
	                labelWidth: 70,
	                padding: '4 0 0 0',
    	        	labelStyle:"vertical-align=middle",
    	        	value:'', 
    	        	disabledCls: "disabledComboTestCls",
                	allowBlank: true,
    	        	lookupconfig:{
    	        		lookuptype:'itemlookup',         
    	        		idcolumn: 'sku',
    	        		maxselections: '25',
    	        		pageSize: '25',
    	        		defaultfields: [{name:'country',value: params.country},{name:'concept',value: (params.concept=='BABY') ? 'BEDBATH' : params.concept},{name:'primary', value:'Y'}]
    	        	} 	              
                 },
                 {
                	xtype:'lookup',
    	        	fieldLabel: '<b>'+i18n.label.upc+'</b>',
    	        	itemId: 'upcs',
    	        	name: 'upcs',   
					reference: 'upcs',
    	        	maskRe: /[0-9,]+/,
                	//Without this validator then the default
                	// ExtJS validate was overriding lookupValidate 
					// and clearing errors on Search
                	validator: function(){
                        return this.isLookupValid(arguments);
                	},
    	        	width: 275,
                    labelWidth: 100,                        
                    padding: '4 0 0 15',
    	        	value:'', 
    	        	disabledCls: "disabledComboTestCls",
                	allowBlank: true,
    	        	lookupconfig:{
    	        		lookuptype:'itemlookup',
    	        		idcolumn: 'upc',
    	        		maxselections: '25',
    	        		pageSize: '25',
    	        		defaultfields: [{name:'country',value: params.country},{name:'concept',value: (params.concept=='BABY') ? 'BEDBATH' : params.concept}]
    	        	}
                  },
                  {
                		xtype: 'combo',
    	        		fieldLabel: i18n.label.skuupcdesc,
            		    //maskRe: /^[a-zA-Z0-9-.\'\"%#&()\/,@$*!]/, 
    	        		labelWidth: 100,
                        width: 250,
                        padding: '4 1 0 15',
    	        		itemId: 'skuDesc',
    	                name: 'skuDesc',
    					reference: 'skuDesc',
    	        		hidden: false,    	        		
    	        		displayField: 'DESCRIPTION',
    	        		valueField: 'DESCRIPTION',
    	        		queryParam:'DESCRIPTION',
    	        		
    	        		hideTrigger: 'true',
    	        		triggerAction:'query',
    	        		disabledCls: "disabledComboTestCls",
                    	allowBlank: true,
    	        		autoSelect: false,   
    	        		store: {
    	                   type: 'lookupskudesc'
    	        		},
    	        		minChars:3,
    	        		queryMode: 'remote',
    	        		enforceMaxLength:true,
    	        		minLength:3,
    	        		maxLength:30,
    	        		matchFieldWidth:false,
    	        		lastQuery: '',
    	        		listeners:{
    	        			afterrender:{
    	        				fn:function(combo){
    	        					combo.getPicker().setWidth(210);
    	        					combo.getPicker().setBorder(0);
    	        				}
    	        			},
    	        			beforequery: function(qe){
    	        				delete qe.combo.lastQuery;
    	        			},
    	        			change: function( combo, newValue, oldValue, eOpts ){
    	        				if(combo.getValue() == null || combo.getValue() == '') {
    	        					combo.getStore().removeAll();
    	        					combo.setRawValue(null);
    	        					combo.setValue(null);
    	        					var form=combo.up('form');
    	        					if(!(combo.isDisabled())){
    	        						form.down('lookup[itemId=skus]').setValue(null);
    	        						form.down('lookup[itemId=upcs]').setValue(null);
    	        						form.down('lookup[itemId=vendorNos]').setDisabled(false);
    	        					}
    	        				}
    	        			},
    	        			specialkey: function(combo, e){
    	        				if (e.getKey() == e.BACKSPACE || 
    	        						e.getKey() == e.DELETE) {
    	        					combo.getStore().removeAll();
    	        				}
    	        			}
    	        		}                    
                  },
                {
	        		xtype:'button',
	        		itemId: 'skuMode',
	        		action: 'skuMode',
	        		width: 25,
	        		maxHeight:22,
	        		//padding: '4 1 0 15',
	        		//padding: '4 0 0 0',
	        		margin: '5 0 7 0',
	        		text: i18n.label.startWith,
	        		tooltip:i18n.tooltip.startWith
	        	}]
            },            
            //////////////////// 4///////////////////////////
            {
            	flex:1,	
            	xtype: 'container',
                border: false,
                layout: {
                    type: 'hbox'
                },
                layoutConfig : {
					align : 'stretch'
				},
                items: [{
	                xtype: 'tagfield',     	                
	                store: {
	                    type: 'skustatus'
	                },
	                
	                editable: true,
	                triggerAction:'all',
	                multiSelect: true,
                	allowBlank: true,
	                //value: ['A', 'I'],    
	                //value: ['A', 'I','N','D'],
	                displayField: 'id',
	                valueField: 'value',	                
	                filterPickList: true,	                
	                //expand: Ext.emptyFn,
	                hideTrigger: false,
	                queryMode: 'local',
	                publishes: 'value',	                
	                itemId: 'skuStatus',
                    name: 'skuStatus',
	                reference: 'skustatus',
                    align: 'left',
	                flex: 1,
                    fieldLabel: i18n.label.skustatus,
                	width: 265,
                	maxWidth: 265,
                	labelWidth: 70,
                	padding: '4 0 0 0'
	            }, 
	            {
		        	xtype: 'combobox',
		        	fieldLabel: i18n.label.merchanalyz,
		        	flex: 1,
		        	labelWidth:100,
		        	width: 275,
		        	name:'merchAnalyzerComb',
		        	itemId:'merchAnalyzerComb',
		        	displayField:'merchAnalyzerComb',
		        	valueField: 'merchAnalyzerCode',
		        	queryParam:'merchAnalyzer',
		        	hideTrigger: 'false',
		        	triggerAction:'query',
		        	autoSelect: false,
                    padding: '4 0 0 15',
		        	//margins: '7 0 7 0',
		        	// pageSize: 10,
		        	// Remote store things
		        	store: {
		                type: 'lookupmerchandise'
		                //type: 'lookup.Merchandise'
		        	},
		        	minChars:3,
		        	minLength:3,
		        	maxLength:100,
		        	queryMode: 'remote',
		        	enforceMaxLength:true,
		        	forceSelection : false,
		        	matchFieldWidth:false,
		        	lastQuery: '',
                	//Moved this to a function called on submit
                	/*validator: function(combo){
                		if (combo.length === 0){
                			this.store.removeAll();
                			return true;
                		} else {
                			this.store.load({
              				   params:{merchAnalyzer: combo},
              				   loadtimer: 60000
                 			});
	                		if (this.store.find('merchAnalyzerComb', combo, 0, false, false, true) == -1) { 
	                			//does not exists
	                			//this.store.removeAll();
	                    		return combo + ' is invalid. Please click one of the suggestions.';
	                		} else {
	                			//this.store.removeAll();
	                			return true;
	                		}
                		}
                	},*/
		        	listeners:{
		        		afterrender:{
		        			fn:function(combo){
		        				combo.getPicker().setWidth(270);
		        				combo.getPicker().setBorder(0);
		        			}
		        		},
		        		beforequery: function(qe){
		        			delete qe.combo.lastQuery;
		        		},
		        		change: function( combo, newValue, oldValue, eOpts ){
		        			if(combo.getValue() == null || combo.getValue() == '') {
		        				combo.getStore().removeAll();
		        				combo.setRawValue(null);
		        				combo.setValue(null);
		        			}
		        		},
		        		specialkey: function(combo, e){
		        			var bTab = (e.getKey() == e.TAB);
		        			if (e.getKey() == e.BACKSPACE || 
		        					e.getKey() == e.DELETE || 
		        					e.getKey() == e.TAB) {
		        				combo.getStore().removeAll();
		        				if(bTab && (combo.getRawValue() == null || combo.getRawValue() == ''))
		        				{
		        					combo.setValue(null);
		        				}
		        			}
		        		}
		        	}
		        }
            ]},
            ////////////////////5//////////////////////

            {
                xtype: 'container',
                padding: '10 5 5 5',
                flex: 1,
                layout: {
                    type: 'hbox'
                },

                items: [{
                    xtype: 'component',
                    flex: 1
                },
                {
                    xtype: 'hidden',
                    name: 'hiddenInstSavingsType',
                    itemId: 'hiddenInstSavingsType',
                    value: 'searchInsSavingsBySku'
                    //value: 'searchStoreSku'
                },
                {
                    xtype: 'checkbox',
                    boxLabel: i18n.label.selectedcriteria,
                    labelAlign: 'left',
                    name: 'selectedCriteria',
                    itemId: 'selectedCriteria',
                    checked: false,
                    inputValue: 'YES',
                    padding: '4 375 0 0'
                },{
                    xtype: 'button',
                    iconCls: null,
                    text: i18n.text.save,
                    hidden: true,
                    width: 75,                  
                    itemId: 'savedSearcheSelBtn',
                    //disabled:params.userLevel=='1'?true:false, //disable for level1 users
                    action: 'saveInsSavingsSelection',
                    handler: 'saveInsSavingsSelectionHandler'
                }, 
                {
    	        	xtype:'button',
    	        	text: i18n.text.savedsearches,
    	        	hidden: true,
    	        	itemId: 'savedSearches',
    	        	name: 'savedSearches',    	        	
    	        	handler: 'loadSavedSearchesHandler',
    	        	menu : {
    	        		items: [{
    	        			xtype: 'savedsearchgrid'    	        			
    	        		} 
    	        		]
    	        	},
    	        	scale: 'small',
    	        	width: 140
    	        }, 
                {
                    xtype: 'button',
                    iconCls: null,
                    text: i18n.text.reset,
                    width: 75,
                    itemId: 'resetIsmBtn',
                    //action: 'resetIsmBtn'
                    handler: 'resetIsmBtn',
                    margin: '0px 5px 0 0px'
                }, {
                    xtype: 'button',
                    iconCls: null,
                    text: i18n.text.search,
                    width: 75,
                    /* Orange
                    style: {
                        background: '#E49501',
                        borderColor: '#CE8600'
                    },*/
                    itemId: 'searchBtn',
                    name: 'searchBtn',
                    //action: 'searchBtn',
                    handler: 'searchBtnHandler'
                }]
            }
        ]
    }
    ],
    listeners: {
	    afterlayout: function(form) {
	    }
	}
});
