Ext.define('SSM.view.instantsavingsmaint.InstantSavingsGroupGrid', {
	extend: 'Ext.grid.Panel',   
    alias: 'widget.instantSavingsGroupGrid',
    itemId: 'instantSavingsGroupGrid',
    name: 'instantSavingsGroupGrid',
    store: {
        type: 'instantsavingsgroupstore'
    },
    columnLines: true,
    region: 'center',
    flex: 1,
    border: true,
    frame: false,
    height: 420,
    padding: '0px 2px 0px 2px',
    viewConfig: {
        deferEmptyText: false,
        emptyText: i18n.text.NoResults
    },   
    dockedItems: [
		{
		    xtype: 'toolbar',
		    dock: 'top',
		    border: false,
		    frame: false,
		    style: {
		        background: '#F5F8FB'
		    },
		    defaults: {
		        scale: 'small'
		    },
		    items: [
		        {
		        	xtype : 'displayfield',
		        	value: i18n.text.instantavingsbygroup,
		        	width : 180
		        }, {
	     	    	   xtype:'button',
	    	    	   itemId: 'ShowSkuElgiBtn',
	    	    	   action: 'ShowSkuElgiBtn',    	    	  
	    	    	   width: 130,
	    	    	   /* Old Blue
	                   style: {
	                       background: '#476FA7',
	                       borderColor: '#476FA7'
	                   },*/
	    	    	   /* New Blue */
	                   style: {
	                       background: '#157FCC',
	                       borderColor: '#157FCC'
	                   },
	    	    	   //text: 'Switch to SKU ',
	    	    	   text: '<div style="color: white">Switch to SKU</div>',
	    	    	   handler: 'ShowInsSavingsBySkuHandler'
		    	}
		    ]
		},
		{
		    xtype: 'toolbar',
		    dock: 'bottom',
		    border: true,
		    frame: true,
		    autoWidth: true,
		    style: {
		        background: '#F5F8FB'
		    },
		    defaults: {
		        scale: 'small'
		    },
		    items: ['->',
		        {
     	    	   xtype:'button',
    	    	   itemId: 'saveInstantGroup',
    	    	   action: 'saveInstantGroup',    	    	  
    	    	   width: 75,
    	    	   /* Orange
                   style: {
                       background: '#E49501',
                       borderColor: '#CE8600'
                   },*/
    	    	   /* New Blue */
                   style: {
                       background: '#157FCC',
                       borderColor: '#157FCC'
                   },
    	    	   maxHeight:22,
    	    	   text:'<span style="color:white">Save</span>',
    	    	   handler: 'saveInstantSavingsGrpHandler'
	    	     }
		    ]
		},
        {
            xtype: 'pagingtoolbar',
            dock:'bottom',
            name: 'pagingBar',
            itemId: 'pagingBar',
            displayInfo: true,
            displayMsg: 'Displaying data {0} - {1} of {2}',
            emptyText: i18n.text.NoResults,
            border: true,
            frame: true,
            enableFocusableContainer : true,
            style: {
                background: '#F5F8FB'
            },
            defaults: {
                scale: 'small'
            },
            items: [],
            listeners:{
	         	beforechange: 'saveInstantSavingsGrpBeforeChange' 
            }
            //listeners:{
            //	onPagingtoolbarChange: function(pagingtoolbar, pageData, eOpts) {  		
            //	}
            //}
        }
    ],
    columns: {
        defaults: {
            style: 'text-align:center',
            draggable: false,
            autoExpandColumn: true,
            menuDisabled: true,
            //sortable: false,
            resizable: true,
            hideable: false
        },
        items: [
        {
            xtype: 'fiddlecheckcolumn',
            dataIndex: 'groupEligFl',
            text: 'Active',
            autoExpandColumn: true,
            sortable: false,
            sortDir: 'DESC',
            align: 'center',
            style: 'text-align:center',
            flex: .1
        },{
            xtype: 'gridcolumn',
            dataIndex: 'isAsnum',
            itemId: 'isAsnum',
            text: i18n.header.vendor,
            autoExpandColumn: true,
            //menuDisabled: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'isDept',
            text: i18n.header.dept,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'isSdept',
            text: i18n.header.subdept,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,           
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        },         
        {
            xtype: 'gridcolumn',
            dataIndex: 'isClas',
            text: i18n.header.clas,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,           
            align: 'left',
            style: 'text-align:center',
            flex: .4,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        },         
        {
            xtype: 'gridcolumn',
            dataIndex: 'isevt',
            text: i18n.header.eventname,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'left',
            style: 'text-align:center',
            flex: .7,
            renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        }, 
        {
        	xtype: 'gridcolumn',
            dataIndex: 'isma',  // Merchant Analyz
            text: i18n.header.merchanalyz,
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            hidden: false,
            align: 'right',
            style: 'text-align:center',
            flex: .7
            //renderer: function (value, m, r) {if(value === 0){ return ''; } else {return value}}
        },
        {
            xtype: 'gridcolumn',
            dataIndex: 'isId',
            text: 'isId',
            autoExpandColumn: true,
            menuDisabled: true,
            sortable: true,
            align: 'right',
            style: 'text-align:center',
            flex: .7,
            hidden: true
        },
        {
            xtype: 'gridcolumn',
            dataIndex: 'isId',
            text: 'Action',
            autoExpandColumn: true,
            sortable: false,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            hidden: true,
            flex: .26,
            renderer: function (v, m, r) {
                var id = Ext.id();
                Ext.defer(function () {
                    Ext.widget('button', {
                        renderTo: id,
                        //text: 'Edit: ' + r.get('groupElgFlag'),
                        text:  r.get('groupElgFlag'),
                        width: 75
                        //handler: function () { Ext.Msg.alert('Info', r.get('isId')) },
                        //handler: 'instSavingsSaveDelHandler',
                    });
                }, 50);
                return Ext.String.format('<div id="{0}"></div>', id);
            }
        }, {
            xtype: 'gridcolumn',
            dataIndex: 'isinumbr',
            text: i18n.header.sku,
            autoExpandColumn: true,
            menuDisabled: true,
            hidden: true,
            sortable: true,
            sortDir: 'DESC',
            align: 'left',
            style: 'text-align:center',
            flex: .5
        }
    ]
	}
});
