Ext.define('SSM.view.instantsavingsmaint.InstantSavingsMaint', {
	extend : 'Ext.panel.Panel',
	alias : 'widget.instantsavingsmaint',
	
	requires : [		
		'Ext.form.Panel',
		'Ext.form.FieldSet',
		'Ext.form.field.Text',
		'Ext.form.field.Display',
		'Ext.resizer.Splitter',
		
		'SSM.store.InstantSavingsSkuStore',
		'SSM.model.lookup.Vendor',
		'SSM.store.lookup.Vendor',
		
		'SSM.store.SaveSearchStore',
		
		'SSM.store.lookup.Sku',
		'SSM.model.lookup.Sku',
		
		'SSM.view.instantsavingsmaint.InstantSavingsMaintController',
		'SSM.view.instantsavingsmaint.InstantSavingsMaintSearch',		
		'SSM.view.instantsavingsmaint.InstantSavingsSkuGrid',
		'SSM.view.instantsavingsmaint.InstantSavingsMaintViewModel',
		
		//'SSM.store.InstantSavingsMaintGroupStore',
		
		'SSM.view.instantsavingsmaint.InstantSavingsGroupGrid',
		'SSM.store.InstantSavingsGroupStore',
		
		'SSM.view.instantsavingsmaint.SavedSearchGrid',
		
		//'SSM.view.instantsavingsmaint.IsmModel',
		'SSM.view.instantsavingsmaint.CheckColumn',
		'SSM.view.instantsavingsmaint.InstantSavingsGrpPopup',
		'SSM.view.instantsavingsmaint.InstantSavingsGrpPopupGrid',
		'SSM.store.InstantSavingsGrpPopupGridStore'
	],
	
	bodyStyle : {
		//background : '#e5e9ef',
		//padding : '10px'
	},
	bodyBorder : true,
	//bodyPadding : '8',   
	controller : 'instantSavingsMaintController',
	viewModel : {
		type : 'instantSavingsMaintViewModel'
	},
	
	
	itemId : 'instantSavingsMaint',
	//border: false,
	//layout : 'anchor',
	layout : 'border',
	layoutConfig: {
        align: 'stretch'
    },
    resizable: true,
	scrollable : true,
	showToolbar : false,
  
	init: function () {
        var me = this;
    },

    items: [{
        region: 'north',
        xtype: 'instantsavingsmaintsearch'
        //autoHeight: true
    },
	{
        region: 'center',
        //xtype: 'panel',
        //height: 430,
        layout: 'card',
        itemId: 'instantsavingsmaintcard',
        reference: 'instantsavingsmaintcard',
        activeItem: 0,
        items: [{
            id: 'card-0',
            xtype: 'instantSavingsSkuGrid'
            //autoHeight : true
        }, {
            id: 'card-2',
            xtype: 'instantSavingsGroupGrid'
            //autoHeight : true
        }]
    }, {
        region: 'south',
        height: 11,
        items: []
    }
   ]
});