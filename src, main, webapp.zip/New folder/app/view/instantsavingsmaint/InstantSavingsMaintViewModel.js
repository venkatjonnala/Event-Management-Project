Ext.define('SSM.view.instantsavingsmaint.InstantSavingsMaintViewModel', {
	extend : 'Ext.app.ViewModel',

	alias : 'viewmodel.instantSavingsMaintViewModel',

	data : {
		datainfo : true,
		useAppName : ""
	}
});