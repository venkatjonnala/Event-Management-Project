Ext.define('SSM.view.AboutWindow', {
	extend : 'Ext.window.Window',	
	alias:'widget.aboutWindow',
	width  : 400,
	height : 250,	
	bodyPadding: 5,
	title: 'About',
	closeable: false,
	closeAction: 'hide',
	plain: true,	
	modal:true,
	layout: 'fit',
	buttonAlign : 'center',
	items: [{
        xtype: 'displayfield',
        name: 'message',
        itemId:'message',
        padding: 5,
        value: '',
    	renderer: function(value){
    		return value.replace(/\n/g, '<br>');
    	}
    }],
	buttons: [{
		text: 'OK',
		handler: function(btn) {
			btn.up("aboutWindow").close()
		},
		scope : this
	}]
});