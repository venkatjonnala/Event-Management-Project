Ext.define('SSM.view.main.MainViewModel', {
	extend : 'Ext.app.ViewModel',
	alias : 'viewmodel.mainViewModel',

	requires : [
		'Ext.app.bind.Formula',
		'Ext.data.TreeStore'
	],

	data : {
		homeStore : params.strnum,
		homeStoreDesc : '',
		currentFullName : params.fullname,
		searchSku : '',
		searchSkuDesc : '',
		searchStore : params.strnum,
		searchStoreDesc : '',
		searchVendor :  '',
		appErrorMessage: 'Security Error!'
	},

	formulas : {
		selectionText : function(get) {
			var selection = get('treelist.selection'),
				path;
			if (selection) {
				path = selection.getPath('text');
				path = path.replace(/^\/Root/, '');
				return 'Selected: ' + path;
			}
			else {
				return 'No node selected';
			}

		},
		homeStore_homeStoreDesc : {
			bind : {
				num : '{homeStore}',
				desc : '{homeStoreDesc}'
			},
			get : function(data) {
				if (data.desc && ('' + data.desc).trim().length > 0) {
					return i18n.label.store + ' ' + ('' + data.num).trim() + ' - ' + ('' + data.desc).trim();
				}
				else {
					return i18n.label.store + ' ' + ('' + data.num).trim();
				}
			}
		},
		userFullName : {
			bind : {
				desc : '{currentFullName}'
			},
			get : function(data) {
				console.log("userFullName ##########");
				return i18n.label.welcome + ', ' + data.desc.trim() + '!';
			}
		}
	},

	stores : {
		navItems : {
			type : 'tree',
			root : {
				expanded : true,
				children : [
					{
						text : i18n.label.treeInstantSavingsMaint,
						reference : 'treeNodeInstantSavingsMaint',
						iconCls : 'x-fa fa-home',
						id: 2,						
						leaf : true,
						style : {
							height : '30px'
						}
					}
					/*,
					{
						text : i18n.label.treeApp2,
						reference : 'treeNodeApp2',
						iconCls : 'x-fa fa-user',
						leaf : true
					}*/	
					
					/*{
						text : i18n.label.treeSkuPerformance,
						reference : 'treeNodeSkuPer',
						iconCls : 'x-fa fa-home',
						leaf : true,
						style : {
							height : '30px'
						}
					},
					{
						text : i18n.label.treeVendorInq,
						reference : 'treeNodeVendorInq',
						iconCls : 'x-fa fa-user',
						leaf : true
					},					
					{
						text : i18n.label.treeStoreCostRetail,
						reference : 'treeNodeStrCst',
						iconCls : 'x-fa fa-dollar',
						leaf : true
					}*/				
				]
			}
		}
	}
});