Ext.define('SSM.view.main.CountryChangeWindow', {
	extend : 'Ext.Window',
	alias : 'widget.countrychangewindow',
 	controller : 'countrychangecontroller',
	viewModel : {},
	title : i18n.label.countryconceptchage,
	itemId : 'countrychangewindow',
	reference : 'cntryChangeWindow',
	layout : {
		align : 'stretch',
		type : 'vbox'
	},
	autoShow : false,
	resizable : true,
	draggable : true,
	width : 370,
	//height : 180,
	modal : true,

	changeCountry : '',
	changeConcept : '',
	countryStoreList : '',

	listeners : {
		close : 'onWindowClose'
	},

	items : [
		{
			xtype : 'form',
			bodyStyle : 'background-color:#F7F7F7;',
			itemId : 'cntryChangeForm',
			name : 'cntryChangeForm',
			reference : 'cntryChangeForm',
			padding : '0 0 0 0',
			frame : false,
			defaults : {
				margins : 3
			},
			layout : {
				type : 'vbox'
			},
			items : [
				{
					baseCls : 'x-plain',
					border : false,
					width : 350,
					itemId : 'cntryChangeMsg',
					padding : '3 3 10 3',
					bind : {
						html : '{countryChangeMessage}'
					}
				},
				{
					xtype : 'hiddenfield',
					name : 'countryChg',
					itemId : 'countryChg'
				},
				{
					xtype : 'hiddenfield',
					name : 'conceptChg',
					itemId : 'conceptChg'
				},
				{
					xtype : 'lookup',
					fieldLabel : i18n.label.store,
					labelWidth : 50,
					value : params.homeStore,
					maskRe : /^[0-9]/,
					padding : '3 3 10 3',
					width : 165,
					itemId : 'cntryStore',
					value : '',
					allowBlank : false,
					scope : this,
					hidden: true,
					lookupconfig : {
						lookuptype : 'storelookup',
						idcolumn : 'storeno',
						maxselections : '1',
						disabledfields : [ {
							name : 'country'
						} ]
					},
					listeners : {
						'preLookupLaunch' : function(lookup) {
							if (!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
								lookup.setValue('');
								return true;
							}
						}
					}
				}
			]
		}
	],

	buttons : [
		{
			text : i18n.text.ok,
			reference : 'okButton',
	        handler: 'onOkClick'
		},
		{
			text : i18n.text.close,
			reference : 'closeButton',
	        handler: 'onCloseClick'
		} ]
});