Ext.define('SSM.view.main.CountryChangeController', {
	extend : 'Ext.app.ViewController',
	alias : 'controller.countrychangecontroller',
	    
	init : function(window) {
		var me = this;
		
		/* These variable values are used on Reset form */
		me.control({
			'countrychangewindow *' : {
				specialkey : function(field, e) {
					if (e.getKey() == e.ENTER) {
						var searchBtn = me.lookupReference('okButton');
						me.onOkClick(searchBtn);
					}
				}
			}

		});
	
	},

	onOkClick : function(btn) {
		var me = this.getView();
		console.log("CountryChangeController onOkClick");
		//var cntryStoreLookup = me.down('#cntryChangeForm').down('#cntryStore');
		//console.log("CountryChangeController onOkClick cntryStoreLookup = "+cntryStoreLookup);
		//console.log("CountryChangeController onOkClick cntryStoreLookup.isLookupValid() = "+cntryStoreLookup.isLookupValid() +" cntryStoreLookup.value = "+cntryStoreLookup.value);
		console.log("CountryChangeController onOkClick me.changeCountry = "+me.changeCountry +" me.changeConcept = "+me.changeConcept);
		
		//RC:: Store is not required for Instant Savings
		//if (cntryStoreLookup.isLookupValid()) {
			var data = {};
			data.changeCountry = me.changeCountry;
			data.changeConcept = me.changeConcept;
			//data.changeStore = cntryStoreLookup.value;
			
			//RC:: passing dummy Store for Instant Savings
			data.changeStore = i18n.text.cntryChangeDummyStore;
			Ext.GlobalEvents.fireEvent('countrychangewindow_countrychanged', me, data);
		//}
	},
	
	onOkClick_old : function(btn) {
		var me = this.getView();
		console.log("CountryChangeController onOkClick");
		var cntryStoreLookup = me.down('#cntryChangeForm').down('#cntryStore');
		console.log("CountryChangeController onOkClick cntryStoreLookup = "+cntryStoreLookup);
		console.log("CountryChangeController onOkClick cntryStoreLookup.isLookupValid() = "+cntryStoreLookup.isLookupValid() +" cntryStoreLookup.value = "+cntryStoreLookup.value);
		console.log("CountryChangeController onOkClick me.changeCountry = "+me.changeCountry +" me.changeConcept = "+me.changeConcept);
		
		if (cntryStoreLookup.isLookupValid()) {
			var data = {};
			data.changeCountry = me.changeCountry;
			data.changeConcept = me.changeConcept;
			data.changeStore = cntryStoreLookup.value;
			Ext.GlobalEvents.fireEvent('countrychangewindow_countrychanged', me, data);
		}
	},
	
	onCloseClick : function(btn) {
    	var me = this;
    	me.getView().close();
	},
	
	onWindowClose : function() {
    	var me = this;
		var data = {};
		Ext.GlobalEvents.fireEvent('countrychangewindow_countrynotchanged', me, data);
	}
	
})