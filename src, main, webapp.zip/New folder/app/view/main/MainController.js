Ext.define('SSM.view.main.MainController', {
	extend : 'Ext.app.ViewController',
	alias : 'controller.mainController',
	pressed : false,
	gearMenu : null,
	listen : {
		//listen to events using GlobalEvents
		global : {
			//skuinquiry_setmainpage : 'onAfterRender',
			countrychangewindow_countrychanged : 'switchStoreCountryConcept',
			countrychangewindow_countrynotchanged : 'resetStoreCountryConcept'
		}
	},
	init : function(window) {},

	//onMainLoad : function() {		
	onAfterRender : function() {		
		this.setHomeStoreDesc();
		if (this.gearMenu == null) {
			this.createGearMenu();
		}
		
		//var treelist = this.lookupReference('treelist');
		//console.log("MainController 1 - 1 onAfterRender treelist = "+treelist);
        console.log("MainController onAfterRender ############ 0 - 5  params.userid = " + params.userid);
		this.ToggleMicro();
		//console.log("MainController 1 - 1 onAfterRender keys = "+Object.keys(treelist));		
		//console.log("MainController 1 - 1 onAfterRender treelist = "+Object.getOwnPropertyNames(treelist));		
		//var c = treelist.findChild("text","Also ASP.net",true);
		
		/*
		var treelist = this.lookupReference('treelist');
		
		//var node = treelist.findNode('id', 2 );
     	//node.expand();
		treelist.getSelectionModel().select( 2 )
		*/
	},

	onToggleConfig : function(menuitem) {
		var treelist = this.lookupReference('treelist');
		treelist.setConfig(menuitem.config, menuitem.checked);
	},

	onToggleMicro : function(button, e, owner, eOpts) {
		this.ToggleMicro()
	},

	ToggleMicro : function() {
		var treelist = this.lookupReference('treelist'),
			ct = treelist.ownerCt;

		var pressed = !this.pressed;
		if (pressed) {
			this.oldWidth = ct.width;
			ct.setWidth(0);
		}
		else {
			ct.setWidth(this.oldWidth);
		}

		this.pressed = pressed;

		// IE8 has an odd bug with handling font icons in pseudo elements;
		// it will render the icon once and not update it when something
		// like text color is changed via style addition or removal.
		// We have to force icon repaint by adding a style with forced empty
		// pseudo element content, (x-sync-repaint) and removing it back to work
		// around this issue.
		// See this: https://github.com/FortAwesome/Font-Awesome/issues/954
		// and this: https://github.com/twbs/bootstrap/issues/13863
		if (Ext.isIE8) {
			this.repaintList(treelist, pressed);
		}
	},

	onToggleNav : function(button, pressed) {
		var treelist = this.lookupReference('treelist'),
			ct = this.lookupReference('treelistContainer');

		treelist.setExpanderFirst(!pressed);
		treelist.setUi(pressed ? 'nav' : null);
		treelist.setHighlightPath(pressed);
		ct[pressed ? 'addCls' : 'removeCls']('treelist-with-nav');
		if (Ext.isIE8) {
			this.repaintList(treelist);
		}
	},

	repaintList : function(treelist, microMode) {
		treelist.getStore().getRoot().cascadeBy(function(node) {
			var item,
				toolElement;

			item = treelist.getItem(node);
			if (item && item.isTreeListItem) {
				if (microMode) {
					toolElement = item.getToolElement();
					if (toolElement && toolElement.isVisible(true)) {
						toolElement.syncRepaint();
					}
				}
				else {
					if (item.element.isVisible(true)) {
						item.iconElement.syncRepaint();
						item.expanderElement.syncRepaint();
					}
				}
			}
		});
	},
	doAppNavigation : function(tl, record, item, index, e, eOpts) {
		var tree = this.lookupReference('treelist');
		var selReference = record.node.raw.reference;

		var content = this.lookupReference('contentPanel');
		var contentCard = content.getLayout();
		/*if (selReference === 'treeNodeApp2') {
			contentCard.setActiveItem(1);
		}
		else if (selReference === 'treeNodeInstantSavingsMaint') {
			contentCard.setActiveItem(0);
		}*/
		
		if (selReference === 'treeNodeInstantSavingsMaint') {
			contentCard.setActiveItem(0);
		}
		/*else if (selReference === 'treeNodeApp2') {
			contentCard.setActiveItem(1);
		}*/
		
		/*
		if (selReference === 'treeNodeVendorInq') {
			contentCard.setActiveItem(1);
		}
		else if (selReference === 'treeNodeSkuPer') {
			contentCard.setActiveItem(0);
		}
		else if (selReference === 'treeNodeStrCst') {
			contentCard.setActiveItem(2);
		}*/
	},

	doLoadGear : function() {
		return this.gearMenu;
	},

	setHomeStoreDesc : function() {
		console.log("MainController setHomeStoreDesc");
		var vm = this.getViewModel();
		vm.set('homeStoreDesc', '');

		//Create local hidden store lookup 
		var homeStoreLookup = Ext.create('LookupApp.view.base.lookup', {
			xtype : 'lookup',
			maskRe : /[0-9]+/,
			maxLength : 5,
			enforceMaxLength : true,
			width : 160,
			fieldLabel : i18n.label.store,
			style : 'padding-right:20px;',
			allowBlank : true,
			width : 180,
			labelWidth : 70,
			margins : 3,
			value : vm.get('homeStore'),
			lookupconfig : {
				lookuptype : 'storelookup',
				idcolumn : 'storeno',
				maxselections : '1',
				disabledfields : [ {
					name : 'country'
				} ],
				defaultfields : [ {
					name : 'country',
					value : params.country
				}, {
					name : 'concept',
					value : params.concept
				} ]
			},
			listeners : {
				'postLookupValidate' : function(lookup, validList, inValidList) {
					var homeStoreDesc = vm.get('homeStoreDesc');
					if (lookup.value.indexOf(',') === -1 && validList.length > 0) {
						var storeName = lookup.getRecord(lookup.value.replace(/^(0+)/g, '')).get('name');
						homeStoreDesc = toProperCase(Ext.String.trim(storeName));
						lookup.setValue(parseInt(lookup.value.replace(/^(0+)/g, '')));
					}
					else {
						homeStoreDesc = '';
					}
					vm.set('homeStoreDesc', homeStoreDesc);
				},
				'preLookupLaunch' : function(lookup) {
					if (!Ext.isEmpty(lookup.value) && lookup.value.indexOf(',') === -1) {
						lookup.setValue('');
						return true;
					}
				}
			}
		});

		//Run lookup validation to load store description
		var homeStoreLookupValid = homeStoreLookup.isLookupValid();
	},

	createGearMenu : function() {
		var me = this;
		var view = me.getView();

		//Build country store
		var countryData = '';
		console.log("MainController 1 - 1 params.countrylist = "+params.countrylist);
		
		
		if (params.countrylist != null) {
			countryData = params.countrylist.split(",");
		}
		var countryStore = Ext.create('Ext.data.ArrayStore', {
			fields : [
				{
					name : 'country',
					type : 'string'
				}
			]
		});
		countryStore.loadData(countryData, false);

		//Build country / concept store
		console.log("MainController 1 - 2 params.countryConceptlist = "+params.countryConceptlist);
		var countryConceptData = '';
		if (params.countryConceptlist != null) {
			countryConceptData = params.countryConceptlist.split(",");
		}
		var countryConceptStore = Ext.create('Ext.data.ArrayStore', {
			fields : [
				{
					name : 'countryconcept',
					type : 'string'
				}
			]
		});
		countryConceptStore.loadData(countryConceptData, false);

		//Build language store
		console.log("MainController 1 - 3 params.langlist = "+params.langlist);
		var langData = '';
		if (params.langlist != null) {
			langData = params.langlist.split(",");
		}

		var langStore = Ext.create('Ext.data.ArrayStore', {
			fields : [
				{
					name : 'language',
					type : 'string'
				}
			]
		});
		langStore.loadData(langData, false);

		//Create empty menu
		me.gearMenu = Ext.create('Ext.menu.Menu',
			{
				width : 230,
				shadow : 'frame'
			});

		//Load language menu items
		var langItem = "";
		var i18nLang = "";
		Ext.each(langStore.data.items, function(item) {
			if (item.data && (typeof item.data === 'string' || item.data instanceof String) && item.data.trim().length > 0) {
				var langChecked = false;
				i18nLang = (item.data).toLowerCase();
				if (params.lang.toLowerCase() === i18nLang) {
					langChecked = true;
				}
				//App supports only english and spanish
				//for other langs, need app_lang_? file
				if (i18nLang == 'en' || i18nLang == 'es') {
					i18nLang = eval('i18n.text.' + (item.data).toLowerCase());
				}
				langItem = Ext.create('Ext.menu.CheckItem', {
					langid : item.data,
					iconCls : 'no_flag',
					text : i18nLang,
					checked : langChecked,
					group : 'langgroup',
					handler : function() {
						if (this.langid != params.lang) {
							document.location = me.buildSwitchLanguageUrl(this.langid);
						}
					}
				});
				me.gearMenu.add(langItem);
			}
		});
		me.gearMenu.add(Ext.create('Ext.menu.Separator', {}));

		//Load country / concept menu items
		var cntryflag = "";
		var cnytryItem = "";
		var i18nCntry = "";
		Ext.each(countryConceptStore.data.items, function(item) {
			if (item.data && (typeof item.data === 'string' || item.data instanceof String) && item.data.trim().length > 0) {
				var cntryChecked = false;
				var paramCntryConcept = params.country.toUpperCase() + '_' + params.concept.toUpperCase();
				if (paramCntryConcept === item.data.toUpperCase()) {
					cntryChecked = true;
				}
				cntryflag = "no_flag";
				if (item.data.indexOf('USA') != -1) {
					cntryflag = "flag_us";
				}
				else if (item.data.indexOf('CAN') != -1) {
					cntryflag = "flag_ca";
				}
				else if (item.data.indexOf('MEX') != -1) {
					cntryflag = "flag_mx";
				}
				i18nCntry = item.data;
				i18nCntry = eval('i18n.text.' + i18nCntry.toLowerCase());

				var cntryItem = Ext.create('Ext.menu.CheckItem', {
					cntryid : item.data,
					iconCls : cntryflag,
					checked : cntryChecked,
					checkHandler : function(item, checked) {
						return me.onItemCheck(item, checked);
					},
					text : i18nCntry,
					group : 'cntrygroup',
					handler : function() {
						//console.log("MainController js 1 CountryChangeWindow");
						var countryConceptCntry = this.cntryid.substring(0, this.cntryid.indexOf('_'));
						var countryConceptConcpt = this.cntryid.substring(this.cntryid.indexOf('_') + 1, this.cntryid.length);						
						var countryChangeMessage = '<font size="2"> <b>' + i18n.text.cntryChangeMsg + eval('i18n.text.' + this.cntryid.toLowerCase()) + ' ?' + '</b></font>';
						var cntryChangeWindow = Ext.create('SSM.view.main.CountryChangeWindow');
						cntryChangeWindow.getViewModel().set("countryChangeMessage", countryChangeMessage);
						cntryChangeWindow.changeCountry = countryConceptCntry;
						cntryChangeWindow.changeConcept = countryConceptConcpt;
						cntryChangeWindow.down('#countryChg').value = countryConceptCntry;
						cntryChangeWindow.down('#conceptChg').value = countryConceptConcpt;

						var countryStoreList = '';
						if (this.cntryid.indexOf('USA') != -1)
							countryStoreList = params.USA;
						else if (this.cntryid.indexOf('CAN') != -1)
							countryStoreList = params.CAN;
						else if (this.cntryid.indexOf('MEX') != -1)
							countryStoreList = params.MEX;
						countryStoreList = removeLastCharComma(countryStoreList);
						if (countryStoreList.charAt(0) === ',') {
							countryStoreList = countryStoreList.substr(1, countryStoreList.length);
						}
						
						/*
						//added for Instant Savings
						var data = {};
						data.changeCountry = countryConceptCntry;
						data.changeConcept = countryConceptConcpt;
						
						//if(instantSavingsRecords.length > 0){    	    	
						    	Ext.Msg.show({
					                title:'Change Concept / Country'
					               ,msg:'Do you want to Change Country and Concept?'
					               ,buttons:Ext.Msg.YESNO
					               ,callback:function(btn) {            	   
					                   if('yes' === btn) {                  	   
					                	   //this.saveInstantSavings(btn, true);
					                	   this.switchStoreCountryConcept('test', data);
					                	   //this.switchStoreCountryConcept : function(sender, changedData) {
					                   } else {
					                	   //return false;
					                	   //this.resetStoreCountryConcept('test', data);
					                	   
					                	   var paramCntryConcept = params.country.toUpperCase() + '_' + params.concept.toUpperCase();
					               		Ext.each(this.lookupReference('maingear').getMenu().items.items, function(item) {
					               			var itemGroup = false;
					               			if (item.group && (typeof item.group === 'string' || item.group instanceof String) && item.group === 'cntrygroup') {
					               				itemGroup = true;
					               			}
					               			var itemData = false;
					               			if (item.cntryid && (typeof item.cntryid === 'string' || item.cntryid instanceof String)) {
					               				itemData = item.cntryid;
					               			}
					               			if (itemGroup && itemData) {
					               				if (paramCntryConcept === itemData) {
					               					item.setChecked(true);
					               				} else {
					               					item.setChecked(false);
					               				}
					               			}
					               		});
					                	   
					                	   
					                   }
					               },
					               scope: this
					           });
						    scope: this
						//}
						    */
						
                       	var cntryStore = cntryChangeWindow.down('#cntryStore');
						cntryStore.lookupconfig.disabledfields = [ {
							name : 'country'
						} ];
						cntryStore.lookupconfig.defaultfields = [ {
							name : 'country',
							value : countryConceptCntry
						}, {
							name : 'concept',
							value : countryConceptConcpt
						} ];
						cntryStore.lookupconfig.validList = countryStoreList;						
						// don't show store poupup for Instant Savings Maintenance
						cntryChangeWindow.show();
						//RC//
						//cntryStore.focus(false, true);
					}
				});
				me.gearMenu.add(cntryItem);
			}
		});

		me.gearMenu.add(Ext.create('Ext.menu.Separator', {}));

		//Load about box menu item
		var aboutItem = Ext.create('Ext.menu.Item', {
			text : 'About',
			handler : function() {
				if (!view.aboutBox) {
					view.aboutBox = Ext.create('SSM.view.AboutWindow');
					var msg = view.aboutBox.down("#message");

					Ext.Ajax.request({
						//url : 'MANIFEST.MF',
						url: 'about.htm?action=getAboutBoxInfo', 
		                method : 'GET',		 
		                
		                callback: function (options, success, response) {
		                    if (success) {
		                    	
		                    	console.log("1 response.responseText @@@@@@@@@@@ = "+response.responseText);
		                    	//msg.setValue(response.responseText);
		                    	
		                    	var jsonData = Ext.JSON.decode(response.responseText);        
		                        var versionNumber = jsonData.results["Specification-Version"];
		                        var serverName = jsonData.results["Server-Name"];
		                        var serverIp = jsonData.results["Server-IP"];
		                        var serverPort = jsonData.results["Server-Port"];
		                        var buildDate = jsonData.results["Build-Timestamp"];
		                        var buildNumber = jsonData.results["Implementation-Build"];
		                        var htmlVal = '<div style="margin: 5px">' + 
		                        '<div style="text-align: center; font-weight: bold">'
		                        + i18n.title.AppName + 
		                        '</div></br>' + i18n.title.Version +': ' + versionNumber +        
		                        '<br></br>' + i18n.title.BuildDate +': '+ buildDate +
		                        '<br></br>' + i18n.title.BuildNumber +': '+  buildNumber +
		                        ' <br></br>' + i18n.title.Server + ': ' + serverName + ' - ' + serverIp + 
		                        ' <br></br>' + i18n.title.Port + ': ' + serverPort+ '<br></br>' + '</div>';
		                        
		                        msg.setValue(htmlVal);
		                        
		                        console.log("1 response.responseText @@@@@@@@@@@ htmlVal = "+htmlVal);
		                        //return htmlVal;
		                        //this.aboutBox.html = htmlVal;        
		                        //this.aboutBox.show();
		                        //this.aboutBox.center();ok
		                    	
		                        //var htmlVal = this.loadApplicationInfo(response);
		                        //console.log("1 - 1 response.responseText @@@@@@@@@@@ = "+htmlVal);
		                    }
		                },
		                scope: this
					});
					//scope: this,
					view.aboutBox.show();
					view.aboutBox.center();

				}
				else {
					view.aboutBox.show();
					view.aboutBox.center();
				}
			}
		});
		me.gearMenu.add(aboutItem);
	},
	
	loadApplicationInfo: function (response) {		
        var jsonData = Ext.JSON.decode(response.responseText);        
        var versionNumber = jsonData.results["Specification-Version"];
        var serverName = jsonData.results["Server-Name"];
        var serverIp = jsonData.results["Server-IP"];
        var serverPort = jsonData.results["Server-Port"];
        var buildDate = jsonData.results["Build-Timestamp"];
        var buildNumber = jsonData.results["Implementation-Build"];
        var htmlVal = '<div style="margin: 5px">' + 
        '<div style="text-align: center; font-weight: bold">'
        + i18n.title.AppName + 
        '</div></br>' + i18n.title.Version +': ' + versionNumber +        
        '<br></br>' + i18n.title.BuildDate +': '+ buildDate +
        '<br></br>' + i18n.title.BuildNumber +': '+  buildNumber +
        ' <br></br>' + i18n.title.Server + ': ' + serverName + ' - ' + serverIp + 
        ' <br></br>' + i18n.title.Port + ': ' + serverPort+ '<br></br>' + '</div>';
        
        return htmlVal;
        //this.aboutBox.html = htmlVal;        
        //this.aboutBox.show();
        //this.aboutBox.center();
    },
    
	switchStoreCountryConcept : function(sender, changedData) {
		//console.log("MainController switchStoreCountryConcept ####1 changedData = "+changedData);
		//console.log("MainController switchStoreCountryConcept ####1 country = "+changedData.changeCountry +" concept = "+changedData.changeConcept);
		console.log("MainController switchStoreCountryConcept ####1 changeStore = "+changedData.changeStore);
		var changeCountry = changedData.changeCountry;
		var changeConcept = changedData.changeConcept;
		var changeStore = '' + changedData.changeStore;
		
		//RC:: passing dummy store for Instant Savings
		//var changeStore = '' + 1;
		var reg = /^\d+$/;
		if (reg.test(changeStore)) {
			changeStore = parseInt(changeStore, 10);
			document.location = this.buildSwitchCountryUrl(changeCountry, changeConcept, changeStore);
		}
	},
	
	switchStoreCountryConcept_old : function(sender, changedData) {
		console.log("MainController switchStoreCountryConcept ####1 changedData = "+changedData);
		console.log("MainController switchStoreCountryConcept ####1 country = "+changedData.changeCountry +" concept = "+changedData.changeConcept);
		console.log("MainController switchStoreCountryConcept ####1 changeStore = "+changedData.changeStore);
		var changeCountry = changedData.changeCountry;
		var changeConcept = changedData.changeConcept;
		var changeStore = '' + changedData.changeStore;
		
		var reg = /^\d+$/;
		if (reg.test(changeStore)) {
			changeStore = parseInt(changeStore, 10);
			document.location = this.buildSwitchCountryUrl(changeCountry, changeConcept, changeStore);
		}
	},

	buildSwitchLanguageUrl : function(newLangId) {
		return this.buildNewUrl(null, "switchLanguage", newLangId);
	},

	buildSwitchCountryUrl : function(changeCountry, changeConcept, changeStore) {
		//console.log("buildSwitchCountryUrl ####################### 1 - 1 changeStore = "+changeStore);
		var conceptShortname = "";
		if (changeConcept == "BABY") {
			conceptShortname = "BU" ;
		}
		else if (changeConcept == "BEDBATH") {
			conceptShortname = "BB" ;
		}
		else if (changeConcept == "HARMON") {
			conceptShortname = "HN";
		}
		else if (changeConcept == "CTS") {
			conceptShortname = "CT";
		}
		return this.buildNewUrl(null, null, null, changeCountry, changeConcept, conceptShortname, changeStore, null, changeStore, null);
	},

	buildNewUrl : function(parmPath, parmAction, parmLang, parmCountry, parmConcept, parmConceptShortName, parmStrnum, parmUserid, parmPstore, parmFullname) {
		/*
		console.log("buildNewUrl ####################### 1 - 1 parmCountry = "+parmCountry +" parmConcept = "+parmConcept +" parmConceptShortName = "+parmConceptShortName);
		console.log("buildNewUrl ####################### 1 - 2  parmPath = "+parmPath);
		console.log("buildNewUrl ####################### 1 - 3  parmAction = "+parmAction +" params.lang = "+params.lang);
		console.log("buildNewUrl ####################### 1 - 4  document.location = "+document.location);
		console.log("buildNewUrl ####################### 1 - 4 - 1  contextPath = "+contextPath);
		console.log("buildNewUrl ####################### 1 - 4 - 2  parmPstore = "+parmPstore);
		*/
		
		//////////////////////////////
		//document.location = "index.htm?" + "action=test&lang=" + params.lang + "&locale=" + params.lang +
		//"&country="+params.country+"&concept="+params.concept +"&countryconcept="+params.countryconcept  +
		//createParamsUrl();		
		//contextPath = http://localhost:8080/SSM/
		
		document.location = "index.htm?" + "action=test";
		console.log("buildNewUrl ####################### 1 - 4 - 2  document.location = "+document.location);		
		////var newPath = "index.html?";
		//var newPath = document.location;
		var newPath = contextPath + "index.htm?" + "action=test";
		
		if (parmPath != null && parmPath.trim().length > 0) {
			newPath = parmPath.trim();
		}
		console.log("buildNewUrl ####################### 1 - 5  newPath = "+newPath);

		var queryString = '';
		if (parmAction != null && parmAction.trim().length > 0) {
			queryString += "action=" + parmAction.trim();
		}
		if (parmLang != null && parmLang.trim().length > 0) {
			queryString += "&lang=" + parmLang.trim();
		}
		else {
			queryString += "&lang=" + params.lang;
		}
		if (parmCountry != null && parmCountry.trim().length > 0) {
			queryString += "&country=" + parmCountry.trim();
		}
		else {
			queryString += "&country=" + params.country;
		}
		if (parmConcept != null && parmConcept.trim().length > 0) {
			queryString += "&concept=" + parmConcept.trim();
		}
		else {
			queryString += "&concept=" + params.concept;
		}
		if (parmConceptShortName != null && parmConceptShortName.trim().length > 0) {
			queryString += "&conceptShortName=" + parmConceptShortName.trim();
		}
		else {
			queryString += "&conceptShortName=" + params.conceptShortName;
		}
		if (parmStrnum != null && parmStrnum > 0) {
			queryString += "&strnum=" + parmStrnum;
		}
		else {
			queryString += "&strnum=" + params.strnum;
		}
		if (parmUserid != null && parmUserid > 0) {
			queryString += "&userid=" + parmUserid.trim();
			queryString += "&jdausername=" + parmUserid.trim();
		}
		else {
			queryString += "&userid=" + params.userid;
			queryString += "&jdausername=" + params.userid;
		}
		// Store is not requited for Instant Savings
		//if (parmPstore != null && parmPstore > 0) {
		//	queryString += "&pstore=" + parmPstore;
		//}
		//else {
		//	queryString += "&pstore=" + params.pstore;
		//}
		if (parmFullname != null && parmFullname > 0) {
			queryString += "&fullname=" + parmFullname.trim();
		}
		else {
			queryString += "&fullname=" + params.fullname;
		}
		
		console.log("buildNewUrl ####################### 1 - 6  queryString = "+queryString);
		console.log("buildNewUrl ####################### 1 - 7  params.devaction = "+params.devaction);
		
		var encodeParams = true;
		
		//RC:::
		//below is for Sku Inquiry
		/*
		if (params.devaction && params.devaction.trim().length > 0) {
			queryString += "&devaction=" + params.devaction;
			if (params.devaction === "test") {
				encodeParams = false;
			}
		}*/
		
		//RC:::
		if (encodeParams) {
			/////queryString = Base64.encode(queryString)
		}
		console.log("buildNewUrl ####################### 1 - 8  queryString = "+queryString);

		return newPath + queryString;
	},

	onItemCheck : function(item, checked) {
	},

	resetStoreCountryConcept : function(sender, data) {
		var paramCntryConcept = params.country.toUpperCase() + '_' + params.concept.toUpperCase();
		Ext.each(this.lookupReference('maingear').getMenu().items.items, function(item) {
			var itemGroup = false;
			if (item.group && (typeof item.group === 'string' || item.group instanceof String) && item.group === 'cntrygroup') {
				itemGroup = true;
			}
			var itemData = false;
			if (item.cntryid && (typeof item.cntryid === 'string' || item.cntryid instanceof String)) {
				itemData = item.cntryid;
			}
			if (itemGroup && itemData) {
				if (paramCntryConcept === itemData) {
					item.setChecked(true);
				} else {
					item.setChecked(false);
				}
			}
		});
	}
	
});