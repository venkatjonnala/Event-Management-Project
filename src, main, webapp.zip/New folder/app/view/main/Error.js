Ext.define('SSM.view.main.Error', {
	extend : 'Ext.container.Container',
	alias : 'widget.errorPanel',

	requires : [
		'SSM.view.main.MainViewModel',
		'SSM.view.main.MainController',
		'SSM.view.main.ThemingHelper',
		'Ext.panel.Panel'
	],

	//controller : 'mainController',
	viewModel : {
		type : 'mainViewModel'
	},
	itemId : 'errorPanel',
	collapsible : false,
	layout : {
		type : 'vbox',
		pack : 'start',
		align : 'stretch'
	},
	items : [
		{
			height : 42,
			title : '<center><table cellpadding="0" cellspacing="0"><tr><td><img src="resources/images/logo_bbb_white.png" style="width:253px;height:22px;"/></td><td class="skuinquirytitle">&nbsp;&nbsp;SKU Inquiry</tr></table></center>',
			titleAlign : 'bottom'
		},
		{
			xtype : 'panel',
			layout : {
				type : 'hbox',
				pack : 'center',
				align : 'center'
			},
			flex : 1,
			items : {
				xtype : 'label',
				cls : 'error_message_label',
				bind : {
					html : '{skuInquiryErrorMessage}'
				}
			}
		},
		{
			flex : 1
		},
		{
			flex : 1
		}
	]
});