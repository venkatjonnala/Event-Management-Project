Ext.define('SSM.view.main.Main', {
    extend: 'Ext.container.Container',
    alias: 'widget.mainPanel',

    requires: [
        'Ext.plugin.Viewport',
        'SSM.view.main.MainViewModel',
        'SSM.view.main.MainController',
        
        'SSM.view.instantsavingsmaint.InstantSavingsMaint',
        //'SSM.view.app2.App2',
        //'SSM.view.storecostretail.StoreCostRetail',
        
        'SSM.view.main.ThemingHelper',
        'SSM.view.main.CountryChangeController',
        'SSM.view.main.CountryChangeWindow',

        'LookupApp.view.base.lookup',
        'LookupApp.common.ConceptStore',
        
        'SSM.model.lookup.Vendor',
		'SSM.store.lookup.Vendor',
		'SSM.model.lookup.MerchAnalyzer',
		'SSM.store.lookup.MerchAnalyzer',
		
		'SSM.model.AjaxWithPayload',
		'SSM.store.lookup.SKUDesc',
		'SSM.model.lookup.SKUDesc',

        'Ext.panel.Panel',
        'Ext.menu.Menu'
    ],

    controller: 'mainController',
    viewModel: {
        type: 'mainViewModel'
    },
    itemId: 'mainPanel',
    layout: 'border',
    collapsible: false,
    listeners: {
    	afterrender: 'onAfterRender'
    },
    items: [{
        xtype: 'panel',
        region: 'north',
        padding: 0,
        margin: 0,
        height: 42,
        title: '<table cellpadding="0" cellspacing="0"><tr><td><img src="' + skuInqGetApplicationLogo() + '" style="height:22px;"/></td><td class="skuinquirytitle">&nbsp;&nbsp;' + i18n.title.AppName + '</tr></table>',
        titleAlign: 'bottom',
        
        tools: [{
            glyph: 'xf0c9@FontAwesome',
            handler: 'onToggleMicro'
        }, {
            type: 'gear',
            reference: 'maingear',
            getMenu: function () {
            	console.log("Main.js getMenu 1");
                return this.up('mainPanel').getController().doLoadGear()
            },
            handler: function (e, el, owner, tool) {
            	console.log("Main.js handler 2");
                this.getMenu(owner).showBy(owner, 'tr-br?');
            }
        }],
        
        header: {
            titlePosition: 1,
            itemPosition: 2,
            items: [{
                xtype: 'container',
                style: {
                    color: '#f0f0f0;', 'font-size': '13px;',
                    font: 'Open Sans;', 'font-weight': '300;'
                },
                bind: {
                    html: '{userFullName}'
                }
            }, {
                xtype: 'splitter'
            }, {
                xtype: 'splitter'
            }, {
                xtype: 'button',
                hidden: true,
                bind: {
                    text: '{homeStore_homeStoreDesc}'
                }
            }]
        }
        
       
    },
    
    {
        xtype: 'container',
        region: 'north',
        style: 'background:#728CB0',
        height: 5
    }, 
    
    {
        xtype: 'panel',
        items: {
            xtype: 'treelist',
            reference: 'treelist',
            expanderFirst: false,
            cls: 'omni-treelist-item',
            style: 'background:#F5F8FB;font-family: Lucida Sans Unicode;height:30px',
            bind: '{navItems}',
            listeners: {
                itemClick: 'doAppNavigation',
                selectionchange: function () {}
            }
        },
        
        region: 'west',
        split: false,
        style: {
            'background': '#F5F8FB;'
        },
        reference: 'treelistContainer',
        itemId: 'navigationPanel',
        scrollable: false,
        width: 170,
        collapsible: false,
        titleCollapse: false,
        layout: {
            type: 'fit',
            align: 'stretch'
        }
    }, {
        xtype: 'panel',
        region: 'center',
        style: {
            'background': '#FFFFFF;',
            'padding-left': '3px'
        },
        itemId: 'contentPanel',
        layout: 'card',
        reference: 'contentPanel',
        items: [/*{
                xtype: 'skuPerformance'
            }, {
                xtype: 'vendorInq'
            }
			,*/
            {
            	xtype : 'instantsavingsmaint'
			}
            /*,
			{
				xtype : 'app2'
			},*/
			
			
        ]
    }]
});
