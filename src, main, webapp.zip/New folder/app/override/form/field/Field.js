Ext.define('SSM.override.form.field.Field', {
  override: 'Ext.form.field.Field',

  onDisable: function() {
    this.container.parent().addCls(this.disabledCls);
    this.callParent();
  },

  onEnable: function() {
    this.container.parent().removeCls(this.disabledCls);
    this.callParent();
  }

});