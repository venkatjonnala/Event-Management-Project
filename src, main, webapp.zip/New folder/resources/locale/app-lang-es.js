if(params.lang === "es"){
	var i18n = {};
	i18n ['label'] = {
		English					: "English",
		Spanish					: "Spanish",    	
		sku						: "SKU",
		store					: "Store",
		vendor					: "Vendor",
    	dept					: "Dept",
    	subdept					: "Sub Dept",
    	clas					: "Class",
    	status                  : "Status",
    	
    	selectedcriteria		: "Filter on only SKUs previously marked as eligible",
    	startWith				: '<b>S</b>',
        contains				: '<b>C</b>',
    	searchform              : "<b>Search Form</b>",   	
    	
    	treeInstantSavingsMaint : "Instant Savings Maintenance",
    	treeApp2                : "App 2",
    	vendorno				: "Vendor #",
    	vendorname				: "Vendor Name",
    	merchanalyz				: "Merch Analyzer",
    	eventnumber				: "Event Number",    	
    	skuupcdesc				: "SKU/UPC Desc",
    	skustatus				: "SKU Status",    	
    	upc						: "UPC",    	
    	welcome					: "Welcome",
    	countryconceptchage 	: 'Country / Concept',
    };

	i18n ['text'] = {
		save					: "Save",
	    savedsearches			: "Saved Searches",
	    search					: "Search",
    	clear					: "Clear",
    	close					: "Close",
    	reset					: "Reset",
    	next					: "Next",
        close                   : 'Close',  
     	usa_bedbath             : "USA/Bedbath",
     	usa_baby                : "USA/Baby",
     	usa_cts                 : "USA/CTS",
     	usa_harmon				: "USA/Harmon",
     	can_bedbath             : "Canada/Bedbath",
     	can_baby                : "Canada/Baby",
     	mex_bedbath             : "Mexico/Bedbath",
     	mex_baby                : "Mexico/Baby",     	
     	emailAddresses          : "Email Addresses",
    	NoResults               : "No results to display",
    	additionalAddresses     : "Additional Addresses",
    	expandAll               : "Expand All",
    	collapseAll             : "Collapse All",
    	NoResults               : "No results to display",
    	en						: "English",
    	es						: "Spanish",
    	instantavingsbygroup	: "<b>Instant Savings By Group</b>",
    	instantsavingsbysku		: "<b>Instant Savings By SKU</b>",
    	grouppopup              : "Instant Savings Group",
    	cntryChangeMsg          : 'Do you want to change Country and Concept to ',
    	cntryChangeDummyStore   : '990',
    	ok                   	: 'Aceptar', 
    };

	i18n ['title'] = {
        AppName                 : "Sign Systems Maintenance",
        startWith				: 'Starts with Search',
        contains				: 'Contains Search',  
        Help					: "Help",
        Version					: "Version",
        BuildNumber				: "Build Number",
        BuildDate				: "Build Date",
        Server					: "Server",
        About                   : "About",
    };

	i18n ['header'] = {
		vendorno				: "Vendor #",
		vendor					: "Vendor",
		dept					: "Dept",
		subdept					: "Sub Dept",
		clas					: "Class",
		sku						: "SKU",
		skuupcdesc				: "SKU/UPC Desc",
		status                  : "Status",
		merchanalyz				: "Merch Analyzer",
		eventname               : "Event",
		
		upc                     : 'UPC',
		vendor                  : 'Vendor',  
		upcType                 : 'Type',
		isid                    : 'isid',		
    };

	i18n ['tooltip'] = {
    	periodSales				: "Sales by WK/PD",    	
   };

	i18n ['message'] = {
		noResultsFound          : "No Results found.",
		unknownError			: "Unknown Error",
		appInitializing			: "Initializing",
		appLoading				: "Loading",
		serverSideFail			: "Server side failure with status code",
		errorNoUser				: "User does not exist",
		pleasewait				: "Please wait..",
		
		refinesearch			: "Please refine your search criteria.",
		formerrors			    : "Please correct the fields highlighted in red.",
		successmessage			: "Instant Savings has been saved successfully.",
		failuremessage			: "Some or All Instant Savings was not successfully process, please re-transmit.",
		groupsuccessmessage		: "Instant Savings Group has been saved successfully.",
		groupfailuremessage		: "Some or All Instant Savings Group was not successfully process, please re-transmit.",
		makechangestoupdate     : 'Please make changes to update.',
		groupskumessage         : 'Instant Savings Groups for SKU: '	
   };
}
