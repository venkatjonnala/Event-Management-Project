//-------------------------------------------------------------
//Dynamic Locale				   
//-------------------------------------------------------------
var i18n = {};

var _lang = "en";

//console.log("i18n.js 1 params.lang = "+params.lang);

if(params.lang) {
    _lang = params.lang;
}
params.lang = _lang;

//console.log("i18n.js 2 _lang = "+_lang);

// include the locale file based on lang parameter
document.write('<script type="text/javascript" src="resources/locale/app-lang-' + _lang + '.js"></script>');
