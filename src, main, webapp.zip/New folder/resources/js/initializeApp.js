//------------------------------------------------------------------------
//  sku inquiry config parameters
//------------------------------------------------------------------------
var config = {
	skuInquiryPath : {
		local : '/index.html',
		deployed : '/SkuInquiry/index.html'
	},
	skuInquiryServiceHost : {
	},
	skuInquiryServicePort : {
		local : 8080,
	},
	skuSecurityPath : {
		local : '/SkuInquiryServices/securityCheck/SKUINQ',
		deployed : '/SkuInquiryServices/securityCheck/SKUINQ'
	},
	skuServicePath : {
		local : '/SkuInquiryServices/',
		deployed : '/SkuInquiryServices/',
	},
	pagesize : 25
};


//-----------------------------------------------------------------------
//Function to parse URL 
//-----------------------------------------------------------------------
function parseURL(url) {
	var parser = document.createElement('a'),
		searchObject = {},
		queries,
		split,
		i;
	// Let the browser do the work
	parser.href = url;
	// Convert query string to object
	queries = parser.search.replace(/^\?/, '').split('&');
	for (i = 0; i < queries.length; i++) {
		split = queries[i].split('=');
		searchObject[split[0]] = split[1];
	}
	return {
		protocol : parser.protocol,
		host : parser.host,
		hostname : parser.hostname,
		port : parser.port,
		pathname : parser.pathname,
		search : parser.search,
		searchObject : searchObject,
		hash : parser.hash
	};
}

//------------------------------------------------------------------------
// SKU Service integration URL
//------------------------------------------------------------------------
//Parse existing document url
var urlToParse = document.URL;
var urlParts = parseURL(urlToParse);

//Try to determine what environment we are in
var currentEnv = null;
switch (urlParts.hostname) {
case 'localhost':
	currentEnv = 'local';
	break;
default:
	currentEnv = 'deployed';
}


//Get path of sku inquiry app (we will need to replace this with the sku inquiry services path)
//Get sku inquiry service path and port to use
var skuInquiryPath;
var skuSecurityPath;
var skuServicePath;
var skuInquiryServiceHost = null;
var skuInquiryServicePort = false;
switch (currentEnv) {
case 'local':
	skuInquiryPath = config.skuInquiryPath.local;
	skuSecurityPath = config.skuSecurityPath.local;
	skuServicePath = config.skuServicePath.local;
	if (config.skuInquiryServicePort.local > 0) {
		skuInquiryServicePort = config.skuInquiryServicePort.local;
	}
	break;
default:
	skuInquiryPath = config.skuInquiryPath.deployed;
	skuSecurityPath = config.skuSecurityPath.deployed;
	skuServicePath = config.skuServicePath.deployed;
	if (urlParts.port) {
		skuInquiryServicePort = urlParts.port;
	}
}
if (!skuInquiryServiceHost) {
	skuInquiryServiceHost = urlParts.hostname;
}

//Load the port we will use for Sku Inquiry Services
if (skuInquiryServicePort) {
	skuInquiryServicePort = ':' + skuInquiryServicePort;
} else {
	skuInquiryServicePort = '';
}

var encodeParameters = true;
if ((urlParts.searchObject.devaction != null && urlParts.searchObject.devaction == 'test') ||
		urlParts.searchObject.action != null && urlParts.searchObject.action == 'test') {
	encodeParameters = false;
}

//If the current url has the path specified for the Sku Inquiry App then create the sku inquiry
//service path by just swapping it in
if (urlParts.pathname.indexOf(skuInquiryPath) >= 0) {
	skuSecurityPath = urlParts.pathname.replace(skuInquiryPath,skuSecurityPath);
}

//Create the final Sku inquiry services url with the host and query parameters Sku Inquiry was called with
//but using the port and path of Sku Inquiry Services
var skuServiceUrl = urlParts.protocol + '//' + skuInquiryServiceHost + skuInquiryServicePort + skuServicePath;
var skuSecurityUrl = urlParts.protocol + '//' + skuInquiryServiceHost + skuInquiryServicePort + skuSecurityPath + urlParts.search;

//------------------------------------------------------------------------
//Security service integration call
//------------------------------------------------------------------------
var params = {};

(function() {
	var httpRequest;

	var reqParam = [];
	reqParam.push(
		"&timestamp=", Date.now()
	);
	var reqParams = reqParam.join("");
	if (encodeParameters) {
		reqParams = Base64.encode(reqParams);
	}
	
	function sendInitRequest() {
		httpRequest = new XMLHttpRequest();
		if (!httpRequest) {
			alert('ERROR :( Cannot create an XMLHTTP instance');
			return false;
		}
		httpRequest.onreadystatechange = processParams;
		httpRequest.open('GET', skuSecurityUrl + reqParams, false);
		httpRequest.send();
	}

	function processParams() {
		if (httpRequest.readyState === XMLHttpRequest.DONE) {
			params.secCheckHttpStatus = httpRequest.status;
			if (httpRequest.status === 200) {
				var ourResponseText = httpRequest.responseText;
				params = JSON.parse(ourResponseText);
				params.securityJson = JSON.parse(ourResponseText);
			}
			else {
				params.secCheckResult = 0;
				params.lang = 'en';
				params.error = 'There was a problem with the XHR request.  [HTTP status code ' + httpRequest.status + '].';
				//alert('There was a problem with the XHR request.');
			}
		}
		if ('USA' === params.country) {
			params['storeList'] = params.USA;
		}
		else if ('CAN' === params.country) {
			params['storeList'] = params.CAN;
		}
		else if ('MEX' === params.country) {
			params['storeList'] = params.MEX;
		}

		locale = params.lang;
		params['skuServiceUrl'] = skuServiceUrl;
	}

	//invoke request
	sendInitRequest();

})();

//------------------------------------------------------------------------
// Base Lookup integration URL
//------------------------------------------------------------------------
console.log("initilizeApp.js !!!!!!!!!!!!!!!!!!! params.vipUrl = "+params.vipUrl);
var base_lookup_url = params.vipUrl + 'elasticsearch/lookups5/';
console.log("initilizeApp.js !!!!!!!!!!!!!!!!!!! base_lookup_url = "+base_lookup_url);

//params.base_lookup_url = base_lookup_url;
//var lookupglobalvars = {};
//lookupglobalvars.lookuplang = params['lang'];