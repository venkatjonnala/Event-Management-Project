function formatDate(date)
{
	var curr_date = date.getDate();
	var curr_month = date.getMonth();
	var curr_year = date.getFullYear();
	var curr_hour = date.getHours();
	var a_p = "";

	if (curr_hour < 12)
	{
	   a_p = "AM";
	}
	else
	{
	   a_p = "PM";
	}
	if (curr_hour == 0)
	{
	   curr_hour = 12;
	}
	if (curr_hour > 12)
	{
	   curr_hour = curr_hour - 12;
	}
	var curr_min = date.getMinutes();
	curr_min = curr_min + "";

	if (curr_min.length == 1)
	{
	   curr_min = "0" + curr_min;
	}
	curr_month = curr_month + 1;
	curr_month = curr_month + "";
	if (curr_month.length == 1)
	{
		curr_month = "0" + curr_month;
	}
	curr_date = curr_date + "";
	if (curr_date.length == 1)
	{
		curr_date = "0" + curr_date;
	}
	var dateformat = "";
	if(params.country=='MEX')
	{
		dateformat = curr_date + "/" + curr_month + "/" + curr_year + " " +
		 curr_hour + ":" + curr_min + " " + a_p;
	}
	else
	{
		dateformat = curr_month + "/" + curr_date + "/" + curr_year + " " +
		 curr_hour + ":" + curr_min + " " + a_p;
	}

	return dateformat;
}

/*
 * escape regular expression special characters
 */
function escapeRegExp(str) {
	  return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}
/*
 * replace all occurences of a string
 */
function replaceAll(find, replaceWith, str) {
	  return str.replace(new RegExp(find, 'g'), replaceWith);
}

/*
 * convert date MM/DD/YYYY format to DD/MM/YYYY
 */
function dateStrDMY(dateStr)
{
	var dmy = dateStr.split("/");
	return dmy[1] + "/" + dmy[0] + "/" + dmy[2];
}

/*
 * convert date yyyy-mm-dd format to DD/MM/YYYY
 */
function dateDMY(dateStr)
{
	var ymd = dateStr.split("-");
	return ymd[2] + "/" + ymd[1] + "/" + ymd[0];
}

/*
 * convert date yyyy-mm-dd format to MM/DD/YYYY
 */
function dateMDY(dateStr)
{
	var ymd = dateStr.split("-");
	return ymd[1] + "/" + ymd[2] + "/" + ymd[0];
}
function skuInqGetApplicationLogo()
{
	var logoPath = "resources/images/";
	var applogo = "logo_bbb_white.png";
	//bedbath new logo
	if(params.conceptShortName == 'BB')
	{
		applogo = "logo_bbb_white.png";
	}
	//baby
	else if(params.conceptShortName == 'BU')
	{
		applogo = "logo_buybuybaby_white.png";
	}
	//harmon
	else if(params.conceptShortName == 'HN')
	{
		applogo = "logo_harmon_white.png";
	}
	//cts
	else if(params.conceptShortName == 'CT')
	{
		applogo = "logo_cts_white.png";
	}

	return logoPath + applogo;
}

function getMonday() {
  var d = new Date();
  var day = d.getDay();
  var monday = d;
  //if(day != 1){ //day 1 means its already monday
	  var diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
	  monday = new Date(d.setDate(diff));
	//Calculate the difference in milliseconds
	  var difference_ms = monday.getTime() - d.getTime();
	  if(difference_ms <= 0){
		  monday = Ext.Date.add(monday, Ext.Date.DAY, 7);
	  }
  //}
  return monday;
}

function toProperCase(str)
{
	var strArray = str.split(' ');
	var properCaseStr = '';
	for (i = 0; i < strArray.length; i++)
	{
		properCaseStr = properCaseStr + strArray[i].substr(0,1).toUpperCase() +
						strArray[i].substr(1).toLowerCase() + ' ';
	}
	return properCaseStr;
}

function getLabelWidth(text)
{
	tm = new Ext.util.TextMetrics(),
    n = tm.getWidth(text + ":");
	tm.destroy();
	return n;
}

function rightPad(string, size, character) {
    var result = String(string);
    character = character || " ";
    if (result.length > size) {
    	return result.substring(0, size -1);
    }
    while (result.length < size) {
        result = result+character;
    }
    return result;
}


function leftPad(string, size, character) {
    var result;
    if (string == null){
    	result='';
    } else {
    	result = String(string);
    }
    character = character || " ";
    if (result.length > size) {
    	return result.substring(0, size -1);
    }
    while (result.length < size) {
        result = character+result;
    }
    return result;
}

function getClientTimezone()
{
	var clientDate = new Date();
	return Ext.Date.getGMTOffset(clientDate, true);
}


function removeLastCharComma(strVal){
	strVal = Ext.String.trim(strVal);
	if(strVal.lastIndexOf(",") == strVal.length-1){
    	//Remove last char comma
		strVal = strVal.substr(0, strVal.lastIndexOf(","));        		        		
	}
	return strVal;
} 



function removeLastComma(fld){
	
	strVal = Ext.String.trim(fld.getValue());
	if(strVal.lastIndexOf(",") == strVal.length-1){
    	//Remove last char comma
		strVal = strVal.substr(0, strVal.lastIndexOf(","));        		        		
	}
	fld.setValue(strVal);
	return fld;
} 


function chunkString (input, len) {
	var curr = len;
	var prev = 0;

	output = [];

	while (input[curr]) {
	    if (input[curr++] == ' ') {
	        output.push(input.substring(prev,curr));
	        prev = curr;
	        curr += len;
	    }
	}
	output.push(input.substr(prev));
	
	var i = 0;
	var str = "";
	for (var i=0; i < output.length; i++) { 
		str += output[i] + '<br/>';
	}
				
	return str;
}


function escapeUrlParam(unsafe) {
    return unsafe.replace(/[&]/g, function (c) {
        switch (c) {
            case '&': return '%26';
        }
    });
}

function arrayContains(a, obj) {
    var i = a.length;
    if(obj!=null){
    	obj = "" + obj;
    }
    while (i--) {
       if (a[i] === obj) {
           return true;
       }
    }
    return false;
}
